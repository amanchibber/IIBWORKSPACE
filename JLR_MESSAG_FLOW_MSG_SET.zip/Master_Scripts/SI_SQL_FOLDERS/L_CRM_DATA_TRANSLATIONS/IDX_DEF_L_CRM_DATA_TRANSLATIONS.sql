--------------------------------------------------------------------------------------------------------
-- Author 		: Kenny McCormack
-- Version 		: $Revision: 1.1 $
-- Description 	: Create index script for L_CRM_DATA_TRANSLATIONS table
-- History 		: 30/04/2014 Kenny McCormack Initial creation
--------------------------------------------------------------------------------------------------------

create index IDX_L_CRM_DATA_TRANSLATIONS_01 on WMBOWNER.L_CRM_DATA_TRANSLATIONS("LOV_TYPE","APPLICATION_ID","APPLICATION_VALUE","LANGUAGE_CODE");
create index IDX_L_CRM_DATA_TRANSLATIONS_02 on WMBOWNER.L_CRM_DATA_TRANSLATIONS("LOV_TYPE","APPLICATION_ID","JLRCDM_VALUE","LANGUAGE_CODE");