--------------------------------------------------------------------------------------------------------
-- 	Author 			: Prasad Panchagnula
-- 	Version 		: $Revision: 1.1 $
--	Description 	: Create trigger definition script for SI_BATCH_CUSTOM_OPTIONS table
-- 	History 		: 20/04/16 		Prasad 			Initial creation statement
--------------------------------------------------------------------------------------------------------

DROP TRIGGER WMBOWNER.SI_BATCH_CUSTOM_OPTIONS_TRG;

CREATE OR REPLACE
TRIGGER WMBOWNER.SI_BATCH_CUSTOM_OPTIONS_TRG
BEFORE INSERT OR UPDATE ON WMBOWNER.SI_BATCH_CUSTOM_OPTIONS
FOR EACH ROW
BEGIN

IF INSERTING THEN
	:new.INSERT_TIMESTAMP := systimestamp;
	:new.UPDATE_TIMESTAMP := NULL;
ELSE
	:new.UPDATE_TIMESTAMP := systimestamp;
  END IF;
END;
/
COMMIT;
