--------------------------------------------------------------------------------------------------------
-- Author 		: Prasad Panchagnula
-- Version 		: $Revision: 1.2 $
-- Description 	: Index definitions on table SI_BATCH_MESSAGE
-- History 		: 26/02/2015 Prasad Panchagnula Created index IDX_SI_BATCH_MESSAGE
				  26/02/2015 Prasad Panchagnula Increased INITIAL and NEXT extent values to 10MB
--				
--------------------------------------------------------------------------------------------------------


DROP INDEX "WMBOWNER"."IDX_SI_BATCH_MESSAGE";
CREATE INDEX "WMBOWNER"."IDX_SI_BATCH_MESSAGE" ON "WMBOWNER"."SI_BATCH_MESSAGE" ("BUSINESS_SERVICE_ID", "SYSTEM_IDENTIFIER", "DESTINATION_SYSTEM", "IS_PROCESSED") 
  PCTFREE 10 INITRANS 2
  STORAGE(INITIAL 10485760 NEXT 10485760 MINEXTENTS 1 MAXEXTENTS UNLIMITED
  BUFFER_POOL DEFAULT)
  TABLESPACE "WMBDATA" ;