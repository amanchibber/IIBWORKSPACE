--------------------------------------------------------------------------------------------------------
-- Author 		: Mike Arrowsmith
-- Version 		: $Revision: 1.1 $
-- Description 	: Create sequence script for table SI_BATCH_MESSAGE table
-- History 		: 06/03/2013 Initial create statement for sequence
--------------------------------------------------------------------------------------------------------

DROP SEQUENCE SI_BATCH_MESSAGE_SEQ;
		
--Sequence to generate the ID value for SI_BUSINESS_SERVICE_DETAILS table
CREATE SEQUENCE SI_BATCH_MESSAGE_SEQ
CYCLE
ORDER
MINVALUE 1
MAXVALUE 99
START WITH 1
INCREMENT BY 1
CACHE 50;							 

COMMIT;

