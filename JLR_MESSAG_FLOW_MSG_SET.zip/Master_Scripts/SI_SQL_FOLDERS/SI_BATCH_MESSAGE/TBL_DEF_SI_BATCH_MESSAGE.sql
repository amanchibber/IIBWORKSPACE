--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: $Revision: 1.4 $
-- Description 	: Create table script for SI_BATCH_MESSAGE table which will hold batch records
-- History 		: 29/12/2011 Hina Mistry Initial create statement for table
--				: 02/11/2012 Mike Arrowsmith Updated META_DATA columns to 50 to allow for attributes
--				: 01/03/2013 Hina Mistry Added alter statements for the changes Mike has made above
-- 										 Changed the Meta data columns back to 20 in the original create
--------------------------------------------------------------------------------------------------------

DROP TABLE SI_BATCH_MESSAGE;

CREATE TABLE SI_BATCH_MESSAGE (SYSTEM_IDENTIFIER VARCHAR2(20) NOT NULL, 
							   DESTINATION_SYSTEM VARCHAR2(20) NOT NULL, 
							   BATCH_PAYLOAD BLOB, 
							   BUSINESS_SERVICE_ID VARCHAR2(40), 
							   BS_INPUT_DESTINATION VARCHAR2(48),
							   META_DATA_1 VARCHAR2(20), 
							   META_DATA_2 VARCHAR2(20), 
							   META_DATA_3 VARCHAR2(20), 
							   META_DATA_4 VARCHAR2(20), 
							   META_DATA_5 VARCHAR2(20), 
							   META_DATA_6 VARCHAR2(20), 
							   INSERT_TIMESTAMP TIMESTAMP (6), 
							   UPDATE_TIMESTAMP TIMESTAMP (6), 
							   IS_PROCESSED VARCHAR2(1), 
							   RECORD_ID VARCHAR2(15) NOT NULL, 
							   DESCRIPTION VARCHAR2(100),
							   CONSTRAINT SI_BATCH_MSG_PK PRIMARY KEY (RECORD_ID));

--13/04/2012 HM Business Service ID column - size alteration
ALTER TABLE SI_BATCH_MESSAGE MODIFY BUSINESS_SERVICE_ID VARCHAR(45);

--01/03/2013 HM Addition of alter statements to increase metadata columns
ALTER TABLE SI_BATCH_MESSAGE MODIFY META_DATA_1 VARCHAR(50);
ALTER TABLE SI_BATCH_MESSAGE MODIFY META_DATA_2 VARCHAR(50);
ALTER TABLE SI_BATCH_MESSAGE MODIFY META_DATA_3 VARCHAR(50);
ALTER TABLE SI_BATCH_MESSAGE MODIFY META_DATA_4 VARCHAR(50);
ALTER TABLE SI_BATCH_MESSAGE MODIFY META_DATA_5 VARCHAR(50);
ALTER TABLE SI_BATCH_MESSAGE MODIFY META_DATA_6 VARCHAR(50);

--11/05/2012 HM RECORD_ID column - size alteration
--06/03/2013 MA RECORD_ID column - size alteration for batch sequence
ALTER TABLE SI_BATCH_MESSAGE MODIFY RECORD_ID VARCHAR(30);

COMMIT;
