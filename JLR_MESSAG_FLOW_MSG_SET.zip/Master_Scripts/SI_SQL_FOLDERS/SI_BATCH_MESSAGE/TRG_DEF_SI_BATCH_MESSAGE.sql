--------------------------------------------------------------------------------------------------------
-- Author 		: Mike Arrowsmith
-- Version 		: $Revision: 1.1 $
-- Description 	: Create trigger script for trigger on table SI_BATCH_MESSAGE which will update the table
--				  with a insert timestamp when a row has been inserted and append record_id with sequence
-- History 		: 06/03/2013 Mike Arrowsmith Initial create statement for trigger SI_BATCH_MESSAGE_TRG
--------------------------------------------------------------------------------------------------------

DROP TRIGGER SI_BATCH_MESSAGE_TRG;

--Trigger which will insert or update the timestamp if an insert or update action occurs
CREATE OR REPLACE
TRIGGER SI_BATCH_MESSAGE_TRG
BEFORE INSERT OR UPDATE ON SI_BATCH_MESSAGE
FOR EACH ROW
BEGIN

IF INSERTING THEN
	:new.RECORD_ID := TO_CHAR(:new.RECORD_ID) || TO_CHAR(LPAD(SI_BATCH_MESSAGE_SEQ.NEXTVAL, 2, '0'));
	:new.INSERT_TIMESTAMP := systimestamp;
	:new.UPDATE_TIMESTAMP := NULL;
ELSE
	:new.UPDATE_TIMESTAMP := systimestamp;
  END IF;
END;
/
COMMIT;
