--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: $Revision: 1.3 $
-- Description 	: Create table script for SI_BATCH_SCHEDULE table which will hold batch schedule information
-- History 		: 29/12/2011 Hina Mistry Initial create statement for table
--  			: 02/08/2012 David Thompson updated to Add FREQUENCY_VAR to allow specific weekdays and month days
--				: 10/08/2012 HM Business Service ID column - size alteration
--              : 10/08/2012 DT Added FREQUENCY_VAR, amalgamated ALTERS into a base script
--				: 13/08/2012 Changed Primary Key
--				: 14/08/2012 HM Addition of user, insert, update timestamp fields for audit purposes
--				: 17/09/2012 SP Addition of column TIMEZONE. Alter statement not used because it will help developer 
--							 to have the position of column before DAILY_BATCH_START_TIME and alter statement does 
--							 not allow this without a bespoke workaround
--				: 12/06/2014 Kenny McCormack Increase size of FREQUENCY_VAR column
-------------------------------------------------------------------------------------------------------------------

DROP TABLE SI_BATCH_SCHEDULE;

CREATE TABLE SI_BATCH_SCHEDULE (SYSTEM_IDENTIFIER VARCHAR2(20), 
								DESTINATION_SYSTEM VARCHAR2(20), 
								BUSINESS_SERVICE_ID VARCHAR2(45),
								TIMEZONE VARCHAR2(35),
								DAILY_BATCH_START_TIME VARCHAR2(10),					
								BATCH_LAST_RAN_DATE TIMESTAMP (6), 
								FREQUENCY VARCHAR2(10),
								FREQUENCY_VAR VARCHAR2(10),					
								ENABLED VARCHAR2(1),
								PROCESSING_STARTED VARCHAR2(1),
								BROKER_INSTANCE VARCHAR2(1),
								DESCRIPTION VARCHAR2(100), 
								USER_ID VARCHAR2(10) NOT NULL,
								INSERT_TIMESTAMP TIMESTAMP(6),
								UPDATE_TIMESTAMP TIMESTAMP(6),
								CONSTRAINT SI_BATCH_SCHEDULE_PK PRIMARY KEY (SYSTEM_IDENTIFIER,DESTINATION_SYSTEM,BUSINESS_SERVICE_ID));
								
-- KM 12/06/2014
-- Updated to account for new frequncy values
ALTER TABLE SI_BATCH_SCHEDULE MODIFY FREQUENCY_VAR VARCHAR(50);

COMMIT;
