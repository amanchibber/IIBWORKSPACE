--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: $Revision: 1.564 $
-- Description 	: Create data script for SI_BUSINESS_SERVICE_DETAILS table which will hold email addresses that will be used for outbound emails 
-- History 		: 24/11/2011 Hina Mistry Initial INSERT statements for table
-- 				  06/01/2012 Seenesh Patel Update with Javis to SAP and AP ALE Outbound Adapter
-- 				  16/03/2012 Hina Mistry Update with Business Service IDs for the eSmart Plan B interfaces
--				  25/05/2012 Hina Mistry Addition of entry for business service id: SI_BS_FGFSH_DEALER_SAP_TRBUK_KJ03
--				  28/05/2012 Hina Mistry Addition of entry for business service ids: SI_BS_EPICS_INVOICES_SAP_ESMDE_EXPINV, SI_BS_JGVAC_INVOICES_SAP_ESMDE_EXPINV
-- 				  07/06/2012 Mike Arrowsmith Added entries for: SI_AD_SAP_TRBGB_BAPI_OUTBOUND, SI_AD_SAP_SMTCN_BAPI_INBOUND, SI_AD_SAP_GENERIC_REPLY, 
--											 SI_BS_SAP_SMTCN_VSTAT_MFT_CHINADMS, SI_BS_FGAFS_MFT_FUNDACCEPT_SAP_TRBGB_KJ12
--				  14/06/2012 Hina Mistry Addition of entry for business service id: SI_BS_FGFSH_VEHICLE_SAP_TRBUK_KJ13
--				  26/06/2012 Amith Sannagowdar 'Addition of entry for business service id:SI_BS_D42_HMRC_RIC_EXPDECL'
--				  18/07/2012 Amith Sannagowdar	'Addition of entry for BSID: SI_BS_D42_VEH_SAP_TRBGB_VEHSTATUSUPD'
--				  18/07/2012 Hina Mistry Addition of entry for business service id: SI_BS_BBSS_CUSTOMER_ALL_CUSTDETALS
--				  23/07/2012 Seenesh Patel Added various BSID entries
--				  26/07/2012 AS Addition of entry for BSID: SI_BS_ALL_INV_SAP_ESMUS_ACCPAY
--				  27/07/2012 AS Addition of entry for BSID: SI_BS_SAP_TRB_HR_ALL_COSTCENTRE, SI_BS_SAP_TRB_HR_ALL_POSDATA
--                                07/08/2012 DT Addition of BSID: SI_BS_SAP_ESMALL_TO_HYPER_FINREPORT for IA-000258
--				  09/08/2012 AS Addition of entry for IA-66 and ESMALL BAPI Inbound adapter
--				  09/08/2012 MA Addition of entries for IA-97 
--				  09/08/2012 SP Addition of entries for IA-000083
--				  03/08/2012 AS Addition of entries for IA-266, SAP ESMALL ALE Outbound
--				  20/08/2012 AS Addition of entries for IA-000076 Caterpillar Accounts Receivable (CAT to SAP eSMART)
--				  22/08/2012 AS Addition of entries for IA-000057 Port Updated Options (SAP eSMART NA to DDW)
--				  23/08/2012 HM Addition of entries for IA-000065 VISTA GOF (Strategic) to SAP eSMART
--				  23/08/2012 AS Addition of entries for IA-000095 HR Cost Centre (SAP Turbo to WAJ1/Catalyst)
--				  24/08/2012 SP Addition of entries for IA-000070_Drafts
--				  24/08/2012 AS Addition of entries for IA-000094 HR Positions (SAP Turbo to WAJ1/Catalyst)
--				  29/08/2012 SP Addition of entries for IA-000063 Warranty Claims to SAP eSMART
-- 				  31/08/2012 SP Addition of entries for IA-000090 Request for NVIS or CO (SAP eSMART to MONRONEY)
-- 				  04/09/2012 SP Addition of entries for IA-000113 Payment Acknowledgement (J P MORGAN to JLR Business)
--				  04/09/2012 MA Addition of entries for IA-000067 D42 Vehicle Events to SAP eSmart
--				  05/09/2012 SP Addition of entries for IA-000114 (SAP to J P MORGAN)
--				  06/09/2012 VY Addition of entries for IA-000019 (KBA to SAP eSMART)
--				  19/09/2012 SP Addition of entries for IA-000020 (SAP eSmart to KBA)
--				  21/09/2012 HM Addition of entries for IA-000074 (Multiple Systems to SAP eSmart)
--				  26/09/2012 HM Addition of entries for IA-000290 HR Employee Data - Current Data (SAP TURBO to Legacy)
--				  01/10/2012 MA Addition of entries for IA-000293 Trade Union Data (WAJ1 to SAP TURBO)
--				  04/10/2012 SP Addition of entries for IA-000087 Reporting Data (SAP to ORBITS)
--				  16/10/2012 SP Addition of entries for IA-000007 Vehicle Homologation Details (WVTA to SAP eSmart)
--				  17/10/2012 RB Addition of entries for IA-000009 Vehicle Status Events to D42
--				  17/10/2012 CM Addition of entries for IA-000234 RADS Engineering Time To SAP Turbo
--				  17/10/2012 CM Addition of entries for IA-000235 Project Category Status to RADS
--				  23/10/2012 MA Addition of entries for IA-000093 HR Employee Data Changes
--				  25/10/2012 AS Addition of entries for IA-000147 Dealer Part Return Dr (SWORD to SAP TRB)
--				  26/10/2012 RB Addition of entries for IA-000309 Used Cars Data (APAK to SAP Turbo)
--				  01/11/2012 VY Addition of entries for IA-000062 Monex Exchange rate to SAP esmart & SAP Turbo
--				  02/11/2012 SP Addition of entry for IA-000137 and IA-000143
--				  06/11/2012 HM Addition of entry for IA-000046 for the eSmart version of this interface
--				  06/11/2012 HM Addition of entry for IA-000138 FGAFS Funding Rejections (KJ11) (FGAFS to SAP eSMART)
--				  13/11/2012 SP Addition of entry for IA-000109 EXTRAC to SAP and IA-000110 SPQC to SAP
--				  14/11/2012 AS Addition of entry for IA-000134 Unipart JAGServiceParts to SAP Turbo
--                19/11/2012 CM Addition of entries for IA-000106 SAP Turbo Payment Info To Caterpillar
--                20/11/2012 KM Took export of SI_BUSINESS_SERVICE_DETAILS from dev and INSERTed here as over half the entries were
--							 missing from this script
--                06/12/2012 RB Addition of entries for IA-000107 SAP Turbo Vendor Master Updates To GSDB
--				  07/12/2012 SP Previous update that altered script with VALUES from database caused dupliate entries and BUSINESS_SERVICE_ID and timestamp to be INSERTed manually
--							 Therefore altered so that duplicates removed (PK changed on table to BUSINESS_SERVICE_NAME to prevent this happening again)
--							 Also BUSINESS_SERVICE_ID is now sequenced again and timestamp reverted back to automatic INSERTion
--				  07/12/2012 SP Addition of entry for IA-000289 SUPPLIER DEBITS (SWORD-SAP)
--				  07/12/2012 SP Additional entries added that were missing
--				  09/12/2012 VY Addition of entry for IA-000269
--				  11/12/2012 CM Addition of entries for IA-000267 second one is required for additional output flow
--				  12/12/2012 CM Addition of entry for IA-000107
--				  13/12/2012 KM Addition of entry for GUANXI Service SI_BS_GEMSL_WrntyCodeConv_To_JVW
--				  14/12/2012 SP IA289 and IA147 are now in same message flow. Removed seperate entries, added new BSID
--				  19/12/2012 CM Addition of entry for IA-000203 - SAP Turbo Order Details to PIMS 
--				  19/12/2012 CM Addition of entry for IA-000204 - PIMS Booking Time to SAP Turbo
--				  02/03/2013 CM Amended entry for IA-000204 - PIMS Booking Time to SAP Turbo
--				  15/01/2013 KM Added entries for IA-000156
--				  16/01/2013 SP Added entry for IA-000323
--				  25/01/2013 CM Added entry for IA-000122 - SAP eSMART Bank Direct Debits To Multiple Systems
--				  25/01/2013 HM Added entry for IA-000330 - NVM Vehicle Transfers Batch Update To SAP TRB
--				  13/02/2013 AS Added entry for IA-000071 - SI_BS_Multiple_Systems_AcksAndBankStmnt_To_SAP_ESM
--				  14/02/2013 AT Added entries for IA-000027 - SI_BS_SAP_TRBGB_INVCRDDETS_*
--				  05/03/2013 SP Added entry for FRS-000258 - Connected Cars - VCATS Interface - Production Control Service
--				  18/03/2013 CB Added entry for IA-000332 - SAP Turbo Expense Ref data to AWS
--				  18/03/2013 SP Added entry for FRS258 Connected Cars - Production Service
--				  18/03/2013 SP Added entry for FRS001 Email Service
--				  18/03/2013 CM Added entry for IA-000103 - CITIBANK Purchase Card Info To SAP Turbo
--				  26/03/2013 SP Added entry for FRS-000259 - Connected Cars - PLO Interface - Vehicle Property Data Service
--				  05/04/2013 CM Added entry for IA-000104 - CITIBANK Travel Card Info To SAP Turbo
--				  22/04/2013 AS Modified entry for FRS-000259/FRS-000003, changed BSID
--				  24/04/2013 SP Update in service naming standards therefore BSID updated from SI_SV_INFSV_SENDEMAIL to SI_SV_INFSV_EMAIL
--				  29/04/2013 SP Added entry for IA-000208 RoadsideAssistanceClaims (Legacy to SAP TURBO) 
--				  10/05/2013 PG Added entry for IA-000296 Warranty Restrictions (POLK to SAP)
--				  14/05/2013 SP Added/Removed entries for IA-000046 due to IFU951
--				  04/06/2013 CB Added entries for IA-000171
--				  04/06/2013 AS Added entries for IA-000172
--				  05/06/2013 RB	Added entry for SOAP MT Outbound Adapter
--				  06/06/2013 RB	Added entry for FRS-000271
--				  07/06/2013 PG Added entry for FRS-000016
--				  10/06/2013 SP Added entry for FRS-000259 - IFU997
--				  14/06/2013 PG Added entry for FRS-000006
--				  17/06/2013 KM Added entry for FRS-000260
--				  20/06/2013 pg Added entries for FRS-000006 MQ Adapters
--         		  25/06/2013 CM Added entries for IA-000071 - eSMART, Deutsche bank statements. 
--       		  28/06/2013 AT Added entries for FRS-000109 
--				  01/07/2013 MA Added entry for FRS-000007
--				  01/07/2013 KM Added entry for FRS-000111
--        		  02/07/2013 CM Added entries for IA-000070 - eSMART, Intesa, Deutsche, Citibank payments.
--				  05/07/2013 KM Added entry for FRS-000110
--				  08/07/2013 AT Added entry for FRS-000108
--				  16/07/2013 KM Added entry for FRS-000107
--				  22/07/2013 AT Added entry for FRS-000116
--				  22/07/2013 RB Changes for IFU-1088. Removed BDA entry for IA-000074
--				  24/07/2013 PG Added entry for FRS-000009
-- 				  29/07/2013 SP Added entries for FRS-000261
-- 				  18/08/2013 CM Added entries for IA-000070 SMART China adapter changes
-- 				  14/08/2013 MA Added entries for FRS-000029
-- 				  14/08/2013 VA Added entries for FRS-000122
-- 				  16/08/2013 AT Added entries for FRS-000121
--				  23/08/2013 PG Added entry for IA-000336
--				  30/08/2013 PG added entry for IA-000336 Queue Monitor 
--				  02/09/2013 SP added entries for IA-000148
--				  05/09/2013 CM added entries for IA-000124
--				  06/09/2013 VA added entries for FRS-000113
--				  10/09/2013 PG added entry for FRS-000267
--				  11/09/2013 AC Added entry for	FRS-000023
--				  19/09/2013 KM Added entry for	Canonical Activity and Lead Adapter
--				  19/09/2013 AS Added entry for	IA-000163
--				  20/09/2013 RB Added entry for	FRS-000273
--				  20/09/2013 KM Added MFT HTTPS Adater entries
--				  23/09/2013 MA Added entry for FRS-000017
--				  24/09/2013 KM Added entry for FRS-000112
--				  01/10/2013 CM Added entry for FRS-000383
--				  03/10/2013 SP Added entry for FRS-000356
--				  04/10/2013 VA added entries for FRS-000128
--				  09/10/2013 RBH added entries for FRS-000266
--				  15/10/2013 KM added entries for FRS-000120
--				  15/10/2013 HM added entry for FRS-000119
--				  18/10/2013 HM added entry for FRS-000130
--				  21/10/2013 KM added entry for FRS-000127
--				  24/10/2013 PG added entry for FRS-000073
--				  25/10/2013 HM added entry for FRS-000130 for SVCRM flow
--				  04/11/2013 HM added entry for FRS-000123
--				  04/11/2013 RBH added entry for FRS-000366
--				  04/11/2013 PG added entry for FRS-000027
--				  08/11/2013 CM added entry for FRS-000133
--				  08/11/2013 VA added entry for FRS-000129
--				  11/11/2013 AC added entry for FRS-000053
--				  12/11/2013 HM added entry for FRS-000118
--				  12/11/2013 KM added entry for FRS-000115
--				  11/11/2013 AC Modified entry for FRS-000053
--				  13/11/2013 RBH added entry for FRS-000380
--				  14/11/2013 HM added entry for IA-172 inclusion of feed from EMC
--				  18/11/2013 KM added entry for IA-000354
--				  19/11/2013 RB Added entries for FRS-000117
--				  20/11/2013 AS Added entries for IA-000158
--				  20/11/2013 PG Added entries for FRS-000083
--				  22/11/2013 CM Added entries for FRS-000139
--				  28/11/2013 SP Added entry for IA-000271
--				  02/12/2013 AS Added entry for FRS-000107 (Vista to SAP Turbo part)
--				  02/12/2013 PG Added entry for FRS-000051 (Enovia to WIPS Target Costs)
--				  05/12/2013 AC Added entry for FRS-000038 (Enovia to Unipart)
--				  05/12/2013 SP Added entry for FRS-000353 (PLO to SAP Turbo)
--				  09/12/2013 HM Added entry for IA-000355 (WIPS to Ricardo)
--				  09/12/2013 HM Added entry for IA-000356 (WERS to Ricardo)
--				  11/12/2013 SP Added entry for IA-000357 (GSDB to Ricardo)
--				  11/12/2013 AS Added entry for IA-000358 (MDG to Ricardo)
--				  23/12/2013 SP Added entry for IA-000359 (CMMS3 to Ricardo)
--				  24/12/2013 PG Added entries for FRS-000091 (ACE BRS Deltas to downstream)
--				  14/01/2014 AS FRS-000123 (AA feed to SAP Turbo)
--				  15/01/2014 AC Added entry for FRS-000022 (PLO Slot Generation to ACE)
--				  16/01/2014 AS Added entry for FRS-000618
--				  16/01/2014 AC Updated entry for FRS-000022 (PLO Slot Generation to ACE)
--				  27/01/2014 RBH Added entry for FRS-000378 (PLO to External Service Provider)
--				  06/02/2014 AC Added entry for FRS-000081 (Enovia Manufacturing UCC SFI To CMMS3)
--				  11/02/2014 AC Updated entry for FRS-000081 (Enovia Manufacturing UCC SFI To CMMS3)
--				  11/02/2014 CM Added entry for IA-000324 (Warranty External Supplier Contracts)
--				  11/02/2014 RBH Added entry for FRS-000617 (CJLR VCATS to Whitley Engineering Server)
--				  17/02/2014 AS Added entry for IA-000363 CMMS3 to Ricardo (Stock Adjustment)
--				  18/02/2014 SP Added entry for FRS-000130 (SAP Turbo feed)
-- 				  20/02/2014 AC Added entry for FRS-000090 (ACE BRS Master Feeds)
--				  21/02/2014 CM Added entry for FRS-000616 (Warranty Vehicle Campaign Enquiry)
-- 				  23/02/2014 AC Added entry for FRS-000081 (iPLM Scheduler Adapter)
--				  24/02/2014 PG Added entries for FRS-000018 (iPLM ACE Profet tp Downstream)
--				  25/02/2014 CM Added entry for FRS-000615 (Replicate Warranty Contract)
--				  25/02/2014 PG Adjusted entries for FRS-000018 (iPLM ACE Prefet to Downstream)
--				  03/03/2014 SP FRS-000381 - Claims Exports (TURBO SAP to DWM)
--				  04/03/2014 PG Adjusted entries for FRS-000018 (iPLM ACE Profet to Downstream)
--				  05/03/2014 AC Added entry for FRS-000093 (Get BOM Validation)
--				  06/03/2014 AC Adjusted entries for FRS-000093 (Get BOM Validation)
--				  25/02/2014 CM Added entries for FRS-000615 (Replicate Warranty Contract) (Batch and Canonical Adapters)
--				  12/03/2014 PG Added entries for IFU-1765. IA-000074
--				  12/03/2014 RBH Added entries for IA-000362
--				  14/03/2014 CM Amended entries for FRS-000615 post desing review 
--				  19/03/2014 RBH Added entries for IA-000027 (eSmart Belgium and eSamart NetherLands)
--				  20/03/2014 KM Added entry for FRS-277 (ASN Provision)
--				  26/03/2014 SP Added entry for IA-324 Phase 2
--				  27/03/2014 PG Added entry for FRS-50 (Unipart Service PArts to MPNR)
--				  04/04/2014 AC IA-000220 IFU1811 FGFSH PymtConfrm To SAP eSmart
--				  07/04/2014 AS FRS-000621 NL Vehicle Licence Plate Order and Release (SAP eSMART to Kirpestein)
--				  07/04/2014 AS FRS-000622 NL Vehicle Licence Plate Response (Kirpestein to SAP eSMART)
--				  08/04/2014 PVH FRS-000282 CMMS3 to JV-Bridge Part Status Updates
--				  08/04/2014 PG FRS-000096 Enovia To MPNR
--				  11/04/2014 AS FRS-000625 Vehicle Registration request (SAP eSMART to local registration organisations)
--				  14/04/2014 RBH Added entry for FRS-000371 (Vehicle Manufacturing Status (CJLR to D42))
--                15/04/2014 GS  Added entries for FRS-000626 Vehicle Registration response (local registration organisations to SAP eSMART).
--                23/04/2014 GS  Added entry for FRS-000372 (Vehicle Distribution Status (D42 to CJLR))
--                01/05/2014 RB  Added entry for FRS-000278 (Vehicle Part Invoice Service)
--                05/05/2014 KM  Added entry for IA-000009 Horizon change IFU1898
--                07/05/2014 RBH Updated the entry for IA-000005 Horizon change IFU1897
--                07/05/2014 GS  Added entries for FRS-00620 VCATS Vehicle Weights to PLO
--                08/05/2014 AC  Added entries for FRS-000136 (Replicate Account and Vehicle )
--                13/05/2014 AS  Added entries for FRS-000130 (Replicate Dealer - Bollywood feed)
--                14/05/2014 PG  Added entry for FRS-000100 (Reference Data to SAP BODS)
--                27/05/2014 GS  Added entries for FRS-000364 (Warranty Vehicle Config to Multiple Systems)
--                28/05/2014 PVH Added entry for FRS-000367 (Derivative/Feature Delta Feed to CJLR)
--                04/06/2014 RB Added entry for FRS-000281 (CMMS3 to JV-Bridge calendar file interface)
--                12/06/2014 PVH Added entry for IA-000005 (New cloned flow for VISTA GOF to SMART)
--                13/06/2014 RBH Added entry for IFU 1981
--                16/06/2014 PVH Added entry for IA-000061 (New cloned flow for Multiple Systems to SMART)
--                27/06/2014 SP Added entry for FRS-000640 � WERS Code Description (WERS to ATD,TOPix and SAP TURBO)
--                04/07/2014 KM Added entry for FRS-000138 � Replicate Vehicle Derivative Data
--                04/07/2014 HA Added entry for IA -000366 - GPIRS Product Update To RICARDO(Phoenix project)
--				  08/07/2014 RBH Added entry for FRS-000633 - Shipment Notification � MAN File (SAP eSMART to PRIXCAR)
--				  09/11/2014 GDS Added entry for FRS-000362 - Vehicle Enquiry (Various to TURBO SAP) 
--				  14/07/2014 CM Added entries for FRS-000382
--				  14/07/2014 KM Added entries for FRS-000141
--				  16/07/2014 GS Corrected BSID of FRS-000362
--				  17/07/2014 AS Corrected BSID of FRS-000632
--				  18/07/2014 RBH Added entry for FRS-000634 - Vehicle Updates � RES File (SAP eSMART to PRIXCAR)
--				  23/07/2014 RBH Updated the Business service name for FRS-000621
--				  25/07/2014 SP Added entries for FRS-000382 2a To SWORD
--				  31/07/2014 PG Added entries for IA-000258
--				  31/07/2014 GS Added entry for FRS-000627 Create or Update PAR (GCM to SAP Turbo)
--				  06/08/2014 RBH Added entry for FRS-000635 - Vehicles To Despatch � ALC/SLIP File (SAP eSMART to PRIXCAR)
--				  06/08/2014 AS Added entry for FRS-000272 - IFU2194, Trading Division related interface
--				  06/08/2014 GS Added entry for FRS-000628 - FRS-000628 Update FRED (SAP Turbo to GCM)
--				  07/08/2014 SP Added entry for FRS-000646 - UVL VIN and feature feed 
--				  13/08/2014 AS Added entry for FRS-000277 (Trading Division)
--				  19/08/2014 SP Added entry for new Outbound ON SAP Turbo BAPI Adapter
--                20/08/2014 AMW Added entries for FRS136 R2.0
--                22/08/2014 AMW added entry for SI_SV_CUSSV_CTUPVHCL
--				  25/08/2014 AB aAdded entires for IA-000368 Pheonix GRIPRS Removal Notifications to RICARDO
--				  26/08/2014 AB aAdded entires for IA-000370 Pheonix GRIPRS Stock Adjustments to RICARDO
--				  26/08/2014 SP Added entry for PLO Outbound Code Translation Response Adapter
--				  26/08/2014 SP Entries added for FRS-000631 CJLR (Brand Codes) Vehicle Specification Based ON WERS Codes (PLO to SAP TURBO) 
--				  27/08/2104 PG New entry for FRS-000090 / IFU2310 ACE BRS Master Feeds. This replaces existing entries
--				  03/09/2014 CM Added entries for FRS-000382 Exit 2b SYC1
--				  05/09/2014 CM Added entries for FRS-000382 Exit 2b CJLR
--				  17/09/2014 AC Added entries for IA-000124 - ANZ Bank Statements
--				  19/09/2014 SP Added entries for FRS-000382 Exit 2b SMART
--				  18/09/2014 CM Added entries for FRS-000382 Exit 2c AUTOA
--				  24/09/2014 RBH Added entry for FRS-000650 TD SAP to Syncreon AOS Integration
--				  25/09/2014 SP Added entry for FRS-000648 Parts Localisation Service
--				  25/09/2014 CM Added entry for FRS-000382 - SAP ALE Inbound Adapter Flow
--				  08/10/2014 CM Added entry for FRS-000382 - Exit 2d Bollywood BSID added 
--				  14/01/2014 RBH Added entry for FRS-000654 � SAP eSMART VMS to DMS Interface
--                22/10/2014 AC Entry added for FRS 657(CJLR To SWORD)
--                22/10/2014 AC Entry added for FRS 657 (SWORD To CJLR)
--				  13/11/2014 SP Entry added for FRS 130 (AWS)
--				  20/11/2014 AC Entry added for FRS 128 (Simplified Batch)	
--				  22/11/2014 Service names SI_SV_VEHSV_PARTSLIST & SI_SV_VEHSV_PARTSPRICEUPD added for FRS-000656
--				  05/12/2014 AC Entry added for FRS 117 - (Simplified Batch Guanxi R1.2)
--				  18/12/2014 AC Entry added for FRS 139 - (Simplified Batch Guanxi R1.2)
--				  18/12/2014 AC Entry added for FRS 118 - (Simplified Batch Guanxi R1.2)
--                23/12/2014 RBH Updated the BSID from SI_BS_SAP_ESMDE_INVOICE_FGFSH_KJ10KJ33 to SI_BS_SAP_ESMALL_INVOICE_FGFSH_KJ10KJ33 for IA-137 
--				  14/01/2015 AaP Entry for FRS-000656
--				  19/01/2015 RBH added entry for FRS-000660
--				  22/01/2015 RBH added entry for FRS-000626 (IFU 2658)
--				  09/02/2015 RBH Added entry for FRS-000091- IFU2317,IFU2431,IFU2461,IFU2708
--				  10/02/2015 KT	Added entry for FRS-000661 - Stone - BankPayments from SAP TRBGB  to BancoITAU
--				  11/02/2015 AC Added entry for FRS-000148 - Guanxi - Replicate Vehicle Planning Event from PLO to SAPCRM
--				  11/02/2015 AC Added entry for FRS-000147 - Guanxi - Replicate Vehicle Status Event from D42 to SAPCRM
--				  23/02/2015 KT Added BSID for FRS-000651 - TD - Invoice Outbound Declaration to Customs
--				  26/02/2015 RBH Added BSID for FRS-000670 - Stone - Invoice Information for Parts and Vehicle (SAP Brazil to Customs Broker)
--				  03/03/2015 AC  Added BSID for FRS-000137-SIMPLIFIED BATCH - Gaunxi - Create or Update Vehicle Simplified Batch.
--				  03/03/2015 AC  Added BSID for FRS-000023-(IFU2807) - IPLM - Component Tooling Request.
--				  13/03/2015 CM Added BSID for FRS-000695 - Bedrock - Replicate Manufacturer Suggested Retail Price Data from SAP Turbo to Multiple Systems
--				  13/03/2015 PG Added BSIDs for FRS-000271 - SI_BS_WERS_VEH_ALL_ENGCHANGE and SI_SV_VEHSV_ENGCHGSAP
--				  18/03/2015 RBH Added BSID for FRS-000669 - Customs Inbound Information for Parts and Vehicle (Customs Broker to SAP Brazil) - Stone
--				  19/03/2015 SP Added BSID for FRS-000693
--				  03/04/2015 AC Added BSID for FRS-000015
--				  09/04/2015 SP Added BSID for FRS-000681
--				  16/04/2015 RBH Added BSID for FRS-000667 SAP to Speedy Interface
--				  16/04/2015 AC Added BSID for FRS-000673 - Tradding Divison - SAP TD to CJLR Tradding Divison
--				  21/04/2015 PG Added BSID for Stabilisation flows SI_AD_HTTP_V2_OUTBOUND, SI_AD_HTTP_V2_INBOUND and SI_AD_HTTP_V2_REPLY
--				  23/04/2015 CM Added BSID for IA-000005 - VISTA to LANDAR - Project Clockwork
-- 				  24/04/2015 AB Added for FRS-000668 SBOM (Service Bill of Material)
--				  29/04/2015 RBH Added BSID for FRS-000705 SAP to SIM Integration
--				  30/04/2015 SP Added BSID for FRS-000716 MES to SAP Plant Maintenance - Fault Alarm Notification
--				  30/04/2015 PG Added BSID for FRS-000651 - TD - Invoice Outbound Declaration to Customs. KN to be used instead of Ricardo
--				  30/04/2015 RB Added BSID for FRS-000680 MES to SAP Turbo - Vehicle Genealogy
--				  05/05/2015 RB Added BSID for FRS-000680 MES to SAP Turbo - NCR Notification
--				  07/05/2015 SP Added BSID for FRS-000716 MES to SAP Plant Maintenance - Update Status
--				  07/05/2015 SP Added BSID for FRS-000716 MES to SAP Plant Maintenance - Measurement Document
--				  08/05/2015 RB Added BSID for FRS-000680 MES to SAP Turbo - Part Quarantine Status
--				  08/05/2015 RB Added BSID for FRS-000680 MES to SAP Turbo - NCR Response
--				  11/05/2015 PG Added BSIDs for FRS-000712 FRS-00712 MF & DHL Red Prairie GXS Integration
--				  24/05/2015 RBH Added BSIDs for FRS-000711 TD SAP to PLO Interface 
--				  18/05/2015 SP Added BSID for FRS-000690 PLO Demand Forecast to SAP Turbo 
--				  21/05/2015 KT Added BSID for FRS-000718 
--				  22/05/2015 AS Added BSIDs for FRS-000715 MES to SAP EWM Interface
--				  02/06/2015 VV Added BSIDs for FRS-000718 (Planned Order Confirmation from MES to SAP)
--				  09/06/2015 AS FRS-000679 Transfer Master Data and Acknowledgement
--				  10/06/2015 KT FRS-000707 OrderBOM and Acknowledgement
--				  16/06/2015 RB FRS-000003 Vehicle Genealogy
-- 				  29/06/2015 RBH FRS-000674 TDSAP to CJLR Customer Invoice 
-- 				  06/07/2015 PG FRS-000668 Updated BSID 
-- 				  09/07/2015 SP FRS-000731 Open Ordering Vista Dealer Allocations
-- 				  29/07/2015 RB FRS-000719 D42 Vehicle Status Update to MES
-- 				  08/09/2015 RB Added BSID for FRS-000687 HR Interface-ESB_To_Kronos Interface
--				  10/09/2015 AS FRS-000720 entries
-- 				  11/09/2015 RBH Added BSID for FRS-000689 HR Interface (ESB to NGA Payroll)
--				  30/09/2015 AS FRS-000670 Purchase Order Feed
--				  08/10/2015 AS FRS-000669 Customs Declaration, IFU3455
--				  16/10/2015 KT IA-000147 Warranty Dealer Part Returns IFU-3432
--				  10/11/2015 SP FRS-000653 WIndependent Operator Trust Centre Service
--                13/11/2015 CM IA-000172 IFU3539 Added flow specific BSID SI_BS_PAYRL_GLENTRY_SAP_TRB
--                18/11/2015 SP FRS-000130 - to SAP eSmart
--                20/11/2015 CM IA-000172 Added entries for IFU3539
-- 				  24/11/2015 AC FRS-000107-VISTA to VITAL IFU3554
-- 				  01/12/2015 RBH Added BSID for FRS-000737 Create Purchase Order from Neovia provided Commercial Invoice
-- 				  02/12/2015 SP Added for FRS-000804 Employee Data to Success Factors
-- 				  03/12/2015 RB Added for FRS-000670 Vehicle Information
-- 				  31/12/2015 RB Added entry for FRS-000807 OA Code Translation
--				  04/01/2016 VV Removed Duplicate BSIDs for FRS-000718 (Planned Order Confirmation from MES to SAP) as it was already there
--				  15/01/2016 VV Added entry for FRS-000791, Employee TA Data from ESB to Kronos UK
--				  25/01/2016 CM Added new BSID for FRS-000802
--				  23/02/2016 PP Added exception replay web service and new batch framework flows
--				  01/03/2016 CM Added new BSID for FRS-000795
--                08/03/2016 NS Added new BSID for FRS-000812
--                18/03/2016 NS Added new BSID for SAP SMART China ALE Outbound Adapter Flow V2
--                30/03/2016 MJ Added BSID for IA-000049
--				  08/04/2016 KT Added BSID for PGZ MQ Outbound Adapter flow IFU3815
--                15/04/2016 CM Added BSID for FRS-000809 
--                18/04/2016 CM Added BSID for outbound SAP Adapter flow for FRS-000809
--				  19/04/2016 AS FRS-000816 Material Master, Vendor Master, CTC/Outline Agreement 
--				  21/04/2016 ANA FRS-000133 Updates for ReplicateCase migration to new batch framework
--				  25/04/2016 AS FRS-000815 Commercial Terms Confirmation Interface ESB to Plant Graz
--				  26/04/2016 VV FRS-000813 and FRS-000814 Material Master and Vendor Master Interface ESB to Plant Graz
--				  27/04/2016 VV FRS-000813 Updated Material Master BSID
--				  27/04/2016 VV FRS-000813 Updated Vendor Master BSID
--                05/05/2016 RBH Added BSID for FRS-000818 
--				  18/05/2016 AC Added BSID for 	FRS-000130 - IFU3888
--				  02/06/2016 LH IFU3924 IA-207 Framework migration.Removed entry  SI_BS_ALL_VEHSERV_SAP_TRBGB_MVRISREG and SI_BS_ALL_VEHSERV_SAP_TRBGB_AFRLREG, Added entry  		SI_BS_ALL_VEHSERV_ALL_VEHREGIS
-- 				  06/06/2016 RBH Updated IA-354 Business service id to SI_BS_CMMS3_HMRC_ALL_GDSRECEIPT (IFU 3950)
-- 				  06/06/2016 RBH Updated IA-355 Business service id to SI_BS_WIPS_HMRC_ALL_PRODPRICNG (IFU 3951)
-- 				  09/06/2016 AS Added BSID for FRS-000820
-- 				  16/06/2016 VV Added BSID for FRS-000819 (Distribution Label from D42 to PGZ)
--				  24/06/2016 SB Added BSID for FRS-000151 IFU3942
--				  01/07/2016 SB Added BSID for FRS-000371 IFU3928
--				  08/07/2016 TK Added BSID for SI_AD_SAP_ESMALL_BAPI_MT_OutboundV2 flow under IFU3907(IA-000027)
--				  03/08/2016 KT IFU4055 BSID changes as per new source system.
--				  09/08/2016 TK Added BSID for SI_AD_SAP_TRBGB_ALE_MT_OutboundV2(IA-000148) and for SI_AD_SAP_TRBGB_ALE_HR_MT_OutboundV2(IA-000097)
--				  12/08/2016 KT IFU4082 FRS-000815 Added new BSID (to be used only for routing)
-- 				  29/08/2016 TK IA-000027-Added BSID for SI_BS_SAP_TRBGB_Invoice_Credit_Details_To_NSCNT flow
--                09/09/2016 SB IA-000094-Added BSID for batch retrieve path in SI_BS_SAP_TRBGB_PosData_To_MultipleSystems flow
--                12/09/2016 SB IA-000290-Added BSIDs for batch retrieve paths (MSXi and MEDAGTE) in SI_BS_SAP_TRBGB_CurrentEmployeeData_To_MultipleSystems flow.
--				  12/09/2016 RBH Added BSID for FRS-000828
--				  14/09/2016 NS Added BSID for dedicated adapter flows for FRS-712 (Material Flow)  
--				  20/09/2016 AC FRS-000154-Added BSID for SI_SV_CreateUpdate_Activity flow.
--				  22/09/2016 VV FRS-000833-Added BSID for SI_BS_PGZ_VALOBOM_To_SAP_TRBGB flow.
-- 				  26/09/2016 AC FRS-000152-Added BSID for SI_SV_CreateUpdate_CareHireEvent flow.
--				  29/09/2016 AS FRS-000790 LMS Vehicle updates
-- 				  30/09/2016 VV Added entry for FRS-837
--				  04/10/2016 KT Changed BSID from SI_BS_SAP_TRBGB_VEHICLE_GXS_PARTS to SI_BS_SAP_TRBGB_VEHICLE_ALL_PARTS
-- 				  26/10/2016 SB Added entry for FRS-823
-- 				  26/09/2016 AC FRS-000155-Added BSID for SI_SV_CreateUpdate_Appointment &  SI_AD_CANONICAL_APPOINTMENT_MT_OUT flow.
--  			  28/10/2016 SB Added entry for common outbound BAPI adapter flow, 'SI_AD_SAP_GTS_BAPI_VEHICLE_Outbound', conceived against work of FRS-000823.
--                31/10/2016 NS Added entry for IA-258 new BS flow; new design
-- 				  31/10/2016 NS Added entry for IA-258 new SAP SMART China BAPI Inbound Adapter flow
--  			  31/10/2016 NS Added entry for IA-258 new SAP SMART France BAPI Inbound Adapter flow
--  			  02/11/2016 TK Added entry for FRS-824 new GTS SAP BAPI Inbound Adapter flow and for business flow(SI_BS_SAP_GTS_Product_Classification_Data_To_CUSSTOMS)
-- 				  04/11/2016 TK Updated entry for FRS-824 for business flow(SI_BS_SAP_GTS_Product_Classification_Data_To_CSTMS)
--				  04/11/2016 AC FRS-000156-Added BSID for SI_SV_ReplicateCampaign
-- 				  07/11/2016 SB Updated entry for FRS-823, post design review.
-- 				  10/11/2016 TK Updated entry for FRS-824, post design review.
-- 				  10/11/2016 VV Added entry for FRS-000153
--				  11/11/2016 NS Added entry for IA-000258 new SAP eSMART BAPI Inbound Adapter flow
-- 				  14/11/2016 TK Added entry for IA-000355 new SAP HMRC BAPI Outbound Adapter flow
-- 				  17/11/2016 TK Added BSID for IA-000074(IFU4179) and SAP emsart outbound adapter V2 
--				  22/11/2016 PP Added BSID for FRS-000839
--				  23/11/2016 SB Added BSID for IA-000221
--                25/11/2016 SK Added BSID for FRS-000156(IFU4244)
--                07/12/2016 SK Removed duplicate entries for FRS-000156
--                08/12/2016 AS FRS-000841 Get List-Price (DVLA VED) Details
--                28/12/2016 AS FRS-000130 Replicate Dealer (New feed to GCM)
-- 				  06/01/2017 VV Added entry for FRS-838
-- 				  06/01/2017 VV Updated the BSID for FRS-838
--				  12/01/2017 CM Added new BSIDs for FRS-000840
--                18/01/2017 AS FRS-000661, IFU4365 BSID renamed
-- 				  02/02/2017 VV Added entry for FRS-000705
-- 				  03/02/2017 RBH Added entry for FRS-000786
--				  05/02/2017 TK Updated BSID for SAP ALE Outbound to SMART China adapter by removing V2 concatenated
-- 				  06/02/2017 SB Added entry for IA-000142 - IFU4401 (D42 Shipping reference to SAP GTS)
-- 				  06/02/2017 TK Added entry for FRS-000787
-- 				  06/02/2017 RBH Added entry for SAP Smart Inbound Adapter.
--				  07/02/2017 CM Added new BSIDs for FRS-000844
--				  08/02/2017 SB Updated the entry for IA-000142 - IFU4401. The description is updated to include the interface number.
--                08/03/2017 SB Added entry for FRS-000107 (IFU4438 - Vista Order Replicate to XROAD)
--				  10/03/2017 CM Added new BSIDs for FRS-000799
--				  17/03/2017 asannag2 Added new BSIDs for FRS-000847
--				  23/01/2017 asannag2 IA-000065 never went to prod, commented entry
-- 				  24/03/2017 tksheers Added missing BSID entry for existing AD-00012 - SI_AD_SAP_TRB_TD_ALE_RFC_04_Inbound adapter.
--                24/03/2017 AC Added entry for FRS-000107 (IFU4515 - Vista GOF to Map Suppliers)
--				  31/03/2017 RBH Added entry for FRS-000259 (IFU4514)	
-- 				  04/04/2017 VV IFU 4433/IFU 4539 (Added new Business Service ID FRS-000278)
-- 				  06/04/2017 VV IFU4434 FRS-000277 Added new entry for ASN request to CJLR over MQ
--				  10/04/2017 RBH Added entry for FRS-000258 (IFU4561) 	
--				  11/04/2017 VV Added entry for SAP Outbound Adapter SI_AD_SAP_TRB_ALE_TD_Outbound
--				  11/04/2017 cmarret1 Updated BSIDs for FRS-000003
--				  13/04/2017 cmarret1 Updated BSID for AD-00015
--				  19/04/2017 asannag2 IA-000107, PODS interface
--				  26/04/2017 asannag2 FRS-000840, GCAMP UPS Warranty Campaign to VISTA
--				  27/04/2017 RBH Added entry for FRS-000003- Encore (IFU4476)
-- 				  04/05/2017 VV Added entry for FRS-000705 migration
--				  09/05/2017 VV Added entry for FRS-000842(IFU4278)
--				  09/05/2017 AC Added entry for FRS-000799(IFU4617)
--				  15/05/2017 AC Added entry for FRS-000160(IFU4637)
--				  15/05/2017 TK Added entry for FRS-000159(IFU4635)
--				  22/05/2017 RBH Added entry for SAP ALE Stone Outbound Adapter (IFU4634)
--				  22/05/2017 asannag2 BSID renamed as part of move to new build process; IFU4640
--				  25/05/2017 KT IFU4633 BSID for FRS-000352 renamed from SI_BS_PLO_VEH_CJLR_EVEHORDREQ to SI_BS_PLO_VEH_ALL_EVEHORDREQ
--				  01/16/2017 TK IFU4658 Updated BSID from SI_BS_SAP_TRBGB_VEHICLE_ALL_PARTS to SI_BS_SAP_TRB_VEHICLE_ALL_PARTS
--				  02/06/2017 KT IFU4659 Updated BSID for IA-000029 to SI_BS_PLO_SALESORDER_SAP_TRB_VEHORDRQ
--				  06/06/2017 AC Added entry for FRS-000003- Encore (IFU4699- OA)
--				  09/06/2017 asannag2 Added entry for SI_AD_SAP_TRB_ALE_HR_RFC_01_Inbound (FRS-000720), adapter flow moved to new build process
-- 				  19/06/2017 RBH Added entry for FRS-870 Vehicle Derivative and Derivative Features To BODS
--				  21/06/2017 VV updated the entries for FRS-650 as the BSID is changed from TRBGB to TRB
--				  29/06/2017 TK Added entry for generic HTTP inbound and reply adapter
-- 				  03/07/2017 CM FRS-000139 IFU4735, Added BSID for the new build removed existing BSID 
--				  05/07/2017 RBH Added entry for FRS-00869 VIN to Order Interface (Plant Graz to ESB) - Encore
--				  10/07/2017 TK Added entry for FRS-000829 TurboSAP and TMS Integration - TD
--				  12/07/2017 asannag2 Added entry for FRS-000867, DigitalCoC
--				  17/07/2016 TK IFU-4773: Updated BSID for FRS-000812
--				  17/07/2017 RBH Added entry for FRS-00842 Invoice Payment Status Updates
--				  21/07/2017 SB Added entry for FRS-00861 Employee Data to GrassRoot (SAP to CANON FRS-720 to FRS-861) - VBR
--				  24/07/2017 SB Updated BSID for FRS-00861 Employee Data to GrassRoot (SAP to CANON FRS-720 to FRS-861) - VBR
-- 				  25/07/2017 KT Added BSID for FRS-000871
-- 				  25/07/2017 asannag2 IA-000115, BSID renamed (from SI_BS_SAP_TRBGB_PAYMT_EIPAY_BACSFILE to SI_BS_SAP_TRB_MULTI_PAYINFO), IFU4792 - flow moved to new build process.
-- 				  25/07/2017 asannag2 FRS-000868 (IFU4800), new interface.
-- 				  08/08/2017 CM FRS-000848 BSID added
--				  09/08/2017 RBH Added entry for FRS-00863 - Stock Levels SAP-ECC to Zoller-TMS
-- 				  08/08/2017 CM FRS-000848 SAP Adapter BSID added
--				  11/08/2017 SB Added entry for FRS-00880 Vehicle weight & ICCID2 (SAP Turbo to Russia NSC) - Boston
-- 				  16/08/2017 asannag2 FRS-000792 HR Interface - ESB to NGA UK, IFU4679, new interface
-- 				  17/08/2017 tksheers Added entry for SOAP STD Outbound adapter
-- 				  16/08/2017 asannag2 IFU4826, FRS-000102 FMS to Enovia AIMS Service, new interface
--				  18/08/2017 sbawri IFU4819, BAPI Inbound Adapter - FRS-000880 Vehicle weight & ICCID2 to Russia NSC - Boston - Russia (RU)
--				  24/08/2017 SB Added entry for FRS-00881 Vehicle weight & ICCID2 (VCATS to SAP Turbo) - Boston - Russia (RU) - CR1426
--				  24/08/2017 SB Added entry for SI_AD_SAP_TRB_BAPI_Vehicle_Outbound (FRS-000881) - Boston - Russia (RU) - CR1426
--				  07/09/2017 TK Added entry for FRS-000872 - SCS Recon Part information request to SAP APO and BoM result
--				  11/09/2017 KT IFU4873 - Amended BSIDs for FRS-000625
--				  14/09/2017 SB Added entry for FRS-00882 Certificate of Conformity Trigger data (SAP eSmart to WVTA) - Boston (Belgium) CR-1415
--				  14/09/2017 TK Added entry for FRS-00787 Funding Response(GL Connect to SAP eSmart)
--				  15/09/2017 RBH Added entry for FRS-00786 Funding Request(SAP eSmart to GL Connect)
--				  18/09/2017 SB Added entry for SI_AD_SAP_TRBGB_ALE_RFC_12_Inbound (FRS-000847) - IFU4890
-- 				  20/09/2017 asannag2 FRS-000866, Sales Purchase Tax Returns from SAP eSmart to GST India
-- 				  20/09/2017 cmarret1 FRS-000799, Added flow details for VISTA IFU4911 change.
--				  22/09/2017 SB Added entry for SI_AD_SAP_ESM_ALE_VEHDATA_RFC_06_Inbound (FRS-000882) - IFU4877
--				  25/09/2017 RBH Added entry for FRS-000778 Publish Vehicle Status	
--				  03/10/2017 TK Added entry for FRS-000107 Order Replicate(Vista to Salesforce LMS)
--				  05/10/2017 AC Added entry for FRS-000151 Canonical Product Reference(BRS to Salesforce LMS)
--				  05/10/2017 AC Added entry for FRS-000130 Replicate Dealer (DDB to WT)
--				  10/10/2017 SB Added entry for IA-000124 (Mizuho bank) IFU-4934
--				  11/10/2017 RBH Added entry for FRS-000864- Stock Levels Zoller-TMS to SAP-ECC 
--				  13/10/2017 SB Updated entry for FRS-000124 (Mizuho bank) IFU4934 - updated the BSID.
--				  18/10/2017 RBH Added entry for FRS-00787 Funding Response(Mizuho to SAP eSmart) - IFU 4957
-- 				  20/10/2017 TK Added entry for FRS-000779- End life cycle of Vehicle SORA to SAP-ESM
-- 				  26/10/2017 KT Added entry for FRS-000875
--				  01/11/2017 SB Added entry for FRS-000884 Automated ABS business service
--				  06/11/2017 SB Added entry for HTTP adapter flows, SI_AD_SCANNER_HTTP_Inbound and SI_AD_SCANNER_HTTP_Reply, and corrected entry for BS FRS-884
--				  07/11/2017 SB Added entry for outbound adapter created for FRS-000884 Automated ABS
--				  16/11/2017 KT Added entry for FRS-000883 - IFU5053 Darwin
--				  17/11/2017 TK Added entry for IFU5048, IFU5049 and IFU5050
--				  24/11/2017 TK Added entry for IFU5069(FRS-000876)
--				  27/11/2017 asannag2 IFU5085, FRS-000690 - SAP Turbo feed will now be moved under adapter component SI_AD_SAP_TRB_ALE_CIR_Outbound. The old entry will be commented.
--				  30/11/2017 SB Added entries for FRS-000885 Supplier Online Portal Integration via Covisint
-- 				  08/12/2017 sbawri Updated BSID SI_BS_GXS_VEHICLE_SAP_TRB_PARTS to SI_BS_MULTIPLE_VEHICLE_SAP_TRB_PARTS for IFU5129
--				  15/01/2018 asannag2 FRS-000707, IFU5178, BSIDs were renamed while moving the flow to new build process
--				  16/01/2018 asannag2 FRS-000679, IFU5179, BSIDs were renamed while moving the flow to new build process
--				  23/01/2018 asannag2 FRS-000719, IFU5196, BSID renamed while moving the flow to new build process
--				  29/01/2018 asannag2 IA-000044, IFU5198, BSID renamed as flow is moved to new build process

-----------------------------------------------------------------------------------------------------------------------------------------
SET DEFINE OFF

DELETE FROM SI_BUSINESS_SERVICE_DETAILS;

INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_GLCOL_GLPOS_FTPADAPTERIN','GL Collector Financials Interface to SAP and PSGL','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_PGLAR_GLPOS_FTPADAPTERIN','PSGL AR Interface to SAP','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SYA1_EXRTE_FTPADAPTERIN','Monex Exchange Rate feed to SAP','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'FINAN_GLCOLL_GLPOS_SAP01_GLCJRNSMS','GL Collector Financials Interface to PSGL','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_ESB_PWDEXPRYNF','Password Notification','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_JAVIS_BILLG_SAPE1_INVOICEREQ','JAVIS Billing Requests To SAP eSmart','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SIT_SAPAD_LOWD_MQSERV_ALEOUT','SAP ALE Outbound Adapter','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SAPE1_BILLG_INVCEOUV_IN','SAP eSmart Invoice and OUV data to Batch Process','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SAPE1_BILLG_INVCEOUV_OUT','Batch Process Invoice and OUV data to JAVIS FTP adapter','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SAPE1_ARCH_ESYAR_MISCINVC','SAP eSmart Miscellaneous Invoices to Easy Archive','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SAPE1_ARCH_ESYAR_PO','SAP eSmart Purchase Orders to Easy Archive','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SAPE1_ARCH_ESYAR_VEHINVC','SAP eSmart Vehicle Invoices to Easy Archive','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SAPE1_PAYMT_DEUBK_PAYTM','SAP eSmart MT101 to Deutsche Bank','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_ADP_JAVIS_FTPOUT','JAVIS FTP Outbound Adapter','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SAPE1_INVOICE_FAR_INVDATA','SAP eSmart to FAR Legacy','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_BRS_MQSERV_MQIN','MQ Inbound Adapter for BRS','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_PLO_MQSERV_MQOUT','MQ Outbound Adapter for PLO','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_BRS_SALESORDER_PLO_MDUPD','BRS Master Data Update to PLO','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_CAT_PARTS_SAPE1_INVOICES','CAT Parts Invoices to SAP eSmart','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_FGAFS_INV_SAPE1_CREDITAV','FGAFS Credit Availability to SAP eSmart','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SAPE1_INV_FGAFS_COMPMOVE','SAP eSmart Compound Movements to FGAGS','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_SMACN_ VEHICLE_DMS_PRICINGINF','SAP SMART Retail and Wholesale pricing to China DMS via MFT','kmccorma');

--IFU3924 Framework migration.Removed entry for SI_BS_ALL_VEHSERV_SAP_TRBGB_MVRISREG and SI_BS_ALL_VEHSERV_SAP_TRBGB_AFRLREG
--INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_VEHSERV_SAP_TRBGB_MVRISREG','SAP TURBO WAVE0B - Registrations Capture Data from MVRIS via MFT to SAP TURBO','kmccorma');
--INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_VEHSERV_SAP_TRBGB_AFRLREG','SAP TURBO WAVE0B - Registrations Capture Data from AFRL via MFT to SAP TURBO','kmccorma');
--Added entry SI_BS_ALL_VEHSERV_ALL_VEHREGIS for IA-207 IFU3924
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_VEHSERV_ALL_VEHREGIS','SAP TURBO WAVE0B - Registrations Capture Data from MVRIS via MFT to SAP TURBO and VISTA','lhake');

INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_FGFSH_DEALER_SAP_TRBUK_KJ03','SAP TURBO WAVE0B - ESB FGAFS Credit Limit (KJ03) to SAP Turbo','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_EPICS_INVOICES_SAP_ESMDE_EXPINV','ESMART - EPICS Landrover Export Invoices to SAP Esmart Germany','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_JGVAC_INVOICES_SAP_ESMDE_EXPINV','ESMART - EPICS Jaguar Export Invoices to SAP Esmart Germany','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PROFT_VEHICLE_SAP_TRBGB_CLASCONFMT','TURBO - ProFET Classification and Configurable Material to SAP Turbo UK','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_TRBGB_BAPI_OUTBOUND','Outbound SAP BAPI adapter for Turbo UK','kmccorma');
NSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_SMTCN_BAPI_INBOUND','Inbound SAP BAPI adapter for Smart China','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_GENERIC_REPLY','Generic SAP BAPI reply adapter','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_SMTCN_VSTAT_MFT_CHINADMS','Smart China Vehicle Status from SAP to MFT','kmccorma');
--INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_FGAFS_MFT_FUNDACCEPT_SAP_TRBGB_KJ12','FGAFS Funding Acceptances from MFT to SAP Turbo UK','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_BRS_SALESORDER_ALL_PRCMATMAS','Pricing Material Master from BRS to SAP, PLO','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_TRBGB_ALE_OUTBOUND','Outbound ALE adapter for SAP Turbo','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_FGFSH_VEHICLE_SAP_TRBUK_KJ13','SAP TURBO WAVE0B - ESB FGAFS Demo Conversions (KJ13) to SAP Turbo','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PLO_SALESORDER_SAP_TRB_VEHORDRQ','SAP TURBO WAVE0B - Vehicle and Order Create-Amend-Cancel (PLO to SAP TURBO)','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_D42_HMRC_RIC_EXPDECL','SAP TURBO WAVE0B - HMRC Export Declarations (D42 to RICARDO)','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_VEHSERV_TO_ALL_VEHTRNSUPD','Vehicle Transfers from DSM,NVM,Vista to SAP Turbo,HUB2','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_NVM_MQSERV_MQIN','NVM MQ Inbound Adapter','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_NVM_MQSERV_MQOUT','NVM MQ Outbound Adapter','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_VISTA_MQSERV_MQIN','VISTA MQ Inbound Adapter','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_HUB2_MQSERV_MQOUT','HUB2 MQ Outbound Adapter','kmccorma');
-- 29/01/2018, IFU5198, BSID renamed as flow is moved to new build process, old BSID "SI_BS_D42_VEH_SAP_TRBGB_VEHSTATUSUPD", new BSID "SI_BS_D42_SAP_TRB_VEHSTATUPD"
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_D42_SAP_TRB_VEHSTATUPD','D42 Vehicle Status Updates to SAP Turbo','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_BBSS_CUSTOMER_ALL_CUSTDETALS','BBSS Customer Details to Multiple Systems','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_BBSS_VEHSERV_TO_ALL_VEHDATA','Vehicle Data from BBSS to SAP eSmart, Monroney, ESPS, DMI, ORBITS','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_MNRNY_MQSERV_MQOUT','Monroney MQ Outbound Adapter','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_BRS_VEH_SAP_ESM_VEHSPECSDERIV','BRS Vehicle Specification Derivatives to SAP eSmart','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_BRS_VEH_SAP_ESM_VEHSPECSFEAT','BRS Vehicle Specification Features to SAP eSmart','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEH_ALL_ALERTUPD','SAP Turbo Vehicle Alert Updates All','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEH_PLO_ALERTUPD','SAP Turbo Vehicle Alert Updates to PLO','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEH_D42_ALERTUPD','SAP Turbo Vehicle Alert Updates to D42','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_VISTA_VEHICLE_ALL_GOF','Vista General Order File to Multiple Systems','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_VISTA_SALESORDER_SAP_ESM_GOFVISTA','Vista General Order File to SAP eSmart BAPI VISTA','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_VISTA_SALESORDER_SAP_ESM_GOFVCHAR','Vista General Order File to SAP eSmart BAPI VCHAR','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRB_MULTI_PAYINFO','SAP Turbo Payment Info to EigerPay/CITI','asannag2');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESMUS_VEH_MNRNY_WINDOWLABEL','SAP eSmart Window Labels to Monroney','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_FGFSH_DEALER_SAP_ESMDE_KJ03','FSFHS KJ03 to SAP eSmart','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_HTTP_OUT','HTTP Outbound Adapter','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_ESMZA_FTPOUT','SAP eSmart South Africa FTP Outbound Adapter','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_INV_SAP_ESMUS_ACCPAY','MultipleSystems Accounts Payable To eSmart US','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESM_VEH_WVTA_COCTRIG','SAP eSmart CoCs to WVTA via MFT','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_NAVTQ_BILLG_SAP_ESMUS_ACCREIV','MS (NAVTEQ) to SAP eSmart','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_DTIRE_BILLG_SAP_ESMUS_ACCREIV','MS (Dealer Tire) to SAP eSmart','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_WVTA_VEH_SAP_ESMDE_HOMOLOGATION','FTP to SAP WVTA Vehicle homologation','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_MONEX_EXRTE_SAP_ESM_EX_RATE','Monex Exchange Rates to SAP eSmart','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CATPR_INVOICE_SAP_ESM_ACNTRECVNA','Caterpillar NA Accounts Receivable to SAP eSmart IA 76','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CATPR_INVOICE_SAP_ESM_ACNTRECV','Caterpillar None NA Accounts Receivable to SAP eSmart IA 76','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_INVOICE_SAP_ESM_BULKSHIP','SAP Turbo Bulk Invoice Shipping To All eSmart','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_ESMALL_ALE_OUTBOUND','Generic outbound SAP ALE eSmart adapter','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_ESB_FTP_SA_OUT','Outbound FTP adapter for South Africa SAP','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESMALL_INVOICE_FGFSH_KJ10KJ33','SAP eSmart Fund Req and Comp Move to FGAFS','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_HR_MSXI_SECRTYDATA','SAP Turbo HR Security Data to MSXi','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESM_PAYMT_ALL_BNKTRNDRFT','SAP eSmart Bank Transactions Drafts to Multiple Systems','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESM_PAYMT_COMER_BNKTRNDRFT','SAP eSmart Bank Transactions Drafts to Comerica','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESM_PAYMT_SCTIA_BNKTRNDRFT','SAP eSmart Bank Transactions Drafts to Scotia','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_POSITION','SAP Turbo HR Positions to WAJ1/Catalyst','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_INVOICE_SAP_ESM_WRNTYBILLG','Multiple Systems Warranty Claims Billing to SAP eSmart','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_LISA_INVOICE_SAP_ESM_WRNTYBILLG','LISA Warranty Claims Billing to SAP eSmart','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_GACES_INVOICE_SAP_ESM_WRNTYBILLG','GACES Jag Warranty Claims Billing to SAP eSmart','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_WVTA_VEH_SAP_ESM_HOMOLGTION','WVTA Homologation Veh Reg data to SAP eSmart','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESM_PAYMT_COMER_BNKTRNPYMT','SAP eSmart Bank Transaction Sent Payments for Comercia Bank','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CANON_VEHSERV_D42_VEHSTATUS','Vehicle Status Events from Canonical Adapter to D42','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_INVOICE_SAP_TRBGB_RECVRYCOST','Mult Sys SupplierCost and TransRecoveryCost to SAP Turbo','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_UNIPT_VEH_SAP_TRBGB_SERVICEPART','Unipart JAGServiceParts to SAP Turbo','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESMUS_VEH_MNRNY_INFOPRINT','SAP eSmart New Vehicle Information Printing to Monroney','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_D3_MQSERV_MQOUT','D3 MQ Outbound Adapter','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_VISTA_SALESORDER_ALL_NONSPECAMD','Non Spec Amends from VISTA to SAP Turbo, D3','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_COSTCENTRE','SAP Turbo HR Cost Centre to WAJ1/Catalyst','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_PAYMT_JPMOR_AUTOPAYMNT','SAP Turbo Automatic Payments to JP Morgan','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESM_VEH_KBA_TITLEDOCDE','SAP eSmart Vehicle Title Documents to KBA via GXS','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESM_VEHICLE_BBSS_VEHSTKREP','SAP eSmart Vehicle Stock Reports to BBSS via MFT','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_CUREMPDATA','SAP Turbo HR Current Emp Data to Multiple Systems','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESMUS_VEH_ORBIT_STOCKDATA','SAP eSmart Stock Data to Orbits','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESMUS_VEH_ORBIT_ORDERDATA','SAP eSmart Order Data to Orbits','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEH_ALL_SFTYRECALL','SAP Turbo Warranty Recall Campaign to CUPOD or GRASSROOTS','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_FGFSH_INVOICE_SAP_ESM_FUNDACKJ12','FGAFS via FiSH Fund Accep to SAP eSmart','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_FGFSH_INVOICE_SAP_ESM_FUNDRJKJ11','FGAFS via FiSH Fund Rejections to SAP eSmart','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PCII_VEH_SAP_TRBGB_LRSERVPART','PCII Land Rover Service Parts to SAP Turbo','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_PAYMT_CAT_PAYMNTINFO','SAP Turbo Payment Info To Caterpillar','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESM_INVOICE_PRM_FINDOCS','SAP eSmart NA Financial_Docs To Premier_Docs','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_ESMALL_BAPI_INBOUND','SAP ESMALL generic inbound BAPI adapter','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_POSDATA','SAP Turbo HR Position Data to MultipleSystems','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_HMRC_ALL_CSMSREPORT','SAP Turbo UK to HMRC Customs Reports','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SHFTD_BILLG_SAP_ESMUS_ACCREIV','MS (Shift Digital) to SAP eSmart','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_BBSS_BILLG_SAP_ESMUS_ACCREIV','MS (BBSS) to SAP eSmart','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CRPTR_BILLG_SAP_ESMUS_ACCREIV','MS (Creative Partners) to SAP eSmart','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_MNACS_BILLG_SAP_ESMUS_ACCREIV','MS (MINACS) to SAP eSmart','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESM_VEHICLE_DDW_PORTOPT','SAP ESM NA Port Updated Option to DDW','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_HR_CVMS_EMPLOYEE_TRBGB_VEHICLES','HR CVMS employee vehicle data to SAP TRBGB','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESM_VEH_ALL_VEHLEVELDET','SAP eSmart Vehicle Level Detail To Multiple Systems','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESM_VEH_PVOS_VEHLEVELDET','SAP eSmart Vehicle Level Detail To PVOS','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESM_VEH_AUTOP_VEHLEVELDET','SAP eSmart Vehicle Level Detail To Autoport','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_VEHICLE_SAP_ESM_STATUSUPD','Vehicle Status Updates from Multiple Syatems to SAP eSmart','kmccorma');
-- 23/01/2017 AS IA-000065 never went to prod, commented entry
--INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_VISTA_VEHICLE_SAP_ESM_GOFSTRAGIC','Vista GOF to SAP eSmart','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESM_INVOICES_HYPER_FINREPORT','eSmart All Financial Report to Hyperion','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_JPMOR_PAYMT_JLRB_ACKNWLGMNT','JP Morgan Payment Acknowledgement to JLR Business','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_KBAGX_VEHSERV_TO_SAP_ESMDE_TSNXREF','TSN Xref from KBA to SAP eSMART','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_B2B_INVOICE_SAP_TRBGB_VERIFINV','Verified Invoices from B2B to SAP Turbo GB','kmccorma');
-- Changes for IFU-1088. Removed BDA entry for IA-000074
-- INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_BDA_BILLG_SAP_ESMUS_ACCREIV','MS (BDA) to SAP eSmart','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_WURTH_BILLG_SAP_ESMUS_ACCREIV','MS (WURTH) to SAP eSmart','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_GSDB_VNDRMASTER','SAP Turbo Vendor Master Updates to GSDB','rbabu');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SWORD_INVOICE_SAP_TRBGB_WARRTYPART','SWORD Warranty Part Returns Service to SAP Turbo','spatel5');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_MONEX_EXRTE_SAP_ESM_EXRATE','Monex Exchange rate to SAP esmart','vyadav1');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_MONEX_EXRTE_SAP_TRBGB_EXRATE','Monex Exchange rate to SAP esmart','vyadav1');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_APAK_VEHICLE_SAP_TRBGB_USEDCARDATA','APAK Used Cars Data To SAP Turbo','rbabu');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_RADS_SAP_TRB_ENGTIME','RADS Engineering Time To SAP Turbo','cmarrett');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRB_RADS_PROJCAT','SAP Turbo GB Project Category Status update to RADS','cmarrett');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRB_MISC_RADS_ENGREQ','ESB TRBGB Engineering Request To RADS','cmarrett');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRB_MISC_RADS_PROJCAT','ESB TRBGB Project Category To RADS','cmarrett');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_D42_VEH_SAP_ESMALL_VEHEVENTS','D42 Vehicle Events to SAP eSmart','marrowsm');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_WAJ1_MFT_TRADEUNION_SAP_TRBGB','WAJ1 Trade Union Data to SAP Turbo','marrowsm');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_EMPDATACHANGES','HR Employee Data Changes','marrowsm');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_HR_TO_SAP_AVGSHIFT','HR Average Shift to SAP Turbo UK','abadal');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRB_HR_PCARS_SECACCCNTL','HR Security Access Control to PCARS','vyadav1');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_DEALER_DLRPL_REMITTANCE','Dealer Remittance to Dealer Portal','cmarrett');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_DEALER_DLRPL_REMITTANCE1','Dealer Remittance to Dealer Portal Additional','cmarrett');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_GSDB_VENDRMASTER','SAP Turbo Vendor Master Updates to GSDB ','pgregory');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_GEMSL_VEH_JVW_WARCDECONV','SGEMSL Warranty Conversion Code to JVW','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_MISC_PIMS_ORDERINFO','SAP Turbo Order Details to PIMS','cmarrett');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_MISC_PIMS_BOOKINGTIM','PIMS Booking Time to SAP Turbo','cmarrett');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_CUPID_SAP_TRBGB_WTYSFTYRCL','CUPID Warranty Recall to SAP Turbo','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_GRSRT_SAP_TRBGB_WTYSFTYRCL','GRASS ROOTS Warranty Recall to SAP Turbo','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRB_FINANCIALS_HYPR_FINANREPRT','SAP Turbo Financial Report to Hyperion','spatel5');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESM_PAYMENTS_ALL_BNK_DIRDEBT','SAP eSMART Bank Direct Debits To Multiple Systems','cmarrett');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_NVM_VEHICLE_SAP_TRBGB_VEHTRANFER','NVM Vehicle Transfers Batch Update To SAP TRB','hmistry');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_PAYMT_SAP_ESM_BNKSTAKCOM','COMERICA AckAndBankStmnt To SAP eSmart','asannago');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_PAYMT_SAP_ESM_BNKSTAKSCO','SCOTIA BankStmnt To SAP eSmart','asannago');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_DEUTB_BNKREPLY_SAP_ESMDE_ACKSTAT','DEUTSCHE AckAndBankStmnt To SAP eSmart','cmarrett');

--IA-000027 entries start:
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_AiOCN',      'IA-000027 - SAP Turbo Bulk Invoice to AiO China',             'rtaylor3');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_AiOFR',      'IA-000027 - SAP Turbo Bulk Invoice to AiO France',            'rtaylor3');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_BOBBE',      'IA-000027 - SAP Turbo Bulk Invoice to BOB Belgium',           'rtaylor3');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_D42',        'IA-000027 - SAP Turbo Bulk Invoice to D42',                   'rtaylor3');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_ESMDE',      'IA-000027 - SAP Turbo Bulk Invoice to eSmart Germany',        'rtaylor3');
--INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_ESMUS',      'SAP Turbo Bulk Invoice to ?',                     'rtaylor3');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_ESMBE','IA-000027 - SAP Turbo Bulk Invoice to eSmart Belgium','rbhamid');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_ESMNL','IA-000027 - SAP Turbo Bulk Invoice to eSmart NetherLands','rbhamid');
-- Added for IFU1981
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_ESMAU','IA-000027 - SAP Turbo Bulk Invoice to eSmart Australia','rbhamid');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_ESMALL','IA-000027 - SAP Turbo Bulk Invoice to ALL','rbhamid');

INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_FVF3',       'IA-000027 - SAP Turbo Bulk Invoice to FVF3',                   'rtaylor3');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_JAGFiSHKJ10','IA-000027 - SAP Turbo Bulk Invoice to Fsh (KJ10)',            'rtaylor3');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_HPFM',       'IA-000027 - SAP Turbo Bulk Invoice to HPFM',                  'rtaylor3');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_IIS',        'IA-000027 - SAP Turbo Bulk Invoice to IIS(D3)',               'rtaylor3');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_JAGNA',      'IA-000027 - SAP Turbo Bulk Invoice to Jag North America (NA)','rtaylor3');
--INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_JAVIS',      'SAP Turbo Bulk Invoice to ?',                     'rtaylor3');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ALL_INVCRDDETS',              'IA-000027 - SAP Turbo Bulk Invoice to Multiple Systems',      'rtaylor3');

INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_NSCRU',      'IA-000027 - SAP Turbo Bulk Invoice to Russia NSC',            'rtaylor3');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_PICC',       'IA-000027 - SAP Turbo Bulk Invoice to PICC',                  'rtaylor3');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_SFS',        'IA-000027 - SAP Turbo Bulk Invoice to SFS',                   'rtaylor3');
--INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SHELL',                                 'SAP Turbo Bulk Invoice to ?',                     'rtaylor3');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_VISTA',      'IA-000027 - SAP Turbo Bulk Invoice to VISTA',                 'rtaylor3');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_WPS',        'IA-000027 - SAP Turbo Bulk Invoice to WPS (Cobelfret)',       'rtaylor3');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_ZA',         'IA-000027 - SAP Turbo Bulk Invoice to South Africa',          'rtaylor3');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_LISA',       'IA-000027 - SAP Turbo Bulk Invoice and Credits to LISA',      'kmccorma');
--IA-000027 entries end:

--IA-000332
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_MISC_AWS_EXPREFDATA','IA-000332 - Expense Ref Data to AWS','cburger1');
-- FRS-259/FRS-003 AS 22/04/2013 Modify the BSID
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'FRS-000259 - SI_SV_VEHSV_PRODCTRL','Production Control Vehicle Service','spatel5');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_INFSV_EMAIL','Email Service Send','spatel5');

--	FRS-258 RBH Added new BSID entry (IFU4561)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PGZ_VEHICLE_WLCAR_PRODCTRL','FRS-000258 Production Control Vehicle service','rbhamid1');

--IA-000103
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CITIB_PAYMT_SAP_TRBGB_PURCHCARDS','IA-000103 - CITIBANK Purchase Card Info To SAP Turbo','cmarrett');
-- FRS-258
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHSV_VEHPROPDTA','FRS-000258 - Vehicle Property Data Service','spatel5');

--IA-000104
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CITIB_PAYMT_SAP_TRBGB_TRAVLCARDS','IA-000104 - CITIBANK Travel Card Info To SAP Turbo','cmarrett');

--IA-000208
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_INVSV_ASSCLAIMS','IA-000208 - Roadside Assistance Claims Service','spatel5');

--IA-000296
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_POLK_VEH_SAP_TRBGB_WTYRESTRICTION','IA-000296 - POLK Warranty Restrictions to SAP Turbo','pgregory');

--IA-000046 / IFU951
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_FGFSH_INVOICES_SAP_TRBGB_KJ12JAG','IA-000046 - FGAFS KJ12 Fund Accept Jag to SAP Turbo','spatel5');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_FGFSH_INVOICES_SAP_TRBGB_KJ12LR','IA-000046 - FGAFS KJ12 Fund Accept LR to SAP Turbo','spatel5');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_FGFSH_INVOICES_SAP_TRBGB_KJ12JAGSIN','IA-000046 - FGAFS KJ12 Fund Accept Jag Single Msg to SAP Turbo','spatel5');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_FGFSH_INVOICES_SAP_TRBGB_KJ12LRSIN','IA-000046 - FGAFS KJ12 Fund Accept LR Single Msg to SAP Turbo','spatel5');

--IA-000171 CB
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_HR_PMTANDDED_SAP_TRBGB_TEMLR','IA-000171 - HR Payments and Deductions from JEM and TEM','cburger1');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_HR_PMTANDDED_SAP_TRBGB_TEMJR','IA-000171 - HR Payments and Deductions from JEM and TEM','cburger1');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_HR_PMTANDDED_SAP_TRBGB_JEMLR','IA-000171 - HR Payments and Deductions from JEM and TEM','cburger1');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_HR_PMTANDDED_SAP_TRBGB_JEMJR','IA-000171 - HR Payments and Deductions from JEM and TEM','cburger1');


--IA-000172 AS 04/06/2013
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PAYRL_GLENTRY_SAP_TRB_JAGHOURLY','IA-000172 - Payroll GL Entries to SAP TRB','asannago');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PAYRL_GLENTRY_SAP_TRB_JAGMONTHLY','IA-000172 - Payroll GL Entries to SAP TRB','asannago');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PAYRL_GLENTRY_SAP_TRB_LRHOURLY','IA-000172 - Payroll GL Entries to SAP TRB','asannago');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PAYRL_GLENTRY_SAP_TRB_LRMONTHLY','IA-000172 - Payroll GL Entries to SAP TRB','asannago');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PAYRL_GLENTRY_SAP_TRB_JLRMONTHLY','IA-000172 - Payroll GL Entries to SAP TRB','asannago');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PAYRL_GLENTRY_SAP_TRB_HALHOURLY','IA-000172 - Payroll GL Entries to SAP TRB','asannago');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_MULTI_SAP_TRB_GLENTNGASK','IA-000172 - Payroll GL Entries to SAP TRB','rbhamid1');

--SOAP Outbound Adapter RB 05/06/2013
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SOAP_MT_OUT','SOAP MT Outbound Adapter','rbabu');

--FRS-000271
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHSV_ENGGCHANGE','FRS-000271 - Engineering Change Service','rbabu');

--FRS-000016
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_PRDSV_CODETRAN','FRS-000016 - Code Translation Service','pgregory');

--FRS-000259 IFU997
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHSV_VEHPROPSUB','FRS-000259 - Vehicle Property Data Subscription','spatel5');

-- eSmart Italy changes - CAF trigger to WVTA 10/06/2013
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CANON_VEHSERV_WVTA_CAFTRIGGER','SAP eSmart CAF Trigger to WVTA','cmarrett');

--FRS-000006
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_PRDSV_MASTFEATDC','FRS-000006 - Master Feature Dictionary Service','pgregory');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_ENOV_MQSERV_MQIN','Enovia MQ Inbound Adapter','pgregory');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_ACE_MQSERV_MQOUT','ACE MQ Outbound Adapter','pgregory');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_RMDV_MQSERV_MQOUT','RMDV MQ Outbound Adapter','pgregory');


--FRS-000260
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_WERS_ENGCHNG_MQ_IN','FRS-000260 - Engineering Change Inbound Adapter','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_WERS_ENGCHNG_MQ_OUT','FRS-000260 - Engineering Change Outbound Adapter','kmccorma');


--FRS-000109
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_CANON_CONTRACT','Contract Canonical Outbound Adapter','rtaylor3');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CONTRACTREPLICATE','FRS-000109 - Contract Replication','rtaylor3');
--INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CONTRACT_CREATEUPDATE','Contract Create/Update','rtaylor3');
--INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHACCREL_CREATEUPDATE','Vehicle Account Relationship Create/Update','rtaylor3');

--FRS-000326
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_INFSV_ECHO','FRS-000326 - Generic Echo Service','sgarapat');

--FRS-000007
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_PRDSV_EVENTCAL','FRS-000007 - Event Calendar','marrowsm');

--FRS-000111
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_GETACCTDTLS','FRS-000111 - Get Account Details Service','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_CANON_ACCOUNT','Account Canonical Adapter','kmccorma');

-- eSmart IA-000070 Italy changes - Multiple Systems Payments 02/07/2013
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESM_PAYMT_MULTI_BNKTRNPYMT','IA-000070 - SAP eSmart Multiple Systems Payments','cmarrett');

-- FRS-000110
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_SEARCHACCT','FRS-000110 - Search Account Service','kmccorma');

-- FRS-000108
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_ACCTCRTUPD','FRS-000108 - Account Create or Update Service','rtaylor3');

-- FRS-000107
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_ORDERREPLICATE','FRS-000107 - Order replicate Service','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_CANON_VEHICLE','Canonical Vehicle Adapter','kmccorma');

-- FRS-000116
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_VEHREFDATAREPLICATE','FRS-000116 - Vehicle Reference Data Replication Service','rtaylor3');

-- FRS-000009
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ACE_PRODUCT_ALL_OKTOUSELST','FRS-000009 - ACE Feature OK to use publish','pgregory');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_ENOV_MQSERV_MQOUT','Enovia outbound adapter','pgregory');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_PRDSV_FEATOK2USE','FRS-000009 - Feature OK to use request','pgregory');

-- FRS-000261
--04/10/2016 KT IFU4163 Changed BSID from SI_BS_SAP_TRBGB_VEHICLE_GXS_PARTS to SI_BS_SAP_TRBGB_VEHICLE_ALL_PARTS
--01/16/2017 TK IFU4658 Updated BSID from SI_BS_SAP_TRBGB_VEHICLE_ALL_PARTS to SI_BS_SAP_TRB_VEHICLE_ALL_PARTS
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRB_VEHICLE_ALL_PARTS','FRS-000261 - SAP Turbo Parts to Multiple Systems','kthanga4');
--08/12/2017 sbawri Updated BSID SI_BS_GXS_VEHICLE_SAP_TRB_PARTS to SI_BS_MULTIPLE_VEHICLE_SAP_TRB_PARTS for IFU5129
--INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_GXS_VEHICLE_SAP_TRB_PARTS','FRS-000261 - GXS Vehicle Parts to SAP Turbor','spatel5');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_MULTIPLE_VEHICLE_SAP_TRB_PARTS','FRS-000261 - GXS Vehicle Parts to SAP Turbor','spatel5');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_HTTP_INBOUND_PARTS','Inbound HTTP Adapter Vehicle Parts','spatel5');

-- FRS-000272
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHSV_PARTS','FRS-000272 - Vehicle Parts service','rbhamid');

--BAPI Inbound Adapter - IA-000070 SMART China - CM 12/08/2013
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_SMTCN_BAPI_INBOUND_BNKTRNPYMT','SMART China Inbound BAPI Adapter Flow','cmarrett');

-- FRS-000029
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_ENOV_VNDRMASTER','FRS-000029 - SAP Turbo Vendor Master Updates to Enovia','marrowsm');

-- FRS-000122
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_GETCMPGNSLIST','FRS-000122 - Get List of Campaigns for Dealer Service','vannare1');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_CANON_CAMPAIGN','Canonical Campaign Adapter','vannare1');

-- FRS-000121
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_GETCMPGNMBRS','FRS-000121 - Get Campaign Members for Campaign Service','rtaylor3');

-- FRS-000352
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PLO_VEH_ALL_EVEHORDREQ','FRS-000352 - External Vehicle Order Requests','rbhamid');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHSV_EVEHORDSTA','FRS-000352 - External Vehicle Order Status Service','rbhamid');

-- IA-000336
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_WERS_VEHICLE_SAP_TRBGB_VENDORTOOL','IA-000336 - WERS Vendor Tooling to SAP Turbo','pgregory');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_QUEUEMON','Queue Monitor','pgregory');

-- IA-000148
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_UNIPT_VEHSERV_SAP_TRBGB_PARTSPRICE','IA-000148 - Unipart Warranty Parts Pricing to SAP Turbo','spatel5');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_NEOV_VEHSERV_SAP_TRBGB_PARTSPRICE','IA-000148 - Neovia Warranty Parts Pricing to SAP Turbo','spatel5');

-- FRS-000113
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_GETCASESLIST','FRS-000113 - Get List of Cases Service','vannare1');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_CANON_CASES','Canonical Case Adapter','vannare1');

-- FRS-000267
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_VEHICLE_SAP_TRBGB_ENGREL','FRS-000267 - Engineering Changes to SAP Turbo','pgregory');

--FRS-000023
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_PRDSV_TOOLINS','FRS-000023 - Tool Instance','achibbe1');

--Canonical Activity Adapter
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_CANON_ACTIVITY','Canonical Activity Adapter','kmccorma');

--Canonical Lead Adapter
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_CANON_LEAD','Canonical Lead Adapter','kmccorma');

--IA-000163
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEH_AWS_PARTSDATA','IA-000163 - Wrnty Parts Data to AWS','asannago');

--IA-000273
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHSV_DEMANDUPD','IA-000273 - Parts Demand Data Update to JV-Bridge and CMMS3','rbabu');

--MFT HTTPS Adater entries
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_MFT_HTTPS_IN','MFT HTTPS Inbound Adapter','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_MFT_HTTPS_REPLY','MFT HTTPS Inbound Adapter','kmccorma');

--FRS-000017
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_PRDSV_GENSOLVE','FRS-000017 - Generic Solve Service','marrowsm');

--FRS-000112
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_CRTUPDLEAD','FRS-000112 - Create or Update Lead','kmccorma');

--FRS-000383
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_WERS_ECHGVDRTPAWS_MQIN','WERS Engineering change Adapter','cmarrett');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_WERS_ECHGVDRTPAWS_IN','FRS-000383 - WERS Engineering change - Business Service','cmarrett');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_WERS_ECHGVDRT_IN','FRS-000383 - WERS Engineering change - To Vendor Tooling','cmarrett');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_WERS_ECHGPAWS_IN','FRS-000383 - WERS Engineering change - To PAWS','cmarrett');

--FRS-000356
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PLO_VEHSERV_SAP_TRBGB_KDCREATE','FRS-000356 - PLO KD Vehicle Create to SAP Turbo','spatel5');

-- FRS-000128
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_CTUPSERREP','FRS-000128 - Create or Update ServiceOrRepair','vannare1');

--Canonical ServiceOrRepair Adapter
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_CANON_SERORREP','Canonical ServiceOrRepair Adapter','vannare1');

-- FRS-000266
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_LSZEB_VEHICLE_SAP_TRB_ENGPARTS','FRS-000266 - LSZEB Vehicle Engine Parts to SAP Turbo','rbhamid');

-- FRS-000120
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_GETLEADDTLS','FRS-000120 - Get Lead Details from SVCRM','kmccorma');

--FRS-000017 MQ Geneic Solve
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PLO_PRO_ACE_GENSOLVE','FRS-000017 - Generic Solve Requests','achibbe1');
COMMIT;

-- FRS-000119
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_GTLSTLEADS','FRS-000119 - Get List of Leads For Dealer from SVCRM','hmistry');

-- FRS-000130 (Service flow) 
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_REPLICTEDR','FRS-000130 - Replicate Dealer service','hmistry');

-- FRS-000130 (Canonical Trading Partner Adapter entry)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_CANON_TRDEPARTNR','Canonical Trading Partner Adapter','hmistry');

-- FRS-000127 (Service flow) 
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_CRTUPDPRTTECHFSE','FRS-000127 - CrtUpd Part Tech or FSE Issue','kmccorma');

-- FRS-000073 (Service flow and Outbound MQ Adapter) 
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ENOV_PRODUCT_VCATS_EBOM','FRS-000073 - Enovia eBOM To VCATS','pgregory');

INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_VCATS_MQSERV_MQOUT','VCATS MQ Outbound Adapter','pgregory');

-- FRS-000130 (Service flow SVCRM) 
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_SVCRM_REPLICTEDR','FRS-000130 - Replicate Dealer service SVCRM','hmistry');


-- FRS-000123 (Service flow) 
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_BRKDWNEVNT','FRS-000123 - Create Breakdown Event for Vehicle','hmistry');

-- FRS-000123 (Canonical BreakdownEvent Adapter entry)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_CANON_BRKDWNEVNT','Canonical Trading Partner Adapter','hmistry');

-- FRS-000123 (Service flow SVCRM) 
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_SVCRM_BRKDWNEVNT','FRS-000123 - Create Breakdown Event for Vehicle SVCRM','hmistry');

-- FRS-000366
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHSV_TRACKUPD','FRS-000366 - Vehicle Service for Tracking and Update','rbhamid');

-- FRS-000027
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ENOV_PRODUCT_SAP_TRBGB_WTYSERVPART','FRS-000027 - Enovia Warranty Service Parts to SAP ','pgregory');

-- FRS-000133
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_REPLICATECASE','FRS-000133 - SAP CRM Replicate Case to Multiple Systems','cmarrett');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_REPLICATECASEBATCH','FRS-000133 - SAP CRM Replicate Case to Multiple Systems Batch Processing','cmarrett');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_REPLICATECASE_RAVT','FRS-000133 - SAP CRM Replicate Case to RAVT Batch Processing','cmarrett');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_REPLICATECASE_ECICDR','FRS-000133 - SAP CRM Replicate Case to ECICDR Batch Processing','cmarrett');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_REPLICATECASE_ALL','FRS-000133 - SAP CRM Replicate Case to Multiple Systems Batch Processing','cmarrett');

-- FRS-000129
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_CRTUPDCASE','FRS-000129 - Create or Update Case Business service','vannare1');

-- FRS-000053
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ENOV_PRD_IPOINT_PRTWGHT','FRS-000053 - Part Weight service','achibbe1');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_IPOINT_PRD_ENOV_SUPPRTWGHT','FRS-000053 - Supplier Part Weight service','achibbe1');

-- FRS-000118
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_CRTUPDCPGNEVNTORRSPS','FRS-000118 - Create or Update Campaign Event/Response','hmistry');

-- FRS-000115
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_REPLEADPSP','FRS-000115 - Replicate Lead and Prospect','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_HTTP_POX_OUT','HTTP POX Outbound Adapter','kmccorma');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SOAP_STD_OUT','SOAP STD Outbound Adapter','kmccorma');

-- FRS-000380
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SDD_VEHICLE_BRNSC_SIMRAVDATA','FRS-000380 - Vehicle SIMRAV Data from SDD to Brazil NSC application','rbhamid');

-- IA-172
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_EMC_GLENTRY_SAP_TRB_NRTHGTARSO','IA-000172 - EMC Northgate Arinso Payroll GL Entries to SAP TRB','hmistry');

-- IA-354
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CMMS3_HMRC_ALL_GDSRECEIPT','IA-000354 - CMMS3 Good Receipt to RICARDO','kmccorma');

-- FRS-000117  Service Flow
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_CRTUPDFINCNTRPROP','Create or Update Finance Contract Or Proposal','rbabu');

-- FRS-000117 Canonical Finance Adapter
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_CANON_FINANCE','Canonical Finance Adapter','rbabu');

-- IA-000158
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ATD_VEH_SAP_TRBGB_SRODATA','IA-000158 - ATD SRO data to SAP Turbo and TOPIx','asannago');

-- FRS-000083
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_VISTA_HTTP_IN','Vista HTTP Inbound Adapter','pgregory');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_VISTA_HTTP_REPLY','Vista HTTP Reply Adapter','pgregory');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_PRDSV_VISTASOLVE','FRS-000083 - Vista Solve Service','pgregory');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_PRDSV_CARS_VISTASOLVE','FRS-000083 - CARS Vista Solve Service','pgregory');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_PRDSV_ACE_VISTASOLVE','FRS-000083 - ACE Vista Solve Service','pgregory');

-- FRS-000139 03/07/2017 CM FRS-000139 IFU4735, Added BSID for the new build removed existing BSID 
-- INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_REPLICATEVEHSALESTAT','FRS-000139 - BBSS Replicate Vehicle Sale or Status to SAP CRM','cmarrett');

-- IA-000271
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_INVSV_WRRNTYCLMS','IA-000271 - Warranty Batch Claims Service','spatel5');

-- FRS-000107 (Vista to SAP Turbo part)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_VISTA_VEH_SAP_TRBGB_GOF','FRS-000107 - Vista GOF to SAPTRB','asannago');

-- FRS-000051 (Enovia to WIPS Target Cost)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ENOV_PRODUCT_WIPS_TARGETCOST','FRS-000051 - Enovia Target Cost to WIPS','pgregory');

-- FRS-000038 (Enovia to UNIPART)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_PROD_UNI_PUB_VIN_ECO','FRS-000038 - Enovia PublishECO & VIN from MFT','achibbe1');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_PROD_TO_UNIP_PROREPFILE','FRS-000038 - Batch processing for footer and report file','achibbe1');

-- FRS-000353
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_GEMSL_VEHSERV_SAP_TRBGB_SPECWERS','FRS-000353 - Vehicle Specification GEMSL to SAP Turbo','spatel5');

-- IA-000355
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_WIPS_HMRC_ALL_PRODPRICNG','IA-000355 - WIPS Product Pricing To Ricardo','hmistry');

-- IA-000356
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_WERS_HMRC_RIC_PRODMASUPD','IA-000356 - WERS Product Master Update To Ricardo','hmistry');

-- IA-000357
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_GSDB_HMRC_RIC_SUPPMASTER','IA-000357 - GSBD Supplier Master To Ricardo','spatel5');

-- IA-000358
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_MDG_HMRC_RIC_REMOVALS','IA-000358 - MDG Removals To Ricardo','asannago');

-- IA-000359
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CMMS3_HMRC_RIC_GOODSDSPTH','IA-000359 - CMMS3 Goods Despatch To Ricardo','spatel5');

-- FRS-000091 (ACE BRS Deltas to downstream)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ACE_VEHICLE_ALL_LEGACYFEEDS','FRS-000091 - ACE Legacy Feeds to multiple systems','pgregory');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_VEHICLE_ALL_VEHSPECSDERIV','FRS-000091 - Derivative Delta Feeds to multiple systems','pgregory');

-- FRS-000123 (AA feed to SAP Turbo)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CANON_VEH_SAP_TRBGB_BRKDWEVNT','FRS-000123 - BreakDwnEvent to SAP Turbo','asannago');

-- FRS-000022 (PLO Slot Generation to ACE)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PLO_PRODUCT_ACE_SLOTGEN','FRS-000022 - PLO Slot Generation to ACE','achibbe1');

-- FRS-000618 (Unipart/Neovia Material Prices Group to SAP Turbo)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_UNIPT_PRODUCT_SAP_TRBGB_MATPRCGRP','FRS-000618 - Unipart MatPriceGrp to SAP Turbo','asannago');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_NEOV_PRODUCT_SAP_TRBGB_MATPRCGRP','FRS-000618 - Neovia MatPriceGrp to SAP Turbo','asannago');

-- FRS-000378 (PLO to External Service Provider)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHSV_EVEHORDFOR','FRS-000378 - External Vehicle Order Forecast Service','rbhamid');
-- FRS-000081 (Enovia Manufacturing UCC SFI To CMMS3)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ENOV_PRODUCT_CMMS3_MANUFACUCC','FRS-000081 - Enovia Manufacturing UCC SFI To CMMS3','achibbe1');


-- IA-000324 (Warranty External Supplier Contracts)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ASRNT_VEHICLE_ALL_WTYEXTCTRT','IA-000324 - Warranty External Supplier Contracts to Multiple Systems','cmarrett');

-- FRS-000617 (CJLR VCATS to Whitley Engineering Server)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHSV_VDIASOFUPD','FRS-000617 - Vehicle Diagnostic Software Update Service','rbhamid');

-- IA-000363 CMMS3 to Ricardo (Stock Adjustment)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CMMS3_HMRC_RIC_STOCKADJST','IA-000363 - CMMS3 Stock Adjustment To RIC','asannago');

-- Added entry for FRS-000130 (SAP Turbo feed)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CANON_DEALER_SAP_TRBGB_REPLICTEDRT','FRS-000130 - Replicate Dealer to SAP Turbo','spatel5');

-- Added entry for FRS-000090 (ACE BRS Master Feeds)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ACE_PRODUCT_ALL_VEHSPECDES','FRS-000090 - ACE BRS Master feeds','pgregory');

-- Added entry for FRS-000616 (Warranty Vehicle Campaign Enquiry)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHSV_VEHCAMPENQ','FRS-000616 - Warranty Vehicle Campaign Enquiry','cmarrett');
-- Added entry for FRS-000081 (iPLM Scheduler Adapter)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_IPLMSCHED_MQSERV_MQIN','FRS-000081 - iPLM Scheduler Adapter','achibbe1');
-- Added entries for FRS-000018 (iPLM ACE Profet to downstream)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_PROFT_FTP_IN','Profet Files FTP in Adapter','pgregory');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_ACE_FTP_IN','ACE Profet Files FTP in Adapter','pgregory');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_PRODUCT_ALL_PROFTCOLL','FRS-000018 - ACE Profet Collector','pgregory');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_PRODUCT_ALL_PROFTMERGE','FRS-000018 - ACE Profet merge files','pgregory');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_PRODUCT_ALL_PROFTSEND','FRS-000018 - ACE Profet send files','pgregory');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_PRODUCT_SAP_TRBGB_CLASCONFMT','FRS-000018 - ACE Profet Class Config files to SAP Turbo','pgregory');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ACE_PRODUCT_CAESR_REPORTFILE','FRS-000018 - ACE Profet Report Files to Caesar','pgregory');
-- Added entry for FRS-000615 (Replicate Warranty Contract)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_ALL_REPWTYCNTR','FRS-000615 - Replicate Warranty Contract','cmarrett');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_CANON_WARRANTYCONTRACT','Warranty Contract Canonical','cmarrett');

-- Added entry for FRS-000381 - Claims Exports (TURBO SAP to DWM) 
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_INVSV_CLMSEXPORT','FRS-000381 - Warranty Batch Claims Export','spatel5');

-- Added entry for FRS-000093 (Get BOM Validation)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_PRDSV_BOMVAL','FRS-000093 - Get BOM Validation Service','achibbe1');

-- Additions for IFU-1765. IA-000074
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ASPEN_BILLG_SAP_ESMUS_ACCREIV','IA-000074 - MS (Aspen) to SAP eSmart','pgregory');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_BYCRK_BILLG_SAP_ESMUS_ACCREIV','IA-000074 - MS (Byers Creek) to SAP eSmart','pgregory');

-- IA-000362 (KD2000 CKD Removals To Ricardo)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_KD2K_HMRC_RIC_CKDREMOVAL','IA-000362 - KD2000 CKD Removals To Ricardo','rbhamid');

-- FRS-000277 (ASN Provision)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHSV_ADVSHPNT','FRS-000277 - ASN Provision to CJLR','kmccorma');
-- IFU4434 FRS-000277 Added new entry for ASN request to CJLR over MQ
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHSV_ADVSHPNT_CJLR','FRS-000277 - ASN Provision to CJLR','vviveka1');

-- IA-000324 Phase 2
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ASRNT_VEHICLE_SAP_TRBGB_WTYEXTCTRT','IA-000324 - Assurant Extended Warranty to SAP Turbo','spatel5');

-- FRS-000050 Unipart service parts to MPNR
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_UNIPT_PRODUCT_MPNR_SRVENGPART','FRS-000050 - Unipart Service Engineering Parts XRef to MPNR','pgregory');

-- IA-000220 IFU1811 FGFSH PymtConfrm To SAP eSmart
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_FGFSH_INVOICE_SAP_ESMALL_KJ09_PCONF','IA-000220 - FGFSH PymtConfrm To SAP eSmart','achibbe1');

-- FRS-000621 NL Vehicle Licence Plate Order and Release (SAP eSMART to Kirpestein)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESM_VEHICLE_KIRPE_LICORD','FRS-000621 - SAP ESM VehLicenceOrdRel To Kirpestein','asannago');

-- FRS-000622 NL Vehicle Licence Plate Response (Kirpestein to SAP eSMART)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_KIRPE_VEHICLE_SAP_ESM_VEHLICRESP','FRS-000622 - Kirpestein VehLicenceResponse To SAP ESM','asannago');

-- FRS-000282 CMMS3 to JV-Bridge Part Status Updates
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHSV_TRNFWDPT','FRS-000282 - CMMS3 to JV-Bridge Part Status Updates','pvonhirs');

-- FRS-000096 Enovia to MPNR 
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ENOV_PRODUCT_MPNR_DESIGNPART','FRS-000096 - Enovia Design Part to MPNR','pgregory');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_MPNR_PRODUCT_ENOV_SERVICEPART','FRS-000096 - MPNR Service Part to Enovia','pgregory');

-- FRS-000625 Vehicle Registration request (SAP eSMART to local registration organisations)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESM_VEHICLE_RDC_VEHREGREQ','FRS-000625 - SAP ESM VehRegReq To RDC','kthanga4');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESM_VEHICLE_FEBAC_VEHREGREQ','FRS-000625 - SAP ESM VehRegReq To FEBAC','kthanga4');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESM_VEHICLE_ANT_VEHREGREQ','FRS-000625 - SAP ESM VehRegReq To ANT','kthanga4');

-- FRS-000371 (Vehicle Manufacturing Status (CJLR to D42))
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHSV_MANUFSTAT','FRS-000371 - Vehicle Manufacturing Status to D42','rbhamid');

-- FRS-000626 Vehicle Registration response (local registration organisations to SAP eSMART).
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_RDC_VEHICLE_SAP_ESM_REGRESP','FRS-000626 - RDC VehRegResponse To SAP ESM','gsmith17');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_FEBAC_VEHICLE_SAP_ESM_REGRESP','FRS-000626 - FEBIAC VehRegResponse To SAP ESM','gsmith17');
-- IFU 2658
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ANT_VEHICLE_SAP_ESM_REGRESP','FRS-000626 - FEBIAC VehRegResponse To SAP ESM','rbhamid');


-- FRS-000372 (Vehicle Distribution Status (D42 to CJLR))
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHSV_VEHDSTST','FRS-000372 - Vehicle Distribution Status to CJLR','pvonhirs');

-- FRS-000278 (Vehicle Part Invoice Service)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_INVSV_VEHPARTINV','FRS-000278 - Vehicle Part Invoice Service','rbabu');
-- IFU 4433/IFU 4539 (Added new Business Service ID FRS-000278)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_INVSV_VEHPARTINV_CJLR','FRS-000278 - Vehicle Part Invoice Message Request to CJLR','vviveka1');

INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHSV_PUBFINSTAT','IA-000009 - Publish Financial Status Service','kmccorma');

-- FRS-000620 (VCATS Vehicle Weights to PLO )
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_VCATS_MQSERV_MQIN','VCATS Inbound MQ Adapter','gsmith17');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_VCATS_VEHICLE_PLO_VEHWEIGHT','FRS-000620 - VCATS Vehicle Weights to PLO','gsmith17');

-- FRS-000136 (Replicate Account and Vehicle )
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_REPACVHOWN','FRS-000136 - Replicate Account and Vehicle Ownership','achibbe1');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_REPVHVHOWN','FRS-000136 - Replicate Vehicle and Vehicle Ownership','achibbe1');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_REPACVHBAT','FRS-000136 - Replicate Account and Vehicle Batch','achibbe1');

-- FRS-000130 (Replicate dealer - Bollywood feed )
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CANON_DEALER_BWOOD_REPLICTEDR','FRS-000130 - ReplicateDealer To Bollywood','asannago');

-- FRS-000100 (Enovia Reference Data to SAP BODS)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ENOV_PRODUCT_SAPDS_REFDATA','FRS-000100 - Enovia Reference Data to SAP BODS','pgregory');

-- FRS-000364 (Warranty Vehicle Config to Multiple Systems) 
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_ALL_WRTYVEHCFG','FRS-000364 - SAP TRBGB Warranty Configuration to Multiple Systems','gsmith17');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_AWS_WRTYVEHCFG','FRS-000364 - SAP TRBGB Warranty Configuration to AWS','gsmith17');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_BWOOD_WRTYVEHCFG','FRS-000364 - SAP TRBGB Warranty Configuration to Bollywood','gsmith17');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_CTHMS_WTYVHCFGJG','FRS-000364 - SAP TRBGB Warranty Configuration to Clifford Thames - Jaguar','gsmith17');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_CTHMS_WTYVHCFGLR','FRS-000364 - SAP TRBGB Warranty Configuration to Clifford Thames - LandRover','gsmith17');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_TOPIX_WTYVHCFGJG','FRS-000364 - SAP TRBGB Warranty Configuration to TOPIX - Jaguar','gsmith17');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_TOPIX_WTYVHCFGLR','FRS-000364 - SAP TRBGB Warranty Configuration to TOPIX - LandRover','gsmith17');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_INFMD_WTYVHCFGJG','FRS-000364 - SAP TRBGB Warranty Configuration to InfoMedia - Jaguar','gsmith17');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_INFMD_WTYVHCFGLR','FRS-000364 - SAP TRBGB Warranty Configuration to InfoMedia - LandRover','gsmith17');


-- FRS-000367 (Derivative/Feature Delta Feed to CJLR)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_BRS_VEH_CJLR_DERIVFEATDELTA','FRS-000367 - Derivative/Feature Delta Feed to CJLR','pvonhirs');

-- FRS-000281 (CMMS3 to JV-Bridge calendar file interface)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_MISCSV_LDPLNTCLNDR','FRS-000281 - CMMS3 to JV-Bridge calendar file interface','rbabu');

-- IA-000005 (New cloned flow for VISTA GOF to SMART)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_VISTA_SALESORDER_SAP_SMT_GOFVISTA','IA-000005 (New cloned flow for VISTA GOF to SMART)','pvonhirs');

-- IA-000061 (New cloned flow for Multiple Systems to SMART)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_MISC_SMA_PLANEVENT','IA-000061 (New cloned flow for Multiple Systems to SMART)','pvonhirs');

-- FRS-000640 � WERS Code Description (WERS to ATD,TOPix and SAP TURBO)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_WERS_VEHSERV_ALL_CODEDESC','FRS-000640 � WERS Code Description','spatel5');

-- FRS-000138 � Replicate Vehicle Derivative Data
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_REPVEHDERV','FRS-000138 Vehicle Derivative Data','kmccorma');

-- IA-000366 GPIRS To RICARDO(Product Update)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_GPIRS_HMRC_RIC_PRODUPDATE','IA-000366 - GPIRS Product Update To RIC','havhale');

-- FRS-000633 � Shipment Notification � MAN File (SAP eSMART to PRIXCAR)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESMAU_VEHICLE_PXCAR_SHPNOTIFIC','FRS-000633 Shipment Notification � MAN File (SAP eSMART to PRIXCAR)','rbhamid');

-- FRS-000362 - Vehicle Enquiry (Various to TURBO SAP)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHSV_VEHENQUIRY','FRS-000362 - Vehicle Enquiry (Various to TURBO SAP)','gsmith17');

-- FRS-000382 - Warranty Claim (SAP TURBO to Various)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_CANON_WARRANTYCLAIM','FRS-000382 - Warranty Claim Canonical Adapter - SAP TURBO to Various','cmarrett');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_ALL_WTYCLAIM','FRS-000382 - Warranty Claim to Multiple Systems - SAP TURBO to Various','cmarrett');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_MFT_WTYCLAIM','FRS-000382 - Warranty Claim to MFT Test - SAP TURBO to MFT','cmarrett');

-- FRS-000141 - Create or Update Vehicle Ownership
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_CTUPVEHOWN','FRS-000141 - Create or Update Vehicle Ownership','kmccorma');

-- FRS-000632 - D42 to FLAGS2
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHSV_FLAGSD42PROC','FRS-000632 D42 To FLAGS2','asannago');

-- FRS-000634 � Vehicle Updates � RES File (SAP eSMART to PRIXCAR)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESMAU_VEHICLE_PXCAR_VEHICLEUPD','FRS-000634 � Vehicle Updates � RES File (SAP eSMART to PRIXCAR)','rbhamid');

-- FRS-000382 2A- Warranty Claim (SAP TURBO to SWORD)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_SWORD_WTYCLAIM','FRS-000382 - Warranty Claim - SAP TURBO to SWORD','spatel5');

-- FRS-000644 Vehicle Order Data(VISTA to DURBAN)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHICLE_ORDER_STATUS_BATCH
','FRS-000644 Vehicle Order Data(VISTA to multiple)','rbaker3');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHICLE_ORDER_STATUS_TO_DURBAN
','FRS-000644 Vehicle Order Data(post to DURBAN)','rbaker3');

-- IA-000367 Pheonix GRIPRS Goods Receipt to RICARDO
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_GPIRS_HMRC_RIC_GOODSREC','IA-000367 Pheonix GRIPRS Goods Receipt to RICARDO','rbaker3');

-- IA-000258 SAP eSmart Financial Data To Hyperion
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESM_INVOICE_HYPER_FIDATA','IA-000258 SAP Financial Data To Hyperion','pgregory');

-- FRS-000627 Create or Update PAR (GCM to SAP Turbo)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHSV_PARMAINT','FRS-000627 Create or Update PAR (GCM to SAP Turbo)','gsmith');

-- FRS-000143 Send Warranty Contract
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_SENDWRTCON','FRS-000143-CRM_S0019 Send Warranty Contract','achibbe1');

-- FRS-000635 � Vehicles To Despatch � ALC/SLIP File (SAP eSMART to PRIXCAR)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESMAU_VEHICLE_PXCAR_VEHDESPUPD','FRS-000635 � Vehicles To Despatch � ALC/SLIP File (SAP eSMART to PRIXCAR)','rbhamid');

-- FRS-000272 - IFU2194, Trading Division related interface
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHSV_TDPARTS','SAP Trading Division to Vehicle Parts service (FRS-000272)','asannago');

-- FRS-000628 - FRS-000628 Update FRED (SAP Turbo to GCM)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_GCM_FREDMAINT','SAP Turbo FRED Maintenance to GCM FRS-000628)','gsmith17');

-- FRS-000646 - UVL VIN and feature feed 
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_DEALER_UVL_VINFEAT','Multiple Systems VIN Feature feed to UVL FRS-000646)','spatel5');

-- FRS-000273 - IFU2199, Trading Division related interface
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHSV_TDDEMANDUPD','SAP Trading Division to Parts Demand Update service (FRS-000273)','rbaker3');

-- FRS-000277 (Trading Division) IFU2200/IFU2227
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ESB_VEHICLE_SAP_TRB_ASNPROV','ASN Provision to Trading Division SAP','asannago');

-- Added entry for new Outbound ON SAP Turbo BAPI Adapter
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_TRBGB_BAPMT_OUTON','Outbound BAPI ON adapter for SAP Turbo','spatel5');

-- Added entries for FRS136, inc Web Service delivery BSID's
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_REPAVO','Second tranche of processing of AVO from SAP','amoseley');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_REPVVO','Second tranche of processing of VVO from SAP','amoseley');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_REPAVO','Standard batch processing of AVO/VVO from SAP','amoseley');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_REPAVO_OSH','Standard WS delivery of AVO to OSH','amoseley');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_REPAVO_BMA','Standard WS delivery of AVO to BMA','amoseley');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_REPAVO_OCCAM','Standard WS delivery of AVO to OCCAM','amoseley');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_REPVVO_OSH','Standard WS delivery of VVO to OSH','amoseley');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_REPVVO_BMA','Standard WS delivery of VVO to BMA','amoseley');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_REPVVO_OCCAM','Standard WS delivery of VVO to OCCAM','amoseley');

-- Added entries for FRS137
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_CTUPVHCL','Create or Update Vehicle','amoseley');

-- IA-000368 Pheonix GRIPRS Removal Notifications to RICARDO
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_GPIRS_HMRC_RIC_REMOVALNOT','IA-000368 Pheonix GRIPRS Removal Notifications to RICARDO','abadal');


-- IA-000370 Pheonix GRIPRS Stock Adjustments to RICARDO
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_GPIRS_HMRC_RIC_STOCKADJST','IA-000370 Pheonix GRIPRS Stock Adjustments to RICARDO','abadal');

-- SP Added entry for PLO Outbound Code Translation Response Adapter
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_PLO_MQSERV_CODETRANS','PLO Outbound Code Translation Response Adapter','spatel5');

-- SP Entries added for FRS-000631 CJLR (Brand Codes) Vehicle Specification Based ON WERS Codes (PLO to SAP TURBO)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEHSERV_PLO_WERSCONV','FRS-000631 SAP Turbo Brand Codes to PLO Translation','spatel5');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PLO_VEHSERV_SAP_TRBGB_WERSCONV','FRS-000631 PLO Translation WERS Codes to SAP Turbo','spatel5');

-- FRS-000382 Exit 2b - Warranty Claim (SAP TURBO to SYC1 and CJLR)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','FRS-000382 - Warranty Claim to SYC1','cmarrett');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_CJLR_WTYCLAIM','FRS-000382 - Warranty Claim to CJLR','cmarrett');

-- FRS-643 Vehicle Appraisal Service for Mobility app
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_MOBSV_VEHICALAPPRAISAL','FRS-000643 - Vehicle Appraisal Service','rbaker3');

-- IA-000124 - ANZ Bank Statements
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ANZB_BNKREPLY_SAP_ESMAU_ACKSTAT','IA-000124 - ANZ Bank Statements','achibbe1');

-- FRS-000382 Exit 2b - Warranty Claim (SAP TURBO to SMART)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_SMART_WTYCLAIM','FRS-000382 - Warranty Claim to SMART','spatel5');

-- FRS-000382 Exit 2c - Warranty Claim (SAP TURBO to AUTOA)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_AUTOA_WTYCLAIM','FRS-000382 - Warranty Claim to AUTOA','cmarrett');

-- FRS-000650 � TD SAP to Syncreon AOS Integration
-- 21/06/2017 VV updated the following entries as the BSID is changed for the following from TRBGB to TRB
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRB_VEHICLE_AOS_VEHPATRAUP','FRS-000650 TD SAP to Syncreon AOS Integration','vviveka1');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_AOS_VEHICLE_SAP_TRB_VEHPATRAUP','FRS-000650 TD Syncreon AOS to SAP Integration','vviveka1');

-- FRS-000648 � Parts Localisation Data
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHSV_PARTSLOCAL','FRS-000648 Parts Localisation Data Service','spatel5');

-- FRS-000382 - Warranty Claim (SAP TURBO) Adapter Flow
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_TRBGB_ALEMTWTYCLAIM_IN','FRS-000382 - Warranty Claim - SAP ALE Inbound Adapter Flow','cmarrett');

-- FRS-000382 Exit 2d - Warranty Claim (SAP TURBO to BWOOD)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_BWOOD_WTYCLAIM','FRS-000382 - Warranty Claim to BWOOD','cmarrett');

-- FRS-000654 � SAP eSMART VMS to DMS Interface 
-- 22/05/2017 AS BSID renamed as part of move to new build process; IFU4640
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESM_VEHICLE_DMS_VEHVMSUPD','FRS-000654 SAP eSMART VMS to DMS Interface','rbhamid');

-- FRS-000657 � CJLR Part Calims to SWORD
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CJLR_RETPRTCLM','FRS-000657 CJLR Part Calims to SWORD','achaudha');

-- FRS-000657 � SWORD To CJLR
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SWORD_RETPRTSUPD','SWORD to CJLR application message flow','achaudha');

-- FRS-000130 � AWS
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CANON_DEALER_AWS_REPLICTEDR','FRS-000130 - ReplicateDealer To AWS','spatel5');

--FRS 128 - (Simplified Batch)	

INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CUSSV_CTUPSERREP_SIMP','FRS-000128 - CreateUpdate ServiceOrRepair Event SimplifiedBatch','achibbe1');

--FRS 112 - (Simplified Batch Guanxi R1.2)	

INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CUSSV_CRTUPDLEAD_SIMP','FRS-000112 - CreateUpdate Lead And Prospect SimplifiedBatch','amoseley');


--FRS-000656
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHSV_TDPARTSLIST','FRS-000656 � List of parts provided by Trading Division SAP to WIPS','ppancha3');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHSV_TDPARTSPRICEUPD','FRS-000656 � Parts price update by WIPS to Trading Division SAP','ppancha3');

--FRS 117 - (Simplified Batch Guanxi R1.2)	

INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CUSSV_CRTUPDFINCNTRPROP_SIMP','FRS-000117 - Create Update Fin Contract Or Proposal Simplified Batch ','achibbe1');


--	 FRS 139 - (Simplified Batch Guanxi R1.2)

INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CUSSV_REPVEHSALESTAT_SIMP','FRS-000139 - Replicate Vehicle Sale Status Simplified Batch','achibbe1');

--	FRS 118 - (Simplified Batch Guanxi R1.2)

INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CUSSV_CRTUPDCPGNEVNTORRSPS_SIMP','FRS-000118 - Create or Update Campaign Events and Responses Simplified Batch','achibbe1');

--14/01/2015 AaP Entry for FRS-000656
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_TD_VEHICLE_WIPS_PARTSLIST','FRS-000656 � List of parts provided by Trading Division SAP to WIPS','apanjiya');

-- FRS-000660 � Vehicle Stock Report (SAP eSMART to IMAWEB & Local Remarketing DB) 
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESMIB_VEHICLE_ALL_VEHSTOKREP','FRS-000660 - Vehicle Stock Report (SAP eSMART to IMAWEB and Local Remarketing DB)','rbhamid');


-- FRS-000091- IFU2317,IFU2431,IFU2461,IFU2708 (ACE Derivative and Features Delta to Multiple Systems)
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ACE_PRODUCT_ALL_LEGACYFEED','FRS-000091 - ACE Derivative and Features Delta to Multiple Systems','achibbe1');

-- 11/02/2015  FRS-000148 - Guanxi - Replicate Vehicle Planning Event from PLO to SAPCRM
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_REPVEHPLAN','FRS-000148 - Guanxi - Replicate Vehicle Planning Event','achibbe1');

-- 17/02/2015  FRS-000148 - Guanxi - Replicate Vehicle Status Event from D42 to SAPCRM
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_REPVEHSTATUS','FRS-000148 - Guanxi - Replicate Vehicle Planning Event','achibbe1');

--23/02/2015 KT Added BSID for FRS-000651 - TD - Invoice Outbound Declaration to Customs. 30/04/2015 PG updated to KN (Ricardo replacement) 
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_HMRC_KN_INVOUTDECL','FRS-000651 - TD - Invoice Outbound Declaration to Customs','pgregory');

--26/02/2015 RBH Added BSID for FRS-000670 - Stone - Invoice Information for Parts and Vehicle (SAP Brazil to Customs Broker)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBBR_INVOICE_TITO_INVDETAILS','FRS-000670 - Invoice Information for Parts and Vehicle (SAP Brazil to Customs Broker)','rbhamid');

INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_MFT_INVOICE_SAP_TRBBR_INVOICEACK','FRS-000670 - Invoice Information for Parts and Vehicle (SAP Brazil to Customs Broker)','rbhamid');

--03/03/2015 AC Added BSID for FRS-000137-SIMPLIFIED BATCH - Gaunxi - Create or Update Simplified Batch.

INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_CTUPVHCL_SIMP','FRS-000137-SIMP - Create or Update Vehicle Simplified Batch','achibbe1');

-- 03/03/2015 AC  Added BSID for FRS-000023-(IFU2807) - IPLM - Component Tooling Request.

INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ENOV_PRODUCT_SAP_TRBGB_COMPTOOLRQ','FRS-000023-Component Tooling Request','achibbe1');

-- 13/03/2015 CM Added BSID for FRS-000695 - Bedrock - Replicate Manufacturer Suggested Retail Price Data from SAP Turbo to Multiple Systems
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_PRICING_TO_ALL_MSRPDATA','FRS-000695 - Replicate MSRP data to All','cmarrett');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_PRICING_TO_VISTA_MSRPDATA','FRS-000695 - Replicate MSRP data to VISTA','cmarrett');

-- 14/03/2015 PG Added BSIDs for FRS-000271 
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_WERS_VEH_ALL_ENGCHANGE','FRS-000271 - SI_BS_WERS_EngineringChange_To_Multiple_Systems','pgregory');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_VEHSV_ENGCHGSAP','FRS-000271 - SI_SV_Engineering_Change_For_SAP','pgregory');

--18/03/2015 RBH Added BSID for FRS-000669 - Customs Inbound Information for Parts and Vehicle (Customs Broker to SAP Brazil) - Stone
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_TITO_HMRC_SAP_TRBBR_IMPORTDECL','FRS-000669 - Customs Inbound Information for Parts and Vehicle (Customs Broker to SAP Brazil)','rbhamid');

--19/03/2015 SP Added for FRS-000693
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_WERS_VEHICLE_SAP_TRBGB_ENGCHANGE','FRS-000693 - WERS Engineering Change To SAP Turbo','spatel5');


--03/04/2015 AC Added BSID for FRS-000015
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_GPIRS_PRODUCT_MULT_COMPVEHREQ','FRS-000015 - GPIRS VehandComp Solve to Multiple System','achibbe1');

--09/04/2015 SP Added for FRS-000681
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_WERS_VEHSERV_SAP_TRBGB_ENGBRAZIL','FRS-000681 - WERS Engineering Change To Brazil SAP Turbo','spatel5');

--16/04/2015 RBH Added BSID for FRS-000667 SAP to Speedy Interface
--INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_MISC_SPEDY_SUPDELINFO','FRS-000667 - SAP to Speedy Interface','rbhamid');

--16/04/2015 AC Added BSID for FRS-000673 - Tradding Divison - SAP TD to CJLR Tradding Divison
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_TD_VEH_CJLR_PROVASN','FRS-000673 - Trading Division - SAP TD to CJLR','achibbe1');

--21/04/2015 PG Added BSIDs for Stabilisation HTTP Adapters 
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_HTTP_V2_OUTBOUND','SI_AD_HTTP_V2_MT_Outbound','pgregory');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_HTTP_V2_INBOUND','SI_AD_HTTP_V2_MT_Inbound','pgregory');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_HTTP_V2_REPLY','SI_AD_HTTP_V2_MT_Reply','pgregory');

--23/04/2015 CM Added BSID for IA-000005 - VISTA to LANDAR - Project Clockwork
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_VISTA_VEHICLE_LNDAR_GOF','IA-000005 - VISTA to LNDAR','cmarrett');

--24/04/2015 AB Added for FRS-000668 SBOM (Service Bill of Material)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_LSTOR_VEHICLE_ALL_SBOM','FRS-000668 - LOCALSTORAGE to Multiple system(CJLR and BOLLYWOOD)','pgregory');

--29/04/2015 RBH Added BSID for FRS-000705 SAP to SIM Integration 
--INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_SUPPLIER_SIM_SUPIMPMETR','FRS-000705 SAP to SIM Integration','rbhamid');

--30/04/2015 SP Added BSID for FRS-000716 MES to SAP Plant Maintenance - Fault Alarm Notification
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_MES_QUALITY_SAP_TRBGB_FAULTALARM','FRS-000716 MES to SAP - Fault Alarm Notification','spatel5');

-- 30/04/2015 RB Added BSID for FRS-000680 MES to SAP Turbo - Vehicle Genealogy
-- 16/06/2015 RB Added BSID for FRS-000003 MES Vehicle Genealogy. Removed Old entry for FRS-000680
-- INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_MES_QUALITY_SAP_TRBGB_VEHGENEALOGY','FRS-000680 MES to SAP Turbo - Vehicle Genealogy','rbabu3');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_MES_QUALITY_ALL_VEHGENEALOGY','FRS-000003 MES Vehicle Genealogy','rbabu3');

--05/05/2015 RB Added BSID for FRS-000680 MES to SAP Turbo - NCR Notification
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_MES_QUALITY_SAP_TRBGB_NCRNOTIFY','FRS-000680 MES to SAP Turbo - NCR Notification','rbabu3');

--07/04/2015 SP Added BSID for FRS-000716 MES to SAP Plant Maintenance - Update Status
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_MES_QUALITY_SAP_TRBGB_UPDSTATUS','FRS-000716 MES to SAP - Update Status','spatel5');

--07/04/2015 SP Added BSID for FRS-000716 MES to SAP Plant Maintenance - Measurement Document
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_MES_QUALITY_SAP_TRBGB_MEASUREDOC','FRS-000716 MES to SAP - Measurement Document','spatel5');

--08/05/2015 RB Added BSID for FRS-000680 MES to SAP Turbo - Part Quarantine Status
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_TRBGB_MQSERV_ALEINSTONE','SAP Turbo MT ALE Inbound Adapter - Stone Interfaces','rbabu3');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_QUALITY_MES_PRTQRNTNSTUS','FRS-000680 MES to SAP Turbo - Part Quarantine Status','rbabu3');

--08/05/2015 RB Added BSID for FRS-000680 MES to SAP Turbo - NCR Response
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_QUALITY_MES_NCRRESPONSE','FRS-000680 MES to SAP Turbo - NCR Response','rbabu3');

--08/05/2015 PG Added BSIDs for FRS-00712 MF & DHL Red Priarie GXS Integration
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_MATFL_VEHICLE_GXS_PARTREQ','FRS-000712 MATFL to GXS Part Request','pgregory');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_GXS_VEHICLE_MATFL_DELCONF','FRS-000712 GXS to MATFL Delivery Confirmation','pgregory');

--14/05/2015 RBH Added BSIDs for FRS-000711 TD SAP to PLO Interface 
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_PLO_PABOORDREQ','FRS-000711 TD SAP to PLO Interface','rbhamid');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PLO_VEHICLE_SAP_TRBGB_PABOORDSTA','FRS-000711 TD SAP to PLO Interface','rbhamid');

--18/05/2015 SP Added BSID for FRS-000690 PLO Demand Forecast to SAP Turbo 
--16/05/2017 RBH Updated the BSID for FRS-000690 PLO Demand Forecast to SAP Turbo
-- 27/11/2017 AS IFU5085, FRS-000690 - SAP Turbo feed will now be moved under adapter component SI_AD_SAP_TRB_ALE_CIR_Outbound. The old entry will be commented.
--INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PLO_SUPPLIER_SAP_TRB_FORECAST','FRS-000690 PLO to SAP Turbo - Demmand Forecast','rbhamid1');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PLO_SUPPLIER_ALL_FORECAST','FRS-000690 PLO to ALL - Demand Forecast','pgregory');

--21/05/2015 KT Added BSID for FRS-000718 
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_MES_VEHICLE_SAP_TRBBR_PLNORDCONF','FRS-000718 Vehicle Plannned Order Conf','kthanga2');

--22/05/2015 AS FRS-000715 MES to SAP EWM INTERFACE
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_MES_VEHICLE_SAP_TRBBR_TLSBROADCT','FRS-000715 MES to SAP EWM Interface','asannag1');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_MES_VEHICLE_SAP_TRBBR_VEHMOVEINF','FRS-000715 MES to SAP EWM Interface','asannag1');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_TRBBREWM_ALEMT_OUT','SAP EWM Brazil Outbound adapter','asannag1');

--09/06/2015 AS FRS-000679  Transfer Master Data and Acknowledgement
--16/08/2018 asannag2 IFU5179, Darwing changes, flow moved to new build process and as a consequence BSIDs were renamed
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRB_MES_TRNMASDATA','FRS-000679 SAP APO � Multiple MES SystemTransfer Master Data and Acknowledgement','asannag2');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ESB_SAP_TRB_MASTDATACK','FRS-000679 SAP APO � Multiple MES SystemTransfer Master Data and Acknowledgement','asannag2');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_MES_ESB_MASTDATACK','FRS-000679 SAP APO � Multiple MES SystemTransfer Master Data and Acknowledgement','asannag2');

--10/06/2015 KT FRS-000707  OrderBOM and Acknowledgement
--15/01/2018 asannag2 IFU5178, BSIDs were renamed while moving the flow to new build process
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRB_MES_ORDERBOM','FRS-000707 OrderBOM and Acknowledgement','kthanga2');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ESB_SAP_TRB_ORDERBOMACK','FRS-000707 OrderBOM and Acknowledgement','kthanga2');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_MES_ESB_ORDERBOMACK','FRS-000707 OrderBOM and Acknowledgement','kthanga2');

--24/06/2015 RB Added BSID for FRS-000261 SAP APO Inbound Adapter
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_TRBBR_ALEAPOMT_IN_V2','SAP Turbo APO MT ALE Inbound Adapter - Stone (Brazil) Interfaces','rbabu3');

--29/06/2015 RBH FRS-000674 TDSAP to CJLR Customer Invoice 
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_CUSTOMER_CJLR_CUSTINVOIC','FRS-000674 TDSAP to CJLR Customer Invoice','rbhamid');

--09/07/2015 SP FRS731 - Open Ordering Vista Dealer Allocations 
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_VISTA_DEALER_PLO_OPENORDER','FRS-000731 Open Ordering Vista Dealer Allocations','spatel5');

-- 29/07/2015 RB FRS-000719 D42 Vehicle Status Update to MES
-- 23/01/2018 asannag2 FRS-000719, IFU5196, BSID renamed while moving the flow to new build process
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_D42_MES_VEHSTATUSUPD','FRS-000719 D42 Vehicle Status Update to MES','rbabu3');

-- 08/09/2015 RB FRS-000687 HR Interface-ESB_To_Kronos Interface
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CANON_HR_KRONOS_EMPTADATA','FRS-000687 HR Interface ESB To Kronos Interface','rbabu3');

-- 10/09/2015 AS FRS-000720 SAP HR Employee and Organisation Management
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_CANON_HREMP','FRS-000720 HR Interface Employee SAP To ESB','asannag1');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_CANON_HRORG','FRS-000720 HR Interface Organisation Management SAP To ESB','asannag1');

-- 11/09/2015 RBH FRS-000689 HR Interface (ESB to NGA Payroll)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CANON_HR_NGA_EMPORGDATA','FRS-000689 HR Interface (ESB to NGA Payroll)','rbhamid');

-- 11/09/2015 RBH SAP NGA Outbound common adapter flow 
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_NGA_STONE_ALE_MT_OUT','SAP NGA Outbound adapter flow','rbhamid');

--AS FRS-000670 Purchase Order Feed
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBBR_INVOICE_TITO_PO','FRS-000670 SAP TRB Purchase Order To TITO','asannag1');

--AS FRS-000669 Customs Declaration Feed, IFU-3455
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_TITO_HMRC_SAP_TRBBR_CUSTDECL','FRS-000669 TITO Customs Declaration Part To SAP TRBBR','asannag1');

--KT IA-000147 Warranty Dealer Part Returns IFU-3432
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SWORD_INVOICE_SAP_TRBGB_WTYDLRPART','IA-000147 Warranty Dealer Part Returns To SAP TRBBR','kthanga2');

--AS FRS-000721 Vehicle Registration, from SAP TRB to SERPRO
-- Vehicle Registration feed
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBBR_VEHICLE_SERPR_VEHREG','FRS-000721 SAP TRB to SERPRO Vehicle Registration','asannag1');
-- Vehicle Registration Acknowledgement feed
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SERPR_VEHICLE_SAP_TRBBR_VEHREGACK','FRS-000721 SAP TRB to SERPRO Vehicle Registration','asannag1');

-- FRS-000653 Independent Operator Trust Centre Service
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_SECSV_SECURITYCK','FRS-000653 Independent Operator Security Check','spatel5');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_SECSV_TRUSTCENTRES','FRS-000653 Trust Centres','spatel5');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_SECSV_SECURITYNF','FRS-000653 Security Notifications','spatel5');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_SECSV_SECURITYCK_RESP','FRS-000653 Security Notifications Response Routing','spatel5');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_SECSV_SECURITYCK_NICB','FRS-000653 Security Notifications NICB Routing','spatel5');

-- IA-000172 IFU3539 Additional FileInput
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PAYRL_GLENTRY_SAP_TRB_NGABRAZIL','IA-000172 NGA Brazil','pgregory');
-- IA-000172 IFU3539 Flow specific BSID added
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'BSID SI_BS_PAYRL_GLENTRY_SAP_TRB','IA-000172 Flow specific','cmarrett');

-- FRS-000130 - to SAP eSmart
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CANON_DEALER_SAP_ESM_REPLICTEDR','FRS-000130 to SAP eSmart','spatel5');

-- 20/11/2015 SN IA-000172 Payroll GL entries for SAP turbo,  IFU3539
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PAYRL_GLENTRY_SAP_TRB_NGABRAZIL','IA-000172 - NGA Brazil Payroll GL Entries to SAP TRB','snidumuk');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PAYRL_GLENTRY_SAP_TRB','IA-000172 - Payroll Flow BSID ','cmarrett');
-- 24/11/2015 AC FRS-000107-VISTA to VITAL IFU3554
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_VISTA_CUSSV_VITAL_ORDERREPL','FRS-000107 - VISTA To VITAL Flow BSID ','achibbe1');

--26/11/2015 RB FRS-000669 Vehicle Import Declarations Feed
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_TITO_HMRC_SAP_TRBBR_VEHIMPDECL','FRS-000669 TITO Vehicle Import Declarations To SAP TRBBR','rbabu3');

--01/12/2015 RBH FRS-000737 Create Purchase Order from Neovia provided Commercial Invoice
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_NEOV_INVOICE_SAP_TRBBR_COMMERCINV','FRS-000737 Create Purchase Order from Neovia provided Commercial Invoice','rbhamid');

--02/12/2015 Added for FRS-000804 Employee Data to Success Factors
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CANON_HR_SF_EMPDATA','FRS-000804 SI_BS_CANON_HR_SF_EMPDATA','spatel5');

--02/12/2015 AS FRS-000722 AfterMarket Order and Response Interfaces
-- After Market Order Feed
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_NEOV_VEHICLE_SAP_TRBBR_AFTMKTORD','FRS-000722 AfterMarket Order and Response Interfaces','asannag1');
-- Confirmation Response feed
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBBR_VEHICLE_NEOV_AMORDRESP','FRS-000722 AfterMarket Order and Response Interfaces','asannag1');

--03/12/2015 Added for FRS-000670 Vehicle Information
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBBR_INVOICE_TITO_VEHINFO','FRS-000670 Vehicle Information','rbabu3');

--31/12/2015 Added entry for FRS-000807 OA Code Translation Service
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_MISCSV_OACODETRANSL','FRS-000807 OA Code Translation Service','rbabu3');

-- 10/02/2015 KT FRS-000661 - Stone - BankPayments from SAP TRBGB  to BancoITAU
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_PAYMT_BITAU_FEBRABAN','FRS-000661 - Stone - BankPayments From SAP TRGBGB to BancoITAU','kthanga2');
--11/01/2016 Added entry for FRS-000661, AR Payment Request/AR Payment Request Confirmation/Credit Limit Data
-- 18/01/2017, IFU4365, SI_BS_SAP_TRBGB_PAYMT_SINTEL_ARPAYMT renamed to SI_BS_SAP_TRBGB_PAYMT_ALL_PAYMTS
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_PAYMT_ALL_PAYMTS','FRS_000661_Bank_Interface_Stone','asannag1');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SINTEL_PAYMT_SAP_TRBGB_ARCONFIRM','FRS_000661_Bank_Interface_Stone','asannag1');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SINTEL_PAYMT_SAP_TRBGB_CREDITLMT','FRS_000661_Bank_Interface_Stone','asannag1');

--15/01/2016 Added entry for FRS-000791, Employee TA Data from ESB to Kronos UK
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CANON_HR_KRONOSUK_EMPTADATA','FRS_000791_Employee_TA_UKTimeAttendance','vvivekan');

-- 25/01/2016 CM Added new BSID for FRS-000802
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_BRS_VEH_SAP_TRB_VEHSPECSFEAT','FRS-000802 Warranty Translated Vehicle Features','cmarrett');

-- 10/02/2016 AS Added new BSID for FRS-000638
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_TOPIX_VEHICLE_SAP_TRBGB_SROTRANSL','FRS-000638 SRO Local Translations, TOPIx to SAP Turbo','asannag1');

-- 16/02/2016 PG Added new BSIDs for FRS-000811
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_MONEX_MISC_ALL_CURRTRIANG','FRS-000811 Currency Triangulation','pgregory');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_MONEX_MISC_FAST_CURRTRIANG','FRS-000811 Currency Triangulation to FAST','pgregory');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_MONEX_MISC_LGCY_CURRTRIANG','FRS-000811 Currency Triangulation','pgregory');

-- 23/02/2016 PP Added new BSIDs for exception replay web service & new batch framework flows
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BATCH_ADMIN_INTERFACE','ALL_NEW_BATCH_FWK New batch framework admin interface web service','ppancha3');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_BATCH_JOB_DISPATCHER','ALL_NEW_BATCH_FWK New batch framework batch job dispatcher for automatic batch triggerring','ppancha3');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_EXCEPTION_REPLAY_MGMT','IA_EXCEP_REPLAY_MGMT Exception replay management web service for replay and add/amend replay rules','ppancha3');

--	01/03/2016 CM Added new BSID for FRS-000795
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_VEHICLE_SAPTRBGB_MATCOSTPRC','FRS-000795 Multiple Systems Warranty Material Cost Price Update To SAP Turbo','cmarrett');

--	04/03/2016 SA Added new BSID for FRS-000810
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_PAYMT_ESB_COADATA','FRS-000810 PeopleSoft Decomm - Combo Explode','asannag1');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ESB_PAYMT_MFRAME_COADATA','FRS-000810 PeopleSoft Decomm - Combo Explode','asannag1');

--	08/03/2016 NS Added new BSID for FRS-000812
--	17/07/2016 TK IFU-4773: Updated BSID for FRS-000812
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_TMS_ALL_GLFILE','FRS-000812 China TMS GL File to SAP SMART','tksheers');

--	18/03/2016 NS Added new BSID for SAP ALE Outbound to SMART China
--	05/02/2017 TK Updated BSID for SAP ALE Outbound to SMART China adapter by removing V2 concatenated
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_SMTCN_ALE_OUTBOUND','SAP SMART China ALE Outbound Adapter Flow','tksheers');

--	30/03/2016 MJ Added BSID for IA-000049
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_BBSS_VEHSERV_ALL_VEHDATA','BBSS Vehicle Data to Multiple Systems','mjeevart');

--08/04/2016 KT Added BSID for PGZ MQ Outbound Adapter flow
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_PGZ_MQSERV_MQOUT','MQ Outbound adatper service for Plant Graz messages','kthanga2');

--13/04/2016 PG Added BSID for FRS-000817 flows
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PLO_VEHICLE_PGZ_ORDER','PLO Orders to Graz','pgregory');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PGZ_VEHICLE_PLO_ORDERSTAT','Graz Order Status to PLO','pgregory');

-- 15/04/2016 CM Added BSID for FRS-000809 
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_GRP_VEHICLE_SAP_TRBGB_USERDATA','GRP User data to SAP Turbo CUA module','cmarrett');

-- 18/04/2016 CM Added BSID for outbound SAP Adapter flow for FRS-000809 
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_TRBGB_ALE_CUA_OUT_V2','SAP adapter flow for SAP Turbo CUA module','cmarrett');

-- 19/04/2016 AS FRS-000816 Material Master, Vendor Master, CTC/Outline Agreement
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_TRBGB_ALEMMMT_IN_V2','SAP adapter flow for SAP Turbo Material Master FRS-000816','asannag1');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_TRBGB_ALEVMMT_IN_V2','SAP adapter flow for SAP Turbo Vendor Master FRS-000816','asannag1');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_TRBGB_ALECTCMT_IN_V2','SAP adapter flow for SAP Turbo Outline Agreement CTC FRS-000816','asannag1');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_CANON_MATMAS','FRS-000816 Material Master Canonical Adapter','asannag1');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_CANON_VENMAS','FRS-000816 Vendor Master Canonical Adapter','asannag1');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_CANON_CTC','FRS-000816 CTC Canonical Adapter','asannag1');

-- 25/04/2016 AS FRS-000815
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CANON_PRODUCT_PGZ_CTC','FRS-000815 CTC Message to Plant Graz','asannag1');
--12/08/2016 IFU4082 FRS-000815 Added new BSID (to be used only for routing)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CANON_PRODUCT_PGZ_SPC','FRS-000815 SPC Message to Plant Graz','kthanga4');

-- 26/04/2016 AS FRS-000813 and FRS-000814
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CANON_PRODUCT_PGZ_MATLMASTER','FRS-000813 Material Master Message to Plant Graz','vvivekan');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CANON_PRODUCT_PGZ_VENDMASTER','FRS-000814 Vendor Master Message to Plant Graz','vvivekan');

-- 05/05/2016 RBH Added BSID for FRS-000818 
--03/08/2016 KT IFU4055 BSID changes as per new source system.
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CMMS3_MISC_SAP_TRBGB_INTSTKMVMT','Internal Stock Movement','kthanga4');

-- 17/05/2016 AS Added BSID for FRS-000151
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_CANON_PRODREF','FRS-000151 Derv Feature Code to SVCRM','asannag2');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CANON_PRODUCT_SVCRM_PRODREF','FRS-000151 Derv Feature Code to SVCRM','asannag2');

-- 17/05/2016 AC Added BSID for FRS-000130 - IFU3888
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CANON_DEALER_OCRM_REPLICTEDR','FRS-000130 Replicate dealer to OCCRM','achibbe1');

-- 17/05/2016 AC Added BSID for FRS-000107 - IFU3897
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_OCRM_ORDERREPL','FRS-000107 Replicate Order to OCCRM','achibbe1');

-- 09/06/2016 AS Added BSID for FRS-000820
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CMMS3_SUPPLIER_ESB_ASNSOL','FRS-000820 ASN-SOL Info CMMS3 to CIC','asannag2');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CMMS3_SUPPLIER_ESB_ASNCBBIW','FRS-000820 ASN-CBBIW Info CMMS3 to CIC','asannag2');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CMMS3_SUPPLIER_ESB_ASNCBTF','FRS-000820 ASN-CBTF Info CMMS3 to CIC','asannag2');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CMMS3_SUPPLIER_ESB_ASNHW','FRS-000820 ASN-HW Info CMMS3 to CIC','asannag2');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ESB_SUPPLIER_CIC_ASNSOL','FRS-000820 ASN-SOL Info CMMS3 to CIC','asannag2');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ESB_SUPPLIER_CIC_ASNCBBIW','FRS-000820 ASN-CBBIW Info CMMS3 to CIC','asannag2');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ESB_SUPPLIER_CIC_ASNCBTF','FRS-000820 ASN-CBTF Info CMMS3 to CIC','asannag2');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ESB_SUPPLIER_CIC_ASNHW','FRS-000820 ASN-HW Info CMMS3 to CIC','asannag2');

-- 16/06/2016 VV Added entry for FRS-819
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_D42_DEALER_PGZ_DISTLABEL','FRS-000819 Distribution Label Message to Plant Graz','vvivekan');

-- 24/06/2016 SB Added entry for FRS-000151 IFU3942
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CANON_PRODUCT_OCRM_PRODREF','FRS-000151 IFU3942 Product reference Message to Overseas CRM','sbawri');

-- 01/07/2016 SB Added BSID for FRS-000371 IFU3928
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PGZ_VEHICLE_D42_MANUFACSTATUS','FRS-000371 IFU3928 Vehicle Manufacturing Status to D42','sbawri');

-- 08/07/2016 TK Added BSID for SI_AD_SAP_ESMALL_BAPI_MT_OutboundV2 flow under IFU3907(IA-000027)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_ESMALL_BAPMT_OUT_V2','SAP ESMALL BAPI Outbound Adapter','tksheers');

-- 09/08/2016 TK IA-000097-Added BSID for SI_AD_SAP_TRBGB_ALE_HR_MT_OutboundV2 flow
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_TRBGBHR_ALEMT_OUT_V2','SAP TRBGB ALE HR Outbound Adapter','tksheers');

-- 09/08/2016 TK IA-000148-Added BSID for SI_AD_SAP_TRBGB_ALE_MT_OutboundV2 flow
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_TRBGB_ALEMT_OUT_V2','SAP TRBGB ALE Outbound Adapter','tksheers');

-- 29/08/2016 TK IA-000027-Added BSID for SI_BS_SAP_TRBGB_Invoice_Credit_Details_To_NSCNT flow
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_JAGNSCNT','IA-000027 - SAP Turbo Bulk Invoice to Austria NSC for Jaguar','tksheers');

INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_LRNSCNT','IA-000027 - SAP Turbo Bulk Invoice to Austria NSC for Land Rover','tksheers');

-- 09/09/2016 SB IA-000094-Added BSID for batch retrieve path in SI_BS_SAP_TRBGB_PosData_To_MultipleSystems flow
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRB_HR_WAJ_POSDATA','SAP Turbo HR Position Data to WAJ','sbawri');

-- 12/09/2016 SB IA-000290-Added BSIDs for batch retrieve paths (MSXi and MEDAGTE) in SI_BS_SAP_TRBGB_CurrentEmployeeData_To_MultipleSystems flow.					
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRB_HR_MSXI_CUREMPDATA','SAP Turbo HR Current Emp Data to MSXi','sbawri');
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRB_HR_MEDGT_CUREMPDATA','SAP Turbo HR Current Emp Data to MEDGATE','sbawri');

-- 12/09/2016 RBH FRS-000828-Added BSID for SI_BS_FAST_Finance_Reconciliation_To_SAP_TRBGB flow
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_FAST_INVOICE_SAP_TRBGB_FINANRECON','Finance reconciliation details from FAST to SAP Turbo','rbhamid1');

-- 14/09/2016 NS FRS-000712-Added BSID for dedicated adapter flows for the interface
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_HTTP_MATERIALGXS_OUTBOUND_V2','Dedicated HTTP outbound adapter flow for FRS-712','nsoste');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_HTTP_MATERIALGXS_INBOUND_V2','Dedicated HTTP inbound adapter flow for FRS-712','nsoste');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_HTTP_MATERIALGXS_REPLY_V2','Dedicated HTTP reply adapter flow for FRS-712','nsoste');

-- 20/09/2016 AC FRS-000154-Added BSID for SI_SV_CreateUpdate_Activity flow.
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_CTUPACTVTY','Create or Update Activity to SVCRM','achibbe1');

-- 22/09/2016 VV FRS-000833-Added BSID for SI_BS_PGZ_VALOBOM_To_SAP_TRBGB flow.
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PGZ_PRODUCT_SAP_TRBGB_VALOBOM','PGZ VALOBOM To SAP TRBGB','vviveka1');

-- 26/09/2016 AC FRS-000152-Added BSID for SI_SV_CreateUpdate_CareHireEvent flow.
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_CTUPCARHIR','Car Hire Evetnt to SVCRM','achibbe1');

-- 29/06/2016 AS FRS-000790 LMS Vehicle updates
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_ESM_VEHICLE_LMS_VEHUPDATES','SAP eSmart Veh Updates to LMS','asannag2');

-- 30/09/2016 VV Added entry for FRS-837
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_INVOICE_PGZ_SBINV','SAP Self Billing Invoice To PGZ','vviveka1');

-- 26/10/2016 SB Added entry for FRS-823
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_WERS_GTS_MATMASTERS','FRS-000823 - WERS Material Master To SAP GTS','sbawri');

-- 26/09/2016 AC FRS-000155-Added BSID for SI_SV_CreateUpdate_Appointment &  SI_AD_CANONICAL_APPOINTMENT_MT_OUT flow.
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_CRTUPDAPPNT','Crt Upd Appointment to SVCRM','achibbe1');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_CANON_APPOINTMENT','Canonical Appointment','achibbe1');

--  28/10/2016 SB Added entry for common outbound BAPI adapter flow, 'SI_AD_SAP_GTS_BAPI_VEHICLE_Outbound', conceived against work of FRS-000823.
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_GTS_BAPI_VEH_OUT','Outbound BAPI adapter flow for GTS, specific to VEHICLE data type','sbawri');

--  31/10/2016 NS Added entry for IA-258 new BS flow; new design
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_INVOICE_HYPER_FIDATA','IA-000258 eSMART/ SMARTCN/ SMARTFR Financial data to Hyperion','nsoste');

--  31/10/2016 NS Added entry for IA-258 new SAP SMART China BAPI Inbound Adapter flow
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_SMTCN_FIDATA_BAPI_IN_V2','IA-000258 eSMART/ SMARTCN/ SMARTFR Financial data to Hyperion','nsoste');

--  31/10/2016 NS Added entry for IA-258 new SAP SMART China BAPI Inbound Adapter flow
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_SMTFR_FIDATA_BAPI_IN_V2','IA-000258 eSMART/ SMARTCN/ SMARTFR Financial data to Hyperion','nsoste');

--  02/11/2016 TK Added entry for FRS-824 new GTS SAP BAPI Inbound Adapter flow and for business flow(SI_BS_SAP_GTS_Product_Classification_Data_To_CUSSTOMS)
--  04/11/2016 TK Updated entry for FRS-824 for business flow(SI_BS_SAP_GTS_Product_Classification_Data_To_CSTMS)
Insert into WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_GTS_HRMC_CSTMS_PRODCLASDATA','SAP GTS Product Classification Data to CUSSTOMS','tksheers');
Insert into WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_GTS_BAPI_HMRC_RFC_01_IN','SAP GTS BAPI Inbound adapter','tksheers');

-- 26/09/2016 AC FRS-000156-Added BSID for SI_SV_ReplicateCampaign.
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_REPLCAMPGN','Replicate Campaign','achibbe1');

-- 10/11/2016 VV Added entry for FRS-000153
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_CMPGNCRTUPD','Create or Update Campaign from External Consumer to SAP SVCRM','vviveka1');

-- 11/11/2016 NS Added entry for IA-000258 new SAP eSMART BAPI Inbound Adapter flow
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_ESMALL_FIDATA_BAPI_IN_V2','SAP eSMART Financial Data Inbound BAPI adapter flow','nsoste');

-- 14/11/2016 TK Added entry for IA-000355 new SAP HMRC BAPI Outbound Adapter flow
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_GTS_BAPI_HMRC_OUT','SAP HMRC BAPI outbound adapter flow','tksheers');

-- 17/11/2016 TK Added BSID for IA-000074 IFU4179
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ALL_BILLG_SAP_ESMRT_ACCREIV','Accounts Receivable - Billings','kthanga4');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_ESMALL_ALEMT_OUTV2','SAP eSmart Out Adapter for V2','kthanga4');

-- 22/11/2016 PP Added BSID for FRS-000839
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_BATCH_VENDORMASTER_TO_MFT','Vendor master data to MFT (Batch service)','ppancha4');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CANON_VENDORMASTER_DATASTORE','Vendor master data to MFT (Batch data loading service)','ppancha4');

-- 23/11/2016 SB Added BSID for IA-000221
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_D42_INV_GTS_EXPDECL','IA-000221 - D42 Export Declaration To SAP GTS','sbawri');

-- 08/12/2016 AS FRS-000841 entries
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_AFRL_VEHICLE_ESB_LISTPRICE','ListPrice to AFRL','asannag2');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ESB_VEHICLE_AFRL_LISTPRICE','ListPrice to AFRL','asannag2');

-- 28/12/2016 AS FRS-000130, GCM feed entry
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_CANON_DEALER_GCM_REPLICTEDR','ReplicateDealer to GCM','asannag2');

-- 06/01/2017 VV Added entry for FRS-838
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PGZ_MISC_PLO_VEHMNFSTAT','Vehicle Manufacturing Status from PGZ To PLO','vviveka1');

-- 12/01/2017 CM Added new BSIDs for FRS-000840
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_GCAMP_DEALER_ALL_UPSCMPGN','FRS-000840 GCAMP UPS Campaign To Multiple Systems','cmarret1');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_GCAMP_DEALER_VISTA_UPSCMPGN','FRS-000840 GCAMP UPS Campaign To Multiple Systems','cmarret1');

-- 02/02/2017 VV Added entry for FRS-000705
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PGZ_MISC_SPEEDY_ASN','ASN from PGZ To SPEEDY','vviveka1');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PGZ_SUPPLIER_SIM_GR','Goods Receipt from PGZ To SIM','vviveka1');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PGZ_SUPPLIER_SIM_QN','Quality Notification from PGZ To SIM','vviveka1');

-- 04/05/2017 VV Added entry for FRS-000705 migration
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRB_MISC_SPEDY_SUPDELINFO','Supplier Delivery Info from SAP To SPEEDY','vviveka1');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRB_SUPPLIER_SIM_GR','Goods Receipt from SAP To SIM','vviveka1');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRB_SUPPLIER_SIM_QN','Quality Notification from SAP To SIM','vviveka1');

-- 03/02/2017 RBH Added entry for FRS-000786
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_SMTCN_INVOICE_BRC_FUNDINGREQ','Funding Request details','rbhamid1');

-- 06/02/2017 SB Added entry for IA-000142 (IFU4401 - D42 Shipping reference to SAP GTS)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_D42_GTS_SHIPINGREF','IA-000142 D42 Shipping Reference to SAP GTS','sbawri');

-- 06/02/2017 TK Added entry for FRS-000787
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_BRC_INVOICE_SAP_SMTCN_FUNDINGRES','Funding Response details','tksheers');

-- 06/02/2017 RBH Added entry for SAP Smart Inbound Adapter.
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_SMTCN_ALE_IN','SAP Smart ALE Inbound adapter flow.','rbhamid1');

-- 07/02/2017 CM Added new BSIDs for FRS-000844
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PODS_VEHICLE_CMMS3_PARTCHANGE','FRS-000844 PODS Vehicle Part Change To CMMS3','cmarret1');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PODS_VEHICLE_CMMS3_PARTCHANGE_ACK','FRS-000844 PODS Vehicle Part Change To CMMS3','cmarret1');

-- 08/03/2017 SB Added entry for FRS-000107 (IFU4438 - Vista Order Replicate to XROAD)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_VISTA_CUSSV_XROAD_ORDERREPL','FRS-000107 VISTA Order Replicate To XROAD','sbawri');

-- 10/03/2017 CM Added new BSIDs for FRS-000799
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_ALL_WTYCAMPAIGN','FRS-000799 Publish Warranty Campaigns','cmarret1');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_GROOT_WTYCAMPAIGN','FRS-000799 Publish Warranty Campaigns','cmarret1');

-- 16/03/2017 CM Added new BSIDs for AD-00010 - SAP adapter SI_AD_SAP_TRBGB_ALE_RFC_10_Inbound
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_TRB_RFC_10_ALEINB','AD-00010 SAP adapter SI_AD_SAP_TRBGB_ALE_RFC_10_Inbound','cmarret1');

-- 17/03/2017 asannag2 Added new BSIDs for FRS-000847
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRB_VEHICLE_PGZ_CUSTDECL','FRS-000847 Customs Declaration Data from SAP TRB to PGZ','asannag2');

-- 24/03/2017 tksheers Added missing BSID entry for existing AD-00012 - SI_AD_SAP_TRB_TD_ALE_RFC_04_Inbound adapter
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_TRBGB_MQSERV_ALEINTD','AD-00012 SAP Adapter SI_AD_SAP_TRB_TD_ALE_RFC_04_Inbound','tksheers');

-- 24/03/2017 AC Added entry for FRS-000107 (IFU4515 - Vista GOF to Map Suppliers)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_VISTA_CUSSV_MAPSUP_GOF','FRS-000107 VISTA GOF To Map Suppliers','achibbe1');

--	31/03/2017 RBH Added entry for FRS-000259 (IFU4514)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PLO_VEHICLE_ALL_VEHMAPPROP','FRS-000259 PLO Integration','rbhamid1');

--	10/04/2017 CM Added entry for FRS-000003 (IFU4552)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SOAP_VEHICLE_ALL_VEHPARTS','AD-00015 is FRS-000003/FRS-000258/717 Adapter','cmarret1');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_MULTI_VEHICLE_MULTI_PARTSERIAL','FRS-000003 Part Serial Number Update To Multiple Systems','cmarret1');

--	11/04/2017 VV Added entry for SAP Outbound Adapter SI_AD_SAP_TRB_ALE_TD_Outbound
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_TRB_TD_ALEOUT','AD-00013 SAP Outbound Adapter To SAP TRB','vviveka1');

--	19/04/2017 asannag2 IA-000107 PODS interface, SI_BS_SAP_TRB_VendorMasterUpdates_To_PODS
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRB_VEHICLE_PODS_VNDRMASTER','IA-000107 SAP VendorMasterUpdates to PODS','asannag2');

--	26/04/2017 asannag2 FRS-000840, GCAMP UPS Warranty Campaign to VISTA
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_GCAMP_WTYCMPGN_ALL_UPS','FRS-000840 UPS Warranty Campaign to VISTA','asannag2');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ESB_WTYCMPGN_VISTA_UPS','FRS-000840 UPS Warranty Campaign to VISTA','asannag2');

--	27/04/2017 RBH Added entry for FRS-000003- Encore (IFU4476)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PGZ_QUALITY_ALL_PARSENOUPD','FRS-000003- Part Serial Numbers (OPCON and VCATS to SAP Turbo)','rbhamid1');

--	27/04/2017 AC Added entry for FRS-000615(TO_SVCRM)	- Wave 1 Warranty (IFU4581)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_ESB_VEHICLE_SVCRM_REPWTYCNTR','FRS-000615- Vehicle Warranty Contract (SAP Turbo to SVCRM)','achibbe1');

--	04/05/2017 AC Added entry for FRS-000158- SVCRM (IFU4602)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_SV_CUSSV_GETVEHLDTLS','FRS-000158- Get Vehicle Warranty Details (Consumer to SAP Turbo)','achibbe1');

--	09/05/2017 VV Added entry for FRS-000842(IFU4278)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_SAP_ESM_INVOICE_LMMS_INPMSTAUPD','FRS-000842 - Invoice Payment Status Update from SAP to LMMS','vviveka1');

--	09/05/2017 AC Added entry for FRS-000799(IFU4617)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_ESB_VEHICLE_SVCRM_WTYCAMPAIGN','FRS-000799 - Warranty Campaign Update from SAP Turbo to SVCRM','achibbe1');

--	09/05/2017 AC Added entry for FRS-000160(IFU4637)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_SV_CUSSV_VEHCLMLDTLS','FRS-000160 - Get Vehicle Warranty Claim Details (Consumer to SAP Turbo)','achibbe1');

--	15/05/2017 TK Added entry for FRS-000159(IFU4635)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_SV_CUSSV_GTWTYCLAIM','FRS-000159 - Get Warranty Claims(SVCRM to SAP Turbo)','tksheers');

--	22/05/2017 RBH Added entry for SAP ALE Stone Outbound Adapter (IFU4634)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_AD_SAP_TRB_STONE_ALEOUT','SAP ALE Stone Outbound adapter flow.','rbhamid1');

--	27/04/2017 AC Added entry for FRS-000003- Encore (IFU4699- OA)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_PGZ_QUALITY_OA_PARSENOUPD','FRS-000003- Part Serial Numbers (OPCON and VCATS to SAP Turbo)','achibbe1');

-- 09/06/2017 asannag2 Added entry for SI_AD_SAP_TRB_ALE_HR_RFC_01_Inbound (FRS-000720), adapter flow moved to new build process
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_TRB_ALE_HR_RFC_01_IN','FRS-000720 SAP Turbo HR Interface','asannag2');

--	19/06/2017 RBH Added entry for FRS-870 Vehicle Derivative and Derivative Features To BODS  
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_BRS_VEHICLE_BODS_VEHDERFEAT','Vehicle Derivative and Derivative Features To BODS','rbhamid1');

--	29/06/2017 TK Added entry for generic HTTP inbound and reply adapter  
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_AD_HTTP_INBOUND_GEN','HTTP inbound adapter','tksheers');

INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_AD_HTTP_REPLY_GEN','HTTP reply adapter','tksheers');

-- 03/07/2017 CM FRS-000139 IFU4735, Added BSID for the new build removed existing BSID 
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_BBSS_ALL_VEHSALESTAT','BBSS Replicate Vehicle Sale or Status','cmarret1');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_ESB_ALL_VEHSALESTAT','BBSS Replicate Vehicle Sale or Status','cmarret1');

--	05/07/2017 RBH Added entry for FRS-00869 VIN to Order Interface (Plant Graz to ESB) - Encore
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_PGZ_VEHICLE_MFT_VINTOORDER','VIN to Order Interface (Plant Graz to ESB)','rbhamid1');

--	10/07/2017 TK Added entry for FRS-000829 TurboSAP and TMS Integration - TD
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_SAP_TRB_TMS_SENDPYMT','FRS-000829 TurboSAP and TMS Integration','tksheers');

INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_AD_SAP_TRB_04_RFC_04_BAPIINB','SAP Turbo inbound adapter','tksheers');

-- 12/07/2017 asannag2 Added entry for FRS-000867 DigitalCoC
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_WVTA_ESB_DCOC','FRS-000867 DigitalCoC','asannag2');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_ESB_MULTI_DCOC','FRS-000867 DigitalCoC','asannag2');

-- 17/07/2017 rbhamid1 Added entry for FRS-000842 Invoice Payment Status Updates
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_SAP_ESM_LMMS_PAYSTATUPD','FRS-000842 Invoice Payment Status Updates','rbhamid1');

--	21/07/2017 sbawri Added entry for FRS-00861 Employee Data to GrassRoot (SAP to CANON FRS-720 to FRS-861) - VBR
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_CANON_GROOT_EMPDATA','FRS-000861 Employee Data to GrassRoot (SAP to CANON FRS-720 to FRS-861-GrassRoot)','sbawri');

-- 25/07/2017 KT Added BSID for FRS-000871
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_FIMS_DDB_INSERTION','FIMS to Dealer DB Insertion','kthanga4');

-- 25/07/2017 asannag2 FRS-000868 (IFU4800), new interface.
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_TRB_RFC_10_BAPIIN','FRS-869, SAP Turbo BAPI Inbound Adapter','asannag2');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_BS_SAP_TRB_SDL_WRNTYLANGT','FRS-868 SAP TRB Wrnty Lang Translt To SDL','asannag2');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_GENERIC_BAPIREPLY','FRS-868, SAP Reply Generic BAPI Adapter','asannag2');

-- 08/08/2017 CM FRS-000848 Added BSID for the new build
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_SAP_TRB_MULTI_WARRANTYSBI','FRS-000848 Warranty SBI - SAP Turbo to Various ','cmarret1');

-- 09/08/2017 rbhamid1 Added entry for FRS-00863 - Stock Levels SAP-ECC to Zoller-TMS
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_SAP_TRB_ZOLER_STOCKLEVEL','FRS-000863 Stock Levels SAP-ECC to Zoller-TMS','rbhamid1');

-- 09/08/2017 CM FRS-000848 Added SAP Adapter BSID for the new build
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_AD_SAP_TRB_ALE_RFC_11_IN','ESB SAP TRB RFC_11 ALE Inbound Adapter ','cmarret1');

-- 09/08/2017 tksheers Added entry for FRS-00865 - Unit Price SAP-ECC to Zoller-TMS
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_SAP_TRB_ZOLER_UNITPRICE','FRS-00865 - Unit Price SAP-ECC to Zoller-TMS','tksheers');

INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_AD_SAP_TRB_ESBTMSALE_ALEINB','SAP Turbo ESBTMSALE ALE Inbound Adapter','tksheers');

--	11/08/2017 SB Added entry for FRS-00880 Vehicle weight & ICCID2 (SAP Turbo to Russia NSC) - Boston
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_SAP_TRB_NSCRU_VEH_WT_ICCID2','FRS-000880 Vehicle weight and ICCID2 (SAP Turbo to Russia NSC)','sbawri');

-- 16/08/2017 asannag2 FRS-000792 HR Interface - ESB to NGA UK, IFU4679, new interface
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_CANON_NGAUK_HREMP','FRS-000792 HR Interface - ESB to NGA UK','asannag2');

-- 17/08/2017 tksheers Added entry for SOAP STD Outbound adapter
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_AD_SOAP_STD_OUT','SOAP STD Outbound adapter','tksheers');

-- 16/08/2017 asannag2 IFU4826, FRS-000102 FMS to Enovia AIMS Service, new interface
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_SV_FMSIssue_AIMS2','FRS-000102 FMS to Enovia AIMS Service','asannag2');

--	18/08/2017 sbawri IFU4819, BAPI Inbound Adapter - FRS-000880 Vehicle weight & ICCID2 to Russia NSC
INSERT INTO WMBOWNER.SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_TRB_VEHICLE_BAPIINB','SAP Turbo Inbound BAPI Adapter Flow for Vehicle data','sbawri');

--	24/08/2017 SB Added entry for FRS-00881 Vehicle weight & ICCID2 (VCATS to SAP Turbo) - Boston - Russia (RU)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_VCATS_SAP_TRB_VEH_WT_ICCID2','FRS-000881 Vehicle weight and ICCID2 (VCATS To SAP Turbo)','sbawri');

--	24/08/2017 SB Added entry for SI_AD_SAP_TRB_BAPI_Vehicle_Outbound (FRS-000881) - Boston - Russia (RU) - CR1426
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_AD_SAP_TRB_VEHICLE_BAPIOUT','Outbound Async BAPI adapter for Vehicle data domain','sbawri');

--	07/09/2017 TK Added entry for FRS-000872 - SCS Recon Part information request to SAP APO and BoM result
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_SCSRC_SAP_APO_PARTINFOREQ','FRS-000872 - SCS Recon Part information request to SAP APO and BoM result','tksheers');

INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_AD_SAP_APO_BAPI_VEH_OUT','Outbound Async SAP APO BAPI adapter for Vehicle data domain','tksheers');

--	14/09/2017 SB Added entry for FRS-00882 Certificate of Conformity Trigger data (SAP eSmart to WVTA) - Boston (Belgium) CR-1415
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_SAP_ESM_WVTA_COCTRIG','FRS-000882 Certificate of Conformity Trigger data (SAP eSmart to WVTA)','sbawri');

--	14/09/2017 TK Added entry for FRS-00787 Funding Response(GL Connect to SAP eSmart)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_GLC_SAP_ESM_FUNDINGRES','FRS-00787 Funding Response (GL Connect to SAP eSmart)','tksheers');

--	15/09/2017 RBH Added entry for FRS-00786 Funding Request(SAP eSmart to GL Connect)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_SAP_ESM_GLC_FUNDINGREQ','FRS-00786 Funding Request (SAP eSmart to GL Connect)','rbhamid1');

--	18/09/2017 SB Added entry for SI_AD_SAP_TRBGB_ALE_RFC_12_Inbound (FRS-000847) - IFU4890 (Encore wanting to have a dedicated inbound adapter)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_AD_SAP_TRB_RFC_12_ALEINB','Inbound adapter on RFC Programme Id WMB_TRBALE_RFC_12','sbawri');

-- 20/09/2017 asannag2 FRS-000866, Sales Purchase Tax Returns from SAP eSmart to GST India
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_SAPESM_ASP_SLSTAXRET','FRS-000866 Sales Purchase Tax Rtrns to GSTIndia','asannag2');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_SAPESM_ASP_PURCHTAXRET','FRS-000866 Sales Purchase Tax Rtrns to GSTIndia','asannag2');

-- 20/09/2017 cmarret1 FRS-000799, Warranty Campaigns to VISTA
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_ESB_VEHICLE_VISTA_WTYCAMPAIGN','FRS-000799 Warranty Campaigns to VISTA','cmarret1');

--	22/09/2017 SB Added entry for SI_AD_SAP_ESM_ALE_VEHDATA_RFC_06_Inbound (FRS-000882) - IFU4877
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_AD_SAP_ESM_VEHDATA_RFC_06_ALEINB','Inbound adapter on RFC Programme Id WMB_ESMALE_VEHDATA_RFC_06','sbawri');

--	25/09/2017 RBH Added entry for FRS-000778 Publish Vehicle Status
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_SAP_ESM_MULTI_PUBVEHSTAT','FRS-000778 Publish Vehicle Status','rbhamid1');

--	03/10/2017 TK Added entry for FRS-000107 Order Replicate(Vista to Salesforce LMS)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_SV_CUSSV_SFLMS_ORDERREPL','FRS-000107 Order Replicate(Vista to Salesforce LMS)','tksheers');

--	05/10/2017 AC Added entry for FRS-000151 Canonical Product Reference(BRS to Salesforce LMS)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_CANON_PRODUCT_LMS_PRODREF','FRS-000151 Canonical Product Reference(BRS to Salesforce LMS)','achibbe1');

--	05/10/2017 AC Added entry for FRS-000130 Replicate Dealer (DDB to WT)
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_CANON_DEALER_WT_REPLICTEDR','FRS-000130 Replicate Dealer (DDB to WT)','achibbe1');

--	10/10/2017 SB Added entry for IA-000124 (Mizuho bank) - IFU-4934
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_MIZ_SAP_ESM_STATEMENT','IA-000124 Bank Statements (Japanese Mizuho bank to SAP eSmart)','sbawri');

-- 11/10/2017 RBH Added entry for FRS-000864- Stock Levels Zoller-TMS to SAP-ECC 
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_SV_STOKLEVUPD','FRS-000864 Stock Levels Zoller-TMS to SAP-ECC','rbhamid1');

-- 18/10/2017 RBH Added entry for FRS-00787 Funding Response(Mizuho to SAP eSmart) - IFU 4957
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_MIZ_SAP_ESM_FUNDINGRES','FRS-000787 Funding response (Mizuho to SAP eSmart)','rbhamid1');

-- 20/10/2017 tksheers Added entry for FRS-000779- End life cycle of Vehicle SORA to SAP-ESM
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_SORA_SAP_ESM_ELV','FRS-000779- End life cycle of Vehicle SORA to SAP-ESM','tksheers');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_AD_SAP_ESM_VEH_ALEOUT','SAP eSmart Vehicle outbound adapter','tksheers');

-- 26/10/2017 kthanga4 Added entry for FRS-000875
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_SAP_TRB_NGASK_HREMP','FRS-000875-EmpData SAP Turbo to NGASK','kthanga4');

-- 27/10/2017 cmarret1 Added entries for FRS-000003 IFU4919/4980
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_AD_SAP_TRB_ALE_OUT','SAP ALE Outbound to SAP TRB','cmarret1');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_AD_MULTI_SOAP_ALL_VEHPARTSERUPDATE','SOAP inbound to UpdatePartSerialNumber Bus Service','cmarret1');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_ESB_ PARTSERNUM_V1TOV2','SOAP V1 to V2 UpdatePartSerialNumber Bus Service','cmarret1');

--	01/11/2017 SB Added entry for FRS-000884 Automated ABS
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_FFS_D42_INTOCOMPOUNDSTS','FRS-000884 Automated ABS','sbawri');

--	06/11/2017 SB Added entry for the inbound created adapter for FRS-000884 Automated ABS
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_AD_SCANNER_HTTPIN','HTTP Inbound adapter for Scanner','sbawri');

--	06/11/2017 SB Added entry for the reply adapter created for FRS-000884 Automated ABS
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_AD_SCANNER_HTTP_REPLY','HTTP Reply adapter for Scanner','sbawri');

--	07/11/2017 SB Added entry for outbound adapter created for FRS-000884 Automated ABS
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_AD_D42_HTTP_OUTBOUND','HTTP Outbound adapter for D42','sbawri');

--	17/11/2017 KT Added entry for FRS-000883
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_PLO_SIMULTDORD_SAP_TRB_VEHORDRQ','PLO Simulated Order to SAP TRB','kthanga4');

--	17/11/2017 TK Added entry for IFU5048, IFU5049 and IFU5050
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_SAP_SMACN_VEHICLE_DMS_PRICINGINF','IA-000192 Pricing Information','tksheers');

INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_SAP_SMACN_DEALER_DMS_DEALERDATA','IA-000193 Dealer Data','tksheers');

INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_MQ_ESB_FTP_MFT_OUTBOUND','SMTCN FTP outbound adapter','tksheers');

INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL,'SI_AD_SAP_SMTCN_VEH_BAPIREPLY','SMTCN BAPI Reply adapter','tksheers');

INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_CANON_HR_KRONOSSK_EMPTADATA','FRS-000876 Canonical Employee TA Batch Data To KRONOS Slovakia','tksheers');

--	30/11/2017 SB Added entry for FRS-000885 Supplier Online Portal Integration via Covisint
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_SAP_TRB_CSOP_SCHDLINES','FRS-000885 Schedule Lines processing part of the interface','sbawri');

INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_BS_CSOP_SAP_TRB_ASN','FRS-000885 ASN processing part of the interface','sbawri');
-- 29/01/2018, asannag2, IFU5198, flow moved to new build process
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_AD_D42_VEHSTATUPD_HTTPIN','HTTP Inbound adapter for D42 Vehicle Status Updates','asannag2');
INSERT INTO SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID,BUSINESS_SERVICE_NAME,DESCRIPTION,USER_ID) VALUES (SI_BUSINESS_SERVICE_ID.NEXTVAL, 'SI_AD_D42_VEHSTATUPD_HTTP_REPLY','HTTP Reply adapter for D42 Vehicle Status Updates','asannag2');

COMMIT;