--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: $Revision: 1.1 $
-- Description 	: Create sequence script for table SI_BUSINESS_SERVICE_DETAILS table
-- History 		: 24/11/2011 Hina Mistry Initial create statement for sequence
--------------------------------------------------------------------------------------------------------

DROP SEQUENCE SI_BUSINESS_SERVICE_ID;
		
--Sequence to generate the ID value for SI_BUSINESS_SERVICE_DETAILS table
CREATE SEQUENCE SI_BUSINESS_SERVICE_ID 
MINVALUE 1
START WITH 1
INCREMENT BY 1
CACHE 10;							 

COMMIT;

