--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: $Revision: 1.2 $
-- Description 	: Create table script for SI_BUSINESS_SERVICE_DETAILS table which will business service information
-- History 		: 24/11/2011 Hina Mistry Initial create statement for table
--				  13/04/2012 Hina Mistry Altering size of the business_service_name column
--				  07/12/2012 Seenesh Patel Primary Key altered to BUSINESS_SERVICE_NAME
--------------------------------------------------------------------------------------------------------

DROP TABLE SI_BUSINESS_SERVICE_DETAILS;

CREATE TABLE SI_BUSINESS_SERVICE_DETAILS (BUSINESS_SERVICE_ID NUMBER(5) NOT NULL,
								 BUSINESS_SERVICE_NAME VARCHAR2(35) NOT NULL,
								 DESCRIPTION VARCHAR2(250),
								 INSERT_TIMESTAMP TIMESTAMP,
								 UPDATE_TIMESTAMP TIMESTAMP,
								 USER_ID VARCHAR2(10) NOT NULL,
								 CONSTRAINT PK_BUS_SERV_ID PRIMARY KEY (BUSINESS_SERVICE_ID));



--13/04/2012 HM Business Service Name column - size alteration
ALTER TABLE SI_BUSINESS_SERVICE_DETAILS MODIFY BUSINESS_SERVICE_NAME VARCHAR2(45);

--07/12/2012 SP Primary Key altered to BUSINESS_SERVICE_NAME rather then BUSINESS_SERVICE_ID
ALTER TABLE SI_BUSINESS_SERVICE_DETAILS DROP CONSTRAINT PK_BUS_SERV_ID;
ALTER TABLE SI_BUSINESS_SERVICE_DETAILS ADD CONSTRAINT PK_BUS_SERV_ID PRIMARY KEY (BUSINESS_SERVICE_NAME);

COMMIT;

