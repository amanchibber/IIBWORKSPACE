--------------------------------------------------------------------------------------------------------
-- Author 		: Ryan Glackin
-- Version 		: $Revision: 1.30 $
-- Description 	: Insert data script for SI_CANONICAL_TRANSLATION. Used to convert to/from system specific
--				  values and standard canonical values.
-- History 		: 11/07/2012 (RGLACKLI) Initial Entries
--				: 09/08/2012 AH	Added translation from SAP to Canonical + Canonical to VISTA for Veh Status
--				: 14/08/2012 HM Addition of user id column
--				: 09/10/2012 AS IA-67, Vehicle Events from D42 to eSmart
--				: 06/11/2012 VY IA-09, For SAP to D42 and reverse
--              : 28/01/2013 CB (cburger1) IFU637 Complete re-write of canonical lookup.
--              : 22/03/2013 CB (cburger1) IFU844 Revert to use old codes for INVEXP, INVDLR and EXCLOVR 
--              : 22/03/2013 CB (cburger1) IFU844 Changed their minds EXCLOVR to remain.
--				: 30/04/2014 KT	IFU1834 METHOD_NAME - Vehicle/vehiclestatusupdate is included for PENAMND
--              : 30/05/2014 AaP Added Entries for IFU1898.
--              : 05/06/2014 AC Added Entries for IFU1978/1979.
--              : 17/06/2014 AC Added Entries for SMART - China and France
--              : 24/07/2014 AC Edited entries as per IFU 2196
--              : 24/07/2014 AC Edited entries as per IFU 2196
--              : 20/08/2014 NM Edited entries as per Defect 8084 and 8085 for events PDICALL and COFT
--				: 16/02/2015 AP entry added as per incident INC000000404874
--				: 16/01/2018 KB Added entry for IA-67 IFU5185 esmart Japan
--------------------------------------------------------------------------------------------------------


DELETE FROM SI_CANONICAL_TRANSLATION;

							   --SYSTEM_IDENTIFIER 	  VARCHAR2  (20),         
							   --SYSTEM_EVENT_TYPE    VARCHAR2  (50) DEFAULT ('2') NOT NULL,  
							   --CANONICAL_EVENT_TYPE VARCHAR2  (50) DEFAULT ('3') NOT NULL, 
							   --METHOD_NAME 	      VARCHAR2 (100),
							   --BROKER 			  VARCHAR2   (8),
							   --INSERT_TIMESTAMP 	  TIMESTAMP  (6), 
							   --UPDATE_TIMESTAMP 	  TIMESTAMP  (6),
							   --DESCRIPTION 		  VARCHAR2 (100),
							   --USER_ID  			  VARCHAR2  (10),
							   
Insert into SI_CANONICAL_TRANSLATION values (null,'ABS','ABS','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'ACCPTEX','ACCPTEX','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'AFD','AFD',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'STAT40','AFDEXP',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'AFS','AFS',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'ARRPTEX','ARRPTEX','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'ARRPTIN','ARRPTIN','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'CALLOVR','CALLOVR',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'CANHDOVER','CANHDOVER',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'CLRABS','CLRABS','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'CLRAFS','CLRAFS',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'CLRFUND','CLRFUND',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'CLRGSTD','CLRGSTD',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'CLRSLCT','CLRSLCT',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
--NM 20/08/2014 Added method name to COFT event entry as per defect 8805
Insert into SI_CANONICAL_TRANSLATION values (null,'COFT','COFT','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'COLLEND','COLLEND',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'CONTOUT','CONTOUT',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'CONTRTN','CONTRTN',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'CPDDUPD','CPDDUPD',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'CPDUPDATE','CPDUPDATE',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'CUSCLRD','CUSCLRD','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'DAMAGE','DAMAGE',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'DELVRDUK','DELVRDUK',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'DEMOREV','DEMOREV',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'DEMOST','DEMOST',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'DISPOSAL','DISPOSAL',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'DLRAMND','DLRAMND',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'DLR-DEL','DLRDELEX','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);
--AP 16/02/2015 AP entry added as per incident INC000000404874
Insert into SI_CANONICAL_TRANSLATION values (null,'DLRDEL','DELVRDIN','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'DPAMND','DPAMND',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'ENGNADD','ENGNADD',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'GATEDES','GATEDES','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'GHOSTED','GHOSTED','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'HANDOVER','HANDOVER',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'HOLDADD','HOLDADD',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'HOLDREM','HOLDREM',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'IN2COMP','IN2COMP','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'INTRANS','INTRANS',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'MANOK','MANOK',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'MSUBMIT','MSUBMIT',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'NOTRFS','NOTRFS',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'NSAMND','NSAMND',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'OCANCEL','OCANCEL',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'OCREATE','OCREATE','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'OFFASSY','OFFASSY','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'OFFPLNT','OFFPLNT',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'OFFPOE','OFFPOE',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'OFFTRIM','OFFTRIM',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'ONASSY','ONASSY',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'ONTOLOAD','ONTOLOAD',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'ONTRIM','ONTRIM','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'OSAMND','OSAMND',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'OSUBMIT','OSUBMIT','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'OUBCAN','OUBCAN',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'OUTCOMP','OUTCOMP','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'OUTPTEN','OUTPTEN','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);
--NM 20/08/2014 Added method name to PDICALL event entry as per defect 8804
Insert into SI_CANONICAL_TRANSLATION values (null,'PDICALL','PDICALL','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'PDICALR','PDICALR',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);

-- Added entry as per IFU 1978/1979
Insert into SI_CANONICAL_TRANSLATION values (null,'PDICOMP','PDICOMP','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);

Insert into SI_CANONICAL_TRANSLATION values (null,'PENAMND','PENAMND','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'PICOMP','PICOMP','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'RBS','RBS',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'RDYCOFT','RDYCOFT',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);

Insert into SI_CANONICAL_TRANSLATION values (null,'RDYTRAN','RDYTRAN','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'REGISTR','REGISTR',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'RELTRUCK','RELTRUCK',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'REMCALL','REMCALL',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'REMLOAD','REMLOAD',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'REQFUND','REQFUND',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'RFS','RFS',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'RTECHG','RTECHG',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'RTNCOMP','RTNCOMP',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'RTNPLAN','RTNPLAN',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'SELECTD','SELECTD','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'SHIPPED','SHIPPED','Vehicle/vehiclestatusupdate',null,null,null,'Canonical Event Code To SAP eSmart System Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'SHPAL','SHPAL',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'SHPDL','SHPDL',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'UNREGST','UNREGST',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'VEHENFD','VEHENFD',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'VEHENST','VEHENST',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'VINADD','VINADD',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'WARRST','WARRST',null,null,null,null,'System Event Code to Canonical Event Code Translation',null);

--KB 16/01/2018 Added entry for IA-67 IFU5185 esmart Japan
Insert into SI_CANONICAL_TRANSLATION values (null,'PDISTRT','PDISTRT','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);

Insert into SI_CANONICAL_TRANSLATION values (null,'EXCLOVR','EXCLOVR','emitCreateAfterImageSapZvistaD42OutIf',null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values ('D42','EUCLOVR','EXCLOVR',null,null,null,null,'Canonical Event Code To D42 System Event Code Translation',null);

--start IFU844 Revert to use old codes
--Insert into SI_CANONICAL_TRANSLATION values (null,'INVDLR','INVDLR','emitCreateAfterImageSapZvistaD42OutIf',null,null,null,'System Event Code to Canonical Event Code Translation',null);
--Insert into SI_CANONICAL_TRANSLATION values ('VISTA','DLRINV','INVDLR',null,null,null,null,'Canonical Event Code To VISTA Event Code Translation',null);
--Insert into SI_CANONICAL_TRANSLATION values (null,'INVEXP','INVEXP','emitCreateAfterImageSapZvistaD42OutIf',null,null,null,'System Event Code to Canonical Event Code Translation',null);
--Insert into SI_CANONICAL_TRANSLATION values ('VISTA','NSCINV','INVEXP',null,null,null,null,'Canonical Event Code To VISTA Event Code Translation',null);

--NM 16/06/2014 Defect 8219 Uncommented the entry for 'SYSTEM_EVENT_TYPE':DLRINV and 'CANONICAL_EVENT_TYPE':INVDLR methodname :'emitCreateAfterImageSapZvistaD42OutIf' 
--NM 16/06/2014 Commented entry for 'SYSTEM_EVENT_TYPE':DLRINV and 'CANONICAL_EVENT_TYPE':INVDLR methodname :'emitCreateAfterImageSapZvistaD42OutIf' 
--(New entries added for VISTA and PRXCAR)
--Insert into SI_CANONICAL_TRANSLATION values ('VISTA','DLRINV','INVDLR','emitCreateAfterImageSapZvistaD42OutIf',null,null,null,'Canonical Event Code To VISTA Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values ('VISTA','NSCINV','INVEXP','emitCreateAfterImageSapZvistaD42OutIf',null,null,null,'Canonical Event Code To VISTA Event Code Translation',null);
--end IFU844

--30/05/2014 AaP Added for IFU1898
--NM 16/06/2014 Commented entry
--Insert into SI_CANONICAL_TRANSLATION values ('VISTA','DLRINV','INVDLR','manufacturing/ExternalVehicleFinanceStatus',null,null,null,'Canonical Event Code To VISTA Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'DLRPN','DLRPN','manufacturing/ExternalVehicleFinanceStatus',null,null,null,'Canonical Event Code To VISTA Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'NOINV','NOINV','manufacturing/ExternalVehicleFinanceStatus',null,null,null,'Canonical Event Code To VISTA Event Code Translation',null);



/* --NM 16/06/2014 Added entries for IA-09
Insert into SI_CANONICAL_TRANSLATION values ('VISTA','DLRINV','INVDLR',null,null,null,null,null,null);
Insert into SI_CANONICAL_TRANSLATION values ('PXCAR','DLRINV','INVDLR',null,null,null,null,null,null);
Insert into SI_CANONICAL_TRANSLATION values (null,'DLRINV','INVDLR','emitCreateAfterImageSapZvistaD42OutIf',null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'DLRINV','INVDLR','manufacturing/ExternalVehicleFinanceStatus',null,null,null,'System Event Code to Canonical Event Code Translation',null);
 */
--NM 21/07/2014 Commented the above 4 entries for IA-09 and added a new entry.
Insert into SI_CANONICAL_TRANSLATION values (null,'DLRINV','INVDLR','emitCreateAfterImageSapZvistaD42OutIf,manufacturing/ExternalVehicleFinanceStatus',null,null,null,'Canonical Event Code Translation',null);
-- 17/07/2014 AC Added missing Event types for SMART- CHina and France (IA- 67, 61)
-- IFU 2196 (entry for event type - MVDLRCOMP needs to be removed and MV2DLRCOMP needs to be added
--Insert into SI_CANONICAL_TRANSLATION values (null,'MVDLRCOMP','MVDLRCOMP','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);
Insert into SI_CANONICAL_TRANSLATION values (null,'MV2DLRCOMP','MV2DLRCOMP','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);

Insert into SI_CANONICAL_TRANSLATION values (null,'RDYTRANDLR','RDYTRANDLR','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);

Insert into SI_CANONICAL_TRANSLATION values (null,'IN2DLRCOMP','IN2DLRCOMP','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);

Insert into SI_CANONICAL_TRANSLATION values (null,'OUTDLRCOMP','OUTDLRCOMP','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);

Insert into SI_CANONICAL_TRANSLATION values (null,'DLR-CLOVR','DLR-CLOVR','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);

Insert into SI_CANONICAL_TRANSLATION values (null,'ETAUPDT','ETAUPDT','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);

Insert into SI_CANONICAL_TRANSLATION values (null,'DELVRD','DELVRD','Vehicle/vehiclestatusupdate',null,null,null,'System Event Code to Canonical Event Code Translation',null);




Commit;













































