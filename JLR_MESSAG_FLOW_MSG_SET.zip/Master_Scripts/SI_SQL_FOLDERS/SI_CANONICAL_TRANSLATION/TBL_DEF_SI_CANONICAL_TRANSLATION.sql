--------------------------------------------------------------------------------------------------------
-- Author 		: Ryan Glackin (RGLACKLI)
-- Version 		: $Revision: 1.2 $
-- Description 	: Create table script for SI_CANONICAL_TRANSLATION table which will hold batch records
-- History 		: 11/07/2012 RG (RGLACKLI) Initial create statement for table
--				  14/08/2012 HM (hmistry) Addition of user id column
--              : 28/01/2013 CB (cburger) IFU637 Complete re-write of canonical lookup.
--------------------------------------------------------------------------------------------------------

DROP TABLE SI_CANONICAL_TRANSLATION;

--CREATE TABLE SI_CANONICAL_TRANSLATION (SYSTEM_IDENTIFIER VARCHAR2(20) NOT NULL,
--							   BUSINESS_SERVICE_ID VARCHAR2(45), 
--							   CANONICAL_EVENT_TYPE VARCHAR2(20), 
--							   CANONICAL_VALUE VARCHAR2(50),
--							   BROKER VARCHAR2(8),
--							   INSERT_TIMESTAMP TIMESTAMP (6), 
--							   UPDATE_TIMESTAMP TIMESTAMP (6),
--							   DESCRIPTION VARCHAR2(100),
--							   CONSTRAINT SI_CANONICAL_TRANSLATION PRIMARY KEY (SYSTEM_IDENTIFIER, BUSINESS_SERVICE_ID, CANONICAL_EVENT_TYPE));

--ALTER TABLE SI_CANONICAL_TRANSLATION ADD USER_ID VARCHAR2(10) NOT NULL;

CREATE TABLE SI_CANONICAL_TRANSLATION (SYSTEM_IDENTIFIER     VARCHAR2  (20),         
                                       SYSTEM_EVENT_TYPE     VARCHAR2  (50) DEFAULT ('2') NOT NULL, 
                                       CANONICAL_EVENT_TYPE  VARCHAR2  (50) DEFAULT ('3') NOT NULL,
                                       METHOD_NAME           VARCHAR2 (100),
                                       BROKER                VARCHAR2   (8),
                                       INSERT_TIMESTAMP      TIMESTAMP  (6), 
                                       UPDATE_TIMESTAMP      TIMESTAMP  (6),
                                       DESCRIPTION           VARCHAR2 (100),
                                       USER_ID               VARCHAR2  (10));

COMMIT;
