--------------------------------------------------------------------------------------------------------
-- Author 		: Ryan Glackin (RGLACKLI)
-- Version 		: $Revision: 1.1 $
-- Description 	: Create trigger script for trigger on table SI_CANONICAL_TRANSLATION which will update the table
--				  with a insert timestamp when a row has been inserted 
-- History 		: 11/07/2012 Ryan Glackin (rglackli) Initial create statement for trigger CANONTRANS_TMSTMP_TRG
--------------------------------------------------------------------------------------------------------

DROP TRIGGER SI_CANONTRANS_TMSTMP_TRG;

--Trigger which will insert or update the timestamp if an insert or update action occurs
CREATE OR REPLACE
TRIGGER SI_CANONTRANS_TMSTMP_TRG
BEFORE INSERT OR UPDATE ON SI_CANONICAL_TRANSLATION
FOR EACH ROW
BEGIN

IF INSERTING THEN
	:new.INSERT_TIMESTAMP := systimestamp;
	:new.UPDATE_TIMESTAMP := NULL;
ELSE
	:new.UPDATE_TIMESTAMP := systimestamp;
  END IF;
END;
/
COMMIT;
