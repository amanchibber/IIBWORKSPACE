--------------------------------------------------------------------------------------------------------
-- Author 		: Mike Arrowsmith
-- Version 		: $Revision: 1.1 $
-- Description 	: Create table script for SI_CICODES table
-- History 		: 26/06/2012 Create
--				  14/08/2012 HM Addition of insert, update timestamp columns and user id
--------------------------------------------------------------------------------------------------------

--SI_CICODES
DROP TABLE SI_CICODES;

CREATE TABLE SI_CICODES
(
  CI_CODE		VARCHAR2(10),
  DESCRIPTION		VARCHAR2(50),
  SHORT_DESCRIPTION	VARCHAR2(25)
)
;								 
		
ALTER TABLE SI_CICODES ADD USER_ID VARCHAR2(10) NOT NULL;
ALTER TABLE SI_CICODES ADD INSERT_TIMESTAMP TIMESTAMP(6);
ALTER TABLE SI_CICODES ADD UPDATE_TIMESTAMP TIMESTAMP(6);
		
COMMIT;
