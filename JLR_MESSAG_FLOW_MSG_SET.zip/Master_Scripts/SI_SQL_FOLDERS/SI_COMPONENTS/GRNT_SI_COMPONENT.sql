/*--------------------------------------------------------------------------------------------------------
-- Author 		: Clive Marrett
-- Version 		: $Revision: 1.1 $
-- Description 	: Create grant script for SI_COMPONENT table 
-- History 		: 19/01/2017 CM Added new grant for WMBOWNER
----------------------------------------------------------------------------------------------------------
*/

GRANT SELECT ON SICOMP.SI_COMPONENT TO WMBOWNER; 

COMMIT;