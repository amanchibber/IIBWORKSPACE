/*--------------------------------------------------------------------------------------------------------
-- Author 		: Clive Marrett
-- Version 		: $Revision: 1.1 $
-- Description 	: Create sequence script for SI_COMPONENT table COMPONENT.ID
-- History 		: 18/01/2017 CM Initial Script Creation
----------------------------------------------------------------------------------------------------------------------------------------
	
*/
DECLARE

SEQ_NAME  VARCHAR(50) := 'SEQ_ESB_SI_COMPONENT_ID';
SEQ_DSTMT VARCHAR(50) := 'DROP SEQUENCE SEQ_ESB_SI_COMPONENT_ID';
SEQ_CSTMT VARCHAR(100) := 'CREATE SEQUENCE SEQ_ESB_SI_COMPONENT_ID MINVALUE 1 START WITH 1 INCREMENT BY 1 CACHE 10';

COUNTER NUMBER;

BEGIN
/* Create Sequence */
COUNTER := 0;
SELECT COUNT(*) INTO COUNTER FROM USER_SEQUENCES WHERE SEQUENCE_NAME = SEQ_NAME;
 
IF COUNTER > 0 THEN 
	EXECUTE IMMEDIATE SEQ_DSTMT;
END IF ;
EXECUTE IMMEDIATE SEQ_CSTMT;

END;
/
COMMIT;