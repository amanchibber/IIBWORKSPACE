/*--------------------------------------------------------------------------------------------------------
-- Author 		: Clive Marrett
-- Version 		: $Revision: 1.1 $
-- Description 	: Create synonym script for SI_COMPONENT table 
-- History 		: 19/01/2017 CM Added new synonym
----------------------------------------------------------------------------------------------------------
*/

CREATE OR REPLACE PUBLIC SYNONYM SI_COMPONENT FOR SICOMP.SI_COMPONENT; 

COMMIT;