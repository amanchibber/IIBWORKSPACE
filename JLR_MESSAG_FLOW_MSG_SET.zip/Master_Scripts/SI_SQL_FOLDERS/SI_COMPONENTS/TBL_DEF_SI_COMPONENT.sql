/*--------------------------------------------------------------------------------------------------------
-- Author 		: Clive Marrett
-- Version 		: $Revision: 1.5 $
-- Description 	: Create script for SI_COMPONENT table
-- History 		: 18/01/2017 - cmarret1 - Initial table creation script
--              : 23/05/2017 - cmarret1 - Added unique constraint for SHORT_NAME
--              : 23/05/2017 - cmarret1 - Removed unique constraint for SHORT_NAME replaced with COMPONENT_NAME
----------------------------------------------------------------------------------------------------------------------------------------
	
*/

DROP TABLE SICOMP.SI_COMPONENT CASCADE CONSTRAINTS;

CREATE TABLE "SICOMP"."SI_COMPONENT"
  (
    "SI_COMPONENT_ID"    		NUMBER NOT NULL ENABLE,
    "COMPONENT_TYPE"	  		VARCHAR2(20 BYTE) NOT NULL ENABLE, -- (BUSINESS_SERVICE, ADAPTER, CANONICAL)
    "COMPONENT_NAME"  			VARCHAR2(70 BYTE) NOT NULL ENABLE, -- (CVS folder name )
	"SHORT_NAME"				VARCHAR2(50 BYTE) NOT NULL ENABLE, -- (FRS-000000, IA-000000, A-00000, CN-00000, ESB-00000)
	"OTHER_REFERENCE"      		VARCHAR2(45 BYTE), -- (Possibly used for external reference long names)
    "BATCH_REQUIRED"			VARCHAR2(5 BYTE), -- (TRUE/FALSE)
    "DESCRIPTION"          		VARCHAR2(250 BYTE), -- (Component narrative)
	"NOTES"						VARCHAR2(500 BYTE),
    CONSTRAINT "SI_COMPONENT_PK" PRIMARY KEY ("SI_COMPONENT_ID") ENABLE,
	CONSTRAINT "SI_COMPONENT_C_NAME" UNIQUE ("COMPONENT_NAME") ENABLE  -- COMPONENT_NAME values should be unique
);

COMMIT;

