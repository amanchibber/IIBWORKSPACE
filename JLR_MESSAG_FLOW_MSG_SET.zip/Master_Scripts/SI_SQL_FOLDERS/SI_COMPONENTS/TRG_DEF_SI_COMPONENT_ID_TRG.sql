/*--------------------------------------------------------------------------------------------------------
-- Author 		: Clive Marrett
-- Version 		: $Revision: 1.1 $
-- Description 	: Create trigger script for SI_COMPONENT table which will update the COMPONENT.ID value on row insertion
-- History 		: 18/01/2017 CM Initial trigger script
----------------------------------------------------------------------------------------------------------------------------------------
	
*/

CREATE OR REPLACE TRIGGER TRG_ESB_SI_COMPONENT_ID 
BEFORE INSERT ON "SICOMP"."SI_COMPONENT" 
FOR EACH ROW
BEGIN
  SELECT SEQ_ESB_SI_COMPONENT_ID.NEXTVAL
  INTO  :new.SI_COMPONENT_ID
  FROM   DUAL;
END;
/
COMMIT;

