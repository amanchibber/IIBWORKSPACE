--------------------------------------------------------------------------------------------------------
-- Author 		: Kenny McCormack
-- Version 		: $Revision: 1.6 $
-- Description 	: Insert script for SI_EMAIL_ADDRESS table 
-- History 		: 10/10/2012 Kenny McCormack Initial insert statement for table
-- 				: 01/05/2013 Kenny McCormack Added HR MultiFile Entries
--				: 12/10/2016 Lakhan Hake Removed MultiFile Entries for IFU4175
--------------------------------------------------------------------------------------------------------
DELETE FROM SI_EMAIL_ADDRESS;

INSERT INTO SI_EMAIL_ADDRESS (OBJECT_NM,EMAIL_ADDRESS, USER_ID) VALUES ('ARCOLL_FROM_ADDRESS','SI_EMAIL_ADDRESS.EMAIL.ARCOLL_FROM','kmccorma');
INSERT INTO SI_EMAIL_ADDRESS (OBJECT_NM,EMAIL_ADDRESS, USER_ID) VALUES ('ARCOLL_TO_ADDRESS','SI_EMAIL_ADDRESS.EMAIL.ARCOLL_TO','kmccorma');

-- HR MultiFile Entries
--LH Removed MultiFile Entries for IFU4175
--INSERT INTO SI_EMAIL_ADDRESS (OBJECT_NM,EMAIL_ADDRESS, USER_ID) VALUES ('CATAL_MULTIFILE_FROM_ADDRESS','SI_EMAIL_ADDRESS.EMAIL.HR_CATAL_FROM','kmccorma');
--INSERT INTO SI_EMAIL_ADDRESS (OBJECT_NM,EMAIL_ADDRESS, USER_ID) VALUES ('CATAL_MULTIFILE_TO_ADDRESS','SI_EMAIL_ADDRESS.EMAIL.HR_CATAL_TO','kmccorma');