--------------------------------------------------------------------------------------------------------
-- Author 		: Kenny McCormack
-- Version 		:$Revision: 1.1 $
-- Description 	: Create table script for SI_EMAIL_ADDRESSES table 
-- History 		: 10/10/2012 Kenny McCormack Initial create statement for table
--------------------------------------------------------------------------------------------------------

DROP TABLE SI_EMAIL_ADDRESS;

CREATE TABLE SI_EMAIL_ADDRESS (OBJECT_NM VARCHAR2(30) NOT NULL, 
								EMAIL_ADDRESS VARCHAR2(60) NOT NULL,
								USER_ID VARCHAR2(10),
								INSERT_TIMESTAMP TIMESTAMP,
								UPDATE_TIMESTAMP TIMESTAMP,
								CONSTRAINT EMAIL_ADDRESS_PK PRIMARY KEY (OBJECT_NM));
							
COMMIT;
