--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: 
-- Description 	: Create data script for SI_EMAIL_ADDRESSES table which will hold email addresses that will be used for outbound emails 
-- History 		: 24/11/2011 Hina Mistry Initial insert statements for table
--------------------------------------------------------------------------------------------------------
DELETE FROM SI_EMAIL_ADDRESSES;

INSERT INTO SI_EMAIL_ADDRESSES (EMAIL_ADDRESS_ID,EMAIL_ADDRESS,CDS_ID,FIRST_NAME,LAST_NAME) VALUES (SI_EMAIL_ADD_ID.NEXTVAL, 'hmistry@jaguarlandrover.com', 'hmistry', 'Hina', 'Mistry');
INSERT INTO SI_EMAIL_ADDRESSES (EMAIL_ADDRESS_ID,EMAIL_ADDRESS,CDS_ID,FIRST_NAME,LAST_NAME) VALUES (SI_EMAIL_ADD_ID.NEXTVAL, 'rglackli@jaguarlandrover.com', 'rglackli', 'Ryan', 'Glackin');
INSERT INTO SI_EMAIL_ADDRESSES (EMAIL_ADDRESS_ID,EMAIL_ADDRESS,CDS_ID,FIRST_NAME,LAST_NAME) VALUES (SI_EMAIL_ADD_ID.NEXTVAL, 'KMCCORMA@jaguarlandrover.com', 'kmccorma', 'Kenny', 'McCormack');
INSERT INTO SI_EMAIL_ADDRESSES (EMAIL_ADDRESS_ID,EMAIL_ADDRESS,CDS_ID,FIRST_NAME,LAST_NAME) VALUES (SI_EMAIL_ADD_ID.NEXTVAL, 'SPATEL5@jaguarlandrover.com', 'spatel5', 'Seenesh', 'Patel');
INSERT INTO SI_EMAIL_ADDRESSES (EMAIL_ADDRESS_ID,EMAIL_ADDRESS,CDS_ID,FIRST_NAME,LAST_NAME) VALUES (SI_EMAIL_ADD_ID.NEXTVAL, 'oifebogu@jaguarlandrover.com', 'oifebogu', 'Oluefemi', 'Ifebogun');
INSERT INTO SI_EMAIL_ADDRESSES (EMAIL_ADDRESS_ID,EMAIL_ADDRESS,CDS_ID,FIRST_NAME,LAST_NAME) VALUES (SI_EMAIL_ADD_ID.NEXTVAL, 'jsneddo2@jaguarlandrover.com', 'jsneddo2', 'Jim', 'Sneddon');
INSERT INTO SI_EMAIL_ADDRESSES (EMAIL_ADDRESS_ID,EMAIL_ADDRESS,CDS_ID,FIRST_NAME,LAST_NAME) VALUES (SI_EMAIL_ADD_ID.NEXTVAL, 'rreddi@jaguarlandrover.com', 'rreddi', 'Ramu', 'Reddi');

COMMIT;
