--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: 
-- Description 	: Create sequence script for table SI_EMAIL_ADDRESSES table
-- History 		: 24/11/2011 Hina Mistry Initial create statement for sequence
--------------------------------------------------------------------------------------------------------

DROP SEQUENCE SI_EMAIL_ADD_ID;
		
--Sequence to generate the ID value for SI_EMAIL_ADDRESSES table
CREATE SEQUENCE SI_EMAIL_ADD_ID
MINVALUE 1
START WITH 1
INCREMENT BY 1
CACHE 10;							 

COMMIT;
