--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: 
-- Description 	: Create table script for SI_EMAIL_ADDRESSES table which will hold email addresses
-- History 		: 24/11/2011 Hina Mistry Initial create statement for table
--------------------------------------------------------------------------------------------------------

DROP TABLE SI_EMAIL_ADDRESSES;

CREATE TABLE SI_EMAIL_ADDRESSES (EMAIL_ADDRESS_ID NUMBER(5) NOT NULL,
								 EMAIL_ADDRESS VARCHAR2(150) NOT NULL,
								 CDS_ID  VARCHAR(15) NOT NULL,
								 FIRST_NAME VARCHAR(30),
								 LAST_NAME VARCHAR(30),
								 INSERT_TIMESTAMP TIMESTAMP,
								 UPDATE_TIMESTAMP TIMESTAMP,
								 CONSTRAINT PK_EMAIL_ADD_ID PRIMARY KEY (EMAIL_ADDRESS_ID));



COMMIT;
