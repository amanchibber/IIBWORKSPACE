--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: 
-- Description 	: Create sequence script for table SI_EMAIL_OUTBOUND_DETAILS table
-- History 		: 24/11/2011 Hina Mistry Initial create statement for sequence
--------------------------------------------------------------------------------------------------------

DROP SEQUENCE SI_EMAIL_OUTBOUND_ID;
		
--Sequence to generate the ID value for SI_EMAIL_OUTBOUND_DETAILS table
CREATE SEQUENCE SI_EMAIL_OUTBOUND_ID 
MINVALUE 1
START WITH 1
INCREMENT BY 1
CACHE 10;							 

COMMIT;
