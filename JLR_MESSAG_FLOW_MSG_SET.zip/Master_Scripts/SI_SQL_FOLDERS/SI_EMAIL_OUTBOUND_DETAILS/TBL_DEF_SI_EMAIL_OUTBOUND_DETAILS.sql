--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: 
-- Description 		: Create table script for SI_EMAIL_OUTBOUND_DETAILS table which will hold details of 
-- the business services and the email addresses that are to be used by them
-- History 		: 29/11/2011 Hina Mistry Initial create statement for table
--------------------------------------------------------------------------------------------------------

DROP TABLE SI_EMAIL_OUTBOUND_DETAILS;

CREATE TABLE SI_EMAIL_OUTBOUND_DETAILS (ID NUMBER(5) NOT NULL,
										BUSINESS_SERVICE_ID NUMBER(5) NOT NULL,
										EMAIL_ADDRESS_ID VARCHAR2(5) NOT NULL,
										INSERT_TIMESTAMP TIMESTAMP,
										UPDATE_TIMESTAMP TIMESTAMP,
										CONSTRAINT PK_EMAIL_OUT_DETS_ID PRIMARY KEY (ID),
										FOREIGN KEY (BUSINESS_SERVICE_ID)
										REFERENCES SI_BUSINESS_SERVICE_DETAILS(BUSINESS_SERVICE_ID));



COMMIT;
