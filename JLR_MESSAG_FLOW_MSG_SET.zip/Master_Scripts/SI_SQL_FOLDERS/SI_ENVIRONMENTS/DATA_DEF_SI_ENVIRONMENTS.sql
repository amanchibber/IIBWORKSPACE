--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: $Revision: 1.3 $
-- Description 	: Create data script for SI_ENVIRONMENTS table which will hold information on the ESB Environments 
-- History 		: 18/08/2011 Hina Mistry Initial insert statements for table
-- 				  14/08/2012 Hina Mistry Populations of user id column
--				  12/11/2012 Kenny McCormack added Environments '0' and '6'
--				  11/03/2013 Kenny McCormack added Environment '7'
--------------------------------------------------------------------------------------------------------
DELETE FROM SI_ENVIRONMENTS;

--Insert statements
INSERT INTO SI_ENVIRONMENTS (ID, ENVIRONMENT, USER_ID, ENABLED) VALUES (0, 'DEV-TEST', 'kmccorma', 'Y');
INSERT INTO SI_ENVIRONMENTS (ID, ENVIRONMENT, USER_ID, ENABLED) VALUES (1, 'DEV', 'hmistry', 'Y');
INSERT INTO SI_ENVIRONMENTS (ID, ENVIRONMENT, USER_ID, ENABLED) VALUES (2, 'QA', 'hmistry', 'Y');
INSERT INTO SI_ENVIRONMENTS (ID, ENVIRONMENT, USER_ID, ENABLED) VALUES (3, 'PRODUCTION', 'hmistry', 'Y');
INSERT INTO SI_ENVIRONMENTS (ID, ENVIRONMENT, USER_ID, ENABLED) VALUES (4, 'PRE-PRODUCTION', 'hmistry', 'Y');
INSERT INTO SI_ENVIRONMENTS (ID, ENVIRONMENT, USER_ID, ENABLED) VALUES (5, 'UAT', 'hmistry', 'Y');
INSERT INTO SI_ENVIRONMENTS (ID, ENVIRONMENT, USER_ID, ENABLED) VALUES (6, 'QA-TEST', 'kmccorma', 'Y');
INSERT INTO SI_ENVIRONMENTS (ID, ENVIRONMENT, USER_ID, ENABLED) VALUES (7, 'QA2', 'kmccorma', 'Y');


COMMIT;

