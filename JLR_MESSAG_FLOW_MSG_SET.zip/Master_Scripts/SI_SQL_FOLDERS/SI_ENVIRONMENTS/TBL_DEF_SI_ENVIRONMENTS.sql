--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: $Revision: 1.2 $
-- Description 	: Create table script for SI_ENVIRONMENTS table which will hold information on the ESB Environments 
-- History 		: 18/08/2011 Hina Mistry Initial create statement for table
-- 				  14/08/2012 Hina Mistry Addition of user id, insert/update timestamp columns
--				  12/11/2012 Kenny McCormack added ENABLED column
--------------------------------------------------------------------------------------------------------
DROP TABLE SI_ENVIRONMENTS;
--Environment tables
CREATE TABLE SI_ENVIRONMENTS (ID NUMBER(2) NOT NULL, 
		ENVIRONMENT VARCHAR(15) NOT NULL);

ALTER TABLE SI_ENVIRONMENTS ADD USER_ID VARCHAR2(10) NOT NULL;
ALTER TABLE SI_ENVIRONMENTS ADD INSERT_TIMESTAMP TIMESTAMP;
ALTER TABLE SI_ENVIRONMENTS ADD UPDATE_TIMESTAMP TIMESTAMP;
ALTER TABLE SI_ENVIRONMENTS ADD ENABLED VARCHAR2(1) TIMESTAMP;

COMMIT;
