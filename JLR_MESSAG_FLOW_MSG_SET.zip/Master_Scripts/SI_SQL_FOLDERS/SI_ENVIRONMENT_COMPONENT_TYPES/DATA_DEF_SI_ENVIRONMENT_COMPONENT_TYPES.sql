--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: $Revision: 1.1 $
-- Description 	: Create data script for SI_ENVIRONMENT_COMPONENT_TYPES table which will hold information on the component types in the ESB Environment
-- History 		: 02/05/2012 Hina Mistry Initial insert statements for table
-- 				  14/08/2012 Hina Mistry Addition of user id data
--------------------------------------------------------------------------------------------------------
DELETE FROM SI_ENVIRONMENT_COMPONENT_TYPES;
--Insert statements
INSERT INTO SI_ENVIRONMENT_COMPONENT_TYPES (COMPONENT_TYPE, DESCRIPTION, USER_ID) VALUES ('BROKER', 'Represents all the Brokers in the ESB environment', 'hmistry');
INSERT INTO SI_ENVIRONMENT_COMPONENT_TYPES (COMPONENT_TYPE, DESCRIPTION, USER_ID) VALUES ('BRKQMGR', 'Represents all Broker QMgrs in the ESB environment', 'hmistry');
INSERT INTO SI_ENVIRONMENT_COMPONENT_TYPES (COMPONENT_TYPE, DESCRIPTION, USER_ID) VALUES ('SWQMGR', 'Represents the Switch QMgrs in the ESB environment', 'hmistry');
INSERT INTO SI_ENVIRONMENT_COMPONENT_TYPES (COMPONENT_TYPE, DESCRIPTION, USER_ID) VALUES ('SIDB01', 'Represent the SI database which is used by the ESB', 'hmistry');

COMMIT;

