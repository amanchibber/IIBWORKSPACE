--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: $Revision: 1.1 $
-- Description 	: Create table script for SI_ENVIRONMENT_COMPONENT_TYPES. table which will hold information on the ESB Environments 
-- History 		: 02/05/2012 Hina Mistry Initial create statement for table
-- 				  14/08/2012 Hina Mistry Addition of user id column
--------------------------------------------------------------------------------------------------------
DROP TABLE SI_ENVIRONMENT_COMPONENT_TYPES;
--Environment tables
CREATE TABLE SI_ENVIRONMENT_COMPONENT_TYPES (COMPONENT_TYPE VARCHAR(15) NOT NULL,
											 DESCRIPTION VARCHAR(100) NOT NULL,
											 INSERT_TIMESTAMP TIMESTAMP NULL,
											 UPDATE_TIMESTAMP TIMESTAMP NULL,
											 CONSTRAINT PK_SI_ENV_CMPTYPE_ID PRIMARY KEY (COMPONENT_TYPE));

ALTER TABLE SI_ENVIRONMENT_COMPONENT_TYPES ADD USER_ID VARCHAR2(10) NOT NULL;

COMMIT;
