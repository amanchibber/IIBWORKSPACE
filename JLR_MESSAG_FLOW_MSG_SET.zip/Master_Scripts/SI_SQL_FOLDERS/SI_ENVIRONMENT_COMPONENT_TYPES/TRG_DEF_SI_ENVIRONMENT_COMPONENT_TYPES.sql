--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: $Revision: 1.1 $
-- Description 	: Create trigger script for SI_ENVIRONMENT_COMPONENT_TYPES table which will hold data on the types of components
-- History 		: 02/05/2012 Hina Mistry Initial create statement for trigger
--------------------------------------------------------------------------------------------------------

DROP TRIGGER SI_ENV_CMPTYPE_TMSTMP_TRG;

--Trigger which will insert or update the timestamp if an insert or update action occurs
CREATE OR REPLACE
TRIGGER SI_ENV_CMPTYPE_TMSTMP_TRG
BEFORE INSERT OR UPDATE ON SI_ENVIRONMENT_COMPONENT_TYPES
FOR EACH ROW
BEGIN

IF INSERTING THEN
	:new.INSERT_TIMESTAMP := systimestamp;
	:new.UPDATE_TIMESTAMP := NULL;
ELSE
	:new.UPDATE_TIMESTAMP := systimestamp;
  END IF;
END;
/
COMMIT;
