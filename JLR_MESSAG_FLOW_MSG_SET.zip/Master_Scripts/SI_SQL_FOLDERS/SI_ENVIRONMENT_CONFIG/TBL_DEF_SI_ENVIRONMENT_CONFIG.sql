--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: $Revision: 1.1 $
-- Description 	: Create table script for SI_ENVIRONMENT_CONFIG table which will hold configuration data for 
--				  the ESB environments
-- History 		: 22/07/2011 Hina Mistry Initial create statement for table
-- 				  14/08/2012 Hina Mistry Addition of user id column
--------------------------------------------------------------------------------------------------------

DROP TABLE SI_ENVIRONMENT_CONFIG;

CREATE TABLE SI_ENVIRONMENT_CONFIG (ID NUMBER(10) NOT NULL, 
		OBJECT_NAME VARCHAR(500) NOT NULL,
		PROPERTY_NAME VARCHAR(500) NOT NULL,
		ENVIRONMENT_ID NUMBER(2) NOT NULL,
		PROPERTY_VALUE VARCHAR(200) NULL,
    SETUP_TYPE VARCHAR2(20) NULL,
		INSERT_TIMESTAMP TIMESTAMP NULL,
		UPDATE_TIMESTAMP TIMESTAMP NULL,
		CONSTRAINT PK_SI_ENV_CFG_ID PRIMARY KEY (ID)
    );

ALTER TABLE SI_ENVIRONMENT_CONFIG ADD USER_ID VARCHAR2(10) NOT NULL;
