--------------------------------------------------------------------------------------------------------
-- Author 		: Siva Garapati
-- Version 		: $Revision: 1.1 $
-- Description 	: Create data script for SI_ENVIRONMENT_LOOKUP table which will hold information on the ESB Environments 
-- History 		: 26/06/2013 Siva Garapati Initial insert statements for table
--------------------------------------------------------------------------------------------------------
DELETE FROM SI_ENVIRONMENT_LOOKUP;

--Insert statements
INSERT INTO SI_ENVIRONMENT_LOOKUP (BROKER_NAME, ENVIRONMENT_TYPE, INSTANCE_ID) VALUES ('SIBKBK1D', 'DEV', 1);
INSERT INTO SI_ENVIRONMENT_LOOKUP (BROKER_NAME, ENVIRONMENT_TYPE, INSTANCE_ID) VALUES ('SIBKBK1Q', 'QA', 1);
INSERT INTO SI_ENVIRONMENT_LOOKUP (BROKER_NAME, ENVIRONMENT_TYPE, INSTANCE_ID) VALUES ('SIBKBK2Q', 'QA', 2);
INSERT INTO SI_ENVIRONMENT_LOOKUP (BROKER_NAME, ENVIRONMENT_TYPE, INSTANCE_ID) VALUES ('SIBKQM1T', 'PREPROD', 1);
INSERT INTO SI_ENVIRONMENT_LOOKUP (BROKER_NAME, ENVIRONMENT_TYPE, INSTANCE_ID) VALUES ('SIBKQM2T', 'PREPROD', 2);
INSERT INTO SI_ENVIRONMENT_LOOKUP (BROKER_NAME, ENVIRONMENT_TYPE, INSTANCE_ID) VALUES ('SIBKBK1P', 'PROD', 1);
INSERT INTO SI_ENVIRONMENT_LOOKUP (BROKER_NAME, ENVIRONMENT_TYPE, INSTANCE_ID) VALUES ('SIBKBK2P', 'PROD', 2);

COMMIT;

