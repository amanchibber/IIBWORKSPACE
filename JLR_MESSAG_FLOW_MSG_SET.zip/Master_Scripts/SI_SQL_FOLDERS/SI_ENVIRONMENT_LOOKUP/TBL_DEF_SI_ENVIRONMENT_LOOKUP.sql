--------------------------------------------------------------------------------------------------------
-- Author 		: Siva Garapati
-- Version 		: $Revision: 1.1 $
-- Description 	: Create table script for SI_ENVIRONMENT_LOOKUP table which will hold information on the ESB Environments 
-- History 		: 26/06/2013 Siva Garapati Initial create statement for table.
--------------------------------------------------------------------------------------------------------
DROP TABLE SI_ENVIRONMENT_LOOKUP;
--Environment tables
CREATE TABLE SI_ENVIRONMENT_LOOKUP (BROKER_NAME VARCHAR(10) NOT NULL, 
									ENVIRONMENT_TYPE VARCHAR2(15) NOT NULL,
									INSTANCE_ID NUMBER(2) NOT NULL,
									CONSTRAINT SI_ENVIRONMENT_LOOKUP_PK PRIMARY KEY (BROKER_NAME));


COMMIT;
