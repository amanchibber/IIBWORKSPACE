--------------------------------------------------------------------------------------------------------
-- Author 		: Paul Gregory
-- Version 		: $Revision: 1.2 $
-- Description 	: Create table script for SI_EXCEPTION_CODE table
-- History 		: 12/12/2014 Initial create statement for table
-------------------------------------------------------------------------------------------------------

DROP TABLE SI_EXCEPTION_CODE;

CREATE TABLE SI_EXCEPTION_CODE 
(EXCEPTION_CODE  VARCHAR2(10) NOT NULL,
BUSINESS_SERVICE_ID	VARCHAR2(50) NOT NULL,
EXCEPTION_SHORT_DESCRIPTION	VARCHAR2(100) NOT NULL,
USER_ID	VARCHAR2(10) , 
EXCEPTION_DESCRIPTION	VARCHAR2(4000) ,
INSERT_TIMESTAMP	TIMESTAMP,
UPDATE_TIMESTAMP	TIMESTAMP,
CONSTRAINT "SI_EXCPT_PK" PRIMARY KEY ("EXCEPTION_CODE")) ;
