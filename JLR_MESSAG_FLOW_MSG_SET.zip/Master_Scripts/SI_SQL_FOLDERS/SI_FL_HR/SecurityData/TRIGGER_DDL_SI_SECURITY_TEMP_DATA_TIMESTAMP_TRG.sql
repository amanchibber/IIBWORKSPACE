--------------------------------------------------------------------------------------------------------
-- Author 		: Prasad Panchagnula (ppancha3)
-- Version 		: $Revision: 1.1 $
-- Description 	: Create before insert trigger script on table SI_SECURITY_TEMP_DATA which will update the table
--				  column INSERT_TIMESTAMP with the CURRENT_TIMESTAMP when a row has been inserted/updated 
-- History 		: 25/09/2014 Prasad Panchagnula (ppancha3) Initial create statement for trigger SI_SECURITY_TEMP_DATA_TRG
--------------------------------------------------------------------------------------------------------

DROP TRIGGER SI_SECURITY_TEMP_DATA_TRG;

--Trigger which will insert or update the timestamp if an insert or update action occurs
CREATE OR REPLACE
TRIGGER SI_SECURITY_TEMP_DATA_TRG
BEFORE INSERT OR UPDATE ON SI_SECURITY_TEMP_DATA
FOR EACH ROW
BEGIN

IF INSERTING THEN
	:new.INSERT_TIMESTAMP := systimestamp;
	:new.UPDATE_TIMESTAMP := NULL;
ELSE
	:new.UPDATE_TIMESTAMP := systimestamp;
  END IF;
END;
/
COMMIT;
