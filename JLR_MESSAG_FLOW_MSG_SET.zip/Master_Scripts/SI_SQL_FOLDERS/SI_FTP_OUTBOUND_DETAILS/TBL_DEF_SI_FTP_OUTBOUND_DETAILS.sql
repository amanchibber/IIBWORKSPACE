--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: 
-- Description 	: Create table script for SI_FTP_OUTBOUND_DETAILS table which will hold details required
--				  by the FTP outbound adapters to override at runtime
-- History 		: 24/11/2011 Hina Mistry Initial create statement for table
--				  13/04/2012 Hina Mistry Altering size of the business_service_id column
--------------------------------------------------------------------------------------------------------

DROP TABLE SI_FTP_OUTBOUND_DETAILS;

CREATE TABLE SI_FTP_OUTBOUND_DETAILS (SYSTEM_IDENTIFIER	VARCHAR2(20) NOT NULL,
								 BUSINESS_SERVICE_ID VARCHAR2 (35) NOT NULL,
								 FILE_IDENTIFIER VARCHAR2(20) NOT NULL,
								 LOCAL_DIRECTORY_LOCATION VARCHAR2 (100),
								 REMOTE_DIRECTORY_LOCATION	VARCHAR2 (100) NOT NULL,
								 ARCHIVE_DIRECTORY_LOCATION	VARCHAR2 (100),
								 INSERT_TIMESTAMP TIMESTAMP,
								 UPDATE_TIMESTAMP TIMESTAMP,
								 USER_ID VARCHAR2 (10) NOT NULL,
								 DESCRIPTION VARCHAR2 (100) NOT NULL);

--13/04/2012 HM Business Service ID column - size alteration
ALTER TABLE SI_FTP_OUTBOUND_DETAILS MODIFY BUSINESS_SERVICE_ID VARCHAR(45);										 
								 
COMMIT;
