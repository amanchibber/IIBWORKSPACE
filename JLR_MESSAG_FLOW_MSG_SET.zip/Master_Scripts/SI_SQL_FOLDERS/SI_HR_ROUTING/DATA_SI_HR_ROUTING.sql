--------------------------------------------------------------------------------------------------------
-- Author 		: Naresh CH
-- Version 		: $Revision: 1.7 $
-- Description 	: Create data script for SI_HR_ROUTING table which will hold routing information
-- History 		: 22/09/2015 Naresh CH Initial creation of master scripts for FRS720
--				: 28/09/2015 Naresh CH added one more entry fro organization flow as part of FRS720
--				: 11/02/2016 PM  added entries as per IFU3667
-- 				: 02/08/2017 PM  Entries added as per IFU4760
-- 				: 21/08/2017 AMAHESH2  Entries migrated to SI_Components FRS 720 under IFU 4684

---------------------------------------------------------------------------------------------------------
--Entries migrated to SI_Components FRS 720 under IFU 4684
--INSERT INTO SI_HR_ROUTING (CMM_COUNTRY_CODE,CMM_COMPANY_CODE,CMM_IDOC_TYPE,CMM_MES_TYPE,TARGET_COUNTRY,TARGET_SYSTEM,DESTINATION,USER_ID,DESCRIPTION) 
--VALUES ('37',null,'HRMD_A09','ZHRMD_A_BRAZIL','Brazil','NGA','SI.BS.CANON.EMPDATA.TO.NGA.IN','nch','HR Employee CMM to NGA Brazil');

--INSERT INTO SI_HR_ROUTING (CMM_COUNTRY_CODE,CMM_COMPANY_CODE,CMM_IDOC_TYPE,CMM_MES_TYPE,TARGET_COUNTRY,TARGET_SYSTEM,DESTINATION,USER_ID,DESCRIPTION) 
--VALUES ('37',null,'HRMD_A09','ZHRMD_A_BRAZIL_KRONOS','Brazil','Kronos','SI.BS.CANON.EMPTADATA.TO.KRONOS.IN','nch','HR Employee CMM to Kronos Brazil');

--INSERT INTO SI_HR_ROUTING (CMM_COUNTRY_CODE,CMM_COMPANY_CODE,CMM_IDOC_TYPE,CMM_MES_TYPE,TARGET_COUNTRY,TARGET_SYSTEM,DESTINATION,USER_ID,DESCRIPTION) 
--VALUES (null,'BR02','ZHRMD_ORG','ZHRMD_O_BRAZIL_ORG','Brazil','NGA','SI.BS.CANON.ORGDATA.TO.NGA.IN','nch','HR Organisation CMM to NGA Brazil');


-- 11/02/2016 PM  Entries added as per IFU3667
--INSERT INTO SI_HR_ROUTING (CMM_COUNTRY_CODE,CMM_COMPANY_CODE,CMM_IDOC_TYPE,CMM_MES_TYPE,TARGET_COUNTRY,TARGET_SYSTEM,DESTINATION,USER_ID,DESCRIPTION) 
--VALUES ('08',null,'HRMD_A09','ZHRMD_A_UK_KRONOS','UK','KroTnA','SI.BS.CANON.EMPTADATA.TO.KROUK.IN','pmondal','HR Employee CMM to Kronos UK');

--INSERT INTO SI_HR_ROUTING (CMM_COUNTRY_CODE,CMM_COMPANY_CODE,CMM_IDOC_TYPE,CMM_MES_TYPE,TARGET_COUNTRY,TARGET_SYSTEM,DESTINATION,USER_ID,DESCRIPTION) 
--VALUES ('08',null,'HRMD_A09','ZHRMD_A_UK_NGA','UK','NGAPyr','SI.BS.CANON.EMPDATA.TO.NGAUK.IN','pmondal','HR Employee CMM to NGA UK Payroll');

-- 02/08/2017 PM  Entries added as per IFU4760
--INSERT INTO SI_HR_ROUTING (CMM_COUNTRY_CODE,CMM_COMPANY_CODE,CMM_IDOC_TYPE,CMM_MES_TYPE,TARGET_COUNTRY,TARGET_SYSTEM,DESTINATION,USER_ID,DESCRIPTION) 
--VALUES ('08',null,'HRMD_A09','ZHRMD_A_GRASS_U','UK','GROOT','SI.BS.CANON.EMPDATA.TO.GROOT.IN','pmondal','HR Employee CMM to GrassRoot');