--------------------------------------------------------------------------------------------------------
-- Author 		: Amith Sannagowdar
-- Version 		: $Revision: 1.1 $
-- Description 	: Create table script for SI_HR_ROUTING table
-- History 		: 14/09/2015 AS Initial create statement for table
-------------------------------------------------------------------------------------------------------

DROP TABLE SI_HR_ROUTING;

CREATE TABLE SI_HR_ROUTING 
(CMM_COUNTRY_CODE	VARCHAR2(2),
CMM_COMPANY_CODE	VARCHAR2(4),
CMM_IDOC_TYPE		VARCHAR2(30) NOT NULL,
CMM_MES_TYPE		VARCHAR2(30) NOT NULL, 
TARGET_COUNTRY		VARCHAR2(6) NOT NULL,
TARGET_SYSTEM		VARCHAR2(6) NOT NULL,
DESTINATION			VARCHAR2(48) NOT NULL,
USER_ID				VARCHAR2(10),
DESCRIPTION			VARCHAR2(50),
INSERT_TIMESTAMP	TIMESTAMP,
UPDATE_TIMESTAMP	TIMESTAMP
) ;
