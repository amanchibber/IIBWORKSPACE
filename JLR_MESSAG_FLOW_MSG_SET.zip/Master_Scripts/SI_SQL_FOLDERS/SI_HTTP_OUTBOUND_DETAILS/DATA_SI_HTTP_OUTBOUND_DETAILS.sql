--------------------------------------------------------------------------------------------------------
-- Author 	: Seenesh Patel
-- Version 	: $Revision: 1.313 $
-- Description 	: Create data script for SI_HTTP_OUTBOUND_DETAILS table which will hold details of runtime overrides used by the HTTP Outbound adapter
-- History 	: 14/06/2012 SP Initial insert statements for table
--			: 14/08/2012 SP Details updated for SAP Turbo Vehicle Alert Update to D42 entry
-- 			: 14/08/2012 Hina Mistry Population of user id column
--			: 17/08/2012 SP Updated so as URL may differ for each env
--			: 03/09/2012 Vikas Yadav Entry for PlanningEvents to VISTA for IA-000061
--          		: 06/09/2012 AB Entry for IA000027 Invoice_Credit_Details_To VISTA and D42	
--			: 06/11/2012 Vikas Yadav, Planning Events to VISTA and D42, IA-000009
--			: 08/11/2012 Chandrasekhar, IA-000234 SI_BS_SAP_TRBGB_Engineer_Request_TO_RADS 
--			: 17/11/2012 Ryan Glackin - update to all entries for Broker Name and WSL String
--			: 02/01/2013 Kenny McCormack - Added PERSIST_PAYLOAD_IN_URL as per requirement for IA 27 interface to VISTA
-- 						 to store the payload of the message in the URL. See defect 1891
--			: 22/01/2013 Mike Arrowsmith - Defect 1643
--			: 03/04/2013 AS Adding entry for FRS-259
--			: 29/04/2013 AS Adding entry for FRS-258
--			: 10/06/2013 SP Adding entry for FRS-259 (IFU997)
--			: 13/06/2013 SP FRS259 entries updated so HTTP Method is 'PUT' - Defect TBC
--			: 19/06/2013 Deepak Ingwale Adding entry for FRS-000016
--			: 27/06/2013 SK Adding entry for FRS-000271
--			: 02/07/2013 Deepak Ingwale Adding entry for FRS-000007
--			: 19/07/2013 Deepak Ingwale Updated entry for FRS-000016 IFU1082
--			: 22/07/2013 Deepak Ingwale Updated entry for FRS-000006 IFU1078
--			: 24/07/2013 Deepak Ingwale Adding entry for FRS-000007
--			: 30/07/2013 Venkata Annareddy Added new entry for FRS-000107
--			: 30/07/2013 Deepak Ingwale Adding entry for FRS-000009
--          : 02/08/2013 Aditi Pathak Adding entry for FRS-000261
--          : 06/08/2013 Aman Chibber Adding entry for FRS-000108,FRS-000116
--          : 08/08/2013 Saptarshi Goswami Adding entry for FRS-000111
--          : 10/08/2013 RB Adding entry for FRS-000260
--			: 16/08/2013 AC Adding entry for FRS-000272
--          : 20/08/2013 Nisha Purohit Adding entry for FRS-109 
-- 			: 22/08/2013 Aman Chibber Added entry for FRS-116
-- 			: 22/08/2013 SP Added entries for FRS-110
--          : 28/08/2013 Nisha Purohit Adding entry for FRS-122
--          : 29/08/2013 Saptarshi Goswami Adding entry for FRS-121
--          : 30/08/2013 Gaurav Gawali Adding entry for FRS-352
--          : 03/09/2013 Gaurav Gawali Adding entry for FRS-352
--          : 05/09/2013 Saptarshi Goswami Updated Broker1 entries for FRS-121 and FRS-111
--          : 23/09/2013 Nisha Purohit     Updated Broker1 entry for FRS-122
--          : 25/09/2013 Srinivas Pithani Adding entry for FRS-113
--			: 26/09/2013 Pratik Khot   Adding entry for FRS-000017
--			: 27/09/2013 Pratik Khot   Adding entry for FRS-000017
--			: 01/10/2013 Srinivas Pithani   Updated entry for FRS-000113
--			: 09/10/2013 SK Adding entry for FRS-000273
--			: 14/10/2013 PG Remove WSL for FRS-000007,9 and 16
--          : 17/10/2013 Pratik Khot   Adding entry for FRS-000017(Under IFU-1257)
--          : 30/10/2013 Srinivas Pithani Adding entry for FRS-000120
--			: 30/10/2013 SK Edited HTTP entris for FRS-000271
--			: 07/11/2013 Saptarshi Goswami Added entry for FRS-128
--			: 11/11/2013 RB Added entry for FRS-112
--			: 12/11/2013 SK added entry for FRS-366
--			: 14/11/2013 TK added entry for FRS-119
--			: 15/11/2013 SS added entry for FRS-127
--			: 21/11/2013 SG added entry for FRS-130
--          : 21/11/2013 SM added entry for FRS-123
--			:22/11/2013 PG added entry for FRS-129
--			:25/11/2013 SM added entry for FRS-118
--			:27/11/2013 KM added entry for FRS-117
--			:27/11/2013 SG Updated entry for FRS-128
--			:01/12/2013 HM Addition of entries for FRS-139
--			:02/12/2013 HM Update of entries for FRS-139
--			:04/12/2013 HM Update of entries for FRS-139
--          :09/12/2013 HS Update of entries for FRS-083
--          :16/12/2013 HS Update of entries for FRS-083
--			:12/12/2013 Hari Sabat Adding entry for FRS-00083
--			:18/12/2013 HM Updating statements which are missing ;
--			:16/01/2014 DI Updating WSL_STRING Value cookie ;
--			:23/01/2013 SK added changed property name for Cookies for FRS_366
--			:06/02/2014 AP Entry added for FRS-378
--			:12/02/2014 AP Entry updated for FRS-259 as per IFU-1698 .Method is set to POST
--			:13/02/2014 RB WSL string SETUP_TYPE changes for FRS-366, IA-234 and IA-235
--			:14/02/2014 RB WSL value removed for FRS-258, FRS-259 and FRS-271
--			:14/02/2014 RB Added Cookies comment for interfaces using them
--          :05/03/2014 Naresh CH added entry for FRS 090
-- 			:05/03/2014 VA updated the entry for FRS378
--			:06/02/2014 VA updated the entry for FRS083
--			:10/03/2014 PG updated FRS083 entry
--          :19/03/2014 AK Added entry for FRS 093
--          :15/04/2014 HA Added entries for FRS 277
--          :22/04/2014 HA Updated entries for FRS 277
--          :24/04/2014 HA Corrected entries for FRS 277
-- 			:25/04/2014 SK added queries for FRS 371
--			:02/05/2014 HA Removed an entry for CJLR URL(FRS 277)
-- 			:25/04/2014 PVH added queries for FRS 282
--			:26/05/2014 SK Added entries for FRS-278
-- 			:27/05/2014 PVH added queries for FRS 367
-- 			:30/05/2014 PK updated entry for FRS 090.
--			:13/06/2014 RB Updated with non valid default URL value for FRS-000271
--			:17/06/2014 SK Added entries for FRS-281
--			:10/07/2014 GT Added entries for FRS-138
-- 			:24/07/2014 TK Added entries for FRS-141
-- 			:12/08/2014 AP Added entries for FRS-272
-- 			:13/08/2014 SM Added entries for FRS-628
-- 			:19/08/2014 SM Updated entries for FRS-628
--          :21/08/2014 SB Updated entries for FRS-137 
--			:21/08/2013 TK Added entries for FRS-143
-- 			:22/08/2014 AP Added entries for FRS-273
-- 			:02/09/2014 AP Added entries for FRS-371/IA-09
-- 			:08/09/2014 NC Added entries for FRS-000090(SI_FL_Product,IFU2310)
-- 			:16/09/2014 SG Added entries for FRS-000136(R2.0)
--          :18/09/2014 AK Added entries for FRS 382-2B
--          :17/10/2014 PK Updated entry for FRS-000017 FRS-000094 Updated timout to 120 secs(Defect 52)
--          :21/10/2014 AC Added Entry for FRS 657
--          :13/11/2014 SG Updated AVO/VVO BMA entries for FRS-136(R2.0)
--          :13/11/2014 SG Removed AVO/VVO BMA entries for FRS-136(R2.0)
--          :14/11/2014 SB updated entries on FRS143
--			:Updated Entries for FRS 000090(IFU2497) 
--          :02/12/2014 AMW added entires for FRS-115
--			:10/12/2014 AaP Added entry  for FRS-003
--			:15/12/2014. NM. Def-33 Added WSL value for FRS-258 and FRS-259 interfaces.
--			:19/12/2014  HA  FRS 643 Addition of new entry for the URL of FMS
-- 			:21/01/2015 HA FRS 643 IFU 2674 WSL entry added
--			:29/01/2015 AP FRS-643 Timeout value changed to 120 sec
--			:09/02/2015 TK FRS-139 Timeout value changed to 120 sec
--			:17/02/2015 TK Updated key for REQUEST_URL for FRS143 and FRS117
--          :24/02/2015 SB Added entries for FRS-148
--          :25/02/2015 KS Added entries for FRS-147
-- 			:11/03/2015 AB Added entries for FRS-137
--			:12/03/2015 AaP Updated the key to VSAVEHPROPDTA from VEHPROPDTAVSA to avoid the build conflict with VEHPROPDTA
--			:20/03/2015 NC added entries for FRS000023 under IFU2807
--			:27/03/2015 KT Entry for FRS-000260 is commented as per FRS271 design change.
--			:14/04/2015 SA Added entry for FRS 352
--          :15/04/2015 PK Corrected entries for FRS000023(IFU 2807).
--			:18/03/2015 KT FRS-000271 Changed BSID SI_SV_VEHSV_ENGGCHGSAP
--			:23/04/2015 AaP Added entry for FRS 673
--			:07/05/2015 VP Added entry for IA-000005
--			:20/05/2015 MJ Added timeout under IA-000005 as per IFU3040
-- 			:21/05/2015 TK MNT: Updated WSL_STRING to Null as Guanxi flows don't use WSL_STRING value
--			:23/05/2015 SM Updated timeout to 120s for DEF4613
--			:23/05/2015 SM Updated timeout to 120s for DEF4614
--			:26/05/2015 PM Added entries for FRS-000712
--			:26/05/2015 VB Added entry for FRS-000111 as per IFU3019
--			:29/05/2015 PM Updated entries for FRS-000712
-- 			:02/06/2015 TK IFU3084: Updated timeout for FRS 115
--          :08/07/2015 VP FRS674 initial entry
-- 			:27/07/2015 AM IFU-3242 Updated QA1 configuration details(URL) for iPLM FRS-000006(MFD) and FRS-000007(EC).
--          :03/08/2015 VV FRS-718 Added two entries for HTTP Outbound Details table
--			:10/08/2015 AB Updated  BUSINESS_SERVICE_NAME for FRS-000111 to sync with design
--	        :04/09/2015 AM: Updated HTTP Outbound URL entry for IFU 3368 (FRS-6 iPLM GetMFD service)
--	        :26/10/2015 AM: Updated HTTP Outbound URL entry for IFU 3498 (FRS-6,7,9,16,93,94)
--			:28/10/2015 AaP Timeout value changed from 20 to 120 under IFU3506 for FRS-259
--			:30/10/2015 HB Timeout value changed from 120 to 180 under IFU3514 for FRS-259
--           09/11/2015 VP Modified timeout for FRS-000273
-- 			:13/11/2015 SB Added entries for Vehicle Genealogy To Multiple Systems(FRS-000003)
--          : 23/12/2015 PM updated as per IFU3626
-- 			:03/03/2016 KV Added entries for FRS-000653
--          :04/03/2016 NM Changed timeout value to 60 for IA-61 under PBI000000015455
--			:16/03/2016 LH Changed timeout value to 175 from 120 for FRS-258 IFU3605
--			:06/04/2016 MJ Changed timeout value for CJLR as per IFU-3813
--          :25/04/2016 SK  timeout modified for FRS-109(IFU3845)
--			:06/05/2016 MJ Updated HTTP Outbound entry as per IFU3813
--          :18/05/2016 KV Updated URL for NICB FRS-653
--          :02/06/2016 KV Added entries for FRS-000130/IFU3888(OCRM) 
--			:02/06/2016 LH Updated BSID for IA-207 for IFU3924
--			:08/06/2016	ANA Added entries for FRS-000151
--          :13/06/2016 NM INC000001411381 Updated the timeout value for web service call Call ESB service - SI_SV_VEHSV_MANUFSTAT
-- 			:13/06/2016 LH Removed entries for IFU 3948 as Topix sub and Topix security are no more used
--       	:27/06/2016 AT Added entries for FRS-000107/IFU3897(OCRM)
-- 			:12/07/2016 RBH Added entries for FRS-000151/IFU3942(OCRM)
--          :19/07/2016 AM Updated TimeOut from 600 to 1800 Sec under INC000001521104 for FRS 6
--			:28/07/2016 VB:IFU4063 - Changed TIMEOUT from 40 sec to 60 sec for FRS-129
--			:28/07/2016 NB: Added entries for FRS-000371(IFU3928)
--			:01/08/2016 VV: Commented the entries for FRS-113, FRS-119, FRS-120, FRS-121 and FRS-122 as required by IFU-4064
--			:03/08/2016 NB: Updated entries for FRS-000371(IFU3928)
--          :08/08/2016 KV Updated Timeout to 120 Secs for FRS-000151/IFU4071(OCRM)
--			:12/09/2016 KT FRS-000271 IFU4135 Timeout changed from 50 to 290 seconds.
-- 			:13/09/2016 HB Updated timeout value to 120 DEF-19941
--          :06/10/2016 SK: Updated entries for FRS-000154(IFU4148)
-- 			:18/10/2016 NB Updated Business Service Name as per IFU4163(FRS-000261)
--			:20/10/2016 NB Added new cookies for FRS-371(NEW) IFU4199
--			:23/10/2016 HB Added New entry for FRS 790
--			:24/11/2016 VVS Added New entries for FRS-155 As per the IFU4236
--			:06/12/2016 AT Added New entries for FRS-153 As per the IFU4255
--			:07/12/2016 AT Added url details for flow SI_SV_CreateUpdate_Activity FRS-000154-IFU4275
--			:16/12/2016 MJ Added WSL entries for FRS-841
--			:06/01/2017 MJ Updated WSL entries for FRS-841
--			:06/01/2017 NS  timeout updated  for IFU4353
--			:09/01/2017 NS updated timeout for  FRS-128 IFU4353
--          :17/01/2017 SK:IFU4364 -Updated timeout for FRS-143 from '30' to '60'
-- 			:30/01/2017 CD Added entries for IFU4373
--			:03/02/2017 NS IFU4402 Updated Timeout from 40 sec to 60 sec for FRS-141
--          :14/02/2017 AB Updated key from CTUPACTVTY_ACCT to CRTUPDTACTVTY_ACCT
-- 			:21/02/2017 KB updated URL FRS817 IFU4443
--			:02/03/2017 VB Updated key from CRTUPDLEADPERSP_ACCT to CRTUPDATELEADPERSP_ACCT
--			:02/03/2017 VB:Updated key from CRTUPDATELEADPERSP_ACCT to CRTUPDTLDPRSP_ACCT for FRS-112
--			:25/03/2017 MJ updated FRS-107 entries as per IFU4438
--			:07/04/2017 IFU4565:Commented below entries as the OSH is no more required
--		    :07/04/2017 VB IFU4565:Commented entries for OSH
-- 			:11/04/2017 KB Added entries for FRS258 IFU4561 for SI_BS_PGZ_VEHICLE_WLCAR_PRODCTRL
-- 			:11/04/2017 MJ updated FRS-107 entries as per IFU4515
--          :14/04/2017 NM Moved FRS-367 entries to SI_Components location as per new build process.
--          :21/04/2017 AT Removed entries as part of IFU4590
--          :21/04/2017 AT Removed entries As part of IFU4590 FRS-138
--          :21/04/2017 AT Removed entries as part of IFU4591
--			:28/04/2017 AT Updated TIMEOUT to 120(FRS136)for  INC000002190079.
--			:28/04/2017 MJ updated entries for FRS-259 as per port nos in FRS
--          :02/05/2017 VK Removed entries after framework migration of FRS-273.
--          :04/05/2017 SK  Updated URL Details for FRS-154 newly added AccountContacts backend() replacing previous Account backend as per IFU4604
--          :05/05/2017 SK IFU4604 Updated URL details,with CRTUPDACTY_ACCTCONT,replaced previous key
--          :05/05/2017 MJ Updated method for NNG service as per defect-2
--          :10/04/2017 MJ Defect-3 Updated new BSID entries for different services
--          :22/05/2017 MJ Defect-4 Updated method for HERE service
--          :24/05/2017 AB Updated timeout to 180 for INC000002251560
--          :25/05/2017 SK IFU4533: Added entries for VVO SAPVMS for FRS-136
--			:07/06/2017 VH IFU4707: TIMEOUT value changed from 40 to 180 for FRS-148
--			:09/06/2017 VH IFU4714: TIMEOUT value changed from 40 to 180 for FRS-147
--			:30/06/2017 VB IFU4755 :Updated timeout for FRS-143 from '60' to '180'
--			:24/08/2017 VB IFU4845:Updated timeout for OCCAM from 120 to 300 seconds
--			:28/09/2017 VB MNT:Updated the backend time-out from 40 to 120
--          :30/11/2017 VH TIMEOUT value changed from 180 to 300 for FRS-107 and FRS-148 for IFU 5114 and IFU5115 respectivly.
--			:01/12/2017 AT TIMEOUT value changed from 180 to 300 for FRS-137 IFU5116.
--			:04/12/2017 VB IFU5120:Updated time-out from 180 to 300 seconds
--			:18/12/2017 VVS IFU5149:Updated time-out from 60 to 180 seconds
--------------------------------------------------------------------------------------------------------------------------------------

--PLEASE NOTE!! An entry is required for each broker.  In most cases this will simply be a duplicate entry except when server specific WSL authentication is in use.
-- Both WSL_STRING and BROKER_NAME are environmental specific.

DELETE FROM SI_HTTP_OUTBOUND_DETAILS;

-- KM 02/01/2013 Added to prevent prompt when inserting due to &
SET DEFINE OFF;

-- !!ENTRY FOR BROKER 1
-- This entry uses Cookies
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_SAP_TRBGB_VEH_D42_ALERTUPD','SI_HTTP_OUTBOUND_DETAILS.URL.VEH_D42_ALERTUPD','20',null,null,null,null,null,null,null,'SAP Turbo Vehicle Alert Update to D42','spatel5','SI_HTTP_OUTBOUND_DETAILS.WSL.WSLSTRING_BROKER1','SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--VY entry for IA000061 Planning Events to VISTA
-- This entry uses Cookies
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_ALL_MISCSERV_ALL_PLANEVENT','SI_HTTP_OUTBOUND_DETAILS.URL.PLANNING_EVENT_VISTA','60',null,null,null,null,null,null,null,'Planning Events to VISTA','vyadav1','SI_HTTP_OUTBOUND_DETAILS.WSL.WSLSTRING_BROKER1','SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
--AB entry for IA000027 Multiple system to VISTA and D42				
-- This entry uses Cookies
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_SAP_TRBGB_INVCRDDETS_VISTA','SI_HTTP_OUTBOUND_DETAILS.URL.INVCRDDETS_VISTA','20',null,null,null,null,null,null,null,'Invoice and credit details to VISTA','abadal','SI_HTTP_OUTBOUND_DETAILS.WSL.WSLSTRING_BROKER1','SI_HTTP_OUTBOUND_DETAILS.BROKER1','Y');
-- This entry uses Cookies
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_SAP_TRBGB_INVCRDDETS_D42','SI_HTTP_OUTBOUND_DETAILS.URL.INVCRDDETS_D42','20',null,null,null,null,null,null,null,'Invoice and credit details to D42','abadal','SI_HTTP_OUTBOUND_DETAILS.WSL.WSLSTRING_BROKER1','SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
--06/11/2012 Vikas Yadav, Planning Events to VISTA, IA-000009
--22/01/2013 MA fix for VISTA IA9
-- This entry uses Cookies
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_CANON_VEHSERV_VISTA_VEHSTATUS','SI_HTTP_OUTBOUND_DETAILS.URL.VEHICLE_STATUS_VISTA','20',null,null,null,null,null,null,null,'Vehicle Status to VISTA','vyadav1','SI_HTTP_OUTBOUND_DETAILS.WSL.WSLSTRING_BROKER1','SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
--06/11/2012 Vikas Yadav, Planning Events to D42, IA-000009
-- This entry uses Cookies
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_CANON_VEHSERV_D42_VEHSTATUS','SI_HTTP_OUTBOUND_DETAILS.URL.VEHICLE_STATUS_D42','20',null,null,null,null,null,null,null,'Vehicle Status to D42','vyadav1','SI_HTTP_OUTBOUND_DETAILS.WSL.VSD42WSL_BROKER1','SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
--08/11/2012 Chandrasekhar, IA-000234 SI_BS_SAP_TRBGB_Engineer_Request_TO_RADS
--14/02/2014. RB. Updated WSL Relacement String for consistency.
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_SAP_TRB_MISC_RADS_ENGREQ','SI_HTTP_OUTBOUND_DETAILS.URL.ENGG_REQ_RADS','120',null,null,null,null,null,null,null,'RADS HTTP Engineering Time Report URL','cgundlap','SI_HTTP_OUTBOUND_DETAILS.WSL.ENGG_REQ_RADS_BRK1','SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
--28/03/2013 Yamini Goyal, IA-000235 SI_BS_SAP_TRBGB_Engineer_Request_TO_RADS
--14/02/2014. RB. Updated WSL Relacement String for consistency.
-- This entry uses Cookies
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_BS_SAP_TRB_MISC_RADS_PROJCAT','SI_HTTP_OUTBOUND_DETAILS.URL.PROJCAT_RADS','20',null,null,null,null,null,null,null,'SAP Turbo GB Project Category Status update to RADS','ygoyal','SI_HTTP_OUTBOUND_DETAILS.WSL.PROJCAT_RADS_BRK1','SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
--HB 30/10/2015 Timeout value changed from 120 to 180 under IFU3514
--AaP 28/10/2015 Timeout value changed from 20 to 120 under IFU3506 for FRS-259
--03/04/2013 AS Adding entry for FRS-259
--14/02/2014. RB. Removed WSL value as it is not relevant for this interface.
--15/12/2014. NM. Def-33 Added WSL value for this interface.
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_VEHSV_VEHPROPDTA','SI_HTTP_OUTBOUND_DETAILS.URL.VEHPROPDTA','180',null,null,null,null,'PUT',null,null,'Vehicle Property Data to XML Gateway','asannago','SI_HTTP_OUTBOUND_DETAILS.WSL.WSLSTRING_BROKER1','SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
--29/04/2013 AS Adding entry for FRS-258
--14/02/2014. RB. Removed WSL value as it is not relevant for this interface.
--15/12/2014. NM. Def-33 Added WSL value for this interface.
--IFU3605 FRS-258 timeout changed to 175 from 120 
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_VEHSV_PRODCTRL','SI_HTTP_OUTBOUND_DETAILS.URL.PRODCTRLTUP','175',null,null,null,null,null,null,null,'Prod Ctrl tuprofile to XML Gateway','asannago','SI_HTTP_OUTBOUND_DETAILS.WSL.WSLSTRING_BROKER1','SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--HB 30/10/2015 Timeout value changed from 120 to 180 under IFU3514
--AaP 28/10/2015 Timeout value changed from 20 to 120 under IFU3506 for FRS-259
--10/06/2013 SP Adding entry for FRS-259 (IFU997)
--14/02/2014. RB. Removed WSL value as it is not relevant for this interface.
--15/12/2014. NM. Def-33 Added WSL value for this interface.
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_VEHSV_VEHPROPSUB','SI_HTTP_OUTBOUND_DETAILS.URL.VEHPROPSUB','180',null,null,null,null,'POST',null,null,'Vehicle Property Subscription Data to XML Gateway','spatel5','SI_HTTP_OUTBOUND_DETAILS.WSL.WSLSTRING_BROKER1','SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--27/06/2013 SK Adding entry for FRS-000271
--14/02/2014. RB. Removed WSL value as it is not relevant for this interface.
--13/06/2014. RB. Updated with non valid default URL value.
-- INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_VEHSV_ENGGCHANGE','SI_HTTP_OUTBOUND_DETAILS.URL.CSAPECSDTA','50', null, null, null,  null, null, null, null,'ECS Data to CSAP through XML Gateway','skarri', null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N' );
--18/03/2015 KT FRS-000271 Changed BSID to SI_SV_VEHSV_ENGGCHGSAP
--12/09/2016 KT FRS-000271 IFU4135 Timeout changed from 50 to 290 seconds.
INSERT INTO WMBOWNER.SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_VEHSV_ENGGCHGSAP','http://OVERRIDDEN/FROM/ROUTINGDETAILS/EDMTABLE','290', null, null, null,  null, null, null, null,'ECN Data outbound by Web Service','kthanga2', null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N' );

--19/07/2013 Deepak Ingwale Updated entry for FRS-000016 IFU1082
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_PRDSV_CODETRAN','SI_HTTP_OUTBOUND_DETAILS.URL.CODETRANSLATION','20',null,null,null,null,null,null,null,'Code Translation Service','dingwale','','SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--22/07/2013 Deepak Ingwale Updated entry for FRS-000006 IFU1078
--27/07/2015 AM Updated Entry for FRS-000006 IFU3242
--26/10/2015 AM Updated Entry for IFU3498
--19/07/2016 AM Updated TimeOut from 600 to 1800 Sec under INC000001521104
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_PRDSV_MASTFEATDC','SI_HTTP_OUTBOUND_DETAILS.URL.MSTRFEATUREDICT','1800',null,null,null,null,null,null,null,'Master Feature Dictionary Service','dingwale','','SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--24/07/2013 Deepak Ingwale Adding entry for FRS-000007
--27/07/2015 AM Updated Entry for FRS-000007 IFU3242
--26/10/2015 AM Updated Entry for IFU3498
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_PRDSV_EVENTCAL','SI_HTTP_OUTBOUND_DETAILS.URL.EVENTCALSERVICE','600',null,null,null,null,null,null,null,'Enovia Get Event Calendar Service','dingwale','','SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--30/07/2013 Deepak Ingwale Adding entry for FRS-000009
--26/10/2015 AM Updated Entry for IFU3498
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_PRDSV_FEATOK2USE','SI_HTTP_OUTBOUND_DETAILS.URL.FEATOK2USE','600',null,null,null,null,null,null,null,'ACE Feature OK To Use List','dingwale','','SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

-- 30/07/2013 FRS-000107 Venkata Annareddy Adding entry for URL for sending messages to SVCRM
-- 21/05/2015 TK Updated WSL_STRING to Null as Guanxi flows don't use WSL_STRING value
-- 24/05/2017 AB Updated timeout to 180 for INC000002251560
-- This entry uses Cookies 
-- VH 30/11/2017 TIMEOUT value changed from 180 to 300 for FRS-107 for IFU5114
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_CUSSV_ORDERREPLICATE','SI_HTTP_OUTBOUND_DETAILS.URL.ORDRREPLCT','300',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','abasak',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--02/08/2013 Aditi Pathak Adding entry for FRS-000261
-- This entry uses Cookies
-- 13/09/2016 HB Updated timeout value to 120 DEF-19941
-- 18/10/2016 NB Updated Business Service Name as per IFU4163(FRS-000261)
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_BS_SAP_TRBGB_VEHICLE_ALL_PARTS','SI_HTTP_OUTBOUND_DETAILS.URL.SAPTOGXS','120',null,null,null,null,null,null,null,'Vehicle updated to GXS','apathak2','SI_HTTP_OUTBOUND_DETAILS.WSL.WSLSTRING_BROKER1','SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
									 
-- 06/08/2013 FRS-000108 achibbe1 Adding entry for URL for sending messages to SVCRM ACTCRTUPDT
-- 21/05/2015 TK Updated WSL_STRING to Null as Guanxi flows don't use WSL_STRING value
-- This entry uses Cookies
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_CUSSV_ACCTCRTUPD','SI_HTTP_OUTBOUND_DETAILS.URL.ACTCRTUPDT','60',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','achibbe1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--10/08/2013 RB Adding entry for FRS-000260
--27/03/2015 KT FRS-000260 Due to MQ design change for FRS-000271 this entry is not required.
--INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_WERS_ADAPSV_ENGCHNG_OUT','SI_HTTP_OUTBOUND_DETAILS.URL.ENGCHNGADOUT','50',null,null,null,null,null,null,null,'URL for sending messages to Engineering Change Service','rbabu',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--16/08/2013 AC Adding entry for FRS-000272
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_VEHSV_PARTS','SI_HTTP_OUTBOUND_DETAILS.URL.VEHPARTS','50',null,null,null,null,null,null,null,'URL for JVBridge Vehicle Parts Service','achibbe1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

-- 21/04/2017 AT Removed entries as part of IFU4590
-- 22/08/2013 Aman Chibber Added entry for FRS-116  
--	23/05/2015 SM Updated timeout to 120s for DEF4614
--INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_CUSSV_VEHREFDATAREPLICATE_SF_VFT','SI_HTTP_OUTBOUND_DETAILS.URL.VEHREFDATAREP_SF_VFT','120',null,null,null,null,null,null,null,'URL to Replicate vehicle reference type data to SAP CRM','achibbe1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
--INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_CUSSV_VEHREFDATAREPLICATE_SF_VFC','SI_HTTP_OUTBOUND_DETAILS.URL.VEHREFDATAREP_SF_VFC','120',null,null,null,null,null,null,null,'URL to Replicate vehicle reference type data to SAP CRM','achibbe1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--22/08/2013 SP Adding entry for FRS-110
-- 21/05/2015 TK Updated WSL_STRING to Null as Guanxi flows don't use WSL_STRING value
-- This entry uses Cookies
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_CUSSV_SEARCHACCT','SI_HTTP_OUTBOUND_DETAILS.URL.CRMSERCHACC','40',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','spatel5',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--03/09/2013 Gaurav Gawali Adding entry for FRS-352
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_PLO_VEH_CJLR_EVEHORDREQ','SI_HTTP_OUTBOUND_DETAILS.URL.VEHORDREQ','120',null,null,null,null,null,null,null,'URL for sending messages to CJLR','ggawali',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

-- 20/08/2013 FRS-109 Nisha Purohit Adding entry for URL for sending messages to SAP CRM webservices
-- 25/04/2016 FRS-109(IFU3845) SK Updated timeout to 180
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_CUSSV_CONTRACTREPLICATE_SF_VEHACC','SI_HTTP_OUTBOUND_DETAILS.URL.CNTRCTREP_SF_VEHACC','180',null,null,null,null,null,null,null,'URL for Contract Veh Account Relationship to SAP CRM','npurohit',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
--23/05/2015:SM:Updated timeout to 120s for DEF4613
-- 25/04/2016 FRS-109(IFU3845) SK Updated timeout to 180
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_CUSSV_CONTRACTREPLICATE_SF_CON','SI_HTTP_OUTBOUND_DETAILS.URL.CNTRCTREPLCT_SF_CON','180',null,null,null,null,null,null,null,'URL for Replicate contract to SAP CRM','npurohit',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--08/10/2013 Gaurav Gawali Adding entry for IA-336
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_WERS_VEHICLE_SAP_TRBGB_VENDORTOOL','SI_HTTP_OUTBOUND_DETAILS.URL.VENDORTOOL','120',null,null,null,null,null,null,null,'SAP SRM Vendor Tooling','ggawali',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--07/11/2013 Saptarshi Goswami Added entry for FRS-128
--09/01/2017 NS updated timeout for  FRS-128 (IFU4353)
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CTUPSERREP','SI_HTTP_OUTBOUND_DETAILS.URL.CRTUPDTSERORREP','60',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','sgoswam1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CTUPSERREP_ACCT','SI_HTTP_OUTBOUND_DETAILS.URL.SERORREPACTCRTUPDT','60',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','sgoswam1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CTUPSERREP_SF_VEHACC','SI_HTTP_OUTBOUND_DETAILS.URL.SERORREPVEHACCREL','60',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','sgoswam1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--11/11/2013 RB Added entry for FRS-112
--MNT:vbordia - Updated the backend time-out from 40 to 120
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CRTUPDLEAD','SI_HTTP_OUTBOUND_DETAILS.URL.CRTUPDLEADPERSP','120',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','rbabu',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CRTUPDLEAD_ACCT','SI_HTTP_OUTBOUND_DETAILS.URL.CRTUPDTLDPRSP_ACCT','120',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','rbabu',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CRTUPDLEAD_ACTV','SI_HTTP_OUTBOUND_DETAILS.URL.CRTUPDLEADPERSP_ACTV','120',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','rbabu',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--12/11/2013 SK added entry for FRS-366
--14/02/2014. RB. Updated WSL Relacement String for consistency.
-- This entry uses Cookies
-- 23/12/2015 PM updated as per IFU3626
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_VEHSV_TRACKUPD','SI_HTTP_OUTBOUND_DETAILS.URL.TRACKUPD','290', null, null, null,  null, 'POST', null, null,'Vehicle Tracking Update to D42','skarri', 'SI_HTTP_OUTBOUND_DETAILS.WSL.D42_TRKUPD_BRK1','SI_HTTP_OUTBOUND_DETAILS.BROKER1','N' );

--14/11/2013 TK added entry for FRS-119
--01/08/2016 VV Commented the following 2 SQL Statements for IFU-4064
--INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_GTLSTLEADS','SI_HTTP_OUTBOUND_DETAILS.URL.GETLSTOFLEADSDEALER','40', null, null, null,  null, null, null, null,'URL for sending messages to SAP CRM','tksheers', null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N' );

--15/11/2013 Surya Prakash Added entry for FRS-127
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CRUPPTCHFS','SI_HTTP_OUTBOUND_DETAILS.URL.CRTUPDPRTTECFSEVEH','40',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','ssingh25',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--21/11/2013 Saptarshi Goswami Added entry for FRS-130
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_REPLICTEDR_SVCRM_CRTUPDDLR','SI_HTTP_OUTBOUND_DETAILS.URL.RPLCTCRTUPDDLR','40',null,null,null,null,null,null,null,'URL for sending messages to SVCRM for Create Update Dealer','sgoswam1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_REPLICTEDR_SVCRM_CRTUPDTER','SI_HTTP_OUTBOUND_DETAILS.URL.RPLCTCRTUPDTER','40',null,null,null,null,null,null,null,'URL for sending messages to SVCRM for Create Update Territory','sgoswam1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--21/11/2013 Shilpa Mathur Added entry for FRS-123
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_SVCRM_BRKDWNEVNT','SI_HTTP_OUTBOUND_DETAILS.URL.CRTBRKDWNEVNTVEH','40',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','smathur',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--21/04/2017 AT Removed entries As part of IFU4591
--22/11/2013 Priyanka Gupta Added entry for FRS-129
--28/07/2016 VB:IFU4063 - Changed TIMEOUT from 40 sec to 60 sec
--Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CRTUPDCASE','SI_HTTP_OUTBOUND_DETAILS.URL.CRTORUPDCASE','60',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','pgupta3',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--25/11/2013 Sunita Muley Added entry for FRS-118
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CRTUPDCPGNEVNTORRSPS','SI_HTTP_OUTBOUND_DETAILS.URL.CRTUPDCPGNEVNTORRSPS','40',null,null,null,null,null,null,null,'URL for sending messages to SAP CRM','smuley',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--11/11/2013 KM Added entry for FRS-117
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CRTUPDFINCNTRPROP','SI_HTTP_OUTBOUND_DETAILS.URL.FINCNTRCRTUPD','40',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','kmccorma',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CRTUPDFINCNTRPROP_ACCT','SI_HTTP_OUTBOUND_DETAILS.URL.CRTUPDFINCNTR_ACCT','40',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','kmccorma',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CRTUPDFINCNTRPROP_SF_VEHACC','SI_HTTP_OUTBOUND_DETAILS.URL.CRTUPDFINCNTR_VREL','40',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','kmccorma',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--01/12/2013 HM Added entries for FRS-139
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_REPVEHSALESTAT_VEH','SI_HTTP_OUTBOUND_DETAILS.URL.REPVEHSALESTAT_VEH','120',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','tksheers',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_REPVEHSALESTAT_SF_VEHACC','SI_HTTP_OUTBOUND_DETAILS.URL.REPVEHSALESTAT_REL','120',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','tksheers',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_REPVEHSALESTAT_ACC','SI_HTTP_OUTBOUND_DETAILS.URL.REPVEHSALESTAT_ACC','120',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','tksheers',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--06/02/2014 AP Entry added for FRS-378
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values
 ('SI_SV_VEHSV_EVEHORDFOR','SI_HTTP_OUTBOUND_DETAILS.URL.EVEHORDFOR','120',null,null,null,null,null,null,null,'Updated vehicle order forecast to XML Gateway','apathak2',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

 
--19/12/2013 HS Added entries for FRS-083

Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_PRDSV_CARS_VISTASOLVE','SI_HTTP_OUTBOUND_DETAILS.URL.VISTASOLVE_CARS','60',null,null,null,null,null,null,null,'CARS Vista Solve','hsabat',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_PRDSV_ACE_VISTASOLVE','SI_HTTP_OUTBOUND_DETAILS.URL.VISTASOLVE_ACE','60',null,null,null,null,null,null,null,'ACE Vista Solve','hsabat',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
 
  --19/03/2014 AK added entry for FRS 093
  --26/10/2015 AM Updated Entry for IFU3498
 Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_PRDSV_BOMVAL','SI_HTTP_OUTBOUND_DETAILS.URL.BOM_FEAT_VAL','120',null,null,null,null,null,null,null,'ACE Get BOM Validation Service','akarma',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
 
 --NM on 27/03/2014 added entry for IA-207
 --AP on 07/05/2014 added wsl value IFU-1910
 --LH on 02/06/2016 changed BSID from SI_BS_ALL_VEHSERV_ALL_MVRISREG to SI_BS_ALL_VEHSERV_ALL_VEHREGIS and removed entry with BSID SI_BS_ALL_VEHSERV_ALL_AFRLREG for IFU3924 framework migration
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_ALL_VEHSERV_ALL_VEHREGIS','SI_HTTP_OUTBOUND_DETAILS.URL.VEHICLE_REGISTRATION',null,null,null,null,null,null,null,null,'Registrations Capture Data from MVRIS','nmithari','SI_HTTP_OUTBOUND_DETAILS.WSL.WSLSTRING_BROKER1','SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
--INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_ALL_VEHSERV_ALL_AFRLREG','SI_HTTP_OUTBOUND_DETAILS.URL.VEHICLE_REGISTRATION',null,null,null,null,null,null,null,null,'Registrations Capture Data from AFRLREG','nmithari','SI_HTTP_OUTBOUND_DETAILS.WSL.WSLSTRING_BROKER1','SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

-- HA 15/04/2014 Entries for FRS 277.
-- HA 02/05/2014 Removed an entry for CJLR URL
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_VEHSV_ADVSHPNT','SI_HTTP_OUTBOUND_DETAILS.URL.ASN_PROV_JVBRIDGE','40',null,null,null,null,null,null,null,'URL for sending messages to JV-Bridge','havhale',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_VEHSV_ADVSHPNT_EVNTSCHD','SI_HTTP_OUTBOUND_DETAILS.URL.ASN_PROV_EVNTSCHD','40',null,null,null,null,null,null,null,'URL for sending messages to the Event Scheduler','havhale',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
 
-- SK 25/04/2014 added queries for FRS 371
--AP  22/05/2014 WSL string added
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_VEHSV_MANUFSTAT','SI_HTTP_OUTBOUND_DETAILS.URL.VEHMANUFSTAT','120', null, null, null,  null, 'POST', null, null,'Vehicle Manufacturing Status to D42 ','skarri', 'SI_HTTP_OUTBOUND_DETAILS.WSL.WSLSTRING_BROKER1','SI_HTTP_OUTBOUND_DETAILS.BROKER1','N' );
 
-- NM 07/05/2014 added queries for FRS 372
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_VEHSV_VEHDSTST','SI_HTTP_OUTBOUND_DETAILS.URL.VEHICLE_DISTRIBUTION','120', null, null, null,  null, 'POST', null, null,'Vehicle Distribution  Status to CJLR ','nmithari', null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N' );
  
  -- 	PVH 15/04/2014 Entries for FRS 282.
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_VEHSV_TRNFWDPT','SI_HTTP_OUTBOUND_DETAILS.URL.FWDPARTSTAT_JVBRIDGE','40',null,null,null,null,null,null,null,'URL for sending messages to JV-Bridge','pvonhirs',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_VEHSV_TRNFWDPT_EVNTSCHD','SI_HTTP_OUTBOUND_DETAILS.URL.FWDPARTSTAT_EVNTSCHD','40',null,null,null,null,null,null,null,'URL for sending messages to the Event Scheduler','pvonhirs',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

-- NM 22/05/2014 added entry for  IA-000005
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_BS_VISTA_VEHICLE_ALL_GOF','SI_HTTP_OUTBOUND_DETAILS.URL.VISTA_GOF_CJLR','120', null, null, null,  null, 'POST', null, null,'Vehicle GOF feed to CJLR application via XML Gateway','nmithari', null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N' );
--SK 26/05/2014 Added entries for FRS_278
--MJ Changed timeout value for CJLR as per IFU-3813
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_INVSV_VEHPARTINV','SI_HTTP_OUTBOUND_DETAILS.URL.ICS_VInPart_JVBRIDGE','40',null,null,null,null,null,null,null,'URL for sending messages to JV-Bridge','skarri',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_INVSV_VEHPARTINV_CJLR','SI_HTTP_OUTBOUND_DETAILS.URL.ICS_VehInvPart_CJLR','120',null,null,null,null,null,null,null,'URL for sending messages to CJLR','skarri',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_INVSV_VEHPARTINV_EVNTSCHD','SI_HTTP_OUTBOUND_DETAILS.URL.ICS_VInPart_EVNTSCHD','40',null,null,null,null,null,null,null,'URL for sending messages to the Event Scheduler','skarri',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

-- NM 14/04/2017 Moved FRS-367 entries to SI_Components location as per new build process.
-- PVH 27/05/2014 Entry for FRS 367
--INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_BRS_VEHICLE_CJLR_DERIVFEAT','SI_HTTP_OUTBOUND_DETAILS.URL.DERIVFEATDELTAFEED','40',null,null,null,null,null,null,null,'URL for sending messages to CJLR','pvonhirs',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--SK 26/05/2014 Added entries for FRS-281
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_MISCSV_LDPLNTCLNDR','SI_HTTP_OUTBOUND_DETAILS.URL.PlntcalenderJVBRIDGE','40',null,null,null,null,null,null,null,'URL for sending messages to JV-Bridge','skarri',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_MISCSV_LDPLNTCLNDR_EVNTSCHD','SI_HTTP_OUTBOUND_DETAILS.URL.PlntcalenderEVNTSCHD','40',null,null,null,null,null,null,null,'URL for sending messages to the Event Scheduler','skarri',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

-- 21/04/2017 AT Removed entries As part of IFU4590 
-- GT 10/07/2014 Added entries for FRS-138
--INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_REPVEHDERV','SI_HTTP_OUTBOUND_DETAILS.URL.REPVEHDERIV','40',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','gthamma',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

-- TK 24/07/2014 Added entries for FRS-141
-- NS 03/02/2017 Updated Timeout from 40 sec to 60 sec for FRS-141
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CTUPVEHOWN_SF_VEHACC','SI_HTTP_OUTBOUND_DETAILS.URL.CTUPVEHOWN','60',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','tksheers',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--AP 12/08/2014 Added entries for FRS-272
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_VEHSV_TDPARTS','SI_HTTP_OUTBOUND_DETAILS.URL.VEHTDPARTS',null,null,null,null,null,null,null,null,'Vehicle Parts Service','apathak2',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

-- SM :19/08/2014 SM Updated entries for FRS-628
 Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_SAP_TRBGB_VEHICLE_GCM_FREDMAINT','SI_HTTP_OUTBOUND_DETAILS.URL.GCM_FREDMAINT','30',null,null,null,null,null,null,null,'Warranty FRED Update to GCM','smuley',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
 
 -- SB 21/08/2014 Added entries for FRS-137
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CTUPVHCL','SI_HTTP_OUTBOUND_DETAILS.URL.CRTUPDVEHICLE','60',null,null,null,null,null,null,null,'FRS-00137 - URL for sending messages to SAP CRM','sbabu4',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--TK 21/08/2013 Added entries for FRS-143
--SK 17/01/2017 IFU4364 :Updated timeout for FRS-143 from '30' to '60'
--VB 30/06/2017 IFU4755 :Updated timeout for FRS-143 from '60' to '180'

Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_SENDWRTCON','SI_HTTP_OUTBOUND_DETAILS.URL.CONSENDWRT','180',null,null,null,null,null,null,null,'URL for sending Warranty Contract  messages to SVCRM','vbordia',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_SENDWRTCON_ACCT','SI_HTTP_OUTBOUND_DETAILS.URL.ACCTSENDWRTCON','180',null,null,null,null,null,null,null,'URL for sending Warranty Contract  Account messages to SVCRM','vbordia',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_SENDWRTCON_SF_VEHACC','SI_HTTP_OUTBOUND_DETAILS.URL.VEHACCSENDWRTCON','180',null,null,null,null,null,null,null,'URL for sending Warranty Contract  Vehicle Account Relate messages to SVCRM','vbordia',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
 
 --AP 22/08/2014 Added entries for FRS-273
-- VK 02/05/2017 Removed entries after framework migration of FRS-273.
--INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_VEHSV_TDDEMANDUPD','SI_HTTP_OUTBOUND_DETAILS.URL.TDDEMANDUPD',null,null,null,null,null,null,null,null,'Trading Division Parts Demand Update Service Service','apathak2',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');


--AP 22/08/2014 Added entries for FRS-371/IA-09
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_VEHSV_PUBFINSTAT','SI_HTTP_OUTBOUND_DETAILS.URL.MANFSTATUS',null,null,null,null,null,null,null,null,'Vehicle Manufacturing Parts Service','apathak2',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

-- 25/11/2014 NC  Added entries for FRS-000090(SI_FL_Product,IFU2310,2497)

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_BS_ACE_PRODUCT_ALL_VEHSPECDES','SI_HTTP_OUTBOUND_DETAILS.URL.VEHSPECDES',null,null,null,null,null,null,null,null,'Entry for Vehicle Desc to VISTA','nch',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

-- 19/12/2014 HA FRS 643 Vehicle Appraisal
-- 21/01/2015 HA FRS 643 IFU 2674 WSL entry added
-- 20/01/2015 AP FRS-643 Timeoutvalue changed to 120 sec
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) 
	VALUES ('SI_SV_MOBSV_VEHICLEAPPRAISAL','SI_HTTP_OUTBOUND_DETAILS.URL.VEHICLE_APPRAISAL','120',null,null,null,null,null,null,null,'FRS-000643 Vehicle Appraisal.URL for FMS','havhale','SI_HTTP_OUTBOUND_DETAILS.WSL.VEH_APR_BROKER1','SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');


-- !!ENTRY FOR BROKER 2
-- This entry uses Cookies
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_SAP_TRBGB_VEH_D42_ALERTUPD','SI_HTTP_OUTBOUND_DETAILS.URL.VEH_D42_ALERTUPD','20',null,null,null,null,null,null,null,'SAP Turbo Vehicle Alert Update to D42','spatel5','SI_HTTP_OUTBOUND_DETAILS.WSL.WSLSTRING_BROKER2','SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--VY entry for IA000061 Planning Events to VISTA				
-- This entry uses Cookies
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_ALL_MISCSERV_ALL_PLANEVENT','SI_HTTP_OUTBOUND_DETAILS.URL.PLANNING_EVENT_VISTA','60',null,null,null,null,null,null,null,'Planning Events to VISTA','vyadav1','SI_HTTP_OUTBOUND_DETAILS.WSL.WSLSTRING_BROKER2','SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
--AB entry for IA000027 Multiple system to VISTA and D42
-- This entry uses Cookies
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_SAP_TRBGB_INVCRDDETS_VISTA','SI_HTTP_OUTBOUND_DETAILS.URL.INVCRDDETS_VISTA','20',null,null,null,null,null,null,null,'Invoice and credit details to VISTA','abadal','SI_HTTP_OUTBOUND_DETAILS.WSL.WSLSTRING_BROKER2','SI_HTTP_OUTBOUND_DETAILS.BROKER2','Y');
-- This entry uses Cookies
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_SAP_TRBGB_INVCRDDETS_D42','SI_HTTP_OUTBOUND_DETAILS.URL.INVCRDDETS_D42','20',null,null,null,null,null,null,null,'Invoice and credit details to D42','abadal','SI_HTTP_OUTBOUND_DETAILS.WSL.WSLSTRING_BROKER2','SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
--06/11/2012 Vikas Yadav, Planning Events to VISTA, IA-000009		
--22/01/2013 MA fix for VISTA IA9
-- This entry uses Cookies
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_CANON_VEHSERV_VISTA_VEHSTATUS','SI_HTTP_OUTBOUND_DETAILS.URL.VEHICLE_STATUS_VISTA','20',null,null,null,null,null,null,null,'Vehicle Status to VISTA','vyadav1','SI_HTTP_OUTBOUND_DETAILS.WSL.WSLSTRING_BROKER2','SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
--06/11/2012 Vikas Yadav, Planning Events to D42, IA-000009				
-- This entry uses Cookies
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_CANON_VEHSERV_D42_VEHSTATUS','SI_HTTP_OUTBOUND_DETAILS.URL.VEHICLE_STATUS_D42','20',null,null,null,null,null,null,null,'Vehicle Status to D42','vyadav1','SI_HTTP_OUTBOUND_DETAILS.WSL.VSD42WSL_BROKER2','SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
--08/11/2012 Chandrasekhar, IA-000234 SI_BS_SAP_TRBGB_Engineer_Request_TO_RADS
--14/02/2014. RB. Updated WSL Relacement String for consistency.
-- This entry uses Cookies
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_SAP_TRB_MISC_RADS_ENGREQ','SI_HTTP_OUTBOUND_DETAILS.URL.ENGG_REQ_RADS','120',null,null,null,null,null,null,null,'RADS HTTP Engineering Time Report URL','cgundlap','SI_HTTP_OUTBOUND_DETAILS.WSL.ENGG_REQ_RADS_BRK2','SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--26/03/2013 Yamini Goyal, IA-000235 SI_BS_SAP_TRBGB_Engineer_Request_TO_RADS
--14/02/2014. RB. Updated WSL Relacement String for consistency.
-- This entry uses Cookies
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_BS_SAP_TRB_MISC_RADS_PROJCAT','SI_HTTP_OUTBOUND_DETAILS.URL.PROJCAT_RADS','20',null,null,null,null,null,null,null,'SAP Turbo GB Project Category Status update to RADS','ygoyal','SI_HTTP_OUTBOUND_DETAILS.WSL.PROJCAT_RADS_BRK2','SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
--HB 30/10/2015 Timeout value changed from 120 to 180 under IFU3514
--AaP 28/10/2015 Timeout value changed from 20 to 120 under IFU3506 for FRS-259
--03/04/2013 AS Adding entry for FRS-259
--14/02/2014. RB. Removed WSL value as it is not relevant for this interface.
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_VEHSV_VEHPROPDTA','SI_HTTP_OUTBOUND_DETAILS.URL.VEHPROPDTA','180',null,null,null,null,'PUT',null,null,'Vehicle Property Data to XML Gateway','asannago',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--29/04/2013 AS Adding entry for FRS-258
--14/02/2014. RB. Removed WSL value as it is not relevant for this interface.
--15/12/2014. NM. Def-33 Added WSL value for this interface.
--LH IFU3605 Increased time out from 120 to 175
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_VEHSV_PRODCTRL','SI_HTTP_OUTBOUND_DETAILS.URL.PRODCTRLTUP','175',null,null,null,null,null,null,null,'Prod Ctrl tuprofile to XML Gateway','asannago','SI_HTTP_OUTBOUND_DETAILS.WSL.WSLSTRING_BROKER2','SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
--HB 30/10/2015 Timeout value changed from 120 to 180 under IFU3514
--10/06/2013 SP Adding entry for FRS-259 (IFU997)
--14/02/2014. RB. Removed WSL value as it is not relevant for this interface.
--15/12/2014. NM. Def-33 Added WSL value for this interface.
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_VEHSV_VEHPROPSUB','SI_HTTP_OUTBOUND_DETAILS.URL.VEHPROPSUB','180',null,null,null,null,'POST',null,null,'Vehicle Property Subscription Data to XML Gateway','spatel5','SI_HTTP_OUTBOUND_DETAILS.WSL.WSLSTRING_BROKER2','SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--AaP 28/10/2015 Timeout value changed from 20 to 120 under IFU3506
--19/06/2013 Deepak Ingwale Adding entry for FRS-000016
--19/07/2013 Deepak Ingwale Updated entry for FRS-000016 IFU1082
--26/10/2015 AM Updated Entry for IFU3498
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_PRDSV_CODETRAN','SI_HTTP_OUTBOUND_DETAILS.URL.CODETRANSLATION','20',null,null,null,null,null,null,null,'Code Translation Service','dingwale','','SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--27/06/2013 SK Adding entry for FRS-000271
--14/02/2014. RB. Removed WSL value as it is not relevant for this interface.
--13/06/2014. RB. Updated with non valid default URL value.
--INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_VEHSV_ENGGCHANGE','SI_HTTP_OUTBOUND_DETAILS.URL.CSAPECSDTA','50', null, null, null,  null, null, null, null,'ECS Data to CSAP through XML Gateway','skarri', null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N' );
--18/03/2015 KT FRS-000271 Changed BSID SI_SV_VEHSV_ENGGCHGSAP
--12/09/2016 KT FRS-000271 IFU4135 Timeout changed from 50 to 290 seconds.
INSERT INTO WMBOWNER.SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_VEHSV_ENGGCHGSAP','http://OVERRIDDEN/FROM/ROUTINGDETAILS/EDMTABLE','290', null, null, null,  null, null, null, null,'ECN Data outbound by Web Service','kthanga2', null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N' );

--26/06/2013 Saptarshi Goswami Adding entry for FRS-000006
--22/07/2013 Deepak Ingwale Updated entry for FRS-000006 IFU1078
--27/07/2015 AM Updated Entry for FRS-000006 IFU3242
--19/07/2016 AM Updated TimeOut from 600 to 1800 Sec under INC000001521104.
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_PRDSV_MASTFEATDC','SI_HTTP_OUTBOUND_DETAILS.URL.MSTRFEATUREDICT','1800',null,null,null,null,null,null,null,'Master Feature Dictionary Service','dingwale','','SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--02/07/2013 Deepak Ingwale Adding entry for FRS-000007
--27/07/2015 AM Updated Entry for FRS-000007 IFU3242
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_PRDSV_EVENTCAL','SI_HTTP_OUTBOUND_DETAILS.URL.EVENTCALSERVICE','600',null,null,null,null,null,null,null,'Enovia Get Event Calendar Service','dingwale','','SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

-- 30/07/2013 FRS-107 Venkata Annareddy Adding entry for URL for sending messages to SVCRM
-- 21/05/2015 TK Updated WSL_STRING to Null as Guanxi flows don't use WSL_STRING value
-- This entry uses Cookies
-- 24/05/2017 AB Updated timeout to 180 for INC000002251560
-- VH 30/11/2017 TIMEOUT value changed from 180 to 300 for FRS-107 for IFU 5114
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_CUSSV_ORDERREPLICATE','SI_HTTP_OUTBOUND_DETAILS.URL.ORDRREPLCT','300',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','abasak',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--30/07/2013 Deepak Ingwale Adding entry for FRS-000009
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_PRDSV_FEATOK2USE','SI_HTTP_OUTBOUND_DETAILS.URL.FEATOK2USE','600',null,null,null,null,null,null,null,'ACE Feature OK To Use List','dingwale','','SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--02/08/2013 Aditi Pathak Adding entry for FRS-000261
-- This entry uses Cookies
-- 13/09/2016 HB Updated timeout value to 120 DEF-19941
-- 18/10/2016 NB Updated Business Service Name as per IFU4163(FRS-000261)
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_BS_SAP_TRBGB_VEHICLE_ALL_PARTS','SI_HTTP_OUTBOUND_DETAILS.URL.SAPTOGXS','120',null,null,null,null,null,null,null,'Vehicle updated to GXS','apathak2','SI_HTTP_OUTBOUND_DETAILS.WSL.WSLSTRING_BROKER2','SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

-- 06/08/2013 FRS-000108 achibbe1 Adding entry for URL for sending messages to SVCRM ACTCRTUPDT
-- 21/05/2015 TK Updated WSL_STRING to Null as Guanxi flows don't use WSL_STRING value
-- This entry uses Cookies
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_CUSSV_ACCTCRTUPD','SI_HTTP_OUTBOUND_DETAILS.URL.ACTCRTUPDT','60',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','achibbe1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--08/08/2013 Saptarshi Goswami Adding entry for FRS-000111
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_GETACCTDTLS','SI_HTTP_OUTBOUND_DETAILS.URL.GETACCTDTLS','40',null,null,null,null,null,null,null,'URL for sending messages to SAP CRM','sgoswam1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_GETACCTDTLS','SI_HTTP_OUTBOUND_DETAILS.URL.GETACCTDTLS','40',null,null,null,null,null,null,null,'URL for sending messages to SAP CRM','sgoswam1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--10/08/2013 RB Adding entry for FRS-000260
--27/03/2015 KT FRS-000260 Due to MQ design change for FRS-000271 this entry is not required.
--INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_WERS_ADAPSV_ENGCHNG_OUT','SI_HTTP_OUTBOUND_DETAILS.URL.ENGCHNGADOUT','50',null,null,null,null,null,null,null,'URL for sending messages to Engineering Change Service','rbabu',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--16/08/2013 AC Adding entry for FRS-000272
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_VEHSV_PARTS','SI_HTTP_OUTBOUND_DETAILS.URL.VEHPARTS','50',null,null,null,null,null,null,null,'URL for JVBridge Vehicle Parts Service','achibbe1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

-- 20/08/2013 FRS-109 Nisha Purohit Adding entry for URL for sending messages to SAP CRM webservices
-- 25/04/2016 FRS-109(IFU3845) SK Updated timeout to 180
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_CUSSV_CONTRACTREPLICATE_SF_VEHACC','SI_HTTP_OUTBOUND_DETAILS.URL.CNTRCTREP_SF_VEHACC','180',null,null,null,null,null,null,null,'URL for Contract Veh Account Relationship to SAP CRM','npurohit',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
-- 23/05/2015:SM:Updated timeout to 120s for DEF4613
-- 25/04/2016 FRS-109(IFU3845) SK Updated timeout to 180
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_CUSSV_CONTRACTREPLICATE_SF_CON','SI_HTTP_OUTBOUND_DETAILS.URL.CNTRCTREPLCT_SF_CON','180',null,null,null,null,null,null,null,'URL for Replicate contract to SAP CRM','npurohit',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

-- 21/04/2017 AT Removed entries as part of IFU4590
-- 22/08/2013 Aman Chibber Added entry for FRS-116  
--23/05/2015 SM Updated timeout to 120s for DEF4614
--INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_CUSSV_VEHREFDATAREPLICATE_SF_VFT','SI_HTTP_OUTBOUND_DETAILS.URL.VEHREFDATAREP_SF_VFT','120',null,null,null,null,null,null,null,'URL to Replicate vehicle reference type data to SAP CRM','achibbe1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
--INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_CUSSV_VEHREFDATAREPLICATE_SF_VFC','SI_HTTP_OUTBOUND_DETAILS.URL.VEHREFDATAREP_SF_VFC','120',null,null,null,null,null,null,null,'URL to Replicate vehicle reference type data to SAP CRM','achibbe1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--22/08/2013 SP Adding entry for FRS-110
-- 21/05/2015 TK Updated WSL_STRING to Null as Guanxi flows don't use WSL_STRING value
-- This entry uses Cookies
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_CUSSV_SEARCHACCT','SI_HTTP_OUTBOUND_DETAILS.URL.CRMSERCHACC','40',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','spatel5',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--28/08/2013 Nisha Purohit Adding entry for FRS-122
-- 01/08/2016 VV Commented the following 2 SQL Statements for IFU-4064
--Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_GETCMPGNSLIST','SI_HTTP_OUTBOUND_DETAILS.URL.GETLSTCMPGNS','60',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','npurohit',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_GETCMPGNSLIST','SI_HTTP_OUTBOUND_DETAILS.URL.GETLSTCMPGNS','60',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','npurohit',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--29/08/2013 Saptarshi Goswami Adding entry for FRS-121
-- 01/08/2016 VV Commented the following 2 SQL Statements for IFU-4064
--Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_GETCMPGNMBRS','SI_HTTP_OUTBOUND_DETAILS.URL.GETCMPGNMBRS','40',null,null,null,null,null,null,null,'URL for sending messages to SAP CRM','sgoswam1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_GETCMPGNMBRS','SI_HTTP_OUTBOUND_DETAILS.URL.GETCMPGNMBRS','40',null,null,null,null,null,null,null,'URL for sending messages to SAP CRM','sgoswam1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--30/08/2013 Gaurav Gawali Adding entry for FRS-352
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_PLO_VEH_CJLR_EVEHORDREQ','SI_HTTP_OUTBOUND_DETAILS.URL.VEHORDREQ','120',null,null,null,null,null,null,null,'URL for sending messages to CJLR','ggawali',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--25/09/2013 Srinivas Pithani Adding entry for FRS-113
-- 01/08/2016 VV Commented the following 2 SQL Statements for IFU-4064
--Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_GETCASESLIST','SI_HTTP_OUTBOUND_DETAILS.URL.GETCASESLIST','60',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','sbabu4',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_GETCASESLIST','SI_HTTP_OUTBOUND_DETAILS.URL.GETCASESLIST','60',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','sbabu4',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--26/09/2013 Pratik Khot   Adding entry for FRS-000017
--26/10/2015 AM Updated Entry for IFU3498
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_PRDSV_GENSOLVE','SI_HTTP_OUTBOUND_DETAILS.URL.GENSOLVE','600',null,null,null,null,null,null,null,'ACE Generic Solve Service','pkhot',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--	NC added entries for FRS000023
-- 15/04/2015 PK Corrected entries for FRS000023(IFU-2807)
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES('SI_BS_ENOV_PRODUCT_SAP_TRBGB_COMPTOOLRQ','SI_HTTP_OUTBOUND_DETAILS.URL.COMPTOOLRQ','120',null,null,null,null,null,null,null,'Component Tooling Requests','pkhot',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--27/09/2013 Pratik Khot   Adding entry for FRS-000017
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_PRDSV_GENSOLVE','SI_HTTP_OUTBOUND_DETAILS.URL.GENSOLVE','600',null,null,null,null,null,null,null,'ACE Generic Solve Service','pkhot',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--08/10/2013 Gaurav Gawali Adding entry for IA-336
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_WERS_VEHICLE_SAP_TRBGB_VENDORTOOL','SI_HTTP_OUTBOUND_DETAILS.URL.VENDORTOOL','120',null,null,null,null,null,null,null,'SAP SRM Vendor Tooling','ggawali',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--17/10/2013 Pratik Khot   Adding entry for FRS-000017 - FRS-000094 (Under IFU-1257)
--17/10/2014 Pratik Khot   Updated entry for FRS-000017 - FRS-000094 Updated timout to 120 secs(DEfect 52)
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_PLO_PRO_ACE_GENSOLVE','SI_HTTP_OUTBOUND_DETAILS.URL.GENSOLVE','120',null,null,null,null,null,null,null,'Generic Solve Requests','pkhot',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_PLO_PRO_ACE_GENSOLVE','SI_HTTP_OUTBOUND_DETAILS.URL.GENSOLVE','120',null,null,null,null,null,null,null,'Generic Solve Requests','pkhot',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--30/10/2013 Srinivas Pithani Adding entry for FRS-120
-- 01/08/2016 VV Commented the following 2 SQL Statements for IFU-4064
--Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_GETLEADDTLS','SI_HTTP_OUTBOUND_DETAILS.URL.GETLEADDETAILS','40',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','sbabu4',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_GETLEADDTLS','SI_HTTP_OUTBOUND_DETAILS.URL.GETLEADDETAILS','40',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','sbabu4',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

--07/11/2013 Saptarshi Goswami Added entry for FRS-128
--09/01/2017 NS updated timeout for  FRS-128 (IFU4353)
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CTUPSERREP','SI_HTTP_OUTBOUND_DETAILS.URL.CRTUPDTSERORREP','60',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','sgoswam1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CTUPSERREP_ACCT','SI_HTTP_OUTBOUND_DETAILS.URL.SERORREPACTCRTUPDT','60',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','sgoswam1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CTUPSERREP_SF_VEHACC','SI_HTTP_OUTBOUND_DETAILS.URL.SERORREPVEHACCREL','60',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','sgoswam1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--11/11/2013 RB Added entry for FRS-112
--MNT:vbordia - Updated the backend time-out from 40 to 120
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CRTUPDLEAD','SI_HTTP_OUTBOUND_DETAILS.URL.CRTUPDLEADPERSP','120',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','rbabu',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CRTUPDLEAD_ACCT','SI_HTTP_OUTBOUND_DETAILS.URL.CRTUPDTLDPRSP_ACCT','120',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','rbabu',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CRTUPDLEAD_ACTV','SI_HTTP_OUTBOUND_DETAILS.URL.CRTUPDLEADPERSP_ACTV','120',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','rbabu',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--12/11/2013 SK added entry for FRS-366
--14/02/2014. RB. Updated WSL Relacement String for consistency.
-- This entry uses Cookies
-- 23/12/2015 PM updated as per IFU3626
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_VEHSV_TRACKUPD','SI_HTTP_OUTBOUND_DETAILS.URL.TRACKUPD','290', null, null, null,  null, 'POST', null, null,'Vehicle Tracking Update to D42','skarri', 'SI_HTTP_OUTBOUND_DETAILS.WSL.D42_TRKUPD_BRK2','SI_HTTP_OUTBOUND_DETAILS.BROKER2','N' );

--14/11/2013 TK added entry for FRS-119
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_GTLSTLEADS','SI_HTTP_OUTBOUND_DETAILS.URL.GETLSTOFLEADSDEALER','40', null, null, null,  null, null, null, null,'URL for sending messages to SAP CRM','tksheers', null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N' );

--15/11/2013 Surya Prakash Added entry for FRS-127
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CRUPPTCHFS','SI_HTTP_OUTBOUND_DETAILS.URL.CRTUPDPRTTECFSEVEH','40',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','ssingh25',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--21/11/2013 Saptarshi Goswami Added entry for FRS-130
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_REPLICTEDR_SVCRM_CRTUPDDLR','SI_HTTP_OUTBOUND_DETAILS.URL.RPLCTCRTUPDDLR','40',null,null,null,null,null,null,null,'URL for sending messages to SVCRM for Create Update Dealer','sgoswam1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_REPLICTEDR_SVCRM_CRTUPDTER','SI_HTTP_OUTBOUND_DETAILS.URL.RPLCTCRTUPDTER','40',null,null,null,null,null,null,null,'URL for sending messages to SVCRM for Create Update Territory','sgoswam1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--21/11/2013 Shilpa Mathur Added entry for FRS-123
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_SVCRM_BRKDWNEVNT','SI_HTTP_OUTBOUND_DETAILS.URL.CRTBRKDWNEVNTVEH','120',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','smathur',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--21/04/2017 AT Removed entries as part of IFU4591
--22/11/2013 Priyanka Gupta Added entry for FRS-129
--28/07/2016 VB:IFU4063 - Changed TIMEOUT from 40 sec to 60 sec
--Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CRTUPDCASE','SI_HTTP_OUTBOUND_DETAILS.URL.CRTORUPDCASE','60',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','pgupta3',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--25/11/2013 Sunita Muley Added entry for FRS-118
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CRTUPDCPGNEVNTORRSPS','SI_HTTP_OUTBOUND_DETAILS.URL.CRTUPDCPGNEVNTORRSPS','40',null,null,null,null,null,null,null,'URL for sending messages to SAP CRM','smuley',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--11/11/2013 KM Added entry for FRS-117
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CRTUPDFINCNTRPROP','SI_HTTP_OUTBOUND_DETAILS.URL.FINCNTRCRTUPD','40',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','kmccorma',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CRTUPDFINCNTRPROP_ACCT','SI_HTTP_OUTBOUND_DETAILS.URL.CRTUPDFINCNTR_ACCT','40',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','kmccorma',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CRTUPDFINCNTRPROP_SF_VEHACC','SI_HTTP_OUTBOUND_DETAILS.URL.CRTUPDFINCNTR_VREL','40',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','kmccorma',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--01/12/2013 HM Added entries for FRS-139
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_REPVEHSALESTAT_VEH','SI_HTTP_OUTBOUND_DETAILS.URL.REPVEHSALESTAT_VEH','120',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','tksheers',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_REPVEHSALESTAT_SF_VEHACC','SI_HTTP_OUTBOUND_DETAILS.URL.REPVEHSALESTAT_REL','120',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','tksheers',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_REPVEHSALESTAT_ACC','SI_HTTP_OUTBOUND_DETAILS.URL.REPVEHSALESTAT_ACC','120',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','tksheers',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');


--19/12/2013 HS Added entries for FRS-083

Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_PRDSV_CARS_VISTASOLVE','SI_HTTP_OUTBOUND_DETAILS.URL.VISTASOLVE_CARS','60',null,null,null,null,null,null,null,'CARS Vista Solve','hsabat',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');


Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_PRDSV_ACE_VISTASOLVE','SI_HTTP_OUTBOUND_DETAILS.URL.VISTASOLVE_ACE','60',null,null,null,null,null,null,null,'ACE Vista Solve','hsabat',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--02/06/2014 AP Added entries for FRS-378
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values
 ('SI_SV_VEHSV_EVEHORDFOR','SI_HTTP_OUTBOUND_DETAILS.URL.EVEHORDFOR','120',null,null,null,null,null,null,null,'Updated vehicle order forecast to XML Gateway','apathak2',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
 
 --05/03/2014 Naresh CH added entry for FRS 090
 
 Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_ALL_VEHICLE_ALL_PUBVEHDESC','SI_HTTP_OUTBOUND_DETAILS.URL.VEH_DESC_BRS','20',null,null,null,null,null,null,null,'Entry for Vehicle Desc to VISTA','nch',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
 
 Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_ALL_VEHICLE_ALL_PUBVEHDESC','SI_HTTP_OUTBOUND_DETAILS.URL.VEH_DESC_BRS','20',null,null,null,null,null,null,null,'Entry for Vehicle Desc to VISTA','nch',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

 
 --19/03/2014 AK added entry for FRS 093
 Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_PRDSV_BOMVAL','SI_HTTP_OUTBOUND_DETAILS.URL.BOM_FEAT_VAL','120',null,null,null,null,null,null,null,'ACE Get BOM Validation Service','akarma',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
 
--NM on 27/03/2014 added entry for IA-207
--AP on 07/05/2014 added wsl value IFU-1910
--LH on 02/06/2016 changed BSID from SI_BS_ALL_VEHSERV_ALL_MVRISREG to SI_BS_ALL_VEHSERV_ALL_VEHREGIS and removed entry with BSID SI_BS_ALL_VEHSERV_ALL_AFRLREG for IFU3924 framework migration
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_ALL_VEHSERV_ALL_VEHREGIS','SI_HTTP_OUTBOUND_DETAILS.URL.VEHICLE_REGISTRATION',null,null,null,null,null,null,null,null,'Registrations Capture Data from MVRIS','nmithari','SI_HTTP_OUTBOUND_DETAILS.WSL.WSLSTRING_BROKER2' ,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
--INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_ALL_VEHSERV_ALL_AFRLREG','SI_HTTP_OUTBOUND_DETAILS.URL.VEHICLE_REGISTRATION',null,null,null,null,null,null,null,null,'Registrations Capture Data from AFRLREG','nmithari','SI_HTTP_OUTBOUND_DETAILS.WSL.WSLSTRING_BROKER2' ,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

-- HA 15/04/2014 Entries for FRS 277.
-- HA 02/05/2014 Removed an entry for CJLR URL
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_VEHSV_ADVSHPNT','SI_HTTP_OUTBOUND_DETAILS.URL.ASN_PROV_JVBRIDGE','40',null,null,null,null,null,null,null,'URL for sending messages to JV-Bridge','havhale',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_VEHSV_ADVSHPNT_EVNTSCHD','SI_HTTP_OUTBOUND_DETAILS.URL.ASN_PROV_EVNTSCHD','40',null,null,null,null,null,null,null,'URL for sending messages to the Event Scheduler','havhale',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

-- SK 25/04/2014 added queries for FRS 371
--AP  22/05/2014 WSL string added
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_VEHSV_MANUFSTAT','SI_HTTP_OUTBOUND_DETAILS.URL.VEHMANUFSTAT','120', null, null, null,  null, 'POST', null, null,'Vehicle Manufacturing Status to D42 ','skarri', 'SI_HTTP_OUTBOUND_DETAILS.WSL.WSLSTRING_BROKER2','SI_HTTP_OUTBOUND_DETAILS.BROKER2','N' );

-- NM 07/05/2014 added queries for FRS 372
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_VEHSV_VEHDSTST','SI_HTTP_OUTBOUND_DETAILS.URL.VEHICLE_DISTRIBUTION','120', null, null, null,  null, 'POST', null, null,'Vehicle Distribution  Status to CJLR ','nmithari', null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N' );

-- PVH 15/04/2014 Entries for FRS 282
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_VEHSV_TRNFWDPT','SI_HTTP_OUTBOUND_DETAILS.URL.FWDPARTSTAT_JVBRIDGE','40',null,null,null,null,null,null,null,'URL for sending messages to JV-Bridge','pvonhirs',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_VEHSV_TRNFWDPT_EVNTSCHD','SI_HTTP_OUTBOUND_DETAILS.URL.FWDPARTSTAT_EVNTSCHD','40',null,null,null,null,null,null,null,'URL for sending messages to the Event Scheduler','pvonhirs',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--NM 22/05/2014 added entry for  IA-000005
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_BS_VISTA_VEHICLE_ALL_GOF','SI_HTTP_OUTBOUND_DETAILS.URL.VISTA_GOF_CJLR','120', null, null, null,  null, 'POST', null, null,'Vehicle GOF feed to CJLR application via XML Gateway','nmithari', null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N' );

--SK added entries for FRS-278
--MJ Changed timeout value for CJLR as per IFU-3813
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_INVSV_VEHPARTINV','SI_HTTP_OUTBOUND_DETAILS.URL.ICS_VInPart_JVBRIDGE','40',null,null,null,null,null,null,null,'URL for sending messages to JV-Bridge','skarri',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_INVSV_VEHPARTINV_CJLR','SI_HTTP_OUTBOUND_DETAILS.URL.ICS_VehInvPart_CJLR','120',null,null,null,null,null,null,null,'URL for sending messages to CJLR','skarri',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_INVSV_VEHPARTINV_EVNTSCHD','SI_HTTP_OUTBOUND_DETAILS.URL.ICS_VInPart_EVNTSCHD','40',null,null,null,null,null,null,null,'URL for sending messages to the Event Scheduler','skarri',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

-- NM 14/04/2017 Moved FRS-367 entries to SI_Components location as per new build process.
-- PVH 27/05/2014 Entry for FRS 367
--INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_BRS_VEHICLE_CJLR_DERIVFEAT','SI_HTTP_OUTBOUND_DETAILS.URL.DERIVFEATDELTAFEED','40',null,null,null,null,null,null,null,'URL for sending messages to CJLR','pvonhirs',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--SK 26/05/2014 Added entries for FRS-281
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_MISCSV_LDPLNTCLNDR','SI_HTTP_OUTBOUND_DETAILS.URL.PlntcalenderJVBRIDGE','40',null,null,null,null,null,null,null,'URL for sending messages to JV-Bridge','skarri',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_MISCSV_LDPLNTCLNDR_EVNTSCHD','SI_HTTP_OUTBOUND_DETAILS.URL.PlntcalenderEVNTSCHD','40',null,null,null,null,null,null,null,'URL for sending messages to the Event Scheduler','skarri',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--  21/04/2017 AT Removed entries As part of IFU4590 
-- GT 10/07/2014 Added entries for FRS-138
--INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_REPVEHDERV','SI_HTTP_OUTBOUND_DETAILS.URL.REPVEHDERIV','40',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','gthamma',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

-- TK 24/07/2014 Added entries for FRS-141
-- NS 03/02/2017 Updated Timeout from 40 sec to 60 sec for FRS-141
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CTUPVEHOWN_SF_VEHACC','SI_HTTP_OUTBOUND_DETAILS.URL.CTUPVEHOWN','60',null,null,null,null,null,null,null,'URL for sending messages to SVCRM','tksheers',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--AP 12/08/2014 Added entries for FRS-272
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_VEHSV_TDPARTS','SI_HTTP_OUTBOUND_DETAILS.URL.VEHTDPARTS',null,null,null,null,null,null,null,null,'Vehicle Parts Service','apathak2',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

-- SM :19/08/2014 SM Updated entries for FRS-628
 Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_SAP_TRBGB_VEHICLE_GCM_FREDMAINT','SI_HTTP_OUTBOUND_DETAILS.URL.GCM_FREDMAINT','30',null,null,null,null,null,null,null,'Warranty FRED Update to GCM','smuley',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
 
 -- SB 21/08/2014 Added entries for FRS-137
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CTUPVHCL','SI_HTTP_OUTBOUND_DETAILS.URL.CRTUPDVEHICLE','60',null,null,null,null,null,null,null,'FRS-00137 - URL for sending messages to SAP CRM','sbabu4',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--TK 21/08/2013 Added entries for FRS-143
--SK 17/01/2017 IFU4364 :Updated timeout for FRS-143 from '30' to '60'
--VB 30/06/2017 IFU4755 :Updated timeout for FRS-143 from '60' to '180'
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_SENDWRTCON','SI_HTTP_OUTBOUND_DETAILS.URL.CONSENDWRT','180',null,null,null,null,null,null,null,'URL for sending Warranty Contract  messages to SVCRM','vbordia',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_SENDWRTCON_ACCT','SI_HTTP_OUTBOUND_DETAILS.URL.ACCTSENDWRTCON','180',null,null,null,null,null,null,null,'URL for sending Warranty Contract  Account messages to SVCRM','vbordia',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_SENDWRTCON_SF_VEHACC','SI_HTTP_OUTBOUND_DETAILS.URL.VEHACCSENDWRTCON','180',null,null,null,null,null,null,null,'URL for sending Warranty Contract  Vehicle Account Relate messages to SVCRM','vbordia',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

 --AP 22/08/2014 Added entries for FRS-273
 -- VK 02/05/2017 Removed entries after framework migration of FRS-273.
-- INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_VEHSV_TDDEMANDUPD','SI_HTTP_OUTBOUND_DETAILS.URL.TDDEMANDUPD',null,null,null,null,null,null,null,null,'Trading Division Parts Demand Update Service Service','apathak2',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--AP 22/08/2014 Added entries for FRS-371/IA-09
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_VEHSV_PUBFINSTAT','SI_HTTP_OUTBOUND_DETAILS.URL.MANFSTATUS',null,null,null,null,null,null,null,null,'Vehicle Manufacturing Parts Service','apathak2',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

-- 25/11/2014 NC  Added entries for FRS-000090(SI_FL_Product,IFU2310,2497)
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) 
VALUES ('SI_BS_ACE_PRODUCT_ALL_VEHSPECDES','SI_HTTP_OUTBOUND_DETAILS.URL.VEHSPECDES',null,null,null,null,null,null,null,null,'Entry for Vehicle Desc to VISTA','nch',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

-- 16/09/2014 SG  Added entries for FRS-000136(R2.0)
-- Entries for AVO OSH
--IFU4565:Commented below entries as the OSH is no more required
/* INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) 
VALUES ('SI_SV_CUSSV_REPAVO_OSH','SI_HTTP_OUTBOUND_DETAILS.URL.REPAVOOSH',null,null,null,null,null,null,null,null,'Entry for Replicate AVO OSH','sgoswam1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) 
VALUES ('SI_SV_CUSSV_REPAVO_OSH','SI_HTTP_OUTBOUND_DETAILS.URL.REPAVOOSH',null,null,null,null,null,null,null,null,'Entry for Replicate AVO OSH','sgoswam1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N'); */

-- Entries for AVO OCCAM
--28/04/2017 AT Updated TIMEOUT to 120 for INC000002190079.
--IFU4845:Updated timeout for OCCAM from 120 to 300 seconds
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) 
VALUES ('SI_SV_CUSSV_REPAVO_OCCAM','SI_HTTP_OUTBOUND_DETAILS.URL.REPAVOOCCAM','300',null,null,null,null,null,null,null,'Entry for Replicate AVO OCCAM','sgoswam1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) 
VALUES ('SI_SV_CUSSV_REPAVO_OCCAM','SI_HTTP_OUTBOUND_DETAILS.URL.REPAVOOCCAM','300',null,null,null,null,null,null,null,'Entry for Replicate AVO OCCAM','sgoswam1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--IFU4565:Commented below entries as the OSH is no more required
-- Entries for VVO OSH
/* INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) 
VALUES ('SI_SV_CUSSV_REPVVO_OSH','SI_HTTP_OUTBOUND_DETAILS.URL.REPVVOOSH',null,null,null,null,null,null,null,null,'Entry for Replicate VVO OSH','sgoswam1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) 
VALUES ('SI_SV_CUSSV_REPVVO_OSH','SI_HTTP_OUTBOUND_DETAILS.URL.REPVVOOSH',null,null,null,null,null,null,null,null,'Entry for Replicate VVO OSH','sgoswam1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N'); */

-- Entries for VVO OCCAM
--28/04/2017 AT Updated TIMEOUT to 120 for INC000002190079.
--IFU4845:Updated timeout for OCCAM from 120 to 300 seconds
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) 
VALUES ('SI_SV_CUSSV_REPVVO_OCCAM','SI_HTTP_OUTBOUND_DETAILS.URL.REPVVOOCCAM','300',null,null,null,null,null,null,null,'Entry for Replicate VVO OCCAM','sgoswam1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) 
VALUES ('SI_SV_CUSSV_REPVVO_OCCAM','SI_HTTP_OUTBOUND_DETAILS.URL.REPVVOOCCAM','300',null,null,null,null,null,null,null,'Entry for Replicate VVO OCCAM','sgoswam1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--25/05/2017 SK IFU4533: Added entries for VVO SAPVMS for FRS-136
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) 
VALUES('SI_SV_CUSSV_REPVVO_SAPVMS','SI_HTTP_OUTBOUND_DETAILS.URL.REPVVOSAPVMS','120',null,null,null,null,null,null,null,'Entry for Replicate VVO SAPVMS','skumari4',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) 
VALUES('SI_SV_CUSSV_REPVVO_SAPVMS','SI_HTTP_OUTBOUND_DETAILS.URL.REPVVOSAPVMS','120',null,null,null,null,null,null,null,'Entry for Replicate VVO SAPVMS','skumari4',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

-- 18/09/2014 AK Entries for FS 382-2B
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) 
VALUES ('SI_BS_SAP_TRBGB_VEHICLE_CJLR_WTYCLAIM','SI_HTTP_OUTBOUND_DETAILS.URL.RPLCLM_TO_CJLR','120',null,null,null,null,null,null,null,'FRS-000382 Warranty Claims to CJLR','akarma',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) 
VALUES ('SI_BS_SAP_TRBGB_VEHICLE_CJLR_WTYCLAIM','SI_HTTP_OUTBOUND_DETAILS.URL.RPLCLM_TO_CJLR','120',null,null,null,null,null,null,null,'FRS-000382 Warranty Claims to CJLR','akarma',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

-- 21/10/2014 AC Added entry  for FRS 657
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL)
 VALUES ('SI_BS_CJLR_RETPRTCLM','SI_HTTP_OUTBOUND_DETAILS.URL.PARTCLAIM','120',null,null,null,null,null,null,null,'URL for sending messages to SWORD','achaudha','SI_HTTP_OUTBOUND_DETAILS.WSL.PARTCLAIM','SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL)
 VALUES ('SI_BS_CJLR_RETPRTCLM','SI_HTTP_OUTBOUND_DETAILS.URL.PARTCLAIM','120',null,null,null,null,null,null,null,'URL for sending messages to SWORD','achaudha','SI_HTTP_OUTBOUND_DETAILS.WSL.PARTCLAIM','SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');


INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL)
 VALUES ('SI_BS_SWORD_RETPRTSUPD','SI_HTTP_OUTBOUND_DETAILS.URL.PARTUPDATE','120',null,null,null,null,null,null,null,'URL for sending messages to CJLR','achaudha',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL)
 VALUES ('SI_BS_SWORD_RETPRTSUPD','SI_HTTP_OUTBOUND_DETAILS.URL.PARTUPDATE','120',null,null,null,null,null,null,null,'URL for sending messages to CJLR','achaudha',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

-- 02/12/2014 - AMW Adding entries for FRS-115
-- IFU3084 TK 02/06/2015 Updated timeout for FRS 115
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_CUSSV_REPLEADPSP_SHIFTDIGITAL','SI_HTTP_OUTBOUND_DETAILS.URL.REPLEAD_SHIFTDIGITAL','SI_HTTP_OUTBOUND_DETAILS.TIMEOUT.REPLEAD_SHIFTDIGITAL',null,null,null,null,null,null,null,'Entry for Replicate Lead to ShiftDigital','amoseley',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_CUSSV_REPLEADPSP_OCCAM','SI_HTTP_OUTBOUND_DETAILS.URL.REPLEAD_OCCAM','SI_HTTP_OUTBOUND_DETAILS.TIMEOUT.REPLEAD_OCCAM',null,null,null,null,null,null,null,			'Entry for Replicate Lead to OCCAM','amoseley',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_CUSSV_REPLEADPSP_ENQUIRYMAX','SI_HTTP_OUTBOUND_DETAILS.URL.REPLEAD_ENQUIRYMAX','SI_HTTP_OUTBOUND_DETAILS.TIMEOUT.REPLEAD_ENQUIRYMAX',null,null,null,null,null,null,null,'Entry for Replicate Lead to EnquiryMax','amoseley',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_CUSSV_REPLEADPSP_SHIFTDIGITAL','SI_HTTP_OUTBOUND_DETAILS.URL.REPLEAD_SHIFTDIGITAL','SI_HTTP_OUTBOUND_DETAILS.TIMEOUT.REPLEAD_SHIFTDIGITAL',null,null,null,null,null,null,null,'Entry for Replicate Lead to ShiftDigital','amoseley',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_CUSSV_REPLEADPSP_OCCAM','SI_HTTP_OUTBOUND_DETAILS.URL.REPLEAD_OCCAM','SI_HTTP_OUTBOUND_DETAILS.TIMEOUT.REPLEAD_OCCAM',null,null,null,null,null,null,null,'Entry for Replicate Lead to OCCAM','amoseley',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_CUSSV_REPLEADPSP_ENQUIRYMAX','SI_HTTP_OUTBOUND_DETAILS.URL.REPLEAD_ENQUIRYMAX','SI_HTTP_OUTBOUND_DETAILS.TIMEOUT.REPLEAD_ENQUIRYMAX',null,null,null,null,null,null,null,'Entry for Replicate Lead to EnquiryMax','amoseley',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--12/03/2015 AaP Updated the key to VSAVEHPROPDTA from VEHPROPDTAVSA to avoid the build conflict with VEHPROPDTA
-- 10/12/2014 AaP Added entry  for FRS-003
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL)
 VALUES ('SI_SV_VEHSV_PRODCTRL_VSA','SI_HTTP_OUTBOUND_DETAILS.URL.VSAVEHPROPDTA','20',null,null,null,null,null,null,null,'Prod Ctrl tuprofile to VSA application','apanjiya',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL)
 VALUES ('SI_SV_VEHSV_PRODCTRL_VSA','SI_HTTP_OUTBOUND_DETAILS.URL.VSAVEHPROPDTA','20',null,null,null,null,null,null,null,'Prod Ctrl tuprofile to VSA application','apanjiya',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

-- 19/12/2014 HA FRS 643 Vehicle Appraisal
-- 21/01/2015 HA FRS 643 IFU 2674 WSL entry added
-- 20/01/2015 AP FRS-643 Timeoutvalue changed to 120 sec
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) 
	VALUES ('SI_SV_MOBSV_VEHICLEAPPRAISAL','SI_HTTP_OUTBOUND_DETAILS.URL.VEHICLE_APPRAISAL','120',null,null,null,null,null,null,null,'FRS-000643 Vehicle Appraisal.URL for FMS','havhale','SI_HTTP_OUTBOUND_DETAILS.WSL.VEH_APR_BROKER2','SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

-- SB 24/02/2015 Added entries for FRS-148
-- VH 30/11/2017 TIMEOUT value changed from 180 to 300 for FRS-148 for IFU5115
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_REPVEHPLAN','SI_HTTP_OUTBOUND_DETAILS.URL.REPVEHPLAN','300',null,null,null,null,null,null,null,'URL for sending messages to SAP CRM','sbabu4',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');	

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_REPVEHPLAN','SI_HTTP_OUTBOUND_DETAILS.URL.REPVEHPLAN','300',null,null,null,null,null,null,null,'URL for sending messages to SAP CRM','sbabu4',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');	
	
-- KS 24/02/2015 Added entries for FRS-147
-- VH 09/06/2017 TIMEOUT value changed from 40 to 180 for FRS-147
-- VB 04/12/2017 IFU5120:Updated time-out from 180 to 300 seconds
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_REPVEHSTATUS','SI_HTTP_OUTBOUND_DETAILS.URL.REPVEHSTATUS','300',null,null,null,null,null,null,null,'URL for sending messages to SAP CRM','ksarma',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');	
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_REPVEHSTATUS','SI_HTTP_OUTBOUND_DETAILS.URL.REPVEHSTATUS','300',null,null,null,null,null,null,null,'URL for sending messages to SAP CRM','ksarma',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');	

-- AB 11/03/2015 Added entries for FRS-137
-- NS 06/01/2017 timeout updated  for IFU4353
-- AT 01/12/2017 Timeout updated 180 to 300 As part oF IFU IFU5116
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CTUPVHCL_SIMP','SI_HTTP_OUTBOUND_DETAILS.URL.CRTUPDVEHSMPBATCH','300',null,null,null,null,null,null,null,'FRS-00137 SIMP- URL for sending messages to SAP CRM','abasak',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');	
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CTUPVHCL_SIMP','SI_HTTP_OUTBOUND_DETAILS.URL.CRTUPDVEHSMPBATCH','300',null,null,null,null,null,null,null,'FRS-00137 SIMP- URL for sending messages to SAP CRM','abasak',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');	

--	NC 20/03/2015 added entries for FRS000023	
-- 15/04/2015 PK Corrected entries for FRS000023(IFU 2807)
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) 
VALUES ('SI_BS_ENOV_PRODUCT_SAP_TRBGB_COMPTOOLRQ','SI_HTTP_OUTBOUND_DETAILS.URL.COMPTOOLRQ','120',null,null,null,null,null,null,null,'Component Tooling Requests','pkhot',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');	

-- 14/04/2015 SA Added entry for FRS 352	
-- 13/06/2016 NM INC000001411381 Updated the timeout value for web service call Call ESB service - SI_SV_VEHSV_MANUFSTAT
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) 
VALUES ('SI_BS_PLO_VEH_CJLR_VEHSTS_D42','SI_HTTP_OUTBOUND_DETAILS.URL.VEHORDREQD42','180',null,null,null,null,null,null,null,'External Vehicle Order Requests','sanupoj2',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');	
	
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) 
VALUES ('SI_BS_PLO_VEH_CJLR_VEHSTS_D42','SI_HTTP_OUTBOUND_DETAILS.URL.VEHORDREQD42','180',null,null,null,null,null,null,null,'External Vehicle Order Requests','sanupoj2',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

-- 23/04/2015 AaP Added entry for FRS 673	
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) 
VALUES ('SI_BS_SAP_TRBGB_TD_VEH_CJLR_PROVASN','SI_HTTP_OUTBOUND_DETAILS.URL.PrvASN','120',null,null,null,null,null,null,null,'FRS-000673 SAP TD to CJLR','apanjiya',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');	
	
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) 
VALUES ('SI_BS_SAP_TRBGB_TD_VEH_CJLR_PROVASN','SI_HTTP_OUTBOUND_DETAILS.URL.PrvASN','120',null,null,null,null,null,null,null,'FRS-000673 SAP TD to CJLR','apanjiya',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

-- 07/05/2015 VP Added entry for IA-000005
-- 20/05/2015 MJ Added timeout under IA-000005 as per IFU 3040
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) 
VALUES ('SI_BS_VISTA_VEHICLE_LNDAR_GOF','SI_HTTP_OUTBOUND_DETAILS.URL.VistaToLndar','20',null,null,null,null,null,null,null,'IA-000005 Vehicle GOF feed to LANDAR application via XML Gateway','vprasad1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) 
VALUES ('SI_BS_VISTA_VEHICLE_LNDAR_GOF','SI_HTTP_OUTBOUND_DETAILS.URL.VistaToLndar','20',null,null,null,null,null,null,null,'IA-000005 Vehicle GOF feed to LANDAR application via XML Gateway','vprasad1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');


--26/05/2015 PM Added entry for FRS-000712
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,DESCRIPTION,USER_ID,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_BS_MATFL_VEHICLE_GXS_PARTREQ','SI_HTTP_OUTBOUND_DETAILS.URL.MATFLVEHGXSPART','Material Flow Full Pallet Pick to GXS','pmondal','SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,DESCRIPTION,USER_ID,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_BS_MATFL_VEHICLE_GXS_PARTREQ','SI_HTTP_OUTBOUND_DETAILS.URL.MATFLVEHGXSPART','Material Flow Full Pallet Pick to GXS','pmondal','SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--26/05/2015 VB Added entry for FRS-000111 as per IFU3019
--10/08/2015 AB Updated  BUSINESS_SERVICE_NAME for FRS-000111 to sync with design
Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_AFRL_CUSSV_SVCRM_GETACCTDTLS','SI_HTTP_OUTBOUND_DETAILS.URL.AFRL_GETACCTDTLS','40',null,null,null,null,null,null,null,'URL for sending messages to SAP CRM','vbordia',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_AFRL_CUSSV_SVCRM_GETACCTDTLS','SI_HTTP_OUTBOUND_DETAILS.URL.AFRL_GETACCTDTLS','40',null,null,null,null,null,null,null,'URL for sending messages to SAP CRM','vbordia',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
	
-- VP FRS674 initial entry
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,	REQUEST_URL,	TIMEOUT,	PROXY_URL,	REQUEST_URI,	HTTP_VERSION,	KEEP_ALIVE,	METHOD,	SSL_PROTOCOL,	SSL_CIPHERS,	DESCRIPTION,	USER_ID,	WSL_STRING,	BROKER_NAME,	PERSIST_PAYLOAD_IN_URL) values ('SI_BS_SAP_TRBGB_CUSTOMER_CJLR_CUSTINVOIC',	'SI_HTTP_OUTBOUND_DETAILS.URL.CustomerInvoice',	'120',	null,	null,	null,	null,	null,	null,	null,	'Customer Invoice details to XML Gateway',	'vprasad1',	null,	'SI_HTTP_OUTBOUND_DETAILS.BROKER1',	'N');

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,	REQUEST_URL,	TIMEOUT,	PROXY_URL,	REQUEST_URI,	HTTP_VERSION,	KEEP_ALIVE,	METHOD,	SSL_PROTOCOL,	SSL_CIPHERS,	DESCRIPTION,	USER_ID,	WSL_STRING,	BROKER_NAME,	PERSIST_PAYLOAD_IN_URL) values ('SI_BS_SAP_TRBGB_CUSTOMER_CJLR_CUSTINVOIC',	'SI_HTTP_OUTBOUND_DETAILS.URL.CustomerInvoice',	'120',	null,	null,	null,	null,	null,	null,	null,	'Customer Invoice details to XML Gateway',	'vprasad1',	null,	'SI_HTTP_OUTBOUND_DETAILS.BROKER2',	'N');

-- VV FRS718 initial entry
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_BS_MES_VEHICLE_SAP_TRBBR_PLNORDCONF','SI_HTTP_OUTBOUND_DETAILS.URL.MESVEHSTATUS','20',null,null,null,null,'POST',null,null,'MES Vehicle Status Message to D42','vvivekan','TBC','SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_BS_MES_VEHICLE_SAP_TRBBR_PLNORDCONF','SI_HTTP_OUTBOUND_DETAILS.URL.MESVEHSTATUS','20',null,null,null,null,'POST',null,null,'MES Vehicle Status Message to D42','vvivekan','TBC','SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--09/10/2013 SK Adding entry for FRS-000273
--09/11/2015 VP Modified timeout for FRS-000273
--02/05/2017 VK Removed entries after framework migration of FRS-273.
-- INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_VEHSV_DEMANDUPD','SI_HTTP_OUTBOUND_DETAILS.URL.VEHPRTDMDUPD','300', null, null, null,  null, null, null, null,'JV-Bridge Service entry for Demand Interface ','skarri', null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N' );
-- INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_SV_VEHSV_DEMANDUPD','SI_HTTP_OUTBOUND_DETAILS.URL.VEHPRTDMDUPD','300', null, null, null,  null, null, null, null,'JV-Bridge Service entry for Demand Interface ','skarri', null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N' );

-- 	:13/11/2015 SB Added entries for Vehicle Genealogy To Multiple Systems(FRS-000003)
 INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_BS_MES_QUALITY_ALL_VEHGENEALOGY_VSA','SI_HTTP_OUTBOUND_DETAILS.URL.VSAVEHPROPDTA','20',null,null,null,null,null,null,null,'URL for Vehicle Genealogy','sbabu4',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
 
 INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_BS_MES_QUALITY_ALL_VEHGENEALOGY_VSA','SI_HTTP_OUTBOUND_DETAILS.URL.VSAVEHPROPDTA','20',null,null,null,null,null,null,null,'URL for Vehicle Genealogy','sbabu4',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

 -- 	:03/03/2016 KV Added entries for FRS-000653
 -- 	:13/06/2016 LH Removed entries for IFU 3948 as Topix sub and Topix security are no more used
/* 
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_SECSV_TRUSTCENTRES_TOPIX_SEC','SI_HTTP_OUTBOUND_DETAILS.URL.GETSECTOPIXDETAILS','120',null,null,null,null,null,null,null,'URL for sending messages to TOPIX','kkorlam',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
									  
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_SECSV_TRUSTCENTRES_TOPIX_SEC','SI_HTTP_OUTBOUND_DETAILS.URL.GETSECTOPIXDETAILS','120',null,null,null,null,null,null,null,'URL for sending messages to TOPIX','kkorlam',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_SECSV_TRUSTCENTRES_TOPIX_SUB','SI_HTTP_OUTBOUND_DETAILS.URL.GETSUBTOPIXDETAILS','120',null,null,null,null,null,null,null,'URL for sending messages to TOPIX','kkorlam',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
									  
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_SECSV_TRUSTCENTRES_TOPIX_SUB','SI_HTTP_OUTBOUND_DETAILS.URL.GETSUBTOPIXDETAILS','120',null,null,null,null,null,null,null,'URL for sending messages to TOPIX','kkorlam',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
 */
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_SECSV_TRUSTCENTRES_ALOA','SI_HTTP_OUTBOUND_DETAILS.URL.GETALOADETAILS','120',null,null,null,null,null,null,null,'URL for sending messages to ALOA','kkorlam',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_SECSV_TRUSTCENTRES_ALOA','SI_HTTP_OUTBOUND_DETAILS.URL.GETALOADETAILS','120',null,null,null,null,null,null,null,'URL for sending messages to ALOA','kkorlam',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_SECSV_SECURITYNF','SI_HTTP_OUTBOUND_DETAILS.URL.GETNICBDETAILS','120',null,null,null,null,null,null,null,'URL for sending messages to NICB','kkorlam',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values  ('SI_SV_SECSV_SECURITYNF','SI_HTTP_OUTBOUND_DETAILS.URL.GETNICBDETAILS','120',null,null,null,null,null,null,null,'URL for sending messages to NICB','kkorlam',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
									  
 

 -- 	:02/06/2016 KV Added entries for FRS-000130/IFU3888(OCRM)
 INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_CANON_DEALER_OCRM_REPLICTEDR','SI_HTTP_OUTBOUND_DETAILS.URL.GETOCRMDETAILS','120',null,null,null,null,null,null,null,'URL for sending messages to OCRM','kkorlam',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
									  
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_CANON_DEALER_OCRM_REPLICTEDR','SI_HTTP_OUTBOUND_DETAILS.URL.GETOCRMDETAILS','120',null,null,null,null,null,null,null,'URL for sending messages to OCRM','kkorlam',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--			:08/06/2016	ANA Added entries for FRS-000151
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_CANON_PRODUCT_SVCRM_PRODREF','SI_HTTP_OUTBOUND_DETAILS.URL.CAN_PRODUCT_SVCRM_FC','60',null,null,null,null,null,null,null,'ZcrmBrandSymphonyFeatCode','aadeney1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_CANON_PRODUCT_SVCRM_PRODREF','SI_HTTP_OUTBOUND_DETAILS.URL.CAN_PRODUCT_SVCRM_FC','60',null,null,null,null,null,null,null,'ZcrmBrandSymphonyFeatCode','aadeney1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_CANON_PRODUCT_SVCRM_PRODREF','SI_HTTP_OUTBOUND_DETAILS.URL.CAN_PRODUCT_SVCRM_FD','60',null,null,null,null,null,null,null,'ZcrmBrandSymphonyFeatDerv','aadeney1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_CANON_PRODUCT_SVCRM_PRODREF','SI_HTTP_OUTBOUND_DETAILS.URL.CAN_PRODUCT_SVCRM_FD','60',null,null,null,null,null,null,null,'ZcrmBrandSymphonyFeatDerv','aadeney1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N'); 

 -- 	:27/06/2016 AT Added entries for FRS-000107/IFU3897(OCRM)
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_OCRM_ORDERREPL','SI_HTTP_OUTBOUND_DETAILS.URL.GETOCRMURL','120',null,null,null,null,null,null,null,'URL for sending UpsertVistaOrders message to OCRM','atatar',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_OCRM_ORDERREPL','SI_HTTP_OUTBOUND_DETAILS.URL.GETOCRMURL','120',null,null,null,null,null,null,null,'URL for sending UpsertVistaOrders message to OCRM','atatar',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

-- 	:12/07/2016 RBH Added entries for FRS-000151/IFU3942(OCRM)
-- 	:08/08/2016 KV Updated Timeout to 120 Secs for FRS-000151/IFU4071(OCRM)
INSERT INTO WMBOWNER.SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_CANON_PRODUCT_OCRM_PRODREF','SI_HTTP_OUTBOUND_DETAILS.URL.CAN_PRODREF_OCRM','120',null,null,null,null,null,null,null,'Feature Code and Derivative request to OCRM','rbhamid1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
INSERT INTO WMBOWNER.SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_CANON_PRODUCT_OCRM_PRODREF','SI_HTTP_OUTBOUND_DETAILS.URL.CAN_PRODREF_OCRM','120',null,null,null,null,null,null,null,'Feature Code and Derivative request to OCRM','rbhamid1',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

-- 28/07/2016 NB: Added New http outbound details for FRS-000371(IFU3928)
-- 03/08/2016 NB: Updated entries for FRS-000371(IFU3928) 
-- 20/10/2016 NB Added new cookies for FRS-371(NEW) IFU4199
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_BS_PGZ_VEHICLE_D42_MANUFACSTATUS','SI_HTTP_OUTBOUND_DETAILS.URL.PGZ_VEH_D42_MSTATUS','120', null, null, null,  null, 'POST', null, null,'Vehicle Manufacturing Status from Plant Graz to D42','nbarma', 'SI_HTTP_OUTBOUND_DETAILS.WSL.PGZD42STATUS_BROKER1','SI_HTTP_OUTBOUND_DETAILS.BROKER1','N' );

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_BS_PGZ_VEHICLE_D42_MANUFACSTATUS','SI_HTTP_OUTBOUND_DETAILS.URL.PGZ_VEH_D42_MSTATUS','120', null, null, null,  null, 'POST', null, null,'Vehicle Manufacturing Status from Plant Graz to D42','nbarma', 'SI_HTTP_OUTBOUND_DETAILS.WSL.PGZD42STATUS_BROKER2','SI_HTTP_OUTBOUND_DETAILS.BROKER2','N' );

---- 06/10/2016 SK: Updated entries for FRS-000154(IFU4148)

Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CTUPACTVTY_ACTV','SI_HTTP_OUTBOUND_DETAILS.URL.CTUPACTVTY','60',null,null,null,null,null,null,null,'URL for sending messages to SAP CRM','skumari4',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CTUPACTVTY_ACTV','SI_HTTP_OUTBOUND_DETAILS.URL.CTUPACTVTY','60',null,null,null,null,null,null,null,'URL for sending messages to SAP CRM','skumari4',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--23/10/2016 HB Added New entry for FRS 790
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_BS_SAP_ESM_VEHICLE_LMS_VEHUPDATES','SI_HTTP_OUTBOUND_DETAILS.URL.SAPToLMS','120', null, null, null,  null, null, null, null,'Vehicle updates to LMS via XML Gateway','hborate', null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N' );

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_BS_SAP_ESM_VEHICLE_LMS_VEHUPDATES','SI_HTTP_OUTBOUND_DETAILS.URL.SAPToLMS','120', null, null, null,  null, null, null, null,'Vehicle updates to LMS via XML Gateway','hborate', null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N' );


--24/11/2016 VVS Added New entries for FRS-155 As per the IFU4236
--VVS:IFU5149:Updated the back end time outs for FRS155 60 to 180 seconds as per the IFU

--CrtUpd Account SAP CRM (SF_AcctCrtUpd_SVCRMV2)

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CRTUPDAPPNT_SF_ACCT','SI_HTTP_OUTBOUND_DETAILS.URL.GETCRTACCTURL','180',null,null,null,null,null,null,null,'FRS-000155 -URL for sending messages to CrtUpd Account SAP CRM','vteki',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
									  
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CRTUPDAPPNT_SF_ACCT','SI_HTTP_OUTBOUND_DETAILS.URL.GETCRTACCTURL','180',null,null,null,null,null,null,null,'FRS-000155 -URL for sending messages to CrtUpd Account SAP CRM','vteki',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');


--CrtUpd Appointment SAP CRM (SF_AppointmentCrtUpd_SVCRM)
--VVS:IFU5149:Updated the back end time outs for FRS155 60 to 180 seconds as per the IFU

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CRTUPDAPPNT_SF_APPT','SI_HTTP_OUTBOUND_DETAILS.URL.GETCRTAPPTURL','180',null,null,null,null,null,null,null,'FRS-000155 -URL for sending messages to CrtUpd Appointment SAP CRM','vteki',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
									  
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CRTUPDAPPNT_SF_APPT','SI_HTTP_OUTBOUND_DETAILS.URL.GETCRTAPPTURL','180',null,null,null,null,null,null,null,'FRS-000155 -URL for sending messages to CrtUpd Appointment SAP CRM','vteki',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');


--CrtUpd Veh Account Relationship SAP CRM (SF_VehicleAccountRelationship_CreateUpdate)
--VVS:IFU5149:Updated the back end time outs for FRS155 60 to 180 seconds as per the IFU

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CRTUPDAPPNT_SF_VEHACC','SI_HTTP_OUTBOUND_DETAILS.URL.GETCRTVELACCTRELURL','180',null,null,null,null,null,null,null,'FRS-00155 -URL for sending messages to CrtUpd Veh Account Relationship SAP CRM','vteki',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
									  
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CRTUPDAPPNT_SF_VEHACC','SI_HTTP_OUTBOUND_DETAILS.URL.GETCRTVELACCTRELURL','180',null,null,null,null,null,null,null,'FRS-00155 -URL for sending messages to CrtUpd Veh Account Relationship SAP CRM','vteki',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');


--06/12/2016 AT Added New entries for FRS-153 As per the IFU4255
--SF_CampaignCrtUpd_SVCRMV2

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CMPGNCRTUPD','SI_HTTP_OUTBOUND_DETAILS.URL.GETCMPGNCRTUPDURL','60',null,null,null,null,null,null,null,'FRS-000153 -URL for sending messages to CampaignCrtUpd SAP CRM','athota',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
									  
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CMPGNCRTUPD','SI_HTTP_OUTBOUND_DETAILS.URL.GETCMPGNCRTUPDURL','60',null,null,null,null,null,null,null,'FRS-000153 -URL for sending messages to CampaignCrtUpd SAP CRM','athota',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');


-- AT Added url details for flow SI_SV_CreateUpdate_Activity FRS-000154-IFU4275
-- AB Updated key from CTUPACTVTY_ACCT to CRTUPDTACTVTY_ACCT
-- --04/05/2017: SK IFU4604 Commented previous FRS-154 URL details for old backend for 'SI_SV_CUSSV_CTUPACTVTY_ACCT'
/*Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CTUPACTVTY_ACCT','SI_HTTP_OUTBOUND_DETAILS.URL.CRTUPDTACTVTY_ACCT','60',null,null,null,null,null,null,null,'URL for sending messages to SAP CRM','abasak',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CTUPACTVTY_ACCT','SI_HTTP_OUTBOUND_DETAILS.URL.CRTUPDTACTVTY_ACCT','60',null,null,null,null,null,null,null,'URL for sending messages to SAP CRM','abasak',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');*/

--04/05/2017: SK IFU4604 Updated URL Details for FRS-154 newly added AccountContacts backend() replacing previous Account backend
--05/05/2017 SK IFU4604 Updated URL details,with CRTUPDACTY_ACCTCONT,replaced previous key

Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CTUPACTVTY_ACCTCONT','SI_HTTP_OUTBOUND_DETAILS.URL.CRTUPDACTY_ACCTCONT','60',null,null,null,null,null,null,null,'URL for sending messages to SAP CRM','skumari4',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

Insert into SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_SV_CUSSV_CTUPACTVTY_ACCTCONT','SI_HTTP_OUTBOUND_DETAILS.URL.CRTUPDACTY_ACCTCONT','60',null,null,null,null,null,null,null,'URL for sending messages to SAP CRM','skumari4',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

--16/12/2016 MJ Added WSL entries for FRS-841
--06/01/2017 MJ Updated WSL entries for FRS-841
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_BS_AFRL_VEHICLE_ESB_LISTPRICE','NA','10', null, null, null,  null, 'GET', null, null,'Entry for ListPrice feed to AFRL','mjeevart', 'SI_HTTP_OUTBOUND_DETAILS.WSL.SETLISTPRICE_BROKER1','SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_BS_AFRL_VEHICLE_ESB_LISTPRICE','NA','10', null, null, null,  null, 'GET', null, null,'Entry for ListPrice feed to AFRL','mjeevart', 'SI_HTTP_OUTBOUND_DETAILS.WSL.SETLISTPRICE_BROKER2','SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_BS_ESB_VEHICLE_AFRL_LISTPRICE','NA','10', null, null, null,  null, 'GET', null, null,'Entry for ListPrice feed to AFRL','mjeevart', 'SI_HTTP_OUTBOUND_DETAILS.WSL.SETLISTPRICE_BROKER1','SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) VALUES ('SI_BS_ESB_VEHICLE_AFRL_LISTPRICE','NA','10', null, null, null,  null, 'GET', null, null,'Entry for ListPrice feed to AFRL','mjeevart', 'SI_HTTP_OUTBOUND_DETAILS.WSL.SETLISTPRICE_BROKER2','SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

-- 30/01/2017 CD Added entries for IFU4373
-- 21/02/2017 KB updated URL FRS817 IFU4443

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_PLO_VEHICLE_PGZ_ORDER','SI_HTTP_OUTBOUND_DETAILS.URL.CCA_STATUS_VISTA','20',null,null,null,null,null,null,null,'Manufacturing Orders under status CCA from PLO to VISTA','cdeshpan','SI_HTTP_OUTBOUND_DETAILS.WSL.WSLSTRING_BROKER1','SI_HTTP_OUTBOUND_DETAILS.BROKER1','Y');

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_PLO_VEHICLE_PGZ_ORDER','SI_HTTP_OUTBOUND_DETAILS.URL.CCA_STATUS_VISTA','20',null,null,null,null,null,null,null,'Manufacturing Orders under status CCA from PLO to VISTA','cdeshpan','SI_HTTP_OUTBOUND_DETAILS.WSL.WSLSTRING_BROKER2','SI_HTTP_OUTBOUND_DETAILS.BROKER2','Y');


-- 15/03/2017 MJ updated FRS-107 entries as per IFU4438

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL,X_API_KEY,AUTHORIZATION) values ('SI_BS_VISTA_CUSSV_XROAD_ORDERREPL','SI_HTTP_OUTBOUND_DETAILS.URL.VISTAXROAD','180',null,null,null,null,null,null,null,'Order Replicate from Vista to XROAD','mjeevart',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N','SI_HTTP_OUTBOUND_DETAILS.X_API_KEY.VISTAXROAD','SI_HTTP_OUTBOUND_DETAILS.AUTHORIZATION.VISTAXROAD');

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL,X_API_KEY,AUTHORIZATION) values ('SI_BS_VISTA_CUSSV_XROAD_ORDERREPL','SI_HTTP_OUTBOUND_DETAILS.URL.VISTAXROAD','180',null,null,null,null,null,null,null,'Order Replicate from Vista to XROAD','mjeevart',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N','SI_HTTP_OUTBOUND_DETAILS.X_API_KEY.VISTAXROAD','SI_HTTP_OUTBOUND_DETAILS.AUTHORIZATION.VISTAXROAD');

-- 11/04/2017 KB Added entries for FRS258 IFU4561 for SI_BS_PGZ_VEHICLE_WLCAR_PRODCTRL
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_PGZ_VEHICLE_WLCAR_PRODCTRL','SI_HTTP_OUTBOUND_DETAILS.URL.PRODCTR.VEHPROPDTA','180',null,null,null,null,null,null,null,'PGZ VCATS to Production Control service','kbhosale',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N');
									  
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL) values ('SI_BS_PGZ_VEHICLE_WLCAR_PRODCTRL','SI_HTTP_OUTBOUND_DETAILS.URL.PRODCTR.VEHPROPDTA','180',null,null,null,null,null,null,null,'PGZ VCATS to Production Control service','kbhosale',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N');

-- 11/04/2017 MJ updated FRS-107 entries as per IFU4515
-- 05/05/2017 MJ Updated method for NNG service as per defect-2
-- 22/05/2017 MJ Updated method for HERE service as per defect-4
INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL,X_API_KEY,AUTHORIZATION) values ('SI_BS_VISTA_CUSSV_MAPSUP_GOF_HERE','SI_HTTP_OUTBOUND_DETAILS.URL.MAPSUPPHERE','120',null,null,null,null,'PUT',null,null,'GOF from VISTA to HERE','mjeevart',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N',null,null);

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL,X_API_KEY,AUTHORIZATION) values ('SI_BS_VISTA_CUSSV_MAPSUP_GOF_HERE','SI_HTTP_OUTBOUND_DETAILS.URL.MAPSUPPHERE','120',null,null,null,null,'PUT',null,null,'GOF from VISTA to HERE','mjeevart',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N',null,null);

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL,X_API_KEY,AUTHORIZATION) values ('SI_BS_VISTA_CUSSV_MAPSUP_GOF_NNG','SI_HTTP_OUTBOUND_DETAILS.URL.MAPSUPPNNG','120',null,null,null,null,'PUT',null,null,'GOF from VISTA to NNG','mjeevart',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N',null,null);

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL,X_API_KEY,AUTHORIZATION) values ('SI_BS_VISTA_CUSSV_MAPSUP_GOF_NNG','SI_HTTP_OUTBOUND_DETAILS.URL.MAPSUPPNNG','120',null,null,null,null,'PUT',null,null,'GOF from VISTA to NNG','mjeevart',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N',null,null);

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL,X_API_KEY,AUTHORIZATION) values ('SI_BS_VISTA_CUSSV_MAPSUP_GOF_AUTONAVI','SI_HTTP_OUTBOUND_DETAILS.URL.MAPSUPPAUTONAVI','120',null,null,null,null,null,null,null,'GOF from VISTA to AUTONAVI','mjeevart',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N',null,null);

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL,X_API_KEY,AUTHORIZATION) values ('SI_BS_VISTA_CUSSV_MAPSUP_GOF_AUTONAVI','SI_HTTP_OUTBOUND_DETAILS.URL.MAPSUPPAUTONAVI','120',null,null,null,null,null,null,null,'GOF from VISTA to AUTONAVI','mjeevart',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N',null,null);


-- 14/04/2017 MJ updated FRS-259 entries as per IFU4514
-- 28/04/2017 MJ updated entries for FRS-259 as per port nos in FRS
-- 10/04/2017 MJ Defect-3 Updated new BSID entries for different services

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL,X_API_KEY,AUTHORIZATION) values ('SI_BS_PLO_VEHICLE_ALL_VEHMAPPROP_HERE','SI_HTTP_OUTBOUND_DETAILS.URL.VEHMAPPROPHERE','120',null,null,null,null,null,null,null,'Vehicle Map Properties to HERE of the Map Supplier application','mjeevart',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N',null,null);

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL,X_API_KEY,AUTHORIZATION) values ('SI_BS_PLO_VEHICLE_ALL_VEHMAPPROP_HERE','SI_HTTP_OUTBOUND_DETAILS.URL.VEHMAPPROPHERE','120',null,null,null,null,null,null,null,'Vehicle Map Properties to HERE of the Map Supplier application','mjeevart',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N',null,null);

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL,X_API_KEY,AUTHORIZATION) values ('SI_BS_PLO_VEHICLE_ALL_VEHMAPPROP_NNG','SI_HTTP_OUTBOUND_DETAILS.URL.VEHMAPPROPNNG','120',null,null,null,null,null,null,null,'Vehicle Map Properties to NNG of the Map Supplier application','mjeevart',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N',null,null);

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL,X_API_KEY,AUTHORIZATION) values ('SI_BS_PLO_VEHICLE_ALL_VEHMAPPROP_NNG','SI_HTTP_OUTBOUND_DETAILS.URL.VEHMAPPROPNNG','120',null,null,null,null,null,null,null,'Vehicle Map Properties to NNG of the Map Supplier application','mjeevart',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N',null,null);

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL,X_API_KEY,AUTHORIZATION) values ('SI_BS_PLO_VEHICLE_ALL_VEHMAPPROP_AUTO_CR','SI_HTTP_OUTBOUND_DETAILS.URL.VEHMAPPROPAUTONAVI','120',null,null,null,null,null,null,null,'Vehicle Map Properties to CreateVehicle of the Map Supplier application','mjeevart',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N',null,null);

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL,X_API_KEY,AUTHORIZATION) values ('SI_BS_PLO_VEHICLE_ALL_VEHMAPPROP_AUTO_CR','SI_HTTP_OUTBOUND_DETAILS.URL.VEHMAPPROPAUTONAVI','120',null,null,null,null,null,null,null,'Vehicle Map Properties to CreateVehicle of the Map Supplier application','mjeevart',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N',null,null);

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL,X_API_KEY,AUTHORIZATION) values ('SI_BS_PLO_VEHICLE_ALL_VEHMAPPROP_AUTO_UP','SI_HTTP_OUTBOUND_DETAILS.URL.VEHMAPPROPUPDAUTO','120',null,null,null,null,null,null,null,'Vehicle Map Properties to UpdateVehicle of the Map Supplier application','mjeevart',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER1','N',null,null);

INSERT INTO SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME,REQUEST_URL,TIMEOUT,PROXY_URL,REQUEST_URI,HTTP_VERSION,KEEP_ALIVE,METHOD,SSL_PROTOCOL,SSL_CIPHERS,DESCRIPTION,USER_ID,WSL_STRING,BROKER_NAME,PERSIST_PAYLOAD_IN_URL,X_API_KEY,AUTHORIZATION) values ('SI_BS_PLO_VEHICLE_ALL_VEHMAPPROP_AUTO_UP','SI_HTTP_OUTBOUND_DETAILS.URL.VEHMAPPROPUPDAUTO','120',null,null,null,null,null,null,null,'Vehicle Map Properties to UpdateVehicle of the Map Supplier application','mjeevart',null,'SI_HTTP_OUTBOUND_DETAILS.BROKER2','N',null,null);

COMMIT;