--------------------------------------------------------------------------------------------------------
-- Author 		: Seenesh Patel
-- Version 		: $Revision: 1.8 $
-- Description 	: Create table script for SI_HTTP_OUTBOUND_DETAILS table which will hold details of runtime overrides used by the HTTP Outbound adapter
-- History 		: 14/06/2012 Initial create statement for table
-- 				: 27/06/2012 Modified so that BUSINESS_SERVICE_NAME is no longer primary key
-- 				: 14/08/2012 Hina Mistry Addition of user id, insert/update timestamp columns 
-- 				: 17/11/2012 Ryan Glackin Addition of Broker and WSL columns 
--				: 02/01/2013 Kenny McCormack - Added PERSIST_PAYLOAD_IN_URL as per requirement for IA 27 interface to VISTA
-- 						 to store the payload of the message in the URL. See defect 1891
--				: 06/03/2017 Sanjay Bawri - Added columns X_API_KEY and CREDENTIALS as per requirement for FRS-000107 XROAD Feed (IFU4438)
--				: 22/05/2018 Aman Chibber - Modified columns REQUEST_URL to increase the size from 200 to 300.
-------------------------------------------------------------------------------------------------------

DROP TABLE SI_HTTP_OUTBOUND_DETAILS;

CREATE TABLE SI_HTTP_OUTBOUND_DETAILS (BUSINESS_SERVICE_NAME VARCHAR2(40) NOT NULL,
					REQUEST_URL VARCHAR2(200) NOT NULL,
					TIMEOUT VARCHAR2(5),
					PROXY_URL VARCHAR2(200),
					REQUEST_URI VARCHAR2(100),
					HTTP_VERSION VARCHAR2(5),
					KEEP_ALIVE VARCHAR2(5),
					METHOD VARCHAR2(10),
					SSL_PROTOCOL VARCHAR2(10),
					SSL_CIPHERS VARCHAR2(200),
					DESCRIPTION VARCHAR2(100));

ALTER TABLE SI_HTTP_OUTBOUND_DETAILS ADD USER_ID VARCHAR2(10) NOT NULL;
ALTER TABLE SI_HTTP_OUTBOUND_DETAILS ADD INSERT_TIMESTAMP TIMESTAMP;
ALTER TABLE SI_HTTP_OUTBOUND_DETAILS ADD UPDATE_TIMESTAMP TIMESTAMP;	
ALTER TABLE SI_HTTP_OUTBOUND_DETAILS ADD WSL_STRING VARCHAR2(500);
ALTER TABLE SI_HTTP_OUTBOUND_DETAILS ADD BROKER_NAME VARCHAR2(8) NOT NULL;
ALTER TABLE SI_HTTP_OUTBOUND_DETAILS ADD PERSIST_PAYLOAD_IN_URL VARCHAR2(1) NOT NULL;
ALTER TABLE SI_HTTP_OUTBOUND_DETAILS ADD X_API_KEY VARCHAR2(20);
ALTER TABLE SI_HTTP_OUTBOUND_DETAILS ADD AUTHORIZATION VARCHAR2(60);
ALTER TABLE SI_HTTP_OUTBOUND_DETAILS MODIFY REQUEST_URL VARCHAR2(300);  
COMMIT;
