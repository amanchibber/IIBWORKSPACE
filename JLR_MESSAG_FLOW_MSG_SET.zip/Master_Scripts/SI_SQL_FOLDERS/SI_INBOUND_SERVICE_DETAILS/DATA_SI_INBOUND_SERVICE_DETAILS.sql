------------------------------------------------------------------------------------------------------------------------
-- Author 		: Clive Marrett
-- Version 		: $Revision: 1.4 $
-- Description 	: Insert table script for SI_INBOUND_SERVICE_DETAILS table which will hold BAPI service lookup records
-- History 		: 28/06/2013 Clive Marrett Initial create statement for table
------------------------------------------------------------------------------------------------------------------------
DELETE FROM SI_INBOUND_SERVICE_DETAILS;

-- IA-000070
INSERT INTO SI_INBOUND_SERVICE_DETAILS (ID,SYSTEM_IDENTIFIER,MESSAGE_TYPE,SERVICE_DETAIL_FIELD,EFFECTIVE_FROM_DATE,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID) VALUES (SI_INSERV_DET_ID.NEXTVAL,'SAP_ESMALL_BAPI','SapZfiF110XmlToEsbWrapper','SapZfiF110XmlToEsb.BUKRS','01-JUL-2013',null,null,'cmarrett');
INSERT INTO SI_INBOUND_SERVICE_DETAILS (ID,SYSTEM_IDENTIFIER,MESSAGE_TYPE,SERVICE_DETAIL_FIELD,EFFECTIVE_FROM_DATE,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID) VALUES (SI_INSERV_DET_ID.NEXTVAL,'SAP_SMTCN_BAPI','SapZfiF110XmlToEsbWrapper','SapZfiF110XmlToEsb.BUKRS','01-JUL-2013',null,null,'cmarrett');

--AaP 18/03/2016 IFU3579 Entry added for routing of BAPI SapZfmTmsF110SapToEsbWrapper
INSERT INTO SI_INBOUND_SERVICE_DETAILS (ID,SYSTEM_IDENTIFIER,MESSAGE_TYPE,SERVICE_DETAIL_FIELD,EFFECTIVE_FROM_DATE,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID) VALUES (SI_INSERV_DET_ID.NEXTVAL,'SAP_SMTCN_BAPI','SapZfmTmsF110SapToEsbWrapper','SapZfmTmsF110SapToEsb.BUKRS','01-JUL-2013',null,null,'apanjiya');
COMMIT;
