--------------------------------------------------------------------------------------------------------
-- Author 		: Clive Marrett
-- Version 		: $Revision: 1.1 $
-- Description 	: Create sequence script for SI_INBOUND_SERVICE_DETAILS table which will hold INBOUND LOOKUP data.
-- History 		: 28/06/2013 Clive Marrett Initial create statement for sequence
--------------------------------------------------------------------------------------------------------

DROP SEQUENCE SI_INSERV_DET_ID;

--Sequence to generate the EXCEPTION_ID value		
CREATE SEQUENCE SI_INSERV_DET_ID
MINVALUE 1
START WITH 1
INCREMENT BY 1
CACHE 10;
