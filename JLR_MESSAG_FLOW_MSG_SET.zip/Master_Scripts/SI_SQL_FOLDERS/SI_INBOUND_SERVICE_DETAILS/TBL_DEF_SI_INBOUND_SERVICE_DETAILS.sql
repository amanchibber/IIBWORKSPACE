------------------------------------------------------------------------------------------------------------------------
-- Author 		: Clive Marrett
-- Version 		: $Revision: 1.1 $
-- Description 	: Create table script for SI_INBOUND_SERVICE_DETAILS table which will hold BAPI Header lookup records
-- History 		: 28/06/2013 Clive Marrett Initial create statement for table
------------------------------------------------------------------------------------------------------------------------

DROP TABLE SI_INBOUND_SERVICE_DETAILS;			   
							   
CREATE TABLE SI_INBOUND_SERVICE_DETAILS (ID NUMBER(10) NOT NULL,
							SYSTEM_IDENTIFIER VARCHAR2(15) NOT NULL,
							MESSAGE_TYPE VARCHAR2(48) NOT NULL, 
							SERVICE_DETAIL_FIELD VARCHAR2(48) NOT NULL,
							EFFECTIVE_FROM_DATE DATE NOT NULL,
							INSERT_TIMESTAMP TIMESTAMP,
							UPDATE_TIMESTAMP TIMESTAMP,
							USER_ID VARCHAR2(10),
							CONSTRAINT PK_SI_IN_SERV_DET_ID PRIMARY KEY (ID));
COMMIT;
