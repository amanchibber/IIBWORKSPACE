--------------------------------------------------------------------------------------------------------
-- Author 		: Seenesh Patel
-- Version 		: $Revision: 1.2 $
-- Description 	: Create data script for SI_JLR_ERROR_CODES table which will hold details JLR Common Error Codes
-- History 		: 16/07/2012 Initial script
--------------------------------------------------------------------------------------------------------

DELETE FROM SI_JLR_ERROR_CODES;

-- Added to prevent prompt when inserting due to &
SET DEFINE OFF;

INSERT INTO SI_JLR_ERROR_CODES (ERROR_CODE,ERROR_TYPE,ERROR_DESCRIPTION,USER_ID,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values ('JLR0001-0001','Technical Error','Technical error has occurred','spatel5',null,null);			
INSERT INTO SI_JLR_ERROR_CODES (ERROR_CODE,ERROR_TYPE,ERROR_DESCRIPTION,USER_ID,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values ('JLR0001-0002','Timeout Error','Request has timed out','spatel5',null,null);			
INSERT INTO SI_JLR_ERROR_CODES (ERROR_CODE,ERROR_TYPE,ERROR_DESCRIPTION,USER_ID,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values ('JLR0001-0003','Authentication Error','The request has failed authentication check','spatel5',null,null);
INSERT INTO SI_JLR_ERROR_CODES (ERROR_CODE,ERROR_TYPE,ERROR_DESCRIPTION,USER_ID,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values ('JLR0001-0004','Connection Error','Connection cannot be made','spatel5',null,null);
INSERT INTO SI_JLR_ERROR_CODES (ERROR_CODE,ERROR_TYPE,ERROR_DESCRIPTION,USER_ID,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values ('JLR0001-0005','Validation Error','Request was invalid','spatel5',null,null);
INSERT INTO SI_JLR_ERROR_CODES (ERROR_CODE,ERROR_TYPE,ERROR_DESCRIPTION,USER_ID,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values ('JLR0001-0006','Transformation Error','Transformation of the data has failed','spatel5',null,null);
INSERT INTO SI_JLR_ERROR_CODES (ERROR_CODE,ERROR_TYPE,ERROR_DESCRIPTION,USER_ID,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values ('JLR0001-0007','Business Error','The request cannot be completed due to a business error','spatel5',null,null);
INSERT INTO SI_JLR_ERROR_CODES (ERROR_CODE,ERROR_TYPE,ERROR_DESCRIPTION,USER_ID,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values ('JLR0001-0008','Underlying Service Error','The request cannot be completed due to an underlying service error','spatel5',null,null);

COMMIT;