--------------------------------------------------------------------------------------------------------
-- Author 		: Seenesh Patel
-- Version 		: $Revision: 1.1 $
-- Description 	: Create table script for SI_JLR_ERROR_CODES table
-- History 		: 16/07/2012 Initial create statement for table
-------------------------------------------------------------------------------------------------------

DROP TABLE SI_JLR_ERROR_CODES;

CREATE TABLE SI_JLR_ERROR_CODES (ERROR_CODE VARCHAR2(20) NOT NULL,
					ERROR_TYPE VARCHAR2(30) NOT NULL,
					ERROR_DESCRIPTION VARCHAR2(100) NOT NULL,
					USER_ID VARCHAR(10) NOT NULL,
					INSERT_TIMESTAMP TIMESTAMP,
					UPDATE_TIMESTAMP TIMESTAMP);
   
COMMIT;