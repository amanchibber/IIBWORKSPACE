--------------------------------------------------------------------------------------------------------------------------
-- Author 		: Chandrasekhar Gundlapalli
-- Version 		: $Revision: 1.2 $
-- Description 	: Create data script for SI_JLR_MARKETS table which will hold routing information
-- History 		: 30/10/2012 Chandrasekhar Gundlapalli Initial creation of master scripts
--				: 26/11/2012 SP - Processing flag for Belgium set to N instead of Y as initial market will be Germany only
--------------------------------------------------------------------------------------------------------------------------
DELETE FROM SI_JLR_MARKETS;
--30/10/2012 CG Entries for interface: SI_BS_WVTA_Homologation_To_SAP_ESM.msgflow
SET DEFINE OFF;
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('AUSTRIA', 'AK', 'AT', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('BELGIUM', 'BD', 'BE', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('BULGARIA', 'BN', 'BG', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('CANARIES', 'null', 'CB', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('SWITZERLAND', 'null', 'CH', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('CROATIA', 'null', 'CT', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('CYPRUS', 'CS', 'CY', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('CZECH REPUBLIC', 'CT', 'CZ', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('GERMANY', 'GK', 'DE', 'Y');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('DENMARK', 'DB', 'DK', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('ESTONIA', 'null', 'EE', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('FINLAND', 'FD', 'FI', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('FRANCE', 'FF', 'FR', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('UNITED KINGDOM', 'UB', 'GB', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('GIBRALTAR', 'GT', 'GI', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('GUADELOUPE', 'null', 'GP', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('GREECE', 'GF', 'GR', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('CROATIA', 'null', 'HR', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('HUNGARY', 'HG', 'HU', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('INDIA', 'IC', 'null', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('IRELAND', 'IG', 'IE', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('ISRAEL', 'IH', 'IL', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('ICELAND', 'null', 'IS', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('ITALY', 'IJ', 'IT', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('LITHUANIA', 'null', 'LT', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('LATVIA', 'null', 'LV', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('LUXEMBOURG', 'LF', 'null', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('MACEDONIA', 'null', 'MK', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('MALTA', 'MC', 'MT', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('NETHERLANDS', 'NB', 'NL', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('NORWAY', 'NQ', 'NO', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('POLAND', 'PG', 'PL', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('PORTUGUESE', 'PH', 'PT', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('REUNION', 'null', 'RE', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('ROMANIA', 'RR', 'RO', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('SPAIN', 'SK', 'ES', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('SWEDEN', 'ST', 'SE', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('SLOVENIA', 'SF', 'SI', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('SLOVAK REPUBLIC', 'SW', 'SK', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('SWITZERLAND', 'SU', '-', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('TURKEY', 'TG', 'TR', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('Unknown -  Not Supported', 'UE', '-', 'N');
Insert into SI_JLR_MARKETS   (MARKET_DESC, JAG_CODE, LR_CODE, PROCESS) Values   ('UKRAINE', 'UK', '-', 'N');
COMMIT;

