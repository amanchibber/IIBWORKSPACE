--------------------------------------------------------------------------------------------------------
-- Author 		: Chandrasekhar Gundlapalli
-- Version 		: $Revision: 1.2 $
-- Description 	: Create table script for SI_JLR_MARKETS table which will hold details required
--				: by Business Service flows for mapping purposes
-- History 		: 30/10/2012  Chandrasekhar Gundlapalli Initial create statement for table

--------------------------------------------------------------------------------------------------------

DROP TABLE SI_JLR_MARKETS;

CREATE TABLE SI_JLR_MARKETS (    MARKET_DESC  VARCHAR2(50) NOT NULL, 
								 JAG_CODE     VARCHAR2(5), 
								 LR_CODE      VARCHAR2(5), 
								 PROCESS      VARCHAR2(2));
COMMIT;
