--------------------------------------------------------------------------------------------------------
-- Author 		: Andy Taylor
-- Version 		: $Revision: 1.5 $
-- Description 	: Create data script for SI_JOB_CONTROL table which will hold details required
--				  by the adapters for job control (e.g. mainframe JCL).
-- History 		: 01/03/2013 Andy Taylor Initial creation for test environment.
-- 			: 17/01/2014 HA Entries for FRS 353
--			: 10/11/2014 PG Added entries for FRS 382 Part 2B1 & 2D1
--                      : 10/02/2015 AC Changed entry for schid to SCHID IFU 2741
--------------------------------------------------------------------------------------------------------

Delete from SI_JOB_CONTROL;

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_SAP_TRBGB_INVCRDDETS_SFS', 'AFVF891O', 'Filename', 01, 'jcl.txt', null, null, 'rtaylor3');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_SAP_TRBGB_INVCRDDETS_SFS', 'AFVF891O', 'SiteCommand', 01, 'FILETYPE=JES', null, null, 'rtaylor3');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_SAP_TRBGB_INVCRDDETS_SFS', 'AFVF891O', 'ControlListLine', 01, '//AFVF891E JOB (''AFVF891E   003''),''EUROVAC ETT JOB'',', null, null, 'rtaylor3');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_SAP_TRBGB_INVCRDDETS_SFS', 'AFVF891O', 'ControlListLine', 02, '//         CLASS=L,MSGCLASS=X,', null, null, 'rtaylor3');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_SAP_TRBGB_INVCRDDETS_SFS', 'AFVF891O', 'ControlListLine', 03, '//    USER=POSTXMIT', null, null, 'rtaylor3');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_SAP_TRBGB_INVCRDDETS_SFS', 'AFVF891O', 'ControlListLine', 04, '//*', null, null, 'rtaylor3');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_SAP_TRBGB_INVCRDDETS_SFS', 'AFVF891O', 'ControlListLine', 05, '//*********************************************************************', null, null, 'rtaylor3');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_SAP_TRBGB_INVCRDDETS_SFS', 'AFVF891O', 'ControlListLine', 06, '//*   SAP / ESB to SFS - ETT JOB PRIOR TO FVF DAILY', null, null, 'rtaylor3');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_SAP_TRBGB_INVCRDDETS_SFS', 'AFVF891O', 'ControlListLine', 07, '//*********************************************************************', null, null, 'rtaylor3');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_SAP_TRBGB_INVCRDDETS_SFS', 'AFVF891O', 'ControlListLine', 08, '//*', null, null, 'rtaylor3');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_SAP_TRBGB_INVCRDDETS_SFS', 'AFVF891O', 'ControlListLine', 09, '//*********************************************************************', null, null, 'rtaylor3');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_SAP_TRBGB_INVCRDDETS_SFS', 'AFVF891O', 'ControlListLine', 10, '//*   TEST trigger job send', null, null, 'rtaylor3');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_SAP_TRBGB_INVCRDDETS_SFS', 'AFVF891O', 'ControlListLine', 11, '//*********************************************************************', null, null, 'rtaylor3');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_SAP_TRBGB_INVCRDDETS_SFS', 'AFVF891O', 'ControlListLine', 12, '//*', null, null, 'rtaylor3');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_SAP_TRBGB_INVCRDDETS_SFS', 'AFVF891O', 'ControlListLine', 13, '//*', null, null, 'rtaylor3');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_SAP_TRBGB_INVCRDDETS_SFS', 'AFVF891O', 'ControlListLine', 14, '//STEP010  EXEC PGM=IEFBR14', null, null, 'rtaylor3');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_SAP_TRBGB_INVCRDDETS_SFS', 'AFVF891O', 'ControlListLine', 15, '//DD1      DD   DUMMY,DCB=BLKSIZE=80', null, null, 'rtaylor3');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_SAP_TRBGB_INVCRDDETS_SFS', 'AFVF891O', 'ControlListLine', 16, '//*', null, null, 'rtaylor3');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_SAP_TRBGB_INVCRDDETS_SFS', 'AFVF891O', 'ControlListLine', 17, '//', null, null, 'rtaylor3');






-- 17/01/2014 HA Entries for FRS 353

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_GEMSL_VEHSERV_SAP_TRBGB_SPECWERS', 'WWMSLSLT', 'ControlListLine', 01, '//WWMSLSLT JOB (1,6070101,FOC-451),''GEMSL SOLVE PROCESS'',', null, null, 'havhale');


Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_GEMSL_VEHSERV_SAP_TRBGB_SPECWERS', 'WWMSLSLT', 'ControlListLine', 02, '//          MSGCLASS=M,USER=WWRSB01', null, null, 'havhale');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_GEMSL_VEHSERV_SAP_TRBGB_SPECWERS', 'WWMSLSLT', 'ControlListLine', 03, '//*MAIN FAILURE=CANCEL', null, null, 'havhale');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_GEMSL_VEHSERV_SAP_TRBGB_SPECWERS', 'WWMSLSLT', 'ControlListLine', 04, '//STEP1   EXEC UCC7TRLR,P=''INACT''', null, null, 'havhale');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_GEMSL_VEHSERV_SAP_TRBGB_SPECWERS', 'WWMSLSLT', 'ControlListLine', 05, '//SYSOUT   DD SYSOUT=*', null, null, 'havhale');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_GEMSL_VEHSERV_SAP_TRBGB_SPECWERS', 'WWMSLSLT', 'ControlListLine', 06, '//SYSUDUMP DD SYSOUT=*', null, null, 'havhale');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_GEMSL_VEHSERV_SAP_TRBGB_SPECWERS', 'WWMSLSLT', 'ControlListLine', 07, '//SYSIN    DD *', null, null, 'havhale');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_GEMSL_VEHSERV_SAP_TRBGB_SPECWERS', 'WWMSLSLT', 'ControlListLine', 08, '/LOGON', null, null, 'havhale');
--AaP IFU-2720/DEF11830 value updated to JOB_CONTROL_LINE_TEXT = DEMAND,JOB=WWMSLSL1,schid=001
-- AC IFU 2741 Changed entry for schid to SCHID
Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_GEMSL_VEHSERV_SAP_TRBGB_SPECWERS', 'WWMSLSLT', 'ControlListLine', 09, 'DEMAND,JOB=WWMSLSL1,SCHID=001', null, null, 'havhale');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_GEMSL_VEHSERV_SAP_TRBGB_SPECWERS', 'WWMSLSLT', 'ControlListLine', 10, '/LOGOFF', null, null, 'havhale');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_GEMSL_VEHSERV_SAP_TRBGB_SPECWERS', 'WWMSLSLT', 'ControlListLine', 11, '/*', null, null, 'havhale');

Insert into SI_JOB_CONTROL (BUSINESS_SERVICE_NAME, JOB_CONTROL_NAME, JOB_CONTROL_LINE_TYPE, JOB_CONTROL_LINE_NBR, JOB_CONTROL_LINE_TEXT, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID)
Values ('SI_BS_GEMSL_VEHSERV_SAP_TRBGB_SPECWERS', 'WWMSLSLT', 'ControlListLine', 12, '//', null, null, 'havhale');

-- PG Added entries for FRS 382 Part 2B1 & 2D1
-- For Gaces Paid Claims
insert into si_job_control (business_service_name,job_control_name,job_control_line_type,job_control_line_nbr,job_control_line_text,user_id) 
values ('SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','WTYCLMPAIDSYC1','ControlListLine','1','//BEAC2003  JOB  (1,50630,ITEKW),QAS,USER=BECA701,','pgupta3');

insert into si_job_control (business_service_name,job_control_name,job_control_line_type,job_control_line_nbr,job_control_line_text,user_id) 
values ('SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','WTYCLMPAIDSYC1','ControlListLine','2','//          MSGCLASS=N','pgupta3');

insert into si_job_control (business_service_name,job_control_name,job_control_line_type,job_control_line_nbr,job_control_line_text,user_id) 
values ('SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','WTYCLMPAIDSYC1','ControlListLine','3','//*MAIN FAILURE=CANCEL','pgupta3');

insert into si_job_control (business_service_name,job_control_name,job_control_line_type,job_control_line_nbr,job_control_line_text,user_id) 
values ('SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','WTYCLMPAIDSYC1','ControlListLine','4','//STEP1   EXEC UCC7TRLR,P=''INACT''','pgupta3');

insert into si_job_control (business_service_name,job_control_name,job_control_line_type,job_control_line_nbr,job_control_line_text,user_id) 
values ('SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','WTYCLMPAIDSYC1','ControlListLine','5','//SYSOUT   DD SYSOUT=*','pgupta3');

insert into si_job_control (business_service_name,job_control_name,job_control_line_type,job_control_line_nbr,job_control_line_text,user_id) 
values ('SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','WTYCLMPAIDSYC1','ControlListLine','6','//SYSUDUMP   DD SYSOUT=*','pgupta3');

insert into si_job_control (business_service_name,job_control_name,job_control_line_type,job_control_line_nbr,job_control_line_text,user_id) 
values ('SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','WTYCLMPAIDSYC1','ControlListLine','7','//SYSIN    DD *','pgupta3');

insert into si_job_control (business_service_name,job_control_name,job_control_line_type,job_control_line_nbr,job_control_line_text,user_id) 
values ('SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','WTYCLMPAIDSYC1','ControlListLine','8','/LOGON','pgupta3');

insert into si_job_control (business_service_name,job_control_name,job_control_line_type,job_control_line_nbr,job_control_line_text,user_id) 
values ('SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','WTYCLMPAIDSYC1','ControlListLine','9','DEMAND,JOB=BEAC2004','pgupta3');

insert into si_job_control (business_service_name,job_control_name,job_control_line_type,job_control_line_nbr,job_control_line_text,user_id) 
values ('SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','WTYCLMPAIDSYC1','ControlListLine','10','/LOGOFF','pgupta3');

insert into si_job_control (business_service_name,job_control_name,job_control_line_type,job_control_line_nbr,job_control_line_text,user_id) 
values ('SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','WTYCLMPAIDSYC1','ControlListLine','11','/*','pgupta3');

insert into si_job_control (business_service_name,job_control_name,job_control_line_type,job_control_line_nbr,job_control_line_text,user_id) 
values ('SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','WTYCLMPAIDSYC1','ControlListLine','12','//','pgupta3');

-- For Gaces unpaid Claims

insert into si_job_control (business_service_name,job_control_name,job_control_line_type,job_control_line_nbr,job_control_line_text,user_id) 
values ('SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','WTYCLMUNPAIDSYC1','ControlListLine','1','//BEAC2003  JOB  (1,50630,ITEKW),QAS,USER=BECA701,','pgupta3');

insert into si_job_control (business_service_name,job_control_name,job_control_line_type,job_control_line_nbr,job_control_line_text,user_id) 
values ('SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','WTYCLMUNPAIDSYC1','ControlListLine','2','//          MSGCLASS=N','pgupta3');

insert into si_job_control (business_service_name,job_control_name,job_control_line_type,job_control_line_nbr,job_control_line_text,user_id) 
values ('SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','WTYCLMUNPAIDSYC1','ControlListLine','3','//*MAIN FAILURE=CANCEL','pgupta3');

insert into si_job_control (business_service_name,job_control_name,job_control_line_type,job_control_line_nbr,job_control_line_text,user_id) 
values ('SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','WTYCLMUNPAIDSYC1','ControlListLine','4','//STEP1   EXEC UCC7TRLR,P=''INACT''','pgupta3');

insert into si_job_control (business_service_name,job_control_name,job_control_line_type,job_control_line_nbr,job_control_line_text,user_id) 
values ('SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','WTYCLMUNPAIDSYC1','ControlListLine','5','//SYSOUT   DD SYSOUT=*','pgupta3');

insert into si_job_control (business_service_name,job_control_name,job_control_line_type,job_control_line_nbr,job_control_line_text,user_id) 
values ('SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','WTYCLMUNPAIDSYC1','ControlListLine','6','//SYSUDUMP   DD SYSOUT=*','pgupta3');

insert into si_job_control (business_service_name,job_control_name,job_control_line_type,job_control_line_nbr,job_control_line_text,user_id) 
values ('SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','WTYCLMUNPAIDSYC1','ControlListLine','7','//SYSIN    DD *','pgupta3');

insert into si_job_control (business_service_name,job_control_name,job_control_line_type,job_control_line_nbr,job_control_line_text,user_id) 
values ('SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','WTYCLMUNPAIDSYC1','ControlListLine','8','/LOGON','pgupta3');

insert into si_job_control (business_service_name,job_control_name,job_control_line_type,job_control_line_nbr,job_control_line_text,user_id) 
values ('SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','WTYCLMUNPAIDSYC1','ControlListLine','9','DEMAND,JOB=BEAC2004','pgupta3');

insert into si_job_control (business_service_name,job_control_name,job_control_line_type,job_control_line_nbr,job_control_line_text,user_id) 
values ('SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','WTYCLMUNPAIDSYC1','ControlListLine','10','/LOGOFF','pgupta3');

insert into si_job_control (business_service_name,job_control_name,job_control_line_type,job_control_line_nbr,job_control_line_text,user_id) 
values ('SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','WTYCLMUNPAIDSYC1','ControlListLine','11','/*','pgupta3');

insert into si_job_control (business_service_name,job_control_name,job_control_line_type,job_control_line_nbr,job_control_line_text,user_id) 
values ('SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','WTYCLMUNPAIDSYC1','ControlListLine','12','//','pgupta3');

COMMIT;
