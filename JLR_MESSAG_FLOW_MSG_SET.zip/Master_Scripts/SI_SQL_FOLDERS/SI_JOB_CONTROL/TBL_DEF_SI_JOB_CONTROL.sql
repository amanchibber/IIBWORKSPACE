--------------------------------------------------------------------------------------------------------
-- Author 		: Andy Taylor
-- Version 		: $Revision: 1.1 $
-- Description 	: Create table script for SI_JOB_CONTROL table which will hold details required
--				  by the adapters for job control (e.g. mainframe JCL).
-- History 		: 01/03/2013 Andy Taylor Initial creation.
--------------------------------------------------------------------------------------------------------

DROP TABLE SI_JOB_CONTROL;

CREATE TABLE SI_JOB_CONTROL
(
BUSINESS_SERVICE_NAME VARCHAR2(45) NOT NULL,
JOB_CONTROL_NAME VARCHAR2(20) NOT NULL,
JOB_CONTROL_LINE_TYPE VARCHAR2(20) NOT NULL,
JOB_CONTROL_LINE_NBR NUMBER(5) NOT NULL,
JOB_CONTROL_LINE_TEXT VARCHAR2(80) NULL,
INSERT_TIMESTAMP TIMESTAMP NULL,
UPDATE_TIMESTAMP TIMESTAMP NULL,
USER_ID VARCHAR2(10) NOT NULL,
CONSTRAINT SI_JOB_CONTROL_PK PRIMARY KEY (BUSINESS_SERVICE_NAME,JOB_CONTROL_NAME,JOB_CONTROL_LINE_TYPE,JOB_CONTROL_LINE_NBR)
);

COMMIT;
