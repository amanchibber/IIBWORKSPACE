--------------------------------------------------------------------------------------------------------
-- Author 		: Kenny McCormack
-- Version 		: $Revision: 1.5 $
-- Description 	: Create index script for SI_MESSAGE_AUDIT table
-- History 		: 05/05/2014 Kenny McCormack Initial creation
--------------------------------------------------------------------------------------------------------

create index WMBOWNER.IDX_SI_MESSAGE_AUDIT_01 on WMBOWNER.SI_MESSAGE_AUDIT("BUSINESS_SERVICE_ID");
create index WMBOWNER.IDX_SI_MESSAGE_AUDIT_02 on WMBOWNER.SI_MESSAGE_AUDIT("BUSINESS_SERVICE_ID","INSERT_TIMESTAMP");
create index WMBOWNER.IDX_SI_MESSAGE_AUDIT_03 on WMBOWNER.SI_MESSAGE_AUDIT("BUSINESS_SERVICE_ID","MSG_RECIEVED_TIMESTAMP");
create index WMBOWNER.IDX_SI_MESSAGE_AUDIT_04 on WMBOWNER.SI_MESSAGE_AUDIT("MESSAGE_FLOW_NAME","INSERT_TIMESTAMP");
create index WMBOWNER.IDX_SI_MESSAGE_AUDIT_05 on WMBOWNER.SI_MESSAGE_AUDIT("MESSAGE_FLOW_NAME","MSG_RECIEVED_TIMESTAMP");
create index WMBOWNER.IDX_SI_MESSAGE_AUDIT_06 on WMBOWNER.SI_MESSAGE_AUDIT("BUSINESS_SERVICE_ID","INSERT_TIMESTAMP","BROKER_NAME");
create index WMBOWNER.IDX_SI_MESSAGE_AUDIT_07 on WMBOWNER.SI_MESSAGE_AUDIT("BUSINESS_SERVICE_ID","BROKER_NAME");