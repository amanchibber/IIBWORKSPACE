--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: $Revision: 1.1 $
-- Description 	: Create sequence script for table SI_MESSAGE_AUDIT table
-- History 		: 18/08/2011 Hina Mistry Initial create statement for sequence
--------------------------------------------------------------------------------------------------------

DROP SEQUENCE SI_AUDIT_ID;
		
--Sequence to generate the EXCEPTION_ID value		
CREATE SEQUENCE SI_AUDIT_ID
MINVALUE 1
START WITH 1
INCREMENT BY 1
CACHE 10;

