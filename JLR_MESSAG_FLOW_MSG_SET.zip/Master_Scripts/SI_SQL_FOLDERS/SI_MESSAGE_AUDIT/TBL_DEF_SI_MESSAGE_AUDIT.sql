--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: $Revision: 1.1 $
-- Description 	: Create table script for EBS_EXECEPTION_STORE table which will hold details for errors 
--				  generated in the integration layer
-- History 		: 22/07/2011 Hina Mistry Initial create statement for table and sequence
--				  27/02/2012 Hina Mistry Alteration to table to add additional column which will hold the Correlation ID from the MQMD
--				  13/04/2012 Hina Mistry Altering size of the business_service_id column
--------------------------------------------------------------------------------------------------------

DROP TABLE SI_MESSAGE_AUDIT;

CREATE TABLE SI_MESSAGE_AUDIT (AUDIT_ID NUMBER(10) NOT NULL, 
		BUSINESS_SERVICE_ID VARCHAR(35) NOT NULL, 
		MSG_RECIEVED_TIMESTAMP TIMESTAMP NOT NULL,
		MESSAGE_TYPE VARCHAR(20) NOT NULL, 
		MESSAGE_IDENTIFIER VARCHAR (500),
		MESSAGE_PAYLOAD CLOB NOT NULL, 
		MESSAGE_PAYLOAD_CCSID NUMBER(4), 
		BROKER_NAME VARCHAR(50) NOT NULL, 
		MESSAGE_FLOW_NAME VARCHAR(100) NOT NULL, 
		EXECUTION_GROUP_NAME VARCHAR(50) NOT NULL,
		INSERT_TIMESTAMP TIMESTAMP NULL,
		UPDATE_TIMESTAMP TIMESTAMP NULL,
		CONSTRAINT PK_SI_MSG_AUDIT PRIMARY KEY(AUDIT_ID));

--27/02/2012 HM Alteration to table to add additional column which will hold the Correlation ID from the MQMD
ALTER TABLE SI_MESSAGE_AUDIT ADD MESSAGE_CORRELATION_ID VARCHAR(60);

--13/04/2012 HM Business Service ID column - size alteration
ALTER TABLE SI_MESSAGE_AUDIT MODIFY BUSINESS_SERVICE_ID VARCHAR(45);

COMMIT;