--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: $Revision: 1.1 $
-- Description 	: Create trigger script for trigger on table SI_MESSAGE_AUDIT which will update the table
--				  with a insert timestamp when a row has been inserted 
-- History 		: 22/07/2011 Hina Mistry Initial create statement for trigger SI_MSGAUD_TMSTMP_TRG
--------------------------------------------------------------------------------------------------------

--Trigger which will insert or update the timestamp if an insert or update action occurs
CREATE OR REPLACE
TRIGGER SI_MSGAUD_TMSTMP_TRG
BEFORE INSERT OR UPDATE ON SI_MESSAGE_AUDIT
FOR EACH ROW
BEGIN

IF INSERTING THEN
	:new.INSERT_TIMESTAMP := systimestamp;
	:new.UPDATE_TIMESTAMP := NULL;
ELSE
	:new.UPDATE_TIMESTAMP := systimestamp;
  END IF;
END;
/
COMMIT;
