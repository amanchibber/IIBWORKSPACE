--------------------------------------------------------------------------------------------------------
-- Author 		: Paul Gregory
-- Version 		: $Revision: 1.1 $
-- Description 	: For Exception Admin we are adding a new column and setting a default for INTERFACE
-- History 		: 12/12/2014 Initial create statement for table
-------------------------------------------------------------------------------------------------------

-- NEW_TRANSACTION_UUID column is added to be used by replay web service
ALTER TABLE WMBOWNER.SI_MESSAGE_EXCEPTION ADD NEW_TRANSACTION_UUID VARCHAR2(36);

ALTER TABLE SI_MESSAGE_EXCEPTION  MODIFY ("INTERFACE" DEFAULT 'UNKNOWN');
	
