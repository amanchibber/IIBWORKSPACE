--------------------------------------------------------------------------------------------------------
-- Author 		: Paul Gregory
-- Version 		: $Revision: 1.1 $
-- Description 	: Create new index script for SI_MESSAGE_EXCEPTION table for use with Exception Admin
-- History 		: 01/04/2016 Paul Gregory Initial creation
--------------------------------------------------------------------------------------------------------

CREATE INDEX WMBOWNER.IDX_SI_MESSAGE_EXCEPTION_08 ON WMBOWNER.SI_MESSAGE_EXCEPTION("INTERFACE", "INSERT_TIMESTAMP") ; 
