--------------------------------------------------------------------------------------------------------
-- Author 		: Paul Gregory
-- Version 		: $Revision: 1.1 $
-- Description 		: Create sequence script for SI_MESSAGE_EXCEPTIONS table 
-- History 		: 02/01/2015 Paul Gregory
--------------------------------------------------------------------------------------------------------

DROP SEQUENCE SI_MSG_EXCPT_ID;

--Sequence to generate the EXCEPTION_ID value		
CREATE SEQUENCE SI_MSG_EXCPT_ID
MINVALUE 1
START WITH 1
INCREMENT BY 1 ;

