--------------------------------------------------------------------------------------------------------
-- Author 		: Paul Gregory
-- Version 		: $Revision: 1.1 $
-- Description 	: Create trigger script for SI_MESSAGE_EXCEPTION_CODE table  
-- History 		: 23/12/2014 Paul Gregory Initial create statement for trigger
--------------------------------------------------------------------------------------------------------

DROP TRIGGER SI_MSG_EXCPT_TRG;

--Trigger which will insert or update the timestamp if an insert or update action occurs
CREATE OR REPLACE
TRIGGER SI_MSG_EXCPT_TRG
BEFORE INSERT OR UPDATE ON SI_MESSAGE_EXCEPTION
FOR EACH ROW
BEGIN

IF INSERTING THEN
	:new.EXCEPTION_ID := SI_MSG_EXCPT_ID.nextval;
	:new.INSERT_TIMESTAMP := systimestamp;
	:new.UPDATE_TIMESTAMP := NULL;
ELSE
	:new.UPDATE_TIMESTAMP := systimestamp;
  END IF;
END;
/
COMMIT;
