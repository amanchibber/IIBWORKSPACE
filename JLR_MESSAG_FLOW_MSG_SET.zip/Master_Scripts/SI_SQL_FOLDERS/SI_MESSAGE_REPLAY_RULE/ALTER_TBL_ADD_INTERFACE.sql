--------------------------------------------------------------------------------------------------------
-- Author 		: Paul Gregory
-- Version 		: $Revision: 1.1 $
-- Description 	: Create table script for SI_MESSAGE_REPLAY_RULE table
-- History 		: 12/12/2014 Initial create statement for table
-------------------------------------------------------------------------------------------------------

alter table SI_MESSAGE_REPLAY_RULE add INTERFACE VARchar2(20) default 'ANY' NOT null;
	
