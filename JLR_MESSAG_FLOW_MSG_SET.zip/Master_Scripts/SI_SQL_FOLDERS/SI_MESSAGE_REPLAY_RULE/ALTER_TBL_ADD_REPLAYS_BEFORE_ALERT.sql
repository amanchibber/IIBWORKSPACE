--------------------------------------------------------------------------------------------------------
-- Author 		: Paul Gregory
-- Version 		: $Revision: 1.1 $
-- Description 	: Create table script for SI_MESSAGE_REPLAY_RULE table
-- History 		: 15/01/2015 Add column REPLAYS_BEFORE_ALERT to table
-------------------------------------------------------------------------------------------------------

alter table SI_MESSAGE_REPLAY_RULE add REPLAYS_BEFORE_ALERT INT default 0 NOT NULL;
	
