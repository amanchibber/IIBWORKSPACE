--------------------------------------------------------------------------------------------------------
-- Author 		: Ryan Glackin (RGLACKLI)
-- Version 		: 
-- Description 	: Create table script for SI_MESSAGE_SEQUENCE table which will hold batch records
-- History 		: 03/07/2012 RG (RGLACKLI) Initial create statement for table
-- 				: 10/07/2012 DT (DTHOMPS1) Updated to add additional Sequence Length Column to allow variable roll over (eg, 999 vs 9999)
--------------------------------------------------------------------------------------------------------

DROP TABLE SI_MESSAGE_SEQUENCE;

CREATE TABLE SI_MESSAGE_SEQUENCE (SYSTEM_IDENTIFIER VARCHAR2(20) NOT NULL,
							   BUSINESS_SERVICE_ID VARCHAR2(45), 
							   SEQUENCE NUMBER(10), 
							   APP_SEQ_NO VARCHAR2(20), 
							   BROKER VARCHAR2(8),
							   SEQ_LENGTH NUMBER(2), 
							   INSERT_TIMESTAMP TIMESTAMP (6), 
							   UPDATE_TIMESTAMP TIMESTAMP (6),
							   DESCRIPTION VARCHAR2(100),
							   CONSTRAINT SI_MESSAGE_SEQUENCE PRIMARY KEY (BUSINESS_SERVICE_ID, SEQUENCE, SYSTEM_IDENTIFIER));

ALTER TABLE SI_MESSAGE_SEQUENCE ADD USER_ID VARCHAR2(10) NOT NULL;

COMMIT;
