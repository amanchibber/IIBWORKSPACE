--------------------------------------------------------------------------------------------------------
-- Author 		: Paul Gregory
-- Version 		: $Revision: 1.1 $
-- Description 	: Create table script for SI_MESSAGE_WARNING table
-- History 		: 12/12/2014 Initial create statement for table
-------------------------------------------------------------------------------------------------------

DROP TABLE SI_MESSAGE_WARNING;

CREATE TABLE SI_MESSAGE_WARNING 

(WARNING_ID NUMBER(10) NOT NULL,
WARNING_CODE VARCHAR2(10) DEFAULT ('UNKNOWN') NOT NULL,
WARNING_MESSAGE CLOB,
BUSINESS_SERVICE_ID VARCHAR2(50),
STATUS VARCHAR2(1),
UPDATE_USER_ID VARCHAR2(50),
INSERT_TIMESTAMP TIMESTAMP NOT NULL,
UPDATE_TIMESTAMP TIMESTAMP ,
CONSTRAINT "SI_MSG_WARNG_PK" PRIMARY KEY ("WARNING_ID")) ;
