--------------------------------------------------------------------------------------------------------
-- Author 		: Srinivasarao Karri & Chandrasekhar  Gundlapalli
-- Version 		: $Revision: 1.2 $
-- Description 	: Create table script for SI_MQ_INBOUND_DETAILS table which will hold details 
--              : of runtime overrides used by the MQ inbound adapter
-- History 		: 28/02/2012 Srinivasarao/Chandrasekhar Initial create statement for table
-- 			  14/08/2012 Hina Mistry Altered column USER_ID to not nullable
--			  28/06/2013 Mike Arrowsmith - Added BUSINESS_SERVICE_ID optional column for incoming SOAP over MQ routing	
--------------------------------------------------------------------------------------------------------

DROP TABLE SI_MQ_INBOUND_DETAILS;

CREATE TABLE SI_MQ_INBOUND_DETAILS (SYSTEM_IDENTIFIER  VARCHAR2(20) NOT NULL,
				        HEADER_FIELD VARCHAR (255),
				        HEADER_VALUE VARCHAR(255),
				        QUEUE_NAME VARCHAR2 (48) NOT NULL,
				        MESSAGE_TRANSACTION VARCHAR(9),
				        MESSAGE_SEGMENTATION VARCHAR(3),
				        INSERT_TIMESTAMP TIMESTAMP(6),
				        UPDATE_TIMESTAMP TIMESTAMP(6),
		                	USER_ID VARCHAR(10),
				        DESCRIPTION VARCHAR(30));



ALTER TABLE SI_MQ_INBOUND_DETAILS ADD CONSTRAINT SI_MQ_IN_MSG_TRANSACT_CHK CHECK (MESSAGE_TRANSACTION IN ('no', 'yes', 'automatic')) ENABLE;
ALTER TABLE SI_MQ_INBOUND_DETAILS ADD CONSTRAINT SI_MQ_IN_MSG_SEGMENT_CHK CHECK (MESSAGE_SEGMENTATION IN ('no', 'yes')) ENABLE;

--14/08/2012 HM Altered column USER_ID as not nullable
ALTER TABLE SI_MQ_INBOUND_DETAILS MODIFY USER_ID VARCHAR(10) NOT NULL;

--28/06/2013 Mike Arrowsmith - Added BUSINESS_SERVICE_ID optional column for incoming SOAP over MQ routing
ALTER TABLE SI_MQ_INBOUND_DETAILS ADD BUSINESS_SERVICE_ID VARCHAR2(40);