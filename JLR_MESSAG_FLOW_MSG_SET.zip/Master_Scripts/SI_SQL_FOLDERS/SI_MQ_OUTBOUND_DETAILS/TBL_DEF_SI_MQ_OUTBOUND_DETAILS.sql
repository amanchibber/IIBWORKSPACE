--------------------------------------------------------------------------------------------------------
-- Author 		: Teresa Bastiman-Davies
-- Version 		: $Revision: 1.1 $
-- Description 	: Create table script for SI_MQ_OUTBOUND_DETAILS table which will hold details 
--                of runtime overrides used by the MQ outbound adapter
-- History 		: 24/01/2012 Teresa Bastiman-Davies Initial create statement for table
--				  13/04/2012 Hina Mistry Altering size of the business_service_id column
--------------------------------------------------------------------------------------------------------

DROP TABLE SI_MQ_OUTBOUND_DETAILS;

CREATE TABLE SI_MQ_OUTBOUND_DETAILS (SYSTEM_IDENTIFIER	VARCHAR2(20) NOT NULL,
								 BUSINESS_SERVICE_ID VARCHAR2 (35) NOT NULL,
								 QUEUE_MANAGER VARCHAR2(48),
								 QUEUE_NAME VARCHAR2 (48) NOT NULL,
								 MESSAGE_TRANSACTION VARCHAR(9),
								 MESSAGE_PERSISTENCE VARCHAR(9),
								 MESSAGE_SEGMENTATION VARCHAR(3),
								 MESSAGE_RFH2_REQUIRED VARCHAR(3) NOT NULL,
								 MESSAGE_USERAUTHORITY VARCHAR(3),
								 INSERT_TIMESTAMP TIMESTAMP,
								 UPDATE_TIMESTAMP TIMESTAMP,
								 USER_ID VARCHAR2 (10) NOT NULL,
								 DESCRIPTION VARCHAR2 (100) NOT NULL);


ALTER TABLE SI_MQ_OUTBOUND_DETAILS ADD CONSTRAINT SI_MQ_OUT_MSG_TRANSACT_CHK CHECK (MESSAGE_TRANSACTION IN ('no', 'yes', 'automatic')) ENABLE;

ALTER TABLE SI_MQ_OUTBOUND_DETAILS ADD CONSTRAINT SI_MQ_OUT_MSG_PERSIST_CHK CHECK (MESSAGE_PERSISTENCE IN ('no', 'yes', 'automatic', 'asQdef')) ENABLE;

ALTER TABLE SI_MQ_OUTBOUND_DETAILS ADD CONSTRAINT SI_MQ_OUT_MSG_SEGMENT_CHK CHECK (MESSAGE_SEGMENTATION IN ('no', 'yes')) ENABLE;

ALTER TABLE SI_MQ_OUTBOUND_DETAILS ADD CONSTRAINT SI_MQ_OUT_MSG_RFH_CHK CHECK (MESSAGE_RFH2_REQUIRED IN ('no', 'yes')) ENABLE;

ALTER TABLE SI_MQ_OUTBOUND_DETAILS ADD CONSTRAINT SI_MQ_OUT_MSG_USERAUTH_CHK CHECK (MESSAGE_USERAUTHORITY IN ('no', 'yes')) ENABLE;

--13/04/2012 HM Business Service ID column - size alteration
ALTER TABLE SI_MQ_OUTBOUND_DETAILS MODIFY BUSINESS_SERVICE_ID VARCHAR(45);	

COMMIT;
