--------------------------------------------------------------------------------------------------------
-- Author 		: Teresa Bastiman
-- Version 		: $Revision: 1.1 $
-- Description 	: Create trigger script for trigger on table SI_MQ_OUTBOUND_DETAILS which will 
--              : update the table with a insert or update timestamp when a row is inserted or modified 
-- History 		: 24/01/2012 Teresa Bastiman-Davies Initial create statement for trigger SI_MQOUTDETS_TMSTMP_TRG
--------------------------------------------------------------------------------------------------------

DROP TRIGGER SI_MQOUTDETS_TMSTMP_TRG;

CREATE OR REPLACE
TRIGGER SI_MQOUTDETS_TMSTMP_TRG
BEFORE INSERT OR UPDATE ON SI_MQ_OUTBOUND_DETAILS
FOR EACH ROW
BEGIN

IF INSERTING THEN
	:new.INSERT_TIMESTAMP := systimestamp;
	:new.UPDATE_TIMESTAMP := NULL;
ELSE
	:new.UPDATE_TIMESTAMP := systimestamp;
  END IF;
END;
/
COMMIT;
