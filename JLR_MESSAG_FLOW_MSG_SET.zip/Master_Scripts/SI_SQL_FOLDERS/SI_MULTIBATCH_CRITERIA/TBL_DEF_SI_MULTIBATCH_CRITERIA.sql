--------------------------------------------------------------------------------------------------------
-- Author 		: Mike Arrowsmith
-- Version 		: $Revision: 1.3 $
-- Description 	: Create table script for SI_MULTIBATCH_CRITERIA table which will hold details required
--				  by the MultiBatch_Processing service to determine which feeds require which batch
--				  messages.
-- History 		: 26/06/2012 Create
-- 				  14/08/2012 Hina Mistry Addition of user id, insert/update timestamp columns
-- 				  26/06/2014 Kenny McCormack - Updated size of BS_INPUT_DESTINATION - FRS-000364
-- 				  20/08/2014 Graham Smith - Added BATCH_INTERFACE_GROUP_ID to allow data separation
--------------------------------------------------------------------------------------------------------

--SI_MULTIBATCH_SCHEDULE
DROP TABLE SI_MULTIBATCH_CRITERIA;

CREATE TABLE SI_MULTIBATCH_CRITERIA
(
  BUSINESS_SERVICE_ID 		VARCHAR2(45),
  METHOD 					VARCHAR2(10),
  BS_INPUT_DESTINATION		VARCHAR2(48),
  META_DATA_1 				VARCHAR2(500),
  META_DATA_2 				VARCHAR2(500),
  META_DATA_3				VARCHAR2(500),
  META_DATA_4 				VARCHAR2(500),
  META_DATA_5 				VARCHAR2(500),
  META_DATA_6 				VARCHAR2(500)
);								 

ALTER TABLE SI_MULTIBATCH_CRITERIA ADD USER_ID VARCHAR2(10) NOT NULL;
ALTER TABLE SI_MULTIBATCH_CRITERIA ADD INSERT_TIMESTAMP TIMESTAMP;
ALTER TABLE SI_MULTIBATCH_CRITERIA ADD UPDATE_TIMESTAMP TIMESTAMP;


-- KM 26/06/2014
-- FRS-000364 - Updated as BS_INPUT_DESTINATION can
-- now contain a direcotry path
ALTER TABLE SI_MULTIBATCH_CRITERIA MODIFY BS_INPUT_DESTINATION VARCHAR(100);

-- GS 20/08/2014 - Add BATCH_INTERFACE_GROUP_ID to allow separation of data
-- for multiple interfaces.
ALTER TABLE SI_MULTIBATCH_CRITERIA ADD BATCH_INTERFACE_GROUP_ID VARCHAR2(50);
								 
COMMIT;
