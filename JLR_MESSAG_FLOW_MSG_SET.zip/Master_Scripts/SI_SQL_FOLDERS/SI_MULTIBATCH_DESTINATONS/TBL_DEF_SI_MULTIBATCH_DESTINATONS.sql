--------------------------------------------------------------------------------------------------------
-- Author 		: Mike Arrowsmith
-- Version 		: $Revision: 1.1 $
-- Description 	: Create table script for SI_MULTIBATCH_DESTINATIONS table which will hold details 
--				  of which business services affect which market. It's purely for info.
-- History 		: 26/06/2012 Create
-- 				  14/08/2012 Hina Mistry Addition of user id, insert/update timestamp columns
--------------------------------------------------------------------------------------------------------

--SI_MULTIBATCH_DESTINATIONS
DROP TABLE SI_MULTIBATCH_DESTINATIONS;

CREATE TABLE SI_MULTIBATCH_DESTINATIONS
(
  BUSINESS_SERVICE_ID 	VARCHAR2(45),
  DESTINATION_SYSTEM 	VARCHAR2(30)
);							 

ALTER TABLE SI_MULTIBATCH_DESTINATIONS ADD USER_ID VARCHAR2(10) NOT NULL;
ALTER TABLE SI_MULTIBATCH_DESTINATIONS ADD INSERT_TIMESTAMP TIMESTAMP;
ALTER TABLE SI_MULTIBATCH_DESTINATIONS ADD UPDATE_TIMESTAMP TIMESTAMP;

								 
COMMIT;
