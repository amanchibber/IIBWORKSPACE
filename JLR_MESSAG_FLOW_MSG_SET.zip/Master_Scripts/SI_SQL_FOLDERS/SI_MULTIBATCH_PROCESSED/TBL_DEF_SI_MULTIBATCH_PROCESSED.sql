--------------------------------------------------------------------------------------------------------
-- Author 		: Mike Arrowsmith
-- Version 		: $Revision: 1.2 $
-- Description 	: Create table script for SI_MULTIBATCH_PROCESSED table which will hold details 
--				  of which batches have been ran for which feeds.
-- History 		: 26/06/2012 Create
--------------------------------------------------------------------------------------------------------


--SI_MULTIBATCH_PROCESSED
DROP TABLE SI_MULTIBATCH_PROCESSED;

CREATE TABLE SI_MULTIBATCH_PROCESSED
(
  BUSINESS_SERVICE_ID 		VARCHAR2(45),
  RECORD_ID 				VARCHAR2(25),
  INSERT_TIMESTAMP			TIMESTAMP(6)
)
;						 

-- MA 06/03/2013 - Updated to 30 due to increased size of batch table for sequence purposes
ALTER TABLE SI_MULTIBATCH_PROCESSED MODIFY RECORD_ID VARCHAR(30);

COMMIT;
