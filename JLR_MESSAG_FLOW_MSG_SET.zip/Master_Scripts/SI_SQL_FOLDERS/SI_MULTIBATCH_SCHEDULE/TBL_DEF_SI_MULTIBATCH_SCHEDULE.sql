--------------------------------------------------------------------------------------------------------
-- Author 		: Mike Arrowsmith
-- Version 		: $Revision: 1.2 $
-- Description 	: Create table script for SI_MULTIBATCH_SCHEDULE table which will hold details 
--				  of which batches should be ran when.
-- History 		: 26/06/2012 Create
-- 				  14/08/2012 Hina Mistry Addition of user id, insert/update timestamp columns
--				  11/06/2014 Kenny McCormack Increase size of DAILY_FREQUENCY column
--------------------------------------------------------------------------------------------------------

--SI_MULTIBATCH_SCHEDULE
DROP TABLE SI_MULTIBATCH_SCHEDULE;

CREATE TABLE SI_MULTIBATCH_SCHEDULE
(
  BUSINESS_SERVICE_ID 		VARCHAR2(45),
  ENABLED					VARCHAR2(1),
  PROCESSING_STARTED		VARCHAR2(1),
  DAILY_BATCH_START_TIME	VARCHAR2(8),
  DAILY_BATCH_END_TIME		VARCHAR2(8),
  FREQUENCY					VARCHAR2(20),
  DAILY_FREQUENCY			VARCHAR2(8),
  BATCH_LAST_RAN			TIMESTAMP(6),
  BATCH_DISPATCHED			TIMESTAMP(6)
)
;						 

ALTER TABLE SI_MULTIBATCH_SCHEDULE ADD USER_ID VARCHAR2(10) NOT NULL;
ALTER TABLE SI_MULTIBATCH_SCHEDULE ADD INSERT_TIMESTAMP TIMESTAMP;
ALTER TABLE SI_MULTIBATCH_SCHEDULE ADD UPDATE_TIMESTAMP TIMESTAMP;

-- KM 11/06/2014
-- Updated to account for new frequncy values
ALTER TABLE SI_MULTIBATCH_SCHEDULE MODIFY DAILY_FREQUENCY VARCHAR(50);

								 
COMMIT;
