--------------------------------------------------------------------------------------------------------
-- Author 		: Mike Arrowsmith
-- Version 		: $Revision: 1.37 $
-- Description 		: Create data script for SI_NAMESPACES table which will hold details 
--              	  of namespaces held within SI_MQ_INBOUND_DETAILS table
-- History 		: 28/06/2013 Mike Arrowsmith - Creation	
--  			: 08/08/2013 Deepak Ingwale - Added entry for FRS-000009 Publish OK TO Use List Service 
--  			: 16/09/2013 Aman Chibber   - Added entry for FRS-000023 Tool Instance Service
--  			: 21/10/2013 Pratik Khot   - Added entry for FRS-000017 Generic Solve Service	
-- 				: 24/10/2013 Pratik Khot - Added entry for FRS-000023 Publish Tool Instance service
--				: 28/10/2013 Pratik Khot - Added entry for FRS-000073 ENOVIA eBOM To VCATS service
--              : 12/11/2013 Naresh CH - Added entry for FRS-027 ESB Enovia Warranty Service Parts To SAP Turbo
--              : 19/11/2013 Naresh CH - Added entry for FRS-053 ESB ENOVIA-iPOINT Sevices 
--              : 19/12/2013 Pratik Khot - Added entry for FRS-038 ESB ENOVIA-UNIPART Services
--              : 07/01/2014 Naresh CH - Removed entry for FRS-051 ESB Enovia Target Cost Data To WIPS
--              : 14/01/2014 Hari Krishna Sabat-Added entry for FRS-091-ACE_BRS_Deltas 
--				: 16/01/2014 Naresh CH Added entries for FRS-022(PLO Slot Generation to ACE Services)
--				: 21/02/2014 Amith Karma Added entry for FRS-000081
--              : 03/03/2014 Naresh CH Added entries for FRS-090(Expose BRSData (Derivative and Feature Feeds))
--				: 14/05/2014 Pratik Khot - Added entry for FRS-100 ESB Publish Reference Data
--				: 18/06/2014 Pratik Khot Updated entry for FRS-000081 (SI_BS_PRD_UCC_PUB_NS1) under IFU-2057.
--              : 20/06/2014 Pratik Khot Added description for FRS-038 namespace(SI_BS_PRD_ECO_PUB_NS1) which is to used in FRS-051 as well.
--              : 20/06/2014 Pratik Khot Updated FRS-022 entry(SI_BS_PRD_SSGREQUEST_PUB_NS1)
--				: 20/06/2014 Pratik Khot Commented entries for FRS-022(PLO Slot Generation to ACE Services) under IFU 2060
-- 				: 28/07/2014 Pratik Khot - Commented out the below entry for FRS-07 ESB Publish Event Calendar under IFU 2206.
--              : 28/07/2014 Pratik Khot - Added the updated entry for FRS-07 ESB Publish Event Calendar under IFU 2206.
--				: 29/07/2014 Pratik Khot - Commented out entries for FRS-053 ESB ENOVIA-iPOINT Sevices under IFU 2179(Defect 29)
--				: 29/07/2014 Pratik Khot - Added entries for FRS-053 ESB ENOVIA-iPOINT Sevices under IFU 2179(Defect 29) 
--				: 05/08/2014 Pratik Khot - Reverted entry for FRS-07 ESB Publish Event Calendar under IFU 2206.
--				: 19/08/2014 Pratik Khot - Added for FRS-000009 Publish OK TO Use List Service Under IFU 2253.Also Commented older entry.
-- 				: 28/07/2014 Pratik Khot - Including IFU 2206 Again!!..Commented out the below entry for FRS-07 ESB Publish Event Calendar under IFU 2206  --                                          and added the updated entry for FRS-07 ESB Publish Event Calendar under IFU 2206.
--				: 05/09/2014 Naresh CH Added entries for FRS-096(Enovia to MPNR)
-- 				: 20/03/2015 Naresh CH updated Entry for FRS-000023 under IFU2807
-- 				: 17/04/2015 PK Added Entries for FRS-000015
--				: 21/10/2015 Akhilesh Entry for BODS to be deleted for FRS000015 IFU3443
--				: 11/12/2015 Akhilesh Entry updated for FRS 38 IFU 3528
--------------------------------------------------------------------------------------------------------
DELETE FROM SI_NAMESPACES;

INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
VALUES (null,'SOAPENV_DEFAULT','http://schemas.xmlsoap.org/soap/envelope/','marrowsm','Default soapenv namespace');

--
-- PLEASE NOTE: This may need to change going forward to use ENVIRONMENT_CONFIG replacement for each namespace i.e. development to qa etc
--

-- 28/07/2014 Pratik Khot - Commented out the below entry for FRS-07 ESB Publish Event Calendar under IFU 2206.
-- 05/08/2014 Pratik Khot - Reverted entry for FRS-07 ESB Publish Event Calendar under IFU 2206.
-- 27/08/2014 Pratik Khot - Commented out the below entry for FRS-07 ESB Publish Event Calendar under IFU 2206.
--INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
--VALUES ('ENOV_MQ_IN_1','SI_SV_PRDSV_EVENTCAL_PUB_NS1','http://jlrint.com/development/message/eventcalendar/1','marrowsm','Publish Event Calendar namespace');


INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
VALUES ('ENOV_MQ_IN_1','SI_SV_PRDSV_MASTFEATDC_PUB_NS1','http://jlrint.com/development/message/masterfeaturedictionary/1','marrowsm','Publish Master Feature Dictionary namespace');

-- 08/08/2013 Deepak Ingwale - Added entry for FRS-000009 Publish OK TO Use List Service 	
-- 19/08/2014 Pratik Khot - Commented below entry for FRS-000009 Publish OK TO Use List Service 	
--INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
--VALUES ('ACE_MQ_IN_1','SI_SV_PRDSV_FEATOK2USE_PUB_NS1','http://jlrint.com/development/message/oktouse/1','dingwale','Feature OK To Use List namespace');

-- 19/08/2014 Pratik Khot - Added below entry for FRS-000009 Publish OK TO Use List Service Under IFU 2253
INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
VALUES ('ACE_MQ_IN_1','SI_SV_PRDSV_FEATOK2USE_PUB_NS1','http://jlrint.com/oktouse/message/oktouse/1','pkhot','Feature OK To Use List namespace');

-- 21/10/2013 Pratik Khot - Added entry for FRS-000017 Generic Solve Service 	

INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
VALUES ('PLO_MQ_IN_1','SI_SV_MQ_GEN_SOLV_PUB_NS1','http://jlrint.com/development/message/JLRgenericsolve/1','pkhot','MQ Generic Solve Namespace');

-- 28/10/2013 Pratik Khot - Added entry for FRS-000073 ENOVIA eBOM To VCATS service

INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
VALUES (null,'JLR_COMMON_HEADER','http://jlrint.com/common/message/header/1','pkhot','JLR Common Header Namespace');

-- 12/11/2013 Naresh CH - Added entry for FRS-027 ESB Enovia Warranty Service Parts To SAP Turbo

INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
VALUES ('ENOV_MQ_IN_1','SI_BS_PRODUCT_WARRANTY_PUB_NS1','http://jlrint.com/development/message/warranty/1','nch','JLR Warrranty Namespace');

-- 19/11/2013 Naresh CH - Added entry for FRS-053 ESB ENOVIA-iPOINT Sevices 
-- 29/07/2014 Pratik Khot - Commented out below entries for FRS-053 ESB ENOVIA-iPOINT Sevices under IFU 2179(Defect 29) 
--INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
--VALUES ('ENOV_MQ_IN_1','SI_BS_PRD_PRTWGHT_PUB_NS1','http://jlrint.com/development/message/PartWeight/1','nch','Publish Part Weight Namespace'); 

--INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
--VALUES ('IPOINT_MQ_IN_1','SI_BS_PRD_SUPPRTWGHT_PUB_NS1','http://jlrint.com/development/message/SupplierPartWeight/1','nch','Publish Supplier Part Weight Namespace'); 

-- 19/12/2013 Pratik Khot - Added entry for FRS-038 ESB ENOVIA-UNIPART Services
--							This Entry also used for FRS-051
--11/12/2015 Akhilesh - Entry updated as part of IFU 3528
INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
VALUES ('ENOV_MQ_IN_1','SI_BS_PRD_ECO_PUB_NS1','http://jlrint.com/service/message/eco/1','pkhot','PublishECO Namespace');

--14/01/2014 Hari Krishna Sabat--Added entry for FRS-091 Namespace used by ACE for BrandSymphonyExport and BrandSymphonyFeaturesExport.

INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
VALUES ('ACE_MQ_IN_1','SI_BS_PRD_ACE_FD_NS1','http://jlrint.com/development/message/ACELegacyFeedsFD/1','hsabat','ACE legacy Feed Feature Delta');

INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
VALUES ('ACE_MQ_IN_1','SI_BS_PRD_ACE_DD_NS1','http://jlrint.com/development/message/ACELegacyFeedsDD/1','hsabat','ACE legacy Feed Derivative Delta');

--16/01/2014 Naresh CH Added entries for FRS-022(PLO Slot Generation to ACE Services)

INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
VALUES ('PLO_MQ_IN_1','SI_BS_PRD_SSGREQUEST_PUB_NS1','http://jlrint.com/slotspecgen/message/slotspecgen/1','nch','SSGREQUEST Namespace');

--20/06/2014 Pratik Khot Commented entries for FRS-022(PLO Slot Generation to ACE Services) under IFU 2060
--INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
--VALUES ('ACE_MQ_IN_1','SI_BS_PRD_SSGRESPONSE_PUB_NS1','http://jlrint.com/development/type/ssg/ssgmsgs/1','nch','SSGRESPONSE Namespace');

-- 21/02/2014 Amit Karma Added entry for FRS-000081

INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
VALUES ('ENOV_MQ_IN_1','SI_BS_PRD_UCC_PUB_NS1','http://jlrint.com/manufacturingdata/message/manufacturingdata/1','akarma','JLR Publish UCC');

--03/03/2014 Naresh CH Added entries for FRS-090(Expose BRSData (Derivative and Feature Feeds))

INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
VALUES ('ACE_MQ_IN_1','SI_BS_PRD_ACE_VS_NS1','http://jlrint.com/development/message/BrandSymphony/1','nch','ACE legacy Feed Feature Delta');

INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
VALUES ('ACE_MQ_IN_1','SI_BS_PRD_ACE_VD_NS1','http://jlrint.com/development/message/UpdateFeatureDescriptions/1','nch','ACE legacy Feed Derivative Delta');

-- 14/05/2014 Pratik Khot - Added entry for FRS-100 ESB Publish Reference Data

INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
VALUES ('ENOV_MQ_IN_1','SI_BS_PRD_REFDATA_PUB_NS1','http://jlrint.com/development/message/referencedata/1','pkhot','Reference Data Namespace');

-- 27/08/2014 Pratik Khot - Included for FRS-07 ESB Publish Event Calendar under IFU 2206.
-- 05/08/2014 Pratik Khot - Reverted entry for FRS-07 ESB Publish Event Calendar under IFU 2206.
-- 28/07/2014 Pratik Khot - Added the updated entry for FRS-07 ESB Publish Event Calendar under IFU 2206.
INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
VALUES ('ENOV_MQ_IN_1','SI_SV_PRDSV_EVENTCAL_PUB_NS1','http://jlrint.com/eventcalendar/message/eventcalendar/1','pkhot','Publish Event Calendar namespace');

-- 29/07/2014 Pratik Khot - Added below entries for FRS-053 ESB ENOVIA-iPOINT Sevices under IFU 2179(Defect 29) 
INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
VALUES ('ENOV_MQ_IN_1','SI_BS_PRD_PRTWGHT_PUB_NS1','http://jlrint.com/development/message/partweight/1','pkhot','Publish Part Weight Namespace'); 

INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
VALUES ('IPOINT_MQ_IN_1','SI_BS_PRD_SUPPRTWGHT_PUB_NS1','http://jlrint.com/development/message/partweight/1','pkhot','Publish Supplier Part Weight Namespace'); 

--05/09/2014 Naresh CH Added entries for FRS-096(Enovia to MPNR)

INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
VALUES ('ENOV_MQ_IN_1','SI_BS_DES_PRT_PUB_NS1','http://jlrint.com/development/message/designpart/1','nch','Publish DesignPart Namespace');

-- 20/03/2015 Naresh CH updated Entry for FRS-000023 under IFU2807

INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
VALUES ('ENOV_MQ_IN_1','SI_BS_ENOV_PRODUCT_SAP_TRBGB_COMPTOOLRQ_NS1','http://jlrint.com/componenttool/message/componenttool/1','nch','Component Tool Namespace');

INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
VALUES (null,'SOAPENV_DEFAULT','http://schemas.xmlsoap.org/soap/envelope/','nch','Default soapenv namespace');

INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
VALUES ('SAP_MQ_IN_1','SI_SV_PRDSV_TOOLINSST_PUB_NS1','http://jlrint.com/development/message/componenttool/1','nch','Tool Instance Status namespace');

-- 17/04/2015 PK Added Entries for FRS-000015
--21/10/2015 AM Entry for BODS to be deleted for FRS000015 IFU3443
--INSERT INTO SI_NAMESPACES(SYSTEM_IDENTIFIER,NAMESPACE_ALIAS,NAMESPACE,USER_ID,DESCRIPTION)
--VALUES ('ENOV_MQ_IN_1','SI_BS_GPIRS_PRODUCT_MULT_COMPVEHREQ_NS1','http://jlrint.com/gpirssolverequest/message/gpirssolverequest/1','pkhot','Publish GPIRS Solve Request Namespace');



COMMIT;
