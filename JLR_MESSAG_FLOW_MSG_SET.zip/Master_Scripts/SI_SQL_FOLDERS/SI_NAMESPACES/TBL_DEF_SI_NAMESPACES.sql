--------------------------------------------------------------------------------------------------------
-- Author 		: Mike Arrowsmith
-- Version 		: $Revision: 1.2 $
-- Description 		: Create table script for SI_NAMESPACES table which will hold details 
--              	  of namespaces held within SI_MQ_INBOUND_DETAILS table
-- History 		: 28/06/2013 Mike Arrowsmith - Creation	
--------------------------------------------------------------------------------------------------------

DROP TABLE SI_NAMESPACES;

CREATE TABLE SI_NAMESPACES (SYSTEM_IDENTIFIER  VARCHAR2(20),
			    NAMESPACE_ALIAS VARCHAR (255) NOT NULL,
			    NAMESPACE VARCHAR(255) NOT NULL,
			    INSERT_TIMESTAMP TIMESTAMP(6),
			    UPDATE_TIMESTAMP TIMESTAMP(6),
		            USER_ID VARCHAR(10) NOT NULL,
			    DESCRIPTION VARCHAR(50));

COMMIT;