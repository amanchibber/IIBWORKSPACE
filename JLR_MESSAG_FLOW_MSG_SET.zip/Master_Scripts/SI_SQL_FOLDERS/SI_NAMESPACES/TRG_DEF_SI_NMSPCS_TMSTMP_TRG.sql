--------------------------------------------------------------------------------------------------------
-- Author 		: Mike Arrowsmith
-- Version 		: $Revision: 1.1 $
-- Description 		: Create trigger script for trigger on table SI_NAMESPACES which will update the 
--			  table with a insert timestamp when a row has been inserted 
-- History 		: 28/06/2013 Mike Arrowsmith : Creation
--------------------------------------------------------------------------------------------------------
CREATE OR REPLACE TRIGGER SI_NMSPCS_TMSTMP_TRG
BEFORE INSERT OR UPDATE ON SI_NAMESPACES
FOR EACH ROW
BEGIN

IF INSERTING THEN
	:new.INSERT_TIMESTAMP := systimestamp;
	:new.UPDATE_TIMESTAMP := NULL;
ELSE
	:new.UPDATE_TIMESTAMP := systimestamp;
  END IF;
END;
/
COMMIT;
