--------------------------------------------------------------------------------------------------------
-- Author 		: Naresh CH
-- Version 		: $Revision: 1.6 $
-- Description 	: Create data script for SI_P2P_ROUTING table which will hold routing information
-- History 		: 27/04/2016 Naresh CH Initial creation of master scripts for FRS816
--				: 04/05/2016 NC Added Vendor master routing values
--				: 23/05/2016 NC Added CTC routing values
--              : 13/12/2016 LH Added Entries for FRS839
---------------------------------------------------------------------------------------------------------
--Material Master
INSERT INTO SI_P2P_ROUTING (CMM_PLANT_CODE,CMM_PARTNER,CMM_IDOC_TYPE,CMM_IDOC_EXT_TYPE,CMM_MES_TYPE,TARGET_COUNTRY,TARGET_SYSTEM,DESTINATION,USER_ID,DESCRIPTION) 
VALUES ('5000',NULL,'MATMAS05',NULL,'ZM_MATMAS_GLOBAL','Austria','Plant Graz MQ','SI.BS.CANON.MATERIALMASTER.TO.PGZ.IN','nch','Material Master Data to Plant Graz');

----Vendor Master
INSERT INTO SI_P2P_ROUTING (CMM_PLANT_CODE,CMM_PARTNER,CMM_IDOC_TYPE,CMM_IDOC_EXT_TYPE,CMM_MES_TYPE,TARGET_COUNTRY,TARGET_SYSTEM,DESTINATION,USER_ID,DESCRIPTION) 
VALUES (null,'MAGNA STEYR','CREMAS05','Z_CREMAS05','ZM_CREMA_GLOBAL','Austria','Plant Graz MQ','SI.BS.CANON.VENDORMASTER.TO.PGZ.IN','nch','Vendor Master Data to Plant Graz')

--CTC
INSERT INTO SI_P2P_ROUTING (CMM_PLANT_CODE,CMM_PARTNER,CMM_IDOC_TYPE,CMM_IDOC_EXT_TYPE,CMM_MES_TYPE,TARGET_COUNTRY,TARGET_SYSTEM,DESTINATION,USER_ID,DESCRIPTION) 
VALUES (null,'MAGNA STEYR','ORDERS05','Z_ORDERS05','ZM_ORDCH_GLOBAL','Austria','Plant Graz MQ','SI.BS.CANON.CTC.TO.PGZ.IN','nch','CTC Change Data to Plant Graz')

INSERT INTO SI_P2P_ROUTING (CMM_PLANT_CODE,CMM_PARTNER,CMM_IDOC_TYPE,CMM_IDOC_EXT_TYPE,CMM_MES_TYPE,TARGET_COUNTRY,TARGET_SYSTEM,DESTINATION,USER_ID,DESCRIPTION) 
VALUES (null,'MAGNA STEYR','ORDERS05','Z_ORDERS05','ZM_ORD_GLOBAL','Austria','Plant Graz MQ','SI.BS.CANON.CTC.TO.PGZ.IN','nch','CTC Create Data to Plant Graz')


-- 13/12/2016 LH Added Entries for FRS839
INSERT INTO SI_P2P_ROUTING (CMM_PLANT_CODE,CMM_PARTNER,CMM_IDOC_TYPE,CMM_IDOC_EXT_TYPE,CMM_MES_TYPE,TARGET_COUNTRY,TARGET_SYSTEM,DESTINATION,USER_ID,DESCRIPTION) VALUES (null,'MAGNA STEYR','CREMAS05','Z_CREMAS05','ZM_CREMA_GLOBAL','JLR Data lake(cloud)','MFT FTP','SI.BS.CANON.VENDORMASTER.DATASTORE.IN','lhake','Vendor Master Data to MFT')




