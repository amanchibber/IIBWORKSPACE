--------------------------------------------------------------------------------------------------------
-- Author 		: Amith Sannagowdar
-- Version 		: $Revision: 1.2 $
-- Description 	: Create table script for SI_P2P_ROUTING table
-- History 		: 19/04/2016 AS Initial create statement for table
--				: 29/04/2016 AS CMM_PARTNER can be NULL
-------------------------------------------------------------------------------------------------------

DROP TABLE SI_P2P_ROUTING;

CREATE TABLE SI_P2P_ROUTING 
(CMM_PLANT_CODE		VARCHAR2(4),
CMM_PARTNER			VARCHAR2(30),
CMM_IDOC_TYPE		VARCHAR2(8)  NOT NULL,
CMM_IDOC_EXT_TYPE	VARCHAR2(30), 
CMM_MES_TYPE		VARCHAR2(30) NOT NULL,
TARGET_COUNTRY		VARCHAR2(20) NOT NULL,
TARGET_SYSTEM		VARCHAR2(20) NOT NULL,
DESTINATION			VARCHAR2(48) NOT NULL,
USER_ID				VARCHAR2(10),
DESCRIPTION			VARCHAR2(50),
INSERT_TIMESTAMP	TIMESTAMP,
UPDATE_TIMESTAMP	TIMESTAMP
) ;
