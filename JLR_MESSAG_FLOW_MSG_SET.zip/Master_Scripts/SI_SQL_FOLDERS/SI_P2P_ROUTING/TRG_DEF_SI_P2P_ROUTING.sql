--------------------------------------------------------------------------------------------------------
-- Author 		: Amith Sannagowdar
-- Version 		: $Revision: 1.1 $
-- Description 	: Create trigger script for SI_P2P_ROUTING (Procure To Pay) table  
-- History 		: 19/04/2016 AS Initial create statement for trigger
--------------------------------------------------------------------------------------------------------

DROP TRIGGER SI_P2P_ROUTE_TMSTMP_TRG;

--Trigger which will insert or update the timestamp if an insert or update action occurs
CREATE OR REPLACE
TRIGGER SI_P2P_ROUTE_TMSTMP_TRG
BEFORE INSERT OR UPDATE ON SI_P2P_ROUTING
FOR EACH ROW
BEGIN

IF INSERTING THEN
	:new.INSERT_TIMESTAMP := systimestamp;
	:new.UPDATE_TIMESTAMP := NULL;
ELSE
	:new.UPDATE_TIMESTAMP := systimestamp;
END IF;
END;
/
COMMIT;
