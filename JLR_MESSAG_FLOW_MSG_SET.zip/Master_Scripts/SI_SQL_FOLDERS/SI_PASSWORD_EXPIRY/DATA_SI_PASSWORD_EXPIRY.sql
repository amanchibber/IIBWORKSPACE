--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: $Revision: 1.1 $
-- Description 	: Create data script for SI_PASSWORD_EXPIRY table which will hold information about 
-- 				  usernames and when their password will expire 
-- History 		: 24/11/2011 Hina Mistry Initial insert statements for table
--------------------------------------------------------------------------------------------------------
DELETE FROM SI_PASSWORD_EXPIRY;

INSERT INTO SI_PASSWORD_EXPIRY (ID,USERNAME,PASSWORD_EXPIRY_DATE) VALUES (SI_PWD_EXPIRY.NEXTVAL, 'asrtrans', TO_DATE('26/01/2012', 'DD/MM/YYYY'));

COMMIT;
