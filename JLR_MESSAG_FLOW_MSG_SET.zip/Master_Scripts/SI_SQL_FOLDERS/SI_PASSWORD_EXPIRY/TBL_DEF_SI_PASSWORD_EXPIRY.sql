--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: $Revision: 1.1 $
-- Description 	: Create table script for SI_PASSWORD_EXPIRY table which will hold details of the usernames 
-- 				  that are used by the ESB and when their passwords expire
-- History 		: 24/11/2011 Hina Mistry Initial create statement for table
--------------------------------------------------------------------------------------------------------

DROP TABLE SI_PASSWORD_EXPIRY ;

CREATE TABLE SI_PASSWORD_EXPIRY (ID NUMBER(4) NOT NULL,
								 USERNAME VARCHAR2(50) NOT NULL,
								 PASSWORD_EXPIRY_DATE DATE NOT NULL,
								 INSERT_TIMESTAMP TIMESTAMP,
								 UPDATE_TIMESTAMP TIMESTAMP);



