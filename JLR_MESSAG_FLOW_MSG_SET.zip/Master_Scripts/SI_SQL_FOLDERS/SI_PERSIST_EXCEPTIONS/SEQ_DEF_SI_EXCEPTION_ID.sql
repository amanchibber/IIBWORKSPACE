--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: $Revision: 1.1 $
-- Description 		: Create sequence script for SI_PERSIST_EXCEPTIONS table 
-- History 		: 17/08/2011 Hina Mistry Addition of sequence which will be used to generate primary key on SI_PERSIST_EXCEPTIONS table
--------------------------------------------------------------------------------------------------------

DROP SEQUENCE SI_EXCEPTION_ID;

--Sequence to generate the EXCEPTION_ID value		
CREATE SEQUENCE SI_EXCEPTION_ID
MINVALUE 1
START WITH 1
INCREMENT BY 1
CACHE 10;
