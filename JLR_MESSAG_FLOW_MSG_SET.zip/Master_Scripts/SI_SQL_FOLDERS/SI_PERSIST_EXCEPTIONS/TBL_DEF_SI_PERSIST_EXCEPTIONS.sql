--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: $Revision: 1.1 $
-- Description 	: Create table script for SI_PERSIST_EXCEPTIONS table which will hold details for errors 
--				  generated in the integration layer
-- History 		: 22/07/2011 Hina Mistry Initial create statement for table
--			  	  17/08/2011 Hina Mistry Update the table name
--				  13/04/2012 Hina Mistry Altering size of the business_service_id column
--------------------------------------------------------------------------------------------------------

DROP TABLE SI_PERSIST_EXCEPTIONS;

CREATE TABLE SI_PERSIST_EXCEPTIONS (EXCEPTION_ID NUMBER(10) NOT NULL, 
		ERROR_OCCURRED_TIMESTAMP TIMESTAMP NOT NULL,
		BUSINESS_SERVICE_ID VARCHAR(35) NOT NULL,
		OTHER_ID VARCHAR(50) NULL,
		BROKER_NAME VARCHAR(50) NOT NULL, 
		MESSAGE_FLOW_NAME VARCHAR(100) NOT NULL, 
		EXECUTION_GROUP_NAME VARCHAR(50) NOT NULL, 
		EXCEPTION_TYPE VARCHAR(50) NOT NULL,
		FLOW_NODE_NAME VARCHAR(200) NOT NULL, 
		ERROR_NO VARCHAR(15) NOT NULL,
		ERROR_DESCRIPTION CLOB NOT NULL, 
		MESSAGE_ID VARCHAR(48) NULL,
		CORRELATION_ID VARCHAR(48) NULL,
		SOURCE_QUEUE_NAME VARCHAR(48) NULL,
		PERSISTENCE CHAR(1) NULL,
		ORIGINAL_MQMD BLOB NULL, 
		ORIGINAL_MQRFH2 BLOB NULL, 
		ORIGINAL_MQCIH BLOB NULL, 
		ORIGINAL_PAYLOAD CLOB NOT NULL,
		MESSAGE_PROPERTIES_TYPE VARCHAR(50) NULL,
		MESSAGE_PROPERTIES CLOB NULL,
		INSERT_TIMESTAMP TIMESTAMP NULL,
		UPDATE_TIMESTAMP TIMESTAMP NULL,
		CONSTRAINT PK_SI_PRST_EXCEPS PRIMARY KEY(EXCEPTION_ID));
		
--13/04/2012 HM Business Service ID column - size alteration
ALTER TABLE SI_PERSIST_EXCEPTIONS MODIFY BUSINESS_SERVICE_ID VARCHAR(45);

COMMIT;		

		

