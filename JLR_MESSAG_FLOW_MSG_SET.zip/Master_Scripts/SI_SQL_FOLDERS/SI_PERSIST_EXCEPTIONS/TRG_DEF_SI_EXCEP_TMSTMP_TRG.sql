--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: $Revision: 1.1 $
-- Description 	: Create table script for SI_PERSIST_EXCEPTIONS table which will hold details for errors 
--				  generated in the integration layer
-- History 		: 17/08/2011 Hina Mistry Add of trigger for table SI_PERSIST_EXCEPTIONS to update insert and update timestamp fields
--										 when rows in the table are added or updated
--------------------------------------------------------------------------------------------------------

DROP TRIGGER SI_EXCEP_TMSTMP_TRG;

--Trigger which will insert or update the timestamp if an insert or update action occurs
CREATE OR REPLACE
TRIGGER SI_EXCEP_TMSTMP_TRG
BEFORE INSERT OR UPDATE ON SI_PERSIST_EXCEPTIONS
FOR EACH ROW
BEGIN

IF INSERTING THEN
	:new.INSERT_TIMESTAMP := systimestamp;
	:new.UPDATE_TIMESTAMP := NULL;
ELSE
	:new.UPDATE_TIMESTAMP := systimestamp;
  END IF;
END;
/
COMMIT;
