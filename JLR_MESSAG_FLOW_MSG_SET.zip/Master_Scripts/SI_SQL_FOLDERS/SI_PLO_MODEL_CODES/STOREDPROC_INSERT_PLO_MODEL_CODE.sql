--------------------------------------------------------------------------------------------------------
-- Author 		: Prasad Panchagnula
-- Version 		: $Revision: 1.1 $
-- Description 	: Stored procedure for inserting MODEL_CODE in SI_PLO_MODEL_CODES table. Duplicate 
--				  MODEL_CODE inserts are trapped and returned as DUPLICATE_MODEL_CODE text in the
--				  configured OUT parameter, so that the calling application can take necessary action
--				  because of the failed insert.
--
-- History 		: 
--				30/07/2015 Prasad Panchagnula     Initial version of the stored procedure.
--												  
--------------------------------------------------------------------------------------------------------


CREATE OR REPLACE PROCEDURE WMBOWNER.INSERT_PLO_MODEL_CODE (modelCode IN VARCHAR2, insertResult OUT VARCHAR2) AS
  BEGIN
   
   INSERT INTO SI_PLO_MODEL_CODES(MODEL_CODE) VALUES(modelCode);
 
   insertResult := 'MODEL_CODE_INSERT_SUCCESSFUL';
  
  EXCEPTION 
      WHEN DUP_VAL_ON_INDEX THEN
           insertResult := 'DUPLICATE_MODEL_CODE';
END INSERT_PLO_MODEL_CODE;
/
