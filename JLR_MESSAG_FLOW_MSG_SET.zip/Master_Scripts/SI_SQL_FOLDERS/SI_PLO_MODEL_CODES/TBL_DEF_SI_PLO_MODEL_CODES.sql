--------------------------------------------------------------------------------------------------------
-- Author 		: Ravindra Babu
-- Version 		: $Revision: 1.2 $
-- Description 	: Create table script for SI_PLO_MODEL_CODES table
-- History 		: 25/02/2013 Addition of new table creation script
--				30/07/2015 Prasad Panchagnula     Removed IN_PROGRESS, UPDATE_TIMESTAMP columns and added 
--												  unique constraint as a part of IA-29 service redesign to make 
--												  this service work on both the brokers concurrently as opposed 
--												  to single broker deployment.
--------------------------------------------------------------------------------------------------------

--SI_PLO_MODEL_CODES
DROP TABLE SI_PLO_MODEL_CODES;

CREATE TABLE SI_PLO_MODEL_CODES
(
  MODEL_CODE	   VARCHAR2(18) NOT NULL,
  IN_PROGRESS	   VARCHAR2(1),
  INSERT_TIMESTAMP TIMESTAMP (6),
  UPDATE_TIMESTAMP TIMESTAMP (6)
);								 

CREATE INDEX IDX_SI_PLO_MODEL_CODES
   ON SI_PLO_MODEL_CODES(MODEL_CODE);

ALTER TABLE "SI_PLO_MODEL_CODES" DROP COLUMN "IN_PROGRESS";
ALTER TABLE "SI_PLO_MODEL_CODES" DROP COLUMN "UPDATE_TIMESTAMP";
ALTER TABLE "SI_PLO_MODEL_CODES" ADD CONSTRAINT SI_PLO_MODEL_CODES_UNIQ UNIQUE("MODEL_CODE") ;

COMMIT;
