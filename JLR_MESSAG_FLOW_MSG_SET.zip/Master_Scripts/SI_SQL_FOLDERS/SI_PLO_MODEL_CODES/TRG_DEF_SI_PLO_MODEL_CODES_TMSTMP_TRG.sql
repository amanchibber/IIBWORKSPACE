--------------------------------------------------------------------------------------------------------
-- Author 		: Ravindra Babu
-- Version 		: $Revision: 1.2 $
-- Description 	: Create trigger script for trigger on table SI_PLO_MODEL_CODES which will update the table
--				  with a insert timestamp and update timestamp when a row has been inserted/updated
-- History 		: 25/02/2013 Ravindra Babu Initial create statement for trigger SI_PLO_MODEL_CODES_TMSTMP_TRG
--				  03/08/2015 Prasad Panchagnula   Modified the trigger to be "BEFORE INSERT" trigger rather than "BEFORE INSERT OR UPDATE"
--------------------------------------------------------------------------------------------------------

--Trigger which will insert or update the timestamp if an insert or update action occurs
CREATE OR REPLACE
TRIGGER SI_PLO_MODEL_CODES_TMSTMP_TRG
BEFORE INSERT ON SI_PLO_MODEL_CODES
FOR EACH ROW
BEGIN

IF INSERTING THEN
	:new.INSERT_TIMESTAMP := systimestamp;
  END IF;
END;
/
COMMIT;
