--------------------------------------------------------------------------------------------------------
-- Author 		: Ryan Glackin
-- Version 		: $Revision: 1.1 $
-- Description 		: Create table script for SI_POSITION_TEMP_DATA table which will temporarily hold POSITION DATA FOR HR FEED IA94
-- History 		: 31/08/13 Ryan Glackin - Initial create statement for table
--------------------------------------------------------------------------------------------------------

DROP TABLE SI_POSITION_TEMP_DATA;

CREATE TABLE SI_POSITION_TEMP_DATA (BUSINESS_SERVICE_ID VARCHAR2(45),  
					OBJECT_TYPE VARCHAR2(20), 
					OBJECT_ID VARCHAR2(20), 
					COST_CENTRE VARCHAR2(20), 
					PARENT VARCHAR2(20), 
					INSERT_TIMESTAMP TIMESTAMP (6), 
					CONSTRAINT SI_POSITION_TEMP_DATA_PK PRIMARY KEY (OBJECT_TYPE, OBJECT_ID));



COMMIT;
