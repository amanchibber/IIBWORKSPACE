--------------------------------------------------------------------------------------------------------
-- Author 		: Ryan Glackin
-- Version 		: $Revision: 1.1 $
-- Description 		: Create trigger script for trigger on table SI_POSITION_TEMP_DATA which will update the table
--				  with a insert timestamp when a row has been inserted.
-- History 		: 31/08/2013 Ryan Glackin Initial create statement for trigger SI_POSITION_TEMP_DATA_TRG
--------------------------------------------------------------------------------------------------------

DROP TRIGGER SI_POSITION_TEMP_DATA_TRG;

--Trigger which will insert or update the timestamp if an insert or update action occurs
CREATE OR REPLACE
TRIGGER SI_POSITION_TEMP_DATA_TRG
BEFORE INSERT OR UPDATE ON SI_POSITION_TEMP_DATA
FOR EACH ROW
BEGIN

IF INSERTING THEN
	:new.INSERT_TIMESTAMP := systimestamp;

  END IF;
END;
/
COMMIT;
