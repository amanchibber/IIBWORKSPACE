--------------------------------------------------------------------------------------------------------
-- Author 		: Gaurav Gawali
-- Version 		: $Revision: 1.4 $
-- Description 	: Create table script for SI_QUEUE_MONITOR table 
-- History 		: 10/09/2013 Gaurav Gawali Initial create statement for table
-- 				  10/12/2013 Paul Gregory added Broker for clustered environments (maintenance fix)


--------------------------------------------------------------------------------------------------------


DROP TABLE  SI_QUEUE_MONITOR;

CREATE TABLE  SI_QUEUE_MONITOR (BROKER_NAME VARCHAR2(50) NOT NULL,
								QUEUE_NAME VARCHAR2(48) NOT NULL, 
                               REPORT_AGE_SECONDS NUMBER(7,0) NOT NULL, 
                               REPORTED_MESSAGE_ID BLOB, 
                               BUSINESS_SERVICE_ID VARCHAR2(40) NOT NULL, 
                               DESCRIPTION VARCHAR2(100),
                               USER_ID VARCHAR2(50) NOT NULL,
                               INSERT_TIMESTAMP TIMESTAMP,
                               UPDATE_TIMESTAMP TIMESTAMP,
                               CONSTRAINT SI_QUEUE_MON_PK PRIMARY KEY (BROKER_NAME,QUEUE_NAME));

COMMIT;