--------------------------------------------------------------------------------------------------------
-- Author 		: Mike Arrowsmtih
-- Version 		: $Revision: 1.2 $
-- Description 	: Create table script for SI_RESTRICTED_MARKETS table which will hold details of runtime 
--				  restrictions for allowable countries for a BusinessServiceID.
-- History 		: 27/09/2012 MA Initial inserts for IA-5, IA-61 and IA-67
--------------------------------------------------------------------------------------------------------

DROP TABLE SI_RESTRICTED_MARKETS;
  
CREATE TABLE SI_RESTRICTED_MARKETS
   (BUSINESS_SERVICE_ID 	VARCHAR2(45) NOT NULL, 
    ISO_CODE_2 	  	        VARCHAR2(2),
    ISO_CODE_3	    	    VARCHAR2(3),
	USER_ID					VARCHAR2(10));
	
ALTER TABLE SI_RESTRICTED_MARKETS ADD INSERT_TIMESTAMP TIMESTAMP;
ALTER TABLE SI_RESTRICTED_MARKETS ADD UPDATE_TIMESTAMP TIMESTAMP;					
   
COMMIT;
