--------------------------------------------------------------------------------------------------------
-- Author 		: Mike Arrowsmtih
-- Version 		: $Revision: 1.1 $
-- Description 	: Create trigger script for SI_RESTRICTED_MARKETS table which will hold details of runtime 
--				  restrictions for allowable countries for a BusinessServiceID.
-- History 		: 27/09/2012 MA Initial inserts for IA-5, IA-61 and IA-67
--------------------------------------------------------------------------------------------------------

DROP TRIGGER TRG_DEF_SI_RESTMRKT_TMSTMP_TRG;

--Trigger which will insert or update the timestamp if an insert or update action occurs
CREATE OR REPLACE
TRIGGER TRG_DEF_SI_RESTMRKT_TMSTMP_TRG
BEFORE INSERT OR UPDATE ON SI_RESTRICTED_MARKETS
FOR EACH ROW
BEGIN

IF INSERTING THEN
	:new.INSERT_TIMESTAMP := systimestamp;
	:new.UPDATE_TIMESTAMP := NULL;
ELSE
	:new.UPDATE_TIMESTAMP := systimestamp;
  END IF;
END;
/
COMMIT;
