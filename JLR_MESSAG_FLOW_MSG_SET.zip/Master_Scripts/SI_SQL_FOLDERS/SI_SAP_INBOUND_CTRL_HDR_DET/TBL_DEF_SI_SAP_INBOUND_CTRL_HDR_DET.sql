------------------------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: $Revision: 1.2 $
-- Description 	: Create table script for SI_SAP_INBOUND_CTRL_HDR_DET table which will hold IDOC Control Header records
-- History 		: 18/10/2012 Hina Mistry Initial create statement for table
--      		: 05/12/2012 Hina Mistry Table was missing the column BS_OUTPUT_DESTINATION as this is required where 
-- 										 a reply to queue needs to be set - in the instances where batch processing is used
------------------------------------------------------------------------------------------------------------------------

DROP TABLE SI_SAP_INBOUND_CTRL_HDR_DET;			   
							   
CREATE TABLE SI_SAP_INBOUND_CTRL_HDR_DET (SYSTEM_IDENTIFIER VARCHAR2(30) NOT NULL, 
							IDOCTYP VARCHAR2(30) NOT NULL, 
							MESTYP VARCHAR2(30) NOT NULL, 
							CIMTYP VARCHAR2(30), 
							MESCOD VARCHAR2(3),
							BS_INPUT_DESTINATION VARCHAR2(48),
							BS_OUTPUT_DESTINATION VARCHAR2(48),
							USER_ID VARCHAR2(10),
							INSERT_TIMESTAMP TIMESTAMP,
							UPDATE_TIMESTAMP TIMESTAMP);
COMMIT;
