------------------------------------------------------------------------------------------------------------------------
-- Author 		: Seenesh Patel
-- Version 		: $Revision: 1.1 $
-- Description 	: Create table script for SI_SAP_OUTBOUND_CTRL_HDR_DET table which will hold IDOC Control Header records
-- History 		: 03/01/2012 SP: Initial create statement for table
--				  11/01/2012 SP: Updated CONSTRAINT name as identifier was too large (max 30 char)
-- 				  28/06/2012 SP: Alteration to table to add additional column which will hold MESFCT
-- 				  28/06/2012 SP: Alteration to drop Primary Key as will be violated as more entries are added
-- 				  14/08/2012 Hina Mistry Addition of user id, insert/update timestamp columns
------------------------------------------------------------------------------------------------------------------------

DROP TABLE SI_SAP_OUTBOUND_CTRL_HDR_DET;			   
							   
CREATE TABLE SI_SAP_OUTBOUND_CTRL_HDR_DET (SYSTEM_ID VARCHAR2(30) NOT NULL, 
							IDOCTYP VARCHAR2(30) NOT NULL, 
							MESTYP VARCHAR2(30) NOT NULL, 
							CIMTYP VARCHAR2(30), 
							MESCOD VARCHAR2(3), 
							SNDPOR VARCHAR2(10), 
							SNDPRT VARCHAR2(2), 
							SNDPFC VARCHAR2(2), 
							SNDPRN VARCHAR2(10), 
							RCVPOR VARCHAR2(10), 
							RCVPRT VARCHAR2(2), 
							RCVPRN VARCHAR2(10), 
							RCVPFC VARCHAR2(2), 
							TABNAM VARCHAR2(10), 
							MANDT VARCHAR2(3),
							CONSTRAINT SI_SAP_OUTBOUND_CTRL_HDR__PK PRIMARY KEY 
							  (
							    SYSTEM_ID, 
							    IDOCTYP,
							    MESTYP
							  )
							  ENABLE );

							  
--28/06/2012 SP Alteration to table to add additional column which will hold MESFCT 
ALTER TABLE SI_SAP_OUTBOUND_CTRL_HDR_DET ADD MESFCT VARCHAR(3);

--28/06/2012 SP Alteration to drop Primary Key as will be violated as more entries are added
ALTER TABLE SI_SAP_OUTBOUND_CTRL_HDR_DET DROP PRIMARY KEY;

--14/08/2012 Hina Mistry Addition of user id, insert/update timestamp columns
ALTER TABLE SI_SAP_OUTBOUND_CTRL_HDR_DET ADD USER_ID VARCHAR2(10) NOT NULL;
ALTER TABLE SI_SAP_OUTBOUND_CTRL_HDR_DET ADD INSERT_TIMESTAMP TIMESTAMP;
ALTER TABLE SI_SAP_OUTBOUND_CTRL_HDR_DET ADD UPDATE_TIMESTAMP TIMESTAMP;


COMMIT;
