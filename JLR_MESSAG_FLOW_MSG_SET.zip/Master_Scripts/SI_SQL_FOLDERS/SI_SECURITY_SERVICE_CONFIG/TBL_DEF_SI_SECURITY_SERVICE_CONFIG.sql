--------------------------------------------------------------------------------------------------------
-- Author 		: Ravindra Babu
-- Version 		: $Revision: 1.3 $
-- Description 	: Create table script for SI_SECURITY_SERVICE_CONFIG table
-- History 		: 03/11/2015 Initial create statement for table
-- 		 		: 11/11/2015 Added BROKER_NAME column to the table.
-- 		 		: 13/11/2015 Added BROKER_NAME column to the Primary Key.
-------------------------------------------------------------------------------------------------------

DROP TABLE SI_SECURITY_SERVICE_CONFIG;

CREATE TABLE SI_SECURITY_SERVICE_CONFIG 
(BUSINESS_SERVICE_ID	VARCHAR2(50) NOT NULL,
ENFORCEMENT_ID  		VARCHAR2(30) NOT NULL,
ACTIVITY				VARCHAR2(30) NOT NULL,
ACTIVITY_SEQ 			NUMBER(2)	 NOT NULL,
STORE_LOCATION 			VARCHAR2(300),
STORE_PASS 				VARCHAR2(40),
KEY_ALIAS 				VARCHAR2(300),
KEY_PASS 				VARCHAR2(40),
PRIMARY_ALGORITHM 		VARCHAR2(40),
SECONDARY_ALGORITHM 	VARCHAR2(40),
ENVELOPE_FORMAT 		VARCHAR2(20),
META_DATA_1 			VARCHAR2(30),
META_DATA_2 			VARCHAR2(30),
META_DATA_3				VARCHAR2(30),
BROKER_NAME 			VARCHAR2(8),
ACTIVITY_DESCRIPTION	VARCHAR2(500),
USER_ID					VARCHAR2(10),
INSERT_TIMESTAMP		TIMESTAMP,
UPDATE_TIMESTAMP		TIMESTAMP,
CONSTRAINT "SI_SEC_CFG_PK" PRIMARY KEY (BUSINESS_SERVICE_ID, ENFORCEMENT_ID, ACTIVITY, ACTIVITY_SEQ, BROKER_NAME)) ;

COMMIT ;
