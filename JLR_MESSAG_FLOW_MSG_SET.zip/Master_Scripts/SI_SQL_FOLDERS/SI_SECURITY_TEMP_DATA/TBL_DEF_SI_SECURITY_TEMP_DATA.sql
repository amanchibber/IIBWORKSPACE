--------------------------------------------------------------------------------------------------------
-- Author 		: Prasad Panchagnula (ppancha3)
-- Version 		: $Revision: 1.2 $
-- Description 	: Create table script for SI_SECURITY_TEMP_DATA table which will hold batch records for
--				  HR Security Data business service
-- History 		: 25/09/2014 PP (ppancha3) Initial create statement for table
--------------------------------------------------------------------------------------------------------

DROP TABLE SI_SECURITY_TEMP_DATA;

CREATE TABLE "SI_SECURITY_TEMP_DATA" 
   (	"CHILD_OBJID" VARCHAR2(45), 
	"PARENT_SOBID" VARCHAR2(45), 
	"HRADMIN_SOBID" VARCHAR2(45), 
	"INSERT_TIMESTAMP" TIMESTAMP (6), 
	"RECORD_TYPE" VARCHAR2(5), 
	"PROCESSED" VARCHAR2(1), 
	"DOCNUM" VARCHAR2(45)
   );


DROP INDEX IDX_SI_SECURITY_TEMP_DATA_01;   
CREATE INDEX IDX_SI_SECURITY_TEMP_DATA_01 ON SI_SECURITY_TEMP_DATA (PROCESSED);
   
COMMIT;
