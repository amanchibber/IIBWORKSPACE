--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: $Revision: 1.570 $
-- Description 	: Create data script for SI_SERVICE_ROUTING table which will hold routing information
-- History 		: 14/08/2012 Hina Mistry Initial creation of master scripts
--				  14/08/2012 Hina Mistry Altering statement where user_id column is null
--				  15/08/2012 Mike Arrowsmith - Added entry for IA-89 Window Label (Monroney)
--				  22/08/2012 AH Addition of entries for IA 97:
--         		  28/08/2012 DT addition of entry for IA-000083
--            	  03/09/2012 VY addition of entry for IA-000061
--				  05/09/2012 KM addition of entry for Comercia Payments IA-70
--				  06/09/2012 Harshal Avhale added entries for IA 000065
--				  11/09/2012 SP Addition for IA-70 Drafts
--				  12/09/2012 AB Addition for IA-000099, HR Average Shift Employee Data
--				  13/09/2012 HM Addition of entry for IA 19 TSN Xref (GXS to SAP eSmart)
--				  13/09/2012 AS Addition of entry for IA 67 D42 Vehicle Events to SAP eSmart	 
--				  21/09/2012 AB Addition of entry for IA 76 D42 Caterpillar Accounts Receivable (CAT(NA/NON NA) to SAP eSMART)	
--				  27/09/2012 GG Addition of entry for IA 57 SAP ESMNA PortOpt To DDW
--				  27/09/2012 Mike Arrowsmith Added entries for IA-63
--				  03/10/2012 HM Addition of entry for IA 94 HR Position Data (SAP TURBO to Legacy)
--         		  03/10/2012 HA Addition of entry for SAP eSmart Certificate of Conformity Trigger to WVTA IA-15
--         		  11/10/2012 HM Addition of entry for IA-000290 HR Employee Data - Current Data (SAP TURBO to Legacy)
--          	  17/10/2012 AH Addition of entry for IA-000060 SAP Vehicle Stock Report to BBSS
--         		  18/10/2012 AH Addition of entry for IA-000086
--				  22/10/2012 AH Correction to above
--				  25/10/2012 SK entries for IA-000020 Vehicle Title Documents to KBA
--				  29/10/2012 VY entries for IA-000002 Monex Exchange rates to SAP turbo
--				  29/10/2012 HM Addition for IA-000293 Trade Union Data (Legacy to ESB to SAP)
--				  05/11/2012 CG Addition of entry for IA-000234
--				  07/11/2012 AS Addition for flow SI_BS_FGFSH_Credit_Limits_KJ03_To_SAP_ESMDE (entry for Smart)
--				  09/11/2012 HA Addition for SI_BS_SAP_ESMDE_INVOICE_FGFSH_KJ10KJ33
--				  12/11/2012 VY entries for IA-000155 warranty Safety recall
--				  15/11/2012 CM Amended entry for IA-000114
--				  20/11/2012 AT Addition of entry for IA-000138 (eSmart Germany)
--				  20/11/2012 AT Addition of entry for IA-000139/IA-000046 (eSmart Germany)
--				  20/11/2012 HM Alteration of entries for IA 97
--				  23/11/2012 AP Addition of entry for IA-000134
--				  23/11/2012 GG Addition of entry for IA-000132
--				  29/11/2012 GG Addition of entry for IA-000309
--				  11/12/2012 CM Addition of entry for IA-000267
--                18/12/2012 CG Addition of entry for IA 102
--                18/12/2012 PG Addition of entries for IA 87
--            	  19/12/2012 RB Splitting destinations for Jag and LR FiSH
--            	  21/12/2012 PG Addition of entries for IA 107
-- 			      24/12/2012 HM Correction to missing ; on SQL statements that caused the script to fail
--				  Removal of entry for IA 290, 94
-- 				  27/12/2012 AP entries for IA-000269 Security Access Control (SAP TURBO to PCARS)			
--				  04/01/2013 SP Uncommented entry for SI_BS_FGFSH_Credit_Limits_KJ03_To_SAP_ESMDE to route to Outbound ALE SMART Adapter
--				  11/01/2013 RG Updating queue for IA5 from MT BAPI adap to ST BAPI adap
--				  17/01/2013 HM Updating queue for IA257 from MT ALE adap to ST ALE adap
--                21/01/2013 AP Updating entry for IA-270 for PLO system
--                29/01/2013 CB IFU637 Changes to Canonical lookup
--                30/01/2013 AP D2300 IA-00049 MT change to ST adapter  
--             	  01/02/2013 AP entry of IA 330
-- 				  12/02/2013 KM Routing to Dummy Q for SI_BS_BRS_SALESORDER_ALL_PRCMATMAS to not impact SAP Turbo when BRS goes Live. Temporary change!!
--				  13/02/2013 AS Old IA-71 entry deleted, new entries added
--				  01/03/2013 RG Restoring previous entry, removing dummy entry
--                22/03/2013 CB IFU844 Revert to use old codes for INVEXP, INVDLR and EXCOVR 
--                22/03/2013 CB IFU844 Removing the previous change.  
--                26/03/2013 RG Changing adap names to point to correct ST SAP ADAP where required. IA330
--                26/03/2013 RG Changing adap names to point to correct ST SAP ADAP where required. IA52
--                26/03/2013 RG Changing JAVIS Billing Req back to old queue for prod and commented out!!!
--             	  28/03/2013 AP entry of IA 332
--             	  28/03/2013 RG correcting entry for IA309 back to MT SAP ADAP
--             	  28/03/2013 KM Added entries for HR_MULTIFILE
--                09/05/2012 AC entry of IA 156
--		 		 09/05/2013 SP Entries for IFU951
--			    10/05/2013 YG IA-104 Routing Enteries
--				  20/05/2013 AP IA-296 Routing Enteries
--		  		23/05/2013 YG IA-103 Routing Enteries
--		  		23/05/2013 SP Entries for IFU951
--		  		11/06/2013 HA IA-171 Routing Enteries
--		  		12/06/2013 YG IA-172 Routing Enteries
--		  		12/06/2013 GG IA-09 Routing Enteries
--				21/06/2013 SK FRS-271 Routing Entries
--				27/06/2013 AC IA-71 Routing Entry for DEUTSCHE Bank
--              28/06/2013 CG IA-234 Routing entry updated with new Service Identifier
--              22/07/2013 RB IFU-1088. Removed routing entry related to BDA of IA-74.
--              25/07/2013 YG IFU-1099. Ammended IA70 for CN02 to JLCN company code.
--              26/07/2013 RB FRS-260. Added entry for routing messages to Engineering Change Service.
--				26/07/2013 VA FRS-107. Added  Entry for Replicate Order Service and Entry for Order Replicate for Canonical Vehicle Adapter
--              02/08/2013 AP FRS261 Added  Entry for SI_BS_GXS_Vehicle_Parts_To_SAP_TRBGB  
--              02/08/2013 AP FRS261 Added  Entry for SI_BS_SAP_TRBGB_Vehicle_Parts_To_GXS
--              06/08/2013 AC Added Entry for FRS-108,FRS-116  
-- 				08/08/2013 Deepak Ingwale Added Entry for FRS-000009
-- 				08/08/2013 Saptarshi Goswami Added Entry for FRS-111
--              13/08/2013 Nisha Purohit Adding entry for FRS-109
--              21/08/2013 SP: Entries for FRS-110
--				21/08/2013 PK Added Entries for FRS-000029
--				26/08/2013 PK Updated Entries for FRS-000029
--              28/08/2013 Nisha Purohit Adding entry for FRS-122
--              29/08/2013 Saptarshi Goswami Adding entry for FRS-121
--              29/08/2013 GG Added Entry for FRS 352
--              29/08/2013 HA Added Entry for FRS 352(Vehicel Order Status)
--              11/09/2013 AC Added Entry for IA 124
--				25/09/2013 SB Added Entries for FRS-000113.
--              03/10/2013 Aparna Chaudhary Entry for IA 148
--              08/10/2013 Paul Gregory removed service routing for FRS-9 going to Enovia (this moved to SI_MQ_INBOUND_DETAILS)
--              08/10/2013 Gaurav Gawalu entry for IA-336
--				08/10/2013 AS Entries for FRS-383
--              09/10/2013 AC Entry for FRS 356
--              09/10/2013 SG Entry for FRS 128
--              14/10/2013 AP Entry for FRS 266
--				17/10/2013 Pratik Khot Added Entries for FRS-000017(Under IFU-1257)
--				21/10/2013 Entries for IA93
-- 				26/10/2013 HA - IA -122 Rounting for CITI bank updated(IFU 1277)
--				28/10/2013 Pratik Khot Added Entries for FRS-000073
--      		29/10/2013 SB Added Entries for FRS-000120.
--				30/10/2013 HA IA-09 IFU 1298 - BS_OUTPUT_DESTINATION Added
--				07/11/2013 SG Adding Entries for FRS-128
--				11/11/2013 RB Adding Entries for FRS-112
-- 				14/11/2013 TK Added Entries for FRS-119
--      		15/11/2013 NCH Added Entries for FRS-027
--      		15/11/2013 SS Added Entries for FRS-127
--      		18/11/2013 SG Updated entry for FRS-128
--      		19/11/2013 HM Added entry for FRS-380
--      		19/11/2013 SB Added entry for FRS-133
--      		19/11/2013 SK Added entry for IA-172
--     	 		20/11/2013 SM Added entry for FRS-123
--     	 		21/11/2013 SG Added entry for FRS-130
--     	 		21/11/2013 SG Updated BSID for FRS-128
--				21/11/2013 PG Updated entry for FRS-129
--     	 		22/11/2013 KM Added entry for FRS-117
--     	 		25/11/2013 SM Added entry for FRS-118
--				26/11/2013 PS Added entry for FRS-115
--				27/11/2013 SB Updated entry for FRS-133
--          	27/11/2013 SM Added Entries for FRS-000123
--      		01/12/2013 HM Added entries for FRS-139 - Service Flow
--      		02/12/2013 HM Added entries for FRS-139 - Canonical Adapters
--				02/12/2013 HM Updated entry for FRS-139
--              09/12/2013 HS Updated entry for FRS-083
--				12/12/2013 PG commented out two of the FRS-083 HTTP entries as only one to be active at a time
--				12/12/2013 AS IA-000163
-- 				16/12/2013 HA IA 158 Entries
-- 				17/12/2013 HA IA 158 Entries Updated
-- 				17/12/2013 PG FRS-083 Added one entry for Interim Solution 2 reply to HTTP queue
-- 				17/12/2013 PG FRS-083 Removed AGG entries
--				18/12/2013 SG IFU1422 / IFU1448 - Removed unnecessary entries
--				19/12/2013 HM IFU1478 Removed unnecessary entries for FRS-127
--				21/12/2013 GT IFU1424 Removed entries for FRS-123 As these are no more reuquired
--              02/01/2014 AC Entry changed for IA 49 ( made it to ST adapter)
--          	13/01/2014 NP Added Entries for FRS-000107(Warranty)
--				14/01/2014 PG IFU1562 adjusted FRS-000029 entry
--              14/01/2014 Hari Krishna Sabat Added entries for FRS-091(ACE_BRS_Deltas)
-- 				17/01/2014 HA Entries for FRS 353 added
--              20/01/2014 AC Entries for FRS 618 added
--      	    22/01/2014 Naresh Ch added entries for FRS-022
--				23/01/2014 PG Removed duplicate entries of FRS-083, routing for SI_SV_PRDSV_VISTASOLVE_REPLY also removed
--		        24/01/2014 Snehal Kolhe -Added Entry For FRS-123(Warranty)
--		        28/01/2014 Snehal Kolhe-Updated Entry for FRS-123(Warranty)
--			    03/02/2014 Samiksha Singh -added entry for IA-000271 (Warranty)
--			    06/06/2014 apathak2--Entry added for FRS-378
--              21/02/2014 AC Entry added for FRS 130.
--              21/02/2014 Amit Karma Added entry for FRS-000081
--              03/03/2014 Naresh CH Added entries for FRS-090(Expose BRSData (Derivative and Feature Feeds))
--              07/03/2014 Naresh CH Added entries for FRS-009(For the part of IFU 1749)
--				10/03/2014 PG FRS-000083 switched to stage 2
--				19/03/2014 SK added entries for IFU-1765 for IA-000074 as per the new services ASPEN and BYERS
--				26/03/2014 SK added entries for IFU-1782 for IA-000027 as per the new services Belgium and netherland
--              04/04/2014 SS added Entries for IA-000324 
--              09/04/2014 AaP added Entries for FRS-000621 
--              09/04/2014 Sk added Entries for FRS-000622
--              15/04/2014 AS IFU-1857, Entry commented out for SI_BS_BYCRK_BILLG_SAP_ESMUS_ACCREIV (Byers Creek deactivated)
--              17/04/2014 AC Added Entries for FRS-000626
--              17/04/2014 RBH Added Entries for IFU1813 - FRS-000266
--              21/04/2014 PK Added Entries for FRS-000018.
--              07/05/2014 GG Added Entries for IA-000094.
--				29/05/2014 HA Added for FRS 620\
--              30/05/2014 AaP Added Entries for IFU1898.
--              01/06/2014 SG Added Entries for FRS-136.
-- 				05/06/2014 RB Changes for IFU-2029. IA-172 Routing Enteries changed to SI_AD_SAP_TRBGB_BAPI_ST_Outbound
-- 				05/06/2014 RB Changes for IFU-2029 reverted.
-- 				09/06/2014 AC Changes for IFU-2031 Entry added for IA - 86
-- 				13/06/2014 RBH Changes for IFU-1981 Entry updated for IA-27
--				20/06/2014 HA added for IA - 05 Vista To SMART. Entry added
--				23/06/2014 HA added for IA - 61 PLO/D42 To SMART. Entry added
--				24/06/2014 HA added for IA - 61 HTTP Adapter to BS Flow
--				26/06/2014 HA added for IA - 67 Smart
--                              27/06/2014 AC Addition of entry for IA 122- defect 8323
--                              01/07/2014 AC Addition of entry For IA 05 - SMARt - IFU 2103
--                              01/07/2014 AC Entries added as per IFU 2103
--                              02/07/2014 AC Addition of entries for IFU 2103
--			    03/07/2014 AP FRS-261 Entry added for Http reply adapter as per IFU-2119
--			    08/07/2014 PG FRS-000130 SAP Turbo queue was ST. Updated to match design
--			    10/07/2014 GT FRS-000138 Replicate Vehicle Derivatives. Updated to match design
--			    15/07/2014 GG FRS-000633 Entry added
--			    15/07/2014 AC IFU 2103 Entry removed for IA-67 SMart and Esmart
--		        22/07/2014 AP FRS-632 Entry added.
--		        23/07/2014 TK Added entries for FRS-141
--		        31/07/2014 AK Added entries for FRS-615
--		        06/07/2014 AK Updated entries for FRS-615
--		        11/08/2014 Added entry for FRS-644
--              11/08/2014 SB Added Entries for FRS-000137.
--		        13/08/2014 NM Added entry for IA-258(IFU 2178)
--		        13/08/2014 SM Added entry for FRS-628
--		        19/08/2014 SP Added Routing entry to route FRS266 messages to new BAPI ON Outbound Adapter flow and commented out existing entry
--		        19/08/2014 SM Updated entry for FRS-628
--				20/08/2014 AP Added entry for FRS-272
--				20/08/2014 AaP Removed entry for FRS-621 as it now uses SI_SAP_INBOUND_CTRL_HDR_DET table entry
--				21/08/2014 TK Added for FRS-143
--				22/08/2014 AC Added for IA- 63 (IFU 2250)
--				27/08/2014 HA Added for FRS - 277 (IFU 2220,2227)
--              04/09/2014 NCH Added for FRS - 096 (Enovia TO MPNR)
--		        05/09/2014 NM Added entry for FRS-634(IFU 2278)
--		        09/09/2014 AK Added entries for FRS-631
--		        09/09/2014 AC Added entries for IA-122(IFU 2320)
--		        09/09/2014 GT Updated entries for FRS-115 as part of R2.0
--		        11/09/2014 SG Added entries for FRS-136 as part of R2.0
--		        11/09/2014 AC Added entries for IA- 122 as part IFU 2340
--		        15/09/2014 AP Removed entry for FRS-261(Delfor02) as part IFU 2361
--		        16/09/2014 GT Updated entries for FRS-115 as part of R2.0
--              18/09/2014 AaP Def-9126 Removed space from Service Identifier value
--              19/09/2014 AC IFU 2386 Entry to be removed as this flow wont be in use 
--              24/09/2014 TK Added entries for FRS 362
--		        30/09/2013 AaP IFU-2346 Entries for IA-124(ANZ system added)
--		        06/10/2014 AP Entry added for FRS-650
--				07/10/2014 PP  Entry added for business service 'SI_BS_SAP_TRBGB_HR_MSXI_SECRTYDATA' for incident INC000000122148
--				09/10/2014-SS Entry added for FRS-648
--              10/10/2014 SB Commented BMA entries for FRS-136 as part of IFU2438(R2.0)
-- 				20/10/2014 - SK Added entries for FRS 382-Part1(SAP to Canonical)
--              27/10/2014 -AaP Entry added for FRS-654
--              13/11/2014 AK  Added entries for FRS 364
--              18/11/2014 SG  Updated FRS-107 entries for INC000000230781 and INC000000197968
---				19/11/2014 NCH Entry added for FRS-000090(SI_FL_Product)
--				21/11/2014 - SP Defect 10513 - SERVICE_IDENTIFIER changed from ZI_WTYCLM to SapZiWtyclm1 for FRS382 entry
--				24/11/2014 MJ Added entries as per IFU- 2525
--				22/11/2014 PP FRS-000656 PartsPriceUpdate interface routing entry is added to route messages to SAP TRBGB TD Outbound adapter flow
---				25/11/2014 NCH Entry added for FRS-000090(SI_FL_Product)
---             26/11/2014 AK Added Entries for FRS 382 - 2B 
---             27/11/2014 SK Added Entries for FRS 382 - 2A SWORD 
---             27/11/2014 SM Added Entries for FRS 382 - 2C SMART 
--- 			27/11/2014 TK Added Entries for FRS 382 - 2D2 BWOOD
--- 			01/12/2014 PG Added Entries for FRS 382 - 2C1 AUTOA
--- 			01/12/2014 PG Added Entry for FRS 382 Part 2B1 and 2D1 -  SYC1
--- 			08/12/2014 SS Updated Entry for FRS-00382 for Def 11001
--- 			06/01/2015 SM Added Entry for FRS-00118(R1.2)
---				07/01/2015 AB Added Entry for FRS-00128(R1.2)
---             09/01/2015 SB Added Entry for FRS-00112(R1.2)
---				09/01/2015 YT IFU-2614 Updated Entry for IA-220(BSID value changed)
---				09/01/2015 AS Added Entry for FRS-000117(R1.2)
---				09/01/2015 YT Updated BSID and input destination under IFU-2613 in IA-143
-- 				12/01/2015 YT Addition of Entry for IFU 2615 
-- 				15/01/2015 TK Addition of Entry for FRS 139
-- 				21/01/2015 AK Updated entries for  FRS 631
-- 				23/01/2015 NM Updated entries for  FRS 660
--                              28/01/2015 AC Added entries as per IFU 2593
--                              03/02/2015 MJ Added entry for IFU 2658- FRS 626
-- 				19/02/2015 SB Added entries for  FRS 148
--				25/02/2015 KS Added entries for FRS-000147
--				09/03/2015 AaP IFU-2803 New payments to Scotia
--				10/03/2015 nch added entries for IFU2708 for FRS000091(Under SI_FL_Product,existing entries for FRS000091 under SI_FL_Vehicle)
--				11/03/2015 abasak added entries for IFU2785 for FRS000137
--				12/03/2015 SA added entries for FRS000670
--				19/03/2015 KT FRS-260. Updated BS_INPUT_DESTINATION and INTERFACE_TYPE as per design change
--              26/03/2015 MJ Added entries for FRS000695
--              31/03/2015 PK Added additional entry for FRS-000009 IFU-2901
--				08/04/2015 PT Added entries for FRS000669
--				16/04/2015  KT Added entries for FRS-000271
--				16/04/2015  VV Added entries for FRS-000693
--              16/04/2015  MJ Updated entry for FRS000695
--              17/04/2015 PK Added entries for FRS-000015
--				21/04/2015 NC Added entries for FRS-000681
--				22/04/2015 YR added entries for IFU-2936 ( FRS - 000382)
--				22/04/2015 VP added entries for FRS-667
--	            29/04/2015 NM Added entries for IA-323 as per IFU 2857
--				04-May-2015 AaP added entries for FRS-705
--              05/05/2015 YT Added entires for IA-000005
--              07/05/2015 NM IFU- 3012 Changed BS_INPUT_DESTINATION from SI.AD.HTTP.OUT to SI.AD.HTTP.V2.OUT
--				11/05/2015 PM Added entries for IFU-2873
--				13/05/2015 SB Added entries for FRS-000680(Quarantine Status To MES)
--				14/05/2015 RB Modified entry for FRS-000681 to route messages through FRS-271.
--				14/05/2015 VV Added entries for FRS-000716 to route messages through FRS-000716.
--				19/05/2015 PM Updated entries for IFU-2873
--  			20/05/2015 YR added entries for NCR Response( FRS - 000680)
--  			20/05/2015 NM added entry for TD SAP to PLO Interface( FRS - 000711)
--  			21/05/2015 RB Added entries for FRS-000690
--				21/05/2015 PP FRS-000656 PartsPriceUpdate interface routing entry is amended to have SERVICE_IDENTIFIER as NULL instead of '-TO BE ADDED-'
--				21/05/2015 VP updated entries for FRS-667
-- 				25/05/2015 AaP Added entries for FRS-000711
-- 				26/05/2015 PM  Added entries for FRS-000712
--				27/05/2015 VB  Entry for FRS-000111 as per IFU3019
-- 				01/06/2015 RB  Added entries for FRS-000715
--              08/06/2015 NM Added BS_OUTPUT_DESTINATION value to both JAG and LR entries as per defect 12102
-- 				09/06/2015 SB updated entries for IFU3099(FRS-000680)
--				18/06/2015 KT Added entries for FRS-000679
--				18/06/2015 AS Added entry for FRS-000707
-- 				22/06/2015 SB Added entry for FRS680(Vehicle Genealogy To Multiple Systems)
--              25/06/2015 VP IFU3107 changes
--              25/06/2015 YR FRS 261 changes for Stone
--				30/06/2015 SP FRS670: Amended BAPI Inbound SERVICE_IDENTIFIER entry from  SapZfiRfcCustomBrokerFile to SapZfiRfcCustomBrokerFileWrapper
--				09/07/2015 PM Updated the service identifier from SapZiQnSim01 to SapZiQnsim01 for FRS-705
-- 				15/07/2015 SB Updated the BS_INPUT_DESTINATION with MES.BR.SENDNOTNUM.OUT as per the DEF14606 for FRS716(Fault_Alarm_Notification)
--              15/07/2015 SB updated BS_INPUT_DESTINATION with MES.BR.UPDMAINTACK.OUT under Maintenance for FRS716(Update_Status) 
--				21/07/2015 HB Added New entry for FRS731
--				21/07/2015 NM Added New entry for FRS668
--              23/07/2015 VP insert statements for business service : SI_BS_SAP_TRBGB_DEALER_DLRPL_REMITTANCE1 : IFU3231
--				31/07/2015 VV Added New entry for IFU 3190 (FRS-718)
--				05/08/2015 NC Added New entry for FRS719
--				10/08/2015 PG FRS-000712 The HTTP Inbound/Reply entries had a leading '/' on the service_identifier. Not correct so removed
--				11/08/2015 PG FRS-000712 IFU3043 updates applied
--				19/08/2015 KT IFU3263 FRS-000271 - FFCP request for CJLR will be sent to Local queue in ESB Switch queuemanager
--				03/09/2015 HB FRS-000271 - Added new entry for 'FFE2' -- IFU3362
--				24/09/2015 SB IA-170 - Added new entry as per IFU3382
--				08/10/2015 SN FRS670 - Added new entry as per IFU3429 
--              14/10/2015 VP FRS-000271 - Modified entry for 'FFE2' -- IFU3472
--				21/10/2015 AM Entry for BODS to be deleted for FRS000015 IFU3443
--				04/11/2015 AaP IFU3504 switch to direct delivery to CJLR Switch QM queue (change in BS_INPUT_DESTINATION Q)
--				05/11/2015 SN Added new entry for FRS721
--				12/11/2015 AT Added new entry for FRS689 
--				16/11/2015 SN Added entry for IA-172 as part of IFU3539
--				20/11/2015 NC Added entries for IA-000172
--				23/11/2015 SB Added entry for FRS258(IFU3534)
--				25/11/2015 MJ Added entries for IA 27 (IFU 3557)
--				25/11/2015 NC commented entries ESB is not using these entries (IFU3539).We are using only one(SI_BS_PAYRL_GLENTRY_SAP_TRB) entry instead of 8.
--				08/12/2015 NC Added entries for FRS669(Vehicle import declaration)
--				09/12/2015 SP DEF16585 � IA-44 URL to be updated to match IC-000147
--				09/12/2015 SP DEF16585 � Removed previous change, update to design doc only is required as prod value already matches
--				10/12/2015 SB Added entries for FRS670(Vehicle Information to TITO)
--				14/12/2015 SB Updated entries for FRS670(Vehicle Information to TITO)
--				16/12/2015 KT Added entries for FRS-000803
--				23/12/15   KV Added entries for FRS-722 After Market Order feed
--              23/12/15   KV Added entries for FRS-722 After Market OrderResponse
--              22/12/2015 PM Entries for FRS 130 IFU35454
--				29/12/2015 KT FRS-000271/FRS-000803 SI.BS.WERS.ENGCHANGE.TO.DUMMY.OUT queue is configured temporarily. Messages in this queue can be cleared manually.
-- 				13/07/2016 HB FRS-000807 - Added entries for OA Code Translation Service
--              25/01/2016 SN FRS661 - Added entry for FRS661
--              01/02/2016 LH added entry for FRS-000802
--				02/02/2016 KT IFU3691 - Amended routing entry for FRS-000271/FRS-000803 (deleted entry for FRS-000803)
--              17/02/2016 KV Added entries for FRS 653 
--              22/02/2016 VV IFU 3681 Added entries for FRS-000693
--				24/02/2016 KV Updated entries for FRS 653
--              03/03/2016 VP Added entry for FRS-811
-- 				03/03/2016 PM Entries for FRS 638 Development
-- 				04/03/2016 NM Entries for FRS 795 Development
--				08/03/2016 LH Added entries for IFU3759 , IA-000122
--              15/03/2016 PK Removed insert query for IFU3771
--              16/03/2016 NM FRS 795 One entry deleted and SERVICE_IDENTIFIER changed as per Design update
-- 				17/03/2016 PM Entry added as per FRS-812 Development
--				25/03/2016 KT IFU3806 FRS-000271 BOM Filtered FFPJ data to Plant Graz
--				23/03/2016 HB Added New entry for FRS 810
--				08/04/2016 KT IFU3815 FRS-000271 Amend routing entry to route FFPJ to PGZ via MQ Outbound Adapter.
--				13/04/2016 HB Added missing entry for adapter Def-18078
--				18/04/2016 KB Added entry for FRS-000690 IFU3829
--              21/04/2016 PK Added entries for FRS-809
--				29/04/2016 KB Added entry for FRS-000813 
--              03/05/2016 AM Added entry for FRS-000038(IFU 3816)
--				09/05/2016 KB Added entry for FRS-000814
--				11/05/2016 KB Added entries for FRS-000817
--				16/05/2016 NB Added entries for FRS-000815
-- 				16/05/2016 HB Added New entry for FRS 818
--				16/06/2016 KB Updated entry for FRS-000690 IFU3986
--              27/06/2016 AT Added for FRS-000107(IFU 3897 OCRM) 
-- 				28/06/2016 PK Added for FRS-000820
-- 				01/07/2016 KB Added for FRS-000819
-- 				11/07/2016 NB Added new entries for FRS-000372(IFU3913, IFU3955)
-- 				19/07/2016 LH Removed routing entries as per desing change for INC000001504510 FRS-362.
-- 				28/07/2016 NB: Added entries for FRS-000371(IFU3928)
--              29/07/2016 NM Added entry for IFU4012/INC000001564937 IA-122
--				01/08/2016 VV Commented the entries for FRS-113, FRS-119, FRS-120, FRS-121 and FRS-122 as per IFU-4064
--				05/08/2016 HB Removed IA-000269 entry as a part of IFU-4068
-- 				08/09/2016 HB Updated Entry for FRS-818 as per IFU-4055
--				18/08/2016 KB updated for FRS-632
--				19/08/2016 KB updated queue name for IA-44 
--				24/08/2016 KB Added entry for SPC messages FRS-000815  

--				30/08/2016 MG Addition for IA-000293 Trade Union Data (Legacy to ESB to SAP)

--				30/08/2016 AT Added entry for IA-000099  


--              02/09/2016 HV added entry for IA-000148 
--              07/09/2016 MJ IFU-4084 Entries for IA-124(Citibank Korea system added)
--				13/09/2016 KT IFU4139 FRS-000271/FRS-000803 Removed entry for FFPJ routing from FRS271 to FRS803.
--				13/09/2016 PP IFU4126 Deleted service routing entries for HPFM, FVF3, LISA and BOBBE batch interfaces for IA-27
--              16/09/2016 NM: Added entry for FRS-000828
--				20/09/2016 KB  Updated queues for BSID SI_BS_MATFL_VEHICLE_GXS_PARTREQ, SI_BS_GXS_VEHICLE_MATFL_DELCONF, FRS-712
--              27/09/2016 SN updated routing entry for IA-95
--              29/09/2016 NB Added routing entry for FRS-000833
--              05/09/2016 SK added antries for FRS-000154 for IFU4148
--				07/10/2016 KB Added entry for FRS-000837 
-- 				13/10/2016 SS Updated entries for FRS-115 as part of IFU4177
--				18/10/2016 NB Entry added and updated business service name and input destination for FRS-261(IFU4163)
--				07/11/2016 HB Removed/Commented unwanted routing entries for IA-52 IFU-4097
-- 				08/11/2016 AM Added entries for IA258 as part of IFU4140/4141
--				08/11/2016 PP IFU3907 IA-27 Migration to new batch framework. Deleted unused routing entries (mostly for the BATCH interfaces)
--              18/11/2016 VVS Added new Entries for FRS-000155 as per the IFU4236
--              24/11/2016 SK Added new Entries for FRS-000156 as per the IFU4244
-- 				02/12/2016 AT Added new Entries for FRS-000153 as per the IFU4255
-- 				12/12/2016 MJ Def20298 Commented FRS261 entry for SapDelvry07 as it is present in SAP Inbound table.
--				14/12/2016 PM Addition of entries for IA 74. Other all entries are removed as part of IFU4179
--				14/12/2016 MJ Routing entry added under FRS-841
--				15/12/2016 HV added new entry for FRS-271 as part of New interface for GTS(FRS-000823)
--              19/12/2016 removed below entries as these are not required as part of IA-000221
--              22/12/2016 AM added new entry for IA 27 as a part of IFU4330 
-- 				16/01/2017 CD Added New entry for FRS-000838
--				25/01/2017 HV updated entry for IA-000148
-- 				28/01/2017 NB Added Entry for Encore Program IFU4253(FRS-000620)
-- 				30/01/2017 CD Added New entry for FRS-000817(IFU4373)
--              10/02/2017 KV Commented Service routing entry as it is shifted to New build FRS 661(IFU 4365)
--              18/02/2017 LH Added Initial Entry for FRS-786
--              01/03/2017 NM Added routing entry for IA-52 IFU-4428
-- 				09/03/2017 AS SI_BS_MFT_Invoice_Ack_To_SAP_TRBBR no longer exists, as been removed as part of IFU3563 long back!
--				23/03/2017 asannag2 IA-000065 never went to PROD, commenting the entry
--              07/04/2017 SK IFU4533 :Added entries for newly destination 'SAPVMS' entries for VVO
--				07/04/2017 VB IFU4565:Commented below entries as the OSH is no more required
--				07/04/2017 VB IFU4565:Commented entries for OSH
--              21/04/2017 AT renoved entries as part of IFU4590
--              21/04/2017 AT Removed entries as part of IFU4590 FRS-138
--              21/04/2017 AT Removed entries as part of IFU4591
--				21/04/2017 AM Added routing entry for PODs Interface IA107
--             	02/05/2017 VK Removed entries after Framework migration of FRS-273.
--				10/05/2017 KB  Updated BSID and queue name according to design change IFU4582
--              04/08/2017 NM IA-115 Entry no more required. Interface moved to new build framework
--				07/08/2017 PM Entries added as per FRS-868 Development
--              19/09/2017 KV Added service routing entry for FRS-000681 as part of IFU4902
--				10/11/2017 KB Added routing entry for IA122
--				29/11/2017 PM Updated entry as per IFU4179. IA-75 is now using V2 outbound sap adapter
-------------------------------------------------------------------------------------------------------------------------
DELETE FROM SI_SERVICE_ROUTING;

--PM 07/08/2017 Entries added as per FRS-868 Development
--Inbound Bapi adapter
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRB_BAPI', 'BAPI_INBOUND', 'SapZfmTranslateLongTextWrapper','SI_AD_SAP_TRB_RFC_10_BAPIIN','SI.BS.SAP.TRB.WTYLANGT.TO.SDL.IN',null,null,null,'pmondal','FRS-000868, SAP TRB Warranty Lang Trnslt To SDL');


INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_INBOUND', 'SapZsapVtdTriggerDeif011','SI_SAPE1_VEH_INVOICES_VTDDE','SAP.INVOICES.TO.VTD.BS.IN','VTD.TRIGGER.BATCH.MSG.FRM.SCHED.IN',null,null,'kmccorma','Entry for the VTD Trigger interface between SAP eSmart and VTD');

--29/12/2011 HM addition of entries for interface: SAP_eSmart_Vehicle_Invoices_Credits_and_OUV_To_JAVIS.msgflow
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('JAVIS_FTP_OUT_1','FTP_OUTBOUND','VEH_INVOICE','SI_SAPE1_BILLG_INVCEOUV_OUT','FTP.OUTBOUND.JAVIS.ST.IN',null,null,null,'hmistry','Entry for FTP JAVIS outbound adapter');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_ESM_ALE','ALE_INBOUND','SapZsapJavisDeif10','SI_SAPE1_BILLG_INVCEOUV_IN','JAVIS.VEHICLE.INVOICE.OUV.BS.IN','JAVIS.VEHICLE.INVOICE.OUV.BATCH.IN',null,null,'hmistry','Entry for Invoice OUV eSmart interface');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_ESM_ALE','ALE_INBOUND','SapZsapJavisOuvDeif16','SI_SAPE1_BILLG_INVCEOUV_IN','JAVIS.VEHICLE.INVOICE.OUV.BS.IN','JAVIS.VEHICLE.INVOICE.OUV.BATCH.IN',null,null,'hmistry','Entry for Invoice OUV eSmart interface');

-- 5/1/2012 KM addition of entries for SAP_eSmart_Billing_Confirmation_To_JAVIS.msgflow
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_ESM_ALE','ALE_INBOUND','SapFidccp02Zcustinv','SI_SAPE1_BILLG_JAVIS_BILINGCONF_IN','SAP.TO.JAVIS.BILLING.CONFIRMATION.IN','BILL.CONF.BATCH.MSG.FRM.SCHED.IN',null,null,'kmccorma','SAP ALE Inbound routing entry to LEGACY JAVIS system');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_ESM_ALE','ALE_INBOUND','SapFidccp02ZcustinvOut','SI_SAPE1_BILLG_JAVIS_BILINGCONF_OUT','FTP.OUTBOUND.JAVIS.ST.IN',null,null,null,'kmccorma','SAP ALE Inbound routing entry to LEGACY JAVIS system');
-- END of addtion KM

-- RG DO NOT HAND THIS OVER!! This is still the old entry in PROD!!! "SAP.ALE.OUT.ADAP.IN"
-- 6/1/2012 SP addition of entries for JAVIS_Billing_Requests_To_SAP_eSmart.msgflow
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_ESM_ALE','ALE_OUTBOUND','SapFidccp02Zcustinv','SI_JAVIS_BILLG_SAPE1_INVOICEREQ','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'spatel5','Route to SAP Outbound Adapter');
-- END of addtion SP

-- 11/1/2012 OI addition of entries for interface: SAP_eSmart_Vehicle_Invoices_To_VTD 
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_INBOUND', 'SapZsapVtdTriggerDeif011L','SI_SAPE1_VEH_INVOICES_VTDDE','SAP.INVOICES.TO.VTD.BS.IN','VTD.TRIGGER.BATCH.MSG.FRM.SCHED.IN',null,null,'kmccorma','Entry for the VTD Trigger interface between SAP eSmart and VTD');

-- 11/04/2012 MA addition of entries for interface: SAP_Smart_Vehicle_Status_To_MFT_ChinaDMS
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_SMTCN_BAPI','BAPI_INBOUND','SapZjlrcnDmsIntVehicleStatusWrapper','SI_AD_SAP_SMTCN_BAPI_INBOUND','SI.BS.SAP.SMTCN.VEHICLESTAT.TO.DMS.IN',null,null,null,'marrowsm','Route to ESB MQ service.');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('MFT_FTP_OUT_1','FTP_OUTBOUND','VEH_STATUS','SI_BS_SAP_SMTCN_VSTAT_MFT_CHINADMS','SI.AD.MQ.ESB.TO.MFT.OUT',null,null,null,'marrowsm','Route from ESB MQ service to MFT.');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_SMTCN_BAPI','GENERIC_REPLY','SapZjlrcnDmsIntVehicleStatusWrapper','SI_BS_SAP_SMTCN_VSTAT_MFT_CHINADMS','SI.AD.MQ.ESB.GENERIC.TO.SAP.OUT',null,null,null,'marrowsm','Route from ESB MQ service to SAP Reply.');
-- END OF addition MA

-- 12/04/2012 RG addition of entries for adapter flow SI_ADAPTER_SAP_TRBUK_BAPI_ST_Inbound
--	29/04/2015 NM Removed entries for IA-323 as per IFU 2857
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_INBOUND', 'SapZbapiFiHyperionWrapper','SI_AD_SAP_TRBGB_MQSERV_BAPIIN','SI.BS.SAP.TRB.FINANRPT.TO.HYPRON.IN',null,null,null,'rglackli','Entry for the SAP Financial Report BAPI SapZbapiFiHyperion interface between SAP Turbo and Hyperion');
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_INBOUND', 'SapZbapiFiHyperionIcWrapper','SI_AD_SAP_TRBGB_MQSERV_BAPIIN','SI.BS.SAP.TRB.FINANRPT.TO.HYPRON.IN',null,null,null,'rglackli','Entry for the SAP Financial Report BAPI SapZbapiFiHyperionic interface between SAP Turbo and Hyperion');

-- 22/05/2012 VY Initial insert statements for table for business service : SI_BS_SAP_SMACN_VEHICLE_DMS_PRICINGINF
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) Values('SAP_SMTCN_BAPI','BAPI_INBOUND','SapZjlrcnDmsIntPriceInfoWrapper','SI_BS_SAP_SMACN_VEHICLE_DMS_PRICINGINF','SI.BS.SAP.SMACN.PRICINGINF.TO.DMS.IN','vyadav1','Route to ESB MQ service -- Pricing info');  
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) Values('SAP_SMTCN_BAPI','GENERIC_REPLY','SapZjlrcnDmsIntPriceInfoWrapper','SI_BS_SAP_SMACN_VEHICLE_DMS_PRICINGINF','SI.AD.MQ.ESB.GENERIC.TO.SAP.OUT','vyadav1','Route to ESB MQ service -- SAP Reply');  
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) Values('MFT_FTP_OUT_1','FTP_OUTBOUND','PRICINGINFO','SI_BS_SAP_SMACN_VEHICLE_DMS_PRICINGINF','SI.AD.MQ.ESB.TO.MFT.OUT','vyadav1','Route from ESB MQ service to MFT -- Pricing info');
-- END of addition VY

-- 06/06/2012 DT addition of entries for IA000193 - SI_BS_SAP_SMACN_DEALER_DMS_DEALERDATA
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_SMTCN_BAPI','BAPI_INBOUND','SapZjlrcnDmsIntDealerMasterWrapper','SI_BS_SAP_SMACN_DEALER_DMS_DEALERDATA','SI.BS.SAP.SMACN.DEALERDATA.TO.DMS.IN',null,null,null,'dthomps1','Route to ESB MQ service -- Dealer Data');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('MFT_FTP_OUT_1','FTP_OUTBOUND','DLR_DATA','SI_BS_SAP_SMACN_DEALER_DMS_DEALERDATA','SI.AD.MQ.ESB.TO.MFT.OUT',null,null,null,'dthomps1','Route from ESB MQ service to MFT -- Dealer Data');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_SMTCN_BAPI','GENERIC_REPLY','SapZjlrcnDmsIntDealerMasterWrapper','SI_BS_SAP_SMACN_DEALER_DMS_DEALERDATA','SI.AD.MQ.ESB.GENERIC.TO.SAP.OUT',null,null,null,'dthomps1','Route from ESB MQ service to SAP Reply.');

--21/06/2012 AB Insert statement for IA000223 demo conversion
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'SapZbapiO2cFishkj13','SI_BS_FGFSH_VEHICLE_SAP_TRBGB_KJ13','SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'hmistry','Entry for FISH KJ13 interface');

--21/06/2012 SK Insert statement for IA000224 Credit Limit KJ03
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'SapZbapiFiKj03Creditlimit','SI_BS_FGFSH_DEALER_SAP_TRBGB_KJ03','SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'hmistry','Entry for FGFSH KJ03 interface for SAP Turbo Wave 0A');

--21/06/2012 CG Insert statement for IA000220 Payment Confirmation KJ09
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'SapZbapiSdFishkj09','SI_BS_FGFSH_INVOICE_SAP_TRBGB_KJ09_PCONF','SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'kmccorma','Entry for FISH KJ09 interface');

-- NM 16/01/2018 Commented the old flow entry as this is no more required
--27/06/2012 SP Insert statement for SAP_BACS_Payment_To_EigerPay interface
/* INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_INBOUND', 'SapZfiRfcF110BacsSap2eigerWrapper','SI_BS_SAP_TRBGB_PAYMT_EIPAY_BACSFILE','SI.BS.SAP.TRBGB.BACS.TO.EIPAY.IN',null,null,null,'spatel5','Route BACS Payments to EigerPay'); */

-- 29/06/2012 DT addition of entries for IA000170 - SI_BS_SAP_TRBGB_VehAlertUpdate_To_Multiple_Systems
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('PLO_MQ_OUT_1','MQ_OUTBOUND','VEH_ALERT','SI_BS_SAP_TRBGB_VEH_PLO_ALERTUPD','SI.AD.PLO.OUT',null,null,null,'dthomps1','SAP Turbo routing to PLO MQ Outbound Adapter for Vehicle Alert Updates');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('D42_HTTP_OUT_1','HTTP_OUTBOUND','VEH_ALERT','SI_BS_SAP_TRBGB_VEH_D42_ALERTUPD','SI.AD.HTTP.OUT',null,null,null,'dthomps1','SAP Turbo routing to D42 MQ Outbound Adapter for Vehicle Alert Updates');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_TRBGB_ALE','ALE_INBOUND','SapZiVehordr01','SI_BS_SAP_TRBGB_VEH_ALL_ALERTUPD','SI.BS.SAP.TRBGB.VEHALERTUPD.TO.ALL.IN',null,null,null,'dthomps1','SAP Turbo routing to Business Service Flow for Vehicle Alert Updates');

-- 29/06/2012 VY for will be used by HTTP inbound adapter
-- 20/02/2017 - The above entry, corresponding to HTTP_INBOUND will hence forth be owned by the inbound adapter flow component sql file, commented for IA-000142
--INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) Values ('ESB_HTTP_1','HTTP_INBOUND','Vehicle/ShipmentDetails','SI_BS_D42_VEH_SAP_TRBGB_SHIPPINGREF','SI.BS.D42.SHIPINGREF.TO.SAP.TRBGB.IN','vyadav1','Route to ESB MQ service -- Shipping_Reference');  
				
--29/06/2012 HM Addition of entries for IA 46 (KJ12) and IA 257 (Profet).  Original insert statement moved to the master file
--10/05/2013 SP. Note: The entry below for KJ12 can be removed once the IFU951 entries have been added. (Please remove below commented details when implementing IFU951. BSID: SI_BS_FGFSH_FUNDACCEPT_SAP_TRBGB_KJ12)
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'SapZbapiFiFishkj12','SI_BS_FGFSH_FUNDACCEPT_SAP_TRBGB_KJ12','SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'hmistry','Entry for the FGAFS KJ12 entry for SAP Turbo Wave 0A');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE', 'ALE_OUTBOUND', ' ','SI_BS_PROFT_VEHICLE_SAP_TRBGB_CLASCONFMT','SI.AD.SAP.TRBGB.ALE.OUT',null,null,null,'hmistry','Entry for the Profet Class and Config Mat interface to SAP Turbo Wave 0A');
			
-- 02/07/2012 RB Addition of entry for IA29. Original insert statement moved to the master file
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER, INTERFACE_TYPE, SERVICE_IDENTIFIER, BUSINESS_SERVICE_ID, BS_INPUT_DESTINATION, BS_OUTPUT_DESTINATION, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID, DESCRIPTION) VALUES ('PLO_MQ_OUT_2', 'MQ_OUTBOUND', 'ALL', 'SI_BS_PLO_SALESORDER_SAP_TRBGB_VEHORDRQ', 'SI.AD.PLO.OUT', NULL, NULL, NULL, 'rbabu', 'Route Vehice Order Response Message from to PLO MQ Outbound Adapter');

-- 02/07/2012 RB Addition of entry for IA34. Original insert statement moved to the master file
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER, INTERFACE_TYPE, SERVICE_IDENTIFIER, BUSINESS_SERVICE_ID, BS_INPUT_DESTINATION, BS_OUTPUT_DESTINATION, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID, DESCRIPTION) Values ('PLO_MQ_OUT_1', 'MQ_OUTBOUND', 'ALL', 'SI_BS_BRS_SALESORDER_PLO_MDUPD', 'SI.AD.PLO.OUT', NULL, NULL, NULL, 'rbabu', 'Route Master Data Update Message from BRS to PLO MQ Outbound Adapter');

-- 02/07/2012 VY for HTTP Reply for 'SI_BS_D42_VEH_SAP_TRBGB_SHIPPINGREF'
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) Values ('ESB_HTTP_1','HTTP_REPLY','Vehicle/ShipmentDetails','SI_BS_D42_VEH_SAP_TRBGB_SHIPPINGREF','SI.AD.HTTP.DISTRIBUTION.REPLY.IN','vyadav1','HTTP Reply to D42'); 

-- 02/07/2012 VY for PLO  'SI_BS_BRS_SALESORDER_ALL_PRCMATMAS'
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) Values ('PLO_MQ_OUT_1','MQ_OUTBOUND','NA','SI_BS_BRS_SALESORDER_ALL_PRCMATMAS','SI.AD.PLO.OUT','vyadav1','Route to PLO MQ Outbound Adapter');  

-- 02/07/2012 VY for SAP Turbo 'SI_BS_BRS_SALESORDER_ALL_PRCMATMAS'
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) Values ('SAP_TRBGB_ALE','ALE_OUTBOUND','ALL','SI_BS_BRS_SALESORDER_ALL_PRCMATMAS','SI.AD.SAP.TRBGB.ALE.OUT','vyadav1','Route to SAP Turbo ALE Outbound Adapter');  
  

-- 5/7/2012 KM addition of entries for SI_BS_BRS_VehSpecsDeriv_To_SAP_ESM
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_ESM_ALE','ALE_OUTBOUND','MATMAS05','SI_BS_BRS_VEH_SAP_ESM_VEHSPECSDERIV','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'kmccorma','Route to SAP ESMALL ALE Outbound Adapter');

-- 5/7/2012 KM addition of entries for SI_BS_BRS_VehSpecsFeat_To_SAP_ESM
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_ESM_ALE','ALE_OUTBOUND','CHRMAS04','SI_BS_BRS_VEH_SAP_ESM_VEHSPECSFEAT','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'kmccorma','Route to SAP ESMALL ALE Outbound Adapter');

-- 5/7/2012 AS addition of entries for SI_BS_D42_ExpDeclarations_To_RICARDO
-- 19/12/2016 removed below entries as these are not required as part of IA-000221
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('ESB_HTTP_1','HTTP_INBOUND','Vehicle/ExportDeclarations','SI_BS_D42_HMRC_RIC_EXPDECL','SI.BS.D42.EXPDECL.TO.RIC.IN',null,null,null,'asannago','Route to ESB MQ service -- ExportDeclarations');
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('ESB_HTTP_1','HTTP_REPLY','Vehicle/ExportDeclarations','SI_BS_D42_HMRC_RIC_EXPDECL','SI.AD.HTTP.DISTRIBUTION.REPLY.IN',null,null,null,'asannago','HTTP Reply to D42');

-- 12/07/2012 VY for SAP Turbo 'SI_BS_SAP_TRBGB_HMRC_ALL_CSMSREPORT'
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) Values('SAP_TRBGB_ALE','ALE_INBOUND','SapZicustoms','SI_BS_SAP_TRBGB_HMRC_ALL_CSMSREPORT','SI.BS.SAP.TRBGB.CSMSRPRT.TO.MULTI.IN','vyadav1','Route to SI_BS_SAP_TRBGB_Customs_Reports_To_Multiple flow');  

-- 12/07/2012 KM insert statements for business service : SI_BS_SAP_TRBGB_DEALER_DLRPL_REMITTANCE
-- INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) Values('SAP_TRBGB_BAPI','BAPI_INBOUND','SapZfiRfcF110ToDealerPortalWrapper','SI_BS_SAP_TRBGB_DEALER_DLRPL_REMITTANCE','SI.BS.SAP.TRBGB.REMITTANCE.TO.DLRPL.IN','kmccorma','Routing entry for SI_BS_SAP_TRBGB_Remittance_To_DLRPL');  
-- 23/07/2015 VP insert statements for business service : SI_BS_SAP_TRBGB_DEALER_DLRPL_REMITTANCE1 : IFU3231
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) Values('SAP_TRBGB_BAPI','BAPI_INBOUND','SapZfiRfcF110ToDealerPortalWrapper','SI_BS_SAP_TRBGB_DEALER_DLRPL_REMITTANCE1','SI.BS.SAP.TRBGB.REMITTNEWSERV.TO.DLRPL.IN','vprasad1','Routing entry for SI_BS_SAP_TRBGB_Remittance_NewServ_To_DLRPL');  

-- 16/07/2012 AS insert statements for flow/BSID: SI_BS_D42_Vehicle_Status_Update_To_SAP_TRBGB/SI_BS_D42_VEH_SAP_TRBGB_VEHSTATUSUPD
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) Values ('ESB_HTTP_1','HTTP_INBOUND','Vehicle/vehiclestatussync','SI_BS_D42_VEH_SAP_TRBGB_VEHSTATUSUPD','SI.BS.D42.VEHSTATUPD.TO.SAP.TRBGB.IN','asannago','HTTP Inbound Routing for D42 to SAP for Vehicle Status Updates');
--19/08/2016 KB updated queue name for IA-44  
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) Values ('ESB_HTTP_1','HTTP_REPLY','Vehicle/vehiclestatussync','SI_BS_D42_VEH_SAP_TRBGB_VEHSTATUSUPD','SI.AD.D42.HTTP.VEHSTSUPD.REPLY.IN','asannago','HTTP Reply Routing for messages being set to the HTTP Reply Adapter'); 

-- 20/07/2012 MA insert statements for IA-27
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE','ALE_INBOUND','SapInvoic02Ziinvcrdt','SI_AD_SAP_TRBGB_MQSERV_ALEIN','SI.BS.SAP.TRBGB.INVCRDDETS.TO.ALL.OUT',null,null,null,'marrowsm','Entry for SAP to ESB for Invoice Credits');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_HTTP_1','HTTP_OUTBOUND','VISTA','SI_BS_SAP_TRBGB_INVCRDDETS_VISTA','SI.AD.HTTP.OUT',null,null,null,'marrowsm','Entry for SAP to VISTA feed over HTTP');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_HTTP_1','HTTP_OUTBOUND','D42','SI_BS_SAP_TRBGB_INVCRDDETS_D42','SI.AD.HTTP.OUT',null,null,null,'marrowsm','Entry for SAP to D42 feed over HTTP');

-- 13/06/2014 RBH Updated for IFU-1981
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_MULTI_BATCH','MQ_OUTBOUND','ESMDE','SI_BS_SAP_TRBGB_INVCRDDETS_ESMDE','SI.BS.SAP.TRBGB.INVCRDDETS.TO.ESMALL.IN',null,null,null,'marrowsm','Entry for SAP to eSmart Germany Invoice and Credit transform flow');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_MULTI_BATCH','MQ_OUTBOUND','ESMDT','SI_BS_SAP_TRBGB_INVCRDDETS_ESMIT','SI.BS.SAP.TRBGB.INVCRDDETS.TO.ESMALL.IN',null,null,null,'rbabu','Entry for SAP to eSmart Italy Invoice and Credit transform flow');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_MULTI_BATCH','MQ_OUTBOUND','ESMUS','SI_BS_SAP_TRBGB_INVCRDDETS_ESMUS','SI.BS.SAP.TRBGB.INVCRDDETS.TO.ESMALL.IN',null,null,null,'marrowsm','Entry for SAP to eSmart America Invoice and Credit transform flow');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_MULTI_BATCH','MQ_OUTBOUND','D42','SI_BS_SAP_TRBGB_INVCRDDETS_D42','SI.BS.SAP.TRBGB.INVCRDDETS.TO.D42.IN',null,null,null,'marrowsm','Entry for SAP to D42 Invoice and Credit transform flow');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_MULTI_BATCH','MQ_OUTBOUND','VISTA','SI_BS_SAP_TRBGB_INVCRDDETS_VISTA','SI.BS.SAP.TRBGB.INVCRDDETS.TO.VISTA.IN',null,null,null,'marrowsm','Entry for SAP to VISTA Invoice and Credit transform flow');

--24/07/2012 HM Addition of entries for IA 45: IA-000045 Vehicle Transfers Update (DSM, NVM and Vista to SAP).  Original insert statement moved to the master file
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('HUB2_MQ_OUT_1', 'MQ_OUTBOUND', 'VEHICLE_TRANSFER','SI_BS_ALL_VEHSERV_TO_ALL_VEHTRNSUPD','SI.AD.HUB2.OUT',null,null,null,'hmistry','Entry for the IA 45 for SAP Turbo Wave 0B');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_HTTP_1', 'HTTP_REPLY', 'Vehicle/VehicleTransferUpdate','SI_BS_ALL_VEHSERV_TO_ALL_VEHTRNSUPD','SI.AD.HTTP.DISTRIBUTION.REPLY.IN',null,null,null,'hmistry','Entry for the IA 45 for SAP Turbo Wave 0B');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_HTTP_1', 'HTTP_INBOUND', 'Vehicle/VehicleTransferUpdate','SI_BS_ALL_VEHSERV_TO_ALL_VEHTRNSUPD','SI.BS.DSM.VEHTRANSUPD.TO.SAP.TRBGB.IN',null,null,null,'hmistry','Entry for the IA 45 for SAP Turbo Wave 0B');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('NVM_MQ_OUT_1', 'MQ_OUTBOUND', 'VEHICLE_TRANSFER','SI_BS_ALL_VEHSERV_TO_ALL_VEHTRNSUPD','SI.AD.NVM.OUT',null,null,null,'hmistry','Entry for the IA 45 for SAP Turbo Wave 0B');

--31/07/2012 SP Addition of entries for IA 219:
INSERT into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_TRBGB_BAPI','BAPI_OUTBOUND','SapZo2cFmVmedata','SI_BS_CBCMD_DEALER_SAP_TRBGB_BONUSPYMT','SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'spatel5','Routing Entry to Route ZO2C_FM_VDMDATA BAPI to the SAP BAPI Outbound router');

--31/07/2012 CM Addition of entries for IA 05: IA-000005 VISTA GOF to eSMART
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESMALL_BAPI', 'BAPI_OUTBOUND', 'SapZvmVistaFromEsb','SI_BS_VISTA_SALESORDER_SAP_ESM_GOFVISTA','SI.AD.SAP.ESMALL.BAPIST.OUT',null,null,null,'cmarett','SAP DE BAPI Outbound entry for VISTA General Order Files for VISTA BAPI');

--01/08/2012 GG Addition of entries for IA000270 VISTA to SAP
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'SapZo2cFmVistavusg','SI_BS_VISTA_SALESORDER_ALL_NONSPECAMD','SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'ggawali','Route Plan Code BAPI request to SAP Turbo BAPI Outbound Adapter');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('D3_MQ_OUT_1', 'MQ_OUTBOUND', 'NON_SPEC_AMEND','SI_BS_VISTA_SALESORDER_ALL_NONSPECAMD','SI.AD.D3.OUT',null,null,null,'ggawali','Route VISTA Non Spec Amends to D3 MQ Outbound Adapter');

--01/08/2012 AH Addition of SAP Vehicle Status to Canonical IA-09
-- 06/11/2012 VY service Identifier changed
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE','ALE_INBOUND','SapZvistaD42OutIf','SI_AD_SAP_ESMALL_ALEIN','SI.AD.CANONICAL.VEHICLE.STATUS.IN',null,null,null,'ahirst2','SAP ESM inbound adapter entry for Vehicle Status to Canonical Adapter');

--02/08/2012 AS Addition for flow SI_BS_FGFSH_Credit_Limits_KJ03_To_SAP_ESMDE 
-- 12/01/2015 YT Addition of Entry for IFU 2615 
--INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE','ALE_OUTBOUND','SapZidocFga','SI_BS_FGFSH_DEALER_SAP_ESMDE_KJ03','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'asannago','SAP ESM outbound adapter entry for FGFSH_Credit_Limits_KJ03_To_SAP_ESMDE');
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE','ALE_OUTBOUND','SapZidocFga','SI_BS_FGFSH_DEALER_SAP_ESMALL_KJ03','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'asannago','SAP ESM outbound adapter entry for FGFSH_Credit_Limits_KJ03_To_SAP_ESMALL');

--14/12/2016 PM Removed entries as per IFU4179
--29/06/2012 HM Addition of entries for IA 74
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'AccntRec_DealerTire','SI_BS_DTIRE_BILLG_SAP_ESMUS_ACCREIV','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'hmistry','Dealer Tire Accounts Receivable to Sap eSmart');
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'AccntRec_NAVTEQ','SI_BS_NAVTQ_BILLG_SAP_ESMUS_ACCREIV','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'hmistry','NAVTEQ Accounts Receivable to Sap eSmart');
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'AccntRec_WURTH','SI_BS_WURTH_BILLG_SAP_ESMUS_ACCREIV','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'hmistry','WURTH Accounts Receivable to Sap eSmart');

-- 22/07/2013 RB IFU-1088. Removed routing entry related to BDA of IA-74.
-- INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'AccntRec_BDA','SI_BS_BDA_BILLG_SAP_ESMUS_ACCREIV','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'hmistry','BDA Accounts Receivable to Sap eSmart');
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'AccntRec_MINACS','SI_BS_MNACS_BILLG_SAP_ESMUS_ACCREIV','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'hmistry','MINACS Accounts Receivable to Sap eSmart');
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'AccntRec_CreativePartners','SI_BS_CRPTR_BILLG_SAP_ESMUS_ACCREIV','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'hmistry','Creative Partners Accounts Receivable to Sap eSmart');
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'AccntRec_ShiftDigital','SI_BS_SHFTD_BILLG_SAP_ESMUS_ACCREIV','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'hmistry','Shift Digital Accounts Receivable to Sap eSmart');
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'AccntRec_BBSS','SI_BS_BBSS_BILLG_SAP_ESMUS_ACCREIV','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'hmistry','BBSS Accounts Receivable to Sap eSmart');

-- 03/08/2012 AH Addition of Vehicle Status to VISTA IA-09
-- 10/08/2012 AH Updated after code review
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_HTTP_1','HTTP_OUTBOUND','VEH_STATUS','SI_BS_CANON_VEHSERV_VISTA_VEHSTATUS','SI.AD.HTTP.OUT',null,null,null,'ahirst2','Entry for Canonical Events to VISTA over HTTP');

--03/08/2012 RB Addition of Customer Details Routing for IA-52
--07/11/2016 HB Removed/Commented unwanted routing entries for IA-52 IFU-4097
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE','ALE_OUTBOUND','CUSTOMER_DETAILS','SI_BS_BBSS_CUSTOMER_ALL_CUSTDETALS','SI.AD.SAP.ESMALL.ALEST.OUT',null,null,null,'rbabu','Entry for the BBSS Customer Detail to SAP eSmart');
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('MFT_FTP_OUT_1','FTP_OUTBOUND','CUSTOMER_DETAILS','SI_BS_BBSS_CUSTOMER_ALL_CUSTDETALS','SI.AD.MFT.OUT',null,null,null,'rbabu','Entry for the BBSS Customer Detail to MFT');
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('WAJ1_FTP_OUT_1','FTP_OUTBOUND','CUSTOMER_DETAILS','SI_BS_BBSS_CUSTOMER_ALL_CUSTDETALS','SI.AD.WAJ1.OUT',null,null,null,'rbabu','Entry for the BBSS Customer Detail to DDW');
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('DDW_FTP_OUT_1','FTP_OUTBOUND','CUSTOMER_DETAILS','SI_BS_BBSS_CUSTOMER_ALL_CUSTDETALS','SI.AD.DDW.OUT',null,null,null,'rbabu','Entry for the BBSS Customer Detail to WAJ1');

--06/08/2012 HA Addition of Accounts payable to esmart IA-75
--29/11/2017 PM Updated entry as per IFU4179. IA-75 is now using V2 outbound sap adapter
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE','ALE_OUTBOUND','FIDCCP02','SI_BS_ALL_INV_SAP_ESMUS_ACCPAY','SI.AD.SAP.ESMALL.ALE.OUT.V2',null,null,null,'pmondal','Route to eSmart US ALE outbound adapter');

--06/08/2012 VY Routing for -IA-00049
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) Values('MNRNY_MQ_OUT_1','MQ_OUTBOUND','VEH_DATA','SI_BS_BBSS_VEHSERV_ALL_VEHDATA','SI.AD.MNRNY.OUT','vyadav1','Route BBSS Vehicle Data to Monroney MQ Outbound Adapter');
--02/01/2014 AC Entry changed for IA 49
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) Values('SAP_ESM_ALE','ALE_OUTBOUND','VEH_DATA','SI_BS_BBSS_VEHSERV_ALL_VEHDATA','SI.AD.SAP.ESMALL.ALEST.OUT','vyadav1','Route Vehicle Data IDoc to SAP eSmart All ALE Outbound Adapter');

-- 13/08/2012 AS addition of entries for SI_BS_SAP_TRBGB_BulkInvShip_To_SAP_ESM flow
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE','ALE_OUTBOUND','ZBULK_INV_IDOC','SI_BS_SAP_TRBGB_INVOICE_SAP_ESM_BULKSHIP','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'abadal','Route to SAP ESMALL ALE Outbound Adapter � BulkInvShip');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_TRBGB_ALE','ALE_INBOUND','SapInvoic02Zibulkinv','SI_BS_SAP_TRBGB_INVOICE_SAP_ESM_BULKSHIP','SI.BS.SAP.TRBGB.BULKINVSHIP.TO.SAP.ESM.IN',null,null,null,'asannago','SAP TURBO Routing to SI_BS_SAP_TRBGB_BulkInvShip_To_SAP_ESM flow');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('ZA_FTP_OUT_1','FTP_OUTBOUND','BULK_INV_SHIP','SI_BS_SAP_TRBGB_INVOICE_SAP_ESM_BULKSHIP','SI.AD.SAP.ESMZA.FTP.OUT',null,null,null,'asannago','Route from ESB MQ service to SA FTP -- BulkInvShip');

--14/08/2012: Multiple_Systems_HR_AverageShift_To_SAP_TRBGB
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER, INTERFACE_TYPE, SERVICE_IDENTIFIER, BUSINESS_SERVICE_ID, BS_INPUT_DESTINATION, BS_OUTPUT_DESTINATION, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID, DESCRIPTION) Values ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'TBC', 'SI_BS_ALL_HR_TO_SAP_AVGSHIFT _IN', 'SI.AD.SAP.TRBGB.BAPI.OUT', NULL, NULL, NULL, 'tbc', 'HR Average Shift to SAP Turbo UK');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER, INTERFACE_TYPE, SERVICE_IDENTIFIER, BUSINESS_SERVICE_ID, BS_INPUT_DESTINATION, BS_OUTPUT_DESTINATION, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID, DESCRIPTION) Values ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'TBC', 'SI_EPICS_BILLG_SAPE1_EXPORTINV', 'SI.AD.SAP.ESMALL.ALE.OUT', NULL, NULL, NULL, 'tbc', 'SAP ALE Outbound entry for EPICS Export Invoices');


--15/08/2012 Mike Arrowsmith - Added entry for IA-89 Window Label (Monroney)
INSERT INTO WMBOWNER.SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('MNRNY_MQ_OUT_1','MQ_OUTBOUND','WINDOW_LABEL','SI_BS_SAP_ESMUS_VEH_MNRNY_WINDOWLABEL','SI.AD.MNRNY.OUT',null,null,null,'marrowsm','Routing entry to Monroney MQ Outbound Adapter for Vehicle Window Labels');
INSERT INTO WMBOWNER.SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE','ALE_INBOUND','SapZidocEguidMonr','SI_BS_SAP_ESMUS_VEH_MNRNY_WINDOWLABEL','SI.BS.SAP.ESMUS.WINDOWLABEL.TO.MNRNY.IN',null,null,null,'marrowsm','SAP US ALE routing entry to Business Service Flow to process Vehicle Window Labels');

--22/08/2012 AH Addition of entries for IA 97:
INSERT into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_TRBGB_ALE','ALE_OUTBOUND','SapZiHr044201','SI_BS_HR_CVMS_EMPLOYEE_TRBGB_VEHICLES','SI.AD.SAP.TRBGBHR.ALE.OUT',null,null,null,'ahirst2','Routing Entry to Route ZBAPI_HR_IT0442 BAPI to the SAP BAPI Outbound router');

--28/08/2012 DTHOMPS1 Addition of entries for IA-000083:
INSERT into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_ESM_ALE','ALE_INBOUND','SapZvmsVldIdoce','SI_BS_SAP_ESM_VEH_ALL_VEHLEVELDET','SI.BS.SAP.ESM.VEHLEVELDET.TO.ALL.IN',null,null,null,'dthomps1','SAP ESM ALE routing entry to Business Service Flow to process Vehicle Level Details');
INSERT into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('PVOS_MQ_OUT_1','MQ_OUTBOUND','VEHICLE_LEVEL_DETAIL','SI_BS_SAP_ESM_VEH_PVOS_VEHLEVELDET','SI.AD.PVOS.OUT',null,null,null,'dthomps1','Routing entry to PVOS MQ Outbound Adapter for Vehicle Level Details');
INSERT into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('AUTOP_MQ_OUT_1','MQ_OUTBOUND','VEHICLE_LEVEL_DETAIL','SI_BS_SAP_ESM_VEH_ALL_VEHLEVELDET','SI.AD.AUTOP.OUT',null,null,null,'dthomps1','Routing entry to Autoport MQ Outbound Adapter for Vehicle Level Details');


--03/09/2012 VY Routing for -IA-000061
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) Values ('ESB_HTTP_1','HTTP_INBOUND','Vehicle/VehiclePlanning','SI_BS_ALL_MISCSERV_ALL_PLANEVENT','SI.BS.MULTI.PLANINGEVENT.TO.MULTI.IN','vyadav1','PlaningEvents');  
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) Values('SAP_ESM_ALE','ALE_OUTBOUND','SapZplanningStatus','SI_BS_ALL_MISCSERV_ALL_PLANEVENT','SI.AD.SAP.ESMALL.ALE.OUT','vyadav1','Route PlanningEvents IDoc to SAP eSmart ALE Outbound Adapter');
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES ('D3_MQ_OUT_1','MQ_OUTBOUND','NA','SI_BS_ALL_MISCSERV_ALL_PLANEVENT','SI.AD.D3.OUT','vyadav1','Route Planning Events to D3 MQ Outbound Adapter');
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES ('ESB_HTTP_1','HTTP_OUTBOUND','NA','SI_BS_ALL_MISCSERV_ALL_PLANEVENT','SI.AD.HTTP.OUT','vyadav1','Entry for Planning Events to VISTA feed over HTTP');
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) Values ('ESB_HTTP_1','HTTP_REPLY','Vehicle/VehiclePlanning','SI_BS_ALL_MISCSERV_ALL_PLANEVENT','SI.AD.HTTP.DISTRIBUTION.REPLY.IN','vyadav1','HTTP Reply to D42 for Planning events');

--05/09/2012 RB Addition of Cost Centre Routing for IA-95
--27/09/2016 SN updated routing entry for IA-95 Removed BS_OUTPUT_DESTINATION as this is not required in new framework
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE','ALE_INBOUND','SapCoscor01','SI_BS_SAP_TRB_HR_ALL_COSTCENTRE','SI.BS.SAP.TRBGB.COSTCTR.TO.ALL.IN',null,null,null,'snidumuk','Route to SI_BS_SAP_TRBGB_CostCentre_To_MultipleSystems flow');

--09/03/2015 AaP IFU-2803 New payments to Scotia
-- 05/09/2012 KM Addition of Comercia Payments fir IA 70
-- 12/7/2013 YG Update the existing enteries for IA-70 as per the new design 
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_ESMALL_BAPI','BAPI_INBOUND','SapZfiF110XmlToEsbWrapper_US02','SI_BS_SAP_ESM_PAYMT_COMER_BNKTRNPYMT','SI.BS.SAP.ESM.BANKTRANSPYMTS.TO.COMER.IN','SI.BS.SAP.ESM.BANKTRANSPYMTS.TO.COMER.BATCH',null,null,'kmccorma','SAP eSmart Routing to SI_BS_SAP_ESM_BankTransactionSentPymts_To_COMERCIA flow');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_ESMALL_BAPI','BAPI_INBOUND','SapZfiF110XmlToEsbWrapper_US02','SI_BS_SAP_ESM_PAYMT_COMORSCOT_BNKTRNPYMT','SI.BS.SAP.ESM.BANKTRANSPYMTS.TO.COMORSCOT.IN','SI.BS.SAP.ESM.BANKTRANSPYMTS.TO.COMER.BATCH',null,null,'apanjiya','SAP eSmart Routing to SI_BS_SAP_ESM_BankTransactionSentPymts_To_COMERCIA flow');

--HA 06/09/2012 Entry for IA 000065
-- 23/03/2017 AS IA-000065 never went to PROD, commenting the entries
--INSERT INTO WMBOWNER.SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'VISTA_GOF','SI_BS_VISTA_VEHICLE_SAP_ESM_GOFSTRAGIC','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'havhale','SI_BS_VISTA_Strategic_GeneralOrderFile_TO_SAP_ESM (Vista GOF to SAP eSmart');

-- SP 11/09/2012 SP Addition for IA-70 Drafts
INSERT INTO WMBOWNER.SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_INBOUND', 'SapZvehicleDrafting','SI_BS_SAP_ESM_PAYMT_ALL_BNKTRNDRFT','SI.BS.SAP.ESM.BANKTRANSDFTS.TO.ALL.IN','SI.BS.SAP.ESM.BANKTRANSDFTS.TO.ALL.BATCH',null,null,'spatel5','SAP ESM ALE routing entry to Business Service Flow to process Draft Bank Transactions');

--11/09/2012 CM Addition of entries for IA-000114, SAP Payments to JP Morgan	
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI','BAPI_INBOUND','SapZfiRfcF110BacsSap2jpmWrapper','SI_BS_SAP_TRBGB_PAYMT_JPMOR_AUTOPAYMNT','SI.BS.SAP.TRBGB.AUTOPYMTFILE.TO.JPMOR.IN',null,null,null,'cmarrett','Route Automatic Payments to JPMorgan');


--12/09/2012 AB Addition of entries for IA-000099, HR Average Shift Employee Data	
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE','ALE_OUTBOUND','SapZiHr001401','SI_BS_ALL_HR_TO_SAP_TRGB_AVGSHIFT','SI.AD.SAP.TRBGBHR.ALE.OUT',null,null,null,'abadal','HR Average Shift to SAP Turbo UK');

--13/09/2012 HM Addition of entries for IA 19 TSN Xref (GXS to SAP eSmart)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESMDE_BAPI', 'BAPI_OUTBOUND', 'SapZbapiVmTsnAloc','SI_BS_KBAGX_VEHSERV_SAP_ESMDE_TSNXREF','SI.AD.SAP.ESMALL.BAPI.OUT',null,null,null,'hmistry','Entry for the IA 19 KBA to SAP ESM');

--13/09/2012 AS Addition of entries for IA-67, D42 Vehicle Events to SAP eSmart
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_HTTP_1', 'HTTP_INBOUND', 'Vehicle/vehiclestatusupdate','SI_BS_D42_VEH_SAP_ESMALL_VEHEVENTS','SI.AD.CANONICAL.VEHICLE.STATUS.IN',null,null,null,'asannago','HTTP Inbound Routing for D42 to SAP eSmart for Vehicle Events');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'VEH_STAT', 'Vehicle/vehiclestatusupdate','SI_BS_CANON_VEH_STATUS','SI.BS.D42.VEHEVENTS.TO.SAP.ESMALL.IN',null,null,null,'asannago','Canonical Translation for D42 to SAP eSmart for Vehicle Events');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'SapZstatusPlngIdoc','SI_BS_D42_VEH_SAP_ESMALL_VEHEVENTS','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'asannago','SAP ALE Outbound entry for D42 Vehicle Events');
-- IFU 2103 AC Entry to be removed
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_HTTP_1', 'HTTP_REPLY', 'Vehicle/vehiclestatusupdate','SI_BS_D42_VEH_SAP_ESMALL_VEHEVENTS','SI.AD.HTTP.DISTRIBUTION.REPLY.IN',null,null,null,'asannago','HTTP reply entry for D42 Vehicle Events');

--29/01/2013 CB IFU637 Canonical lookup HTTP response
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_HTTP_1', 'HTTP_REPLY', 'Vehicle/vehiclestatusupdate','SI_BS_CANON_VEH_STATUS','SI.AD.HTTP.DISTRIBUTION.REPLY.IN',null,null,null,'cburger1','HTTP Reply for Vehicle Events for invalid event code');

--13/09/2012 CG  Addition of entries for IA-000090,New Vehicle Info Printing to Monroney Detailed Design
INSERT INTO WMBOWNER.SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE','ALE_INBOUND','SapZidocCoNavis','SI_BS_SAP_ESMUS_VEH_MNRNY_INFOPRINT','SI.BS.SAP.ESMUS.VEHINFOPRINT.TO.MNRNY.IN','SI.BS.SAP.ESMUS.VEHINFOPRINT.TO.MNRNY.BATCH',null,null,'cgundlap','SAP ALE routing entry to Business Service Flow to process New Vehicle Printing Information.');

--21/09/2012 AB  Addition of entries for IA-000076,Caterpillar Accounts Receivable (CAT(NA/NON NA) to SAP eSMART)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_BAPI','BAPI_OUTBOUND','CATPR_NA_ACNTRECV','SI_BS_CATPR_INVOICE_SAP_ESM_ACNTRECVNA','SI.AD.SAP.ESMALL.BAPI.OUT',null,null,null,'abadal','SAP BAPI OUTBOUND entry to business service flow to process Caterpillar AccntReceivable file for North America ');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_BAPI','BAPI_OUTBOUND','CATPR_ACNTRECV','SI_BS_CATPR_INVOICE_SAP_ESM_ACNTRECV','SI.AD.SAP.ESMALL.BAPI.OUT',null,null,null,'abadal','SAP BAPI OUTBOUND entry to business service flow to process Caterpillar AccntReceivable file for NON North America ');

--27/09/2012 GG  Addition of entries for IA-000057,ESB SAP ESM PortUpdatedOpt To DDW Detailed Design
INSERT INTO WMBOWNER.SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE','ALE_INBOUND','SapZvmsIdocDdwOut','SI_BS_SAP_ESM_VEHICLE_DDW_PORTOPT','SI.BS.SAP.ESMNA.PORTOPT.DDW.IN',null,null,null,'ggawali','Route to SI_BS_SAP_ESMNA_PortOpt_To_DDW flow');

--27/09/2012 MA Addition of entries for IA-63
INSERT INTO WMBOWNER.SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE','ALE_OUTBOUND','Warranty_Claim_FromMultipleSystems','SI_BS_ALL_INVOICE_SAP_ESM_WRNTYBILLG','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'marrowsm','Multiple Systems Warranty Claim Billing to SAP eSmart');
INSERT INTO WMBOWNER.SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE','ALE_OUTBOUND','Warranty_Claim_FromLISA','SI_BS_LISA_INVOICE_SAP_ESM_WRNTYBILLG','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'marrowsm','LISA Warranty Claim Billing to SAP eSmart');
INSERT INTO WMBOWNER.SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE','ALE_OUTBOUND','Warranty_Claim_FromGACES','SI_BS_GACES_INVOICE_SAP_ESM_WRNTYBILLG','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'marrowsm','GACES Jag Warranty Claim Billing to SAP eSmart');

--24/09/2012 HM Addition of entries for IA 94 HR Position Data (SAP TURBO to Legacy)
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE', 'ALE_INBOUND', 'SapZiHrmdA06','SI_BS_SAP_TRB_HR_ALL_POSITION','SI.BS.SAP.TRBGB.POSDATA.TO.ALL.IN','SI.BS.SAP.TRBGB.POSDATA.TO.ALL.BATCH',null,null,'hmistry','Entry for the IA 94 SAP TRB HR to MS');

--11/10/2012 HM Addition of entries for IA-000290 HR Employee Data - Current Data (SAP TURBO to Legacy)
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE', 'ALE_INBOUND', 'CUREMPDATA','SI_BS_SAP_TRB_HR_ALL_CUREMPDATA','SI.BS.SAP.TRBGB.CUREMPDATA.TO.ALL.IN','SI.BS.SAP.TRBGB.CUREMPDATA.TO.ALL.BATCH',null,null,'hmistry','Entry for the IA 290 SAP TRB HR to MS');

--11/10/2012 GG Addition of entries for IA-000066 
INSERT INTO WMBOWNER.SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESMALL_BAPI', 'BAPI_INBOUND', 'SapZrfcPremierDocsWrapper','SI_BS_SAP_ESM_INVOICE_PRM_FINDOCS','SI.BS.SAP.ESMNA.FINDOC.PRM.IN',null,null,null,'ggawali','Route to  SI_BS_SAP_ESMNA_FinDocs_To_PremierDocs flow');

--17/10/2012 AH Addition of entry for IA-000060
INSERT INTO "WMBOWNER"."SI_SERVICE_ROUTING" (SYSTEM_IDENTIFIER, INTERFACE_TYPE, SERVICE_IDENTIFIER, BUSINESS_SERVICE_ID, BS_INPUT_DESTINATION, BS_OUTPUT_DESTINATION, USER_ID, DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_INBOUND', 'SapZvmsVsrBbss', 'SI_BS_SAP_ESM_VEHICLE_BBSS_VEHSTKREP', 'SI.BS.SAP.ESM.VEHSTKREP.TO.BBSS.IN', '', 'hirsta', 'Routes SAP Vehicle Stock Reports IDoc to BBSS flow');

--18/10/2012 AH Addition of entry for IA-000086. 10/02/2014 - Entry does not look like it is being used. Entry not in design and interface not using ALE_INBOUND
INSERT INTO "WMBOWNER"."SI_SERVICE_ROUTING" (SYSTEM_IDENTIFIER, INTERFACE_TYPE, SERVICE_IDENTIFIER, BUSINESS_SERVICE_ID, BS_INPUT_DESTINATION, BS_OUTPUT_DESTINATION, USER_ID, DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_INBOUND', 'SapZpvosVehicleStatus', 'SI_BS_ALL_VEHICLE_SAP_ESM_STATUSUPD', 'SI.AD.SAP.ESMALL.ALE.OUT',  null, 'hirsta', 'Route PVOS and AutoPort Vehicle Status Updates in IDoc to SAP eSmart ALE Outbound Adapter');

--25/10/2012 CG Addition of entry for IA-000007
INSERT INTO WMBOWNER.SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'SapZwvta','SI_BS_WVTA_VEH_SAP_ESM_HOMOLGTION','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'cgundlap','WVTA Homologation Data to SAP Outbound ALE Adapter');


--25/10/2012 SK Addition of entries for IA-000020 Vehicle Title Documents to KBA
--08/06/2015 NM Added BS_OUTPUT_DESTINATION value to both JAG and LR entries as per defect 12102
INSERT INTO "WMBOWNER"."SI_SERVICE_ROUTING" (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_INBOUND', 'SapZvmKbaOutJag','SI_BS_SAP_ESM_VEH_KBA_TITLEDOCDE','SI.BS.SAP.ESM.VEHTITLEDOC.TO.KBA.IN','SI.BS.SAP.ESM.VEHTITLEDOC.TO.KBA.BATCH',null,null,'skarri','Entry for the IA 20 SAP KBA vehicle title documents');
INSERT INTO "WMBOWNER"."SI_SERVICE_ROUTING" (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_INBOUND', 'SapZvmKbaOutLr','SI_BS_SAP_ESM_VEH_KBA_TITLEDOCDE','SI.BS.SAP.ESM.VEHTITLEDOC.TO.KBA.IN','SI.BS.SAP.ESM.VEHTITLEDOC.TO.KBA.BATCH',null,null,'skarri','Entry for the IA 20 SAP KBA vehicle title documents');


--26/10/2012 KM Addition of entries for IA-000062 Monex Exchange Rates to SAP eSmart
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('MONEX_XRATE_FTP', 'FTP_INBOUND', 'TBC','SI_AD_MONEX_FTP_IN','SI.BS.MONEX.EXCHANGERATES.TO.SAP.ESM.IN',null,null,null,'kmccorma','Entry for the IA 62 Monex to SAP eSmart');

--29/10/2012 VY Addition of entries for IA-000002 Monex Exchange Rates to SAP turbo
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('MONEX_XRATE_FTP', 'FTP_INBOUND', 'TBC1','SI_AD_MONEX_FTP_IN','SI.BS.MONEX.EXCHANGERATES.TO.SAP.TRBGB.IN',null,null,null,'vyadav1','Entry for the IA 02 Monex to SAP turbo');

--29/10/2012 HA Addition of SAP eSmart Certificate of Conformity to WVTA  IA 15
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_ESM_ALE','ALE_INBOUND','SapZwvtaCocJag','SI_BS_SAP_ESM_VEH_WVTA_COCTRIG','SI.BS.SAP.ESM.COCTRIG.TO.WVTA.IN',null,null,null,'havhale','Routing Entry to Route CoC Triggers to the associated Business Service');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_ESM_ALE','ALE_INBOUND','SapZwvtaCocLr','SI_BS_SAP_ESM_VEH_WVTA_COCTRIG','SI.BS.SAP.ESM.COCTRIG.TO.WVTA.IN',null,null,null,'havhale','Routing Entry to Route CoC Triggers to the associated Business Service');

--30/08/2016 MG Addition for IA-000293 Trade Union Data (Legacy to ESB to SAP)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE', 'ALE_OUTBOUND', 'TRADE_UNION','SI_BS_WAJ1_MFT_HR_SAP_TRBGB_TRADEUNION','SI.AD.SAP.TRBGBHR.ALE.OUT',null,null,null,'mgowsami','Entry for the IA 293 WAJ1 to SAP TRB HR');


--05/11/2012 CG Addition of entry for IA-000234
INSERT INTO WMBOWNER.SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_INBOUND', 'SapZfiRfcRadsGetTimeBookingWrapper','SI_BS_SAP_TRB_MISC_RADS_ENGREQ','SI.BS.SAP.TRBGB.ENGTIMEREQ.TO.RADS.IN',null,null,null,'cgundlap','RADS Engineering Time Request to flow SI_BS_SAP_TRBGB_Engineer_Request_TO_RADS.');
INSERT INTO WMBOWNER.SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_REPLY', 'SapZfiRfcRadsGetTimeBookingWrapper','SI_BS_SAP_TRB_MISC_RADS_ENGREQ','SI.AD.MQ.ESB.TRBGB.TO.SAPMT.OUT',null,null,null,'cgundlap','RADS Engineering Time Response to BAPI SAP Reply Node. ');

-- 06/11/2012 VY Addition of Vehicle Status to D42 IA-000009
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('CANONICAL','VEH_STAT','SapZvistaD42OutIf/INVEXP','SI_BS_CANON_VEH_STATUS','SI.BS.VEHICLE.EVENTS.VISTA.IN',' ',null,null,'vyadav1','Entry for Vehicle Status to VISTA');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('CANONICAL','VEH_STAT','SapZvistaD42OutIf/INVDLR','SI_BS_CANON_VEH_STATUS','SI.BS.VEHICLE.EVENTS.VISTA.IN',' ',null,null,'vyadav1','Entry for Vehicle Status to VISTA');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('CANONICAL','VEH_STAT','SapZvistaD42OutIf/EXCLOVR','SI_BS_CANON_VEH_STATUS','SI.BS.VEHICLE.EVENTS.D42.IN',' ',null,null,'vyadav1','Entry for Vehicle Status to D42');

-- Note: Table constrains needs to be correcetd, once done change VEH_STATUS1to VEH_STATUS
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_HTTP_1','HTTP_OUTBOUND','VEH_STATUS1','SI_BS_CANON_VEHSERV_D42_VEHSTATUS','SI.AD.HTTP.OUT',null,null,null,'vyadav1','Entry for Canonical Events to D42 over HTTP');

-- 07/11/2012 AS Addition for flow SI_BS_FGFSH_Credit_Limits_KJ03_To_SAP_ESMDE (uncommented 04/01/13)
-- 12/01/2015 YT Addition of Entry for IFU 2615 
--INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_SMT_ALE','ALE_OUTBOUND','SapZidocFga','SI_BS_FGFSH_DEALER_SAP_ESMDE_KJ03','SI.AD.SAP.SMTALL.ALE.OUT',null,null,null,'asannago','SAP SMT outbound adapter entry for FGFSH_Credit_Limits_KJ03_To_SAP_ESMDE');
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_SMT_ALE','ALE_OUTBOUND','SapZidocFga','SI_BS_FGFSH_DEALER_SAP_ESMALL_KJ03','SI.AD.SAP.SMTALL.ALE.OUT',null,null,null,'asannago','SAP SMT outbound adapter entry for FGFSH_Credit_Limits_KJ03_To_SAP_ESMALL');


--09/01/2015 YT Updated BSID and input destination under IFU-2613
-- 09/11/2012 HA Addition for flow SI_BS_SAP_ESMDE_INVOICE_FGFSH_KJ10KJ33 
--INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE','ALE_INBOUND','SapZfgafsRequest1','SI_BS_SAP_ESMDE_INVOICE_FGFSH_KJ10KJ33','SI.BS.SAP.ESMDE.KJ10_KJ33.TO.FGFSH.IN',null,null,null,'havhale','SAP ESM Inbound entry for SI_BS_SAP_ESMDE_INVOICE_FGFSH_KJ10KJ33');
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE','ALE_INBOUND','SapZfgafsRequest1','SI_BS_SAP_ESMALL_INVOICE_FGFSH_KJ10KJ33','SI.BS.SAP.ESMALL.KJ10_KJ33.TO.FGFSH.IN',null,null,null,'havhale','SAP ESM Inbound entry for SI_BS_SAP_ESMDE_INVOICE_FGFSH_KJ10KJ33');

-- 12/11/2012 VY for IA-000155, Warranty safety Recall
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_TRB_ALE','ALE_INBOUND','SapZiRclna01','SI_BS_SAP_TRBGB_VEH_ALL_SFTYRECALL','SI.BS.SAP.TRBGB.SAFETYRECALL.TO.ALL.IN','SI.BS.SAP.TRBGB.SAFETYRECALL.TO.ALL.BATCH',null,null,'vyadav1','Routing Entry to Route Idocs to the associated Business Service');

--20/11/2012 AT Addition of entry for IA-000138
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER, INTERFACE_TYPE, SERVICE_IDENTIFIER, BUSINESS_SERVICE_ID, BS_INPUT_DESTINATION, BS_OUTPUT_DESTINATION, USER_ID, DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'KJ11', 'SI_BS_FGFSH_INVOICE_SAP_ESM_FUNDRJKJ11', 'SI.AD.SAP.ESMALL.ALE.OUT',  null, 'rtaylor3', 'SAP ESM ALE Outbound entry for KJ11 Data');

--20/11/2012 AT Addition of entry for IA-000139/IA-000046
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER, INTERFACE_TYPE, SERVICE_IDENTIFIER, BUSINESS_SERVICE_ID, BS_INPUT_DESTINATION, BS_OUTPUT_DESTINATION, USER_ID, DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'KJ12', 'SI_BS_FGFSH_INVOICE_SAP_ESM_FUNDACKJ12', 'SI.AD.SAP.ESMALL.ALE.OUT',  null, 'rtaylor3', 'SAP ESM ALE Outbound entry for KJ12 Data');

-- 23/11/2012 AP Addition of entry for IA-000134
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE','ALE_OUTBOUND','SapMatmas05ZeiWtymatmas','SI_BS_UNIPT_VEH_SAP_TRBGB_SERVICEPART','SI.AD.SAP.TRBGB.ALE.OUT',null,null,null,'apathak2','Route UNIPART JAGServiceParts to SAP Turbo');

-- 23/11/2012 GG Addition of entry for IA-000132
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE','ALE_OUTBOUND','SapMatmas05ZeiWtymatmasLR','SI_BS_PCII_VEH_SAP_TRBGB_LRSERVPART','SI.AD.SAP.TRBGB.ALE.OUT',null,null,null,'ggawali','Routing Entry to Route Idocs to the SAP Turbo ALE Outbound Adapter');

-- 29/11/2012 GG Addition of entry for IA-000309
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE','ALE_OUTBOUND','USED_CARS_DATA','SI_BS_APAK_VEHICLE_SAP_TRBGB_USEDCARDATA','SI.AD.SAP.TRBGB.ALE.OUT',null,null,null,'ggawali','Route Z1APAK IDoc to SAP Turbo ALE Outbound Adapter');

-- 10/12/2012 YG Addition of entry for defect raised for IA-86
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE','ALE_OUTBOUND','SapZvehicleStatus','SI_BS_ALL_VEHICLE_SAP_ESM_STATUSUPD','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'ygoyal','Route Vehicle Status Updates IDoc to SAP eSmart ALE Outbound Adapter');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE','ALE_OUTBOUND','SapZvehicleStatus','SI_BS_ALL_VEHICLE_SAP_ESM_STATUSUPD','SI.AD.SAP.ESMALL.ALE.ON.OUT',null,null,null,'spatel5','Vehicle Status Updates to SAP eSmart Online ALE Outbound Adapter');

-- 11/06/2014 AC Addition of entry for IFU 2031
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE','ALE_OUTBOUND','SapZvehicleStatus','SI_BS_ALL_VEHICLE_SAP_ESM_STATUSUPDPRT','SI.AD.SAP.ESMALL.ALE.ON.PRTVEHSTS.OUT',null,null,null,'achaudha','Vehicle Status Updates to SAP eSmart Priority ALE Outbound Adapter');


-- 11/12/2012 CM insert statements for business service : SI_BS_SAP_TRBGB_DEALER_DLRPL_REMITTANCE1
-- 19/09/2014 AC IFU 2386 Entry to be removed as this flow wont be in use  
--INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) Values('SAP_TRBGB_BAPI','BAPI_INBOUND','SapZfiRfcF110ToDealerPortalWrapper','SI_BS_SAP_TRBGB_DEALER_DLRPL_REMITTANCE1','SI.BS.SAP.TRBGB.REMITTNEWSERV.TO.DLRPL.IN','cmarrett','Routing entry for SI_BS_SAP_TRBGB_Remittance_To_DLRPL Additional');  

-- 17/12/2012 YG insert statements for IA 109,110
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER, INTERFACE_TYPE, SERVICE_IDENTIFIER, BUSINESS_SERVICE_ID, BS_INPUT_DESTINATION, USER_ID, DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'SapZbapiApDocuments', 'SI_BS_ALL_INVOICE_SAP_TRBGB_RECVRYCOST', 'SI.AD.SAP.TRBGB.BAPI.OUT', 'ygoyal', 'Route Recovery Costs Data to SAP Turbo');

-- 18/12/2012 CG Addition of entry for IA 102
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI','BAPI_OUTBOUND','SapZbapiFiAccPark','SI_BS_B2B_INVOICE_SAP_TRBGB_VERIFINV','SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'cgundlap','SAP BAPI  outbound adapter for TRBGB');

-- 18/12/2012 PG IA87 Addition for flow SI_BS_SAP_ESMUS_StockData_To_ORBIT 
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE','ALE_INBOUND','SapZvmOrbitzIdb2','SI_BS_SAP_ESMUS_VEH_ORBIT_STOCKDATA','SI.BS.SAP.ESMUS.STOCKDATA.TO.ORBIT.IN',null,null,null,'pgregory','Route IDB2 Stock Data to Orbits');

-- 18/12/2012 PG IA87 Addition for flow SI_BS_SAP_ESMUS_OrderData_To_ORBIT 
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE','ALE_INBOUND','SapZvmOrbitzVors','SI_BS_SAP_ESMUS_VEH_ORBIT_ORDERDATA','SI.BS.SAP.ESMUS.ORDERDATA.TO.ORBIT.IN',null,null,null,'pgregory','Route VORS Order Data to Orbits');

-- 21/12/2012 PG IA107 addition of entries for adapter flow SI_AD_SAP_TRBGB_BAPI_MT_Inbound and SI_ADAPTER_SAP_TRBGB_BAPI_MT_Reply
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_INBOUND', 'SapZp2pRfcVendorSendWrapper','SI_BS_SAP_TRBGB_VEHICLE_GSDB_VNDRMASTER','SI.BS.SAP.TRBGB.VENDORMASTER.TO.GSDB.IN',null,null,null,'pgregory','Route BAPI Request to Business Service Flow.');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_REPLY', 'SapZp2pRfcVendorSendWrapper','SI_BS_SAP_TRBGB_VEHICLE_GSDB_VNDRMASTER','SI.AD.MQ.ESB.TRBGB.TO.SAPMT.OUT',null,null,null,'pgregory','Route BAPI Response to SAP Turbo BAPI Reply Adapter Flow.');

--27/12/2012 CG Addition of entry for IA-000105
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI','BAPI_OUTBOUND','SapZbapiApDocuments','SI_BS_CATPR_INVOICE_SAP_TRBGB_OPENITEMS','SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'cgundlap','Invoice Open Items Data to SAP Turbo');

--27/12/2012 AP entries for IA-000269 Security Access Control (SAP TURBO to PCARS)
--05/08/2016 HB Removed IA-000269 entry as a part of IFU-4068
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_INBOUND', 'SapZhrFmApplicantDataSetWrapper','SI_BS_SAP_TRB_HR_PCARS_SECACCCNTL','SI.BS.SAP.TRBGB.SECURITYACCSCNTL.TO.PCARS.IN',null,null,null,'apathak2','Route to flow Business service ID SI_BS_SAP_TRB_HR_PCARS_SECACCCNTL');

--09/01/2013 CG Addition of entry for IA-000108
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI','BAPI_OUTBOUND','SapZbapiApDocuments','SI_BS_ERES_INVOICE_SAP_TRBGB_SELFBILLNG','SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'cgundlap','Self Billing Invoice Data to SAP Turbo');


-- 18/01/2013 YG Addition For IA-000323
--	29/04/2015 NM Removed entries for IA-323 as per IFU 2857
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER, INTERFACE_TYPE, SERVICE_IDENTIFIER, BUSINESS_SERVICE_ID, BS_INPUT_DESTINATION, USER_ID, DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_INBOUND', 'SapZbapiFiHyperionCopaWrapper', 'SI_AD_SAP_TRBGB_MQSERV_BAPIIN', 'SI.BS.SAP.TRB.FINANRPT.TO.HYPRON.IN', 'ygoyal', 'Entry for the SAP Financial Report BAPI ZBAPI_FI_HYPERION_COPA interface between SAP Turbo and Hyperion');

--22/01/2013 AP Addition of entry PLO for IA000270 VISTA to SAP
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('PLO_MQ_OUT_1', 'MQ_OUTBOUND', 'NON_SPEC_AMEND','SI_BS_VISTA_SALESORDER_ALL_NONSPECAMD','SI.AD.PLO.OUT',null,null,null,'apathak','Route VISTA Non Spec Amends to PLO MQ Outbound Adapter');

--01/02/2013 AP Addition of entry for IA 330
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'NVM_VEHICLE_TRANSFER','SI_BS_NVM_VEHICLE_SAP_TRBGB_VEHTRANFER','SI.AD.SAP.TRBGB.BAPIST.OUT',null,null,null,'apathak2','SAP TRB BAPI Outbound entry for NVM Transfers feed IA330');

-- 13/02/2013 AS Entries for IA-71
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'VehDraft_Finsta01','SI_BS_ALL_PAYMT_SAP_ESM_BNKSTAKCOM','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'vyadav1','Entry for the IA 71 for SAP eSMART');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'VehDraft_Finsta01','SI_BS_ALL_PAYMT_SAP_ESM_BNKSTAKSCO','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'vyadav1','Entry for the IA 71 for SAP eSMART');

-- 15/02/2013 AS Entries for IA-204
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'SapZfiRfcPimsGetTimeBooking','SI_BS_SAP_TRBGB_MISC_PIMS_BOOKINGTIM','SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'ygoyal','Route PIMS Booking Time to SAP Turbo');

-- 18/03/2013 AS Entries for IA-106
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_INBOUND', 'SapZfiRfcCatObInterfaceWrapper', 'SI_BS_SAP_TRBGB_PAYMT_CATPR_PAYMNTINFO', 'SI.BS.SAP.TRBGB.PYMTINFOFILE.TO.CATPR.IN',null,null,null, 'ygoyal', 'Route Payment Info to Caterpillar');

-- 18/03/2013 AS Entries for IA-235
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_INBOUND', 'SapZfiRfcRadsCapStatusWrapper', 'SI_BS_SAP_TRB_MISC_RADS_PROJCAT', 'SI.BS.SAP.TRBGB.PROJCAT.TO.RADS.IN',null,null,null,'ygoyal', 'SAP TURBO To ESB Engineering Project Category Change');

-- 28/03/2013 AP Entries for IA-332
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE', 'ALE_INBOUND', 'SapZiAwsMiscs', 'SI_BS_SAP_TRBGB_MISC_AWS_EXPREFDATA', 'SI.BS.SAP.TRBGB.EXPREFDATA.TO.AWS.IN',null,null,null,'apathak2', 'Route SAP Request to Business Service Flow');

-- 09/04/2013 YG Entries for IA-203
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE', 'ALE_INBOUND', 'SapZiintorder', 'SI_BS_SAP_TRBGB_MISC_PIMS_ORDERINFO', 'SI.BS.SAP.TRBGB.PIMSORDERINF.TO.PIMS.IN',null,null,null,'ygoyal', 'Route SAP Turbo Order Details to PIMS');

-- 29/04/2013 KM WEntires for HR MultiFile
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('HR_MULTIFILE', 'FTP_OUTBOUND', 'HR_MULTIFILE', 'SI_BS_SAP_TRB_HR_ALL_CUREMPDATA', 'SI.BS.SAP.TRBGB.MULTHRFILE.TO.CATAL.IN',null,null,null,'kmccorma', 'HR Route to SI_BS_SAP_TRBGB_MultiHRFiles_To_CATAL');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('HR_MULTIFILE', 'FTP_OUTBOUND', 'HR_MULTIFILE', 'SI_BS_SAP_TRB_HR_ALL_POSITION', 'SI.BS.SAP.TRBGB.MULTHRFILE.TO.CATAL.IN',null,null,null,'kmccorma', 'HR Route to SI_BS_SAP_TRBGB_MultiHRFiles_To_CATAL');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('HR_MULTIFILE', 'FTP_OUTBOUND', 'HR_MULTIFILE', 'SI_BS_SAP_TRB_HR_ALL_COSTCENTRE', 'SI.BS.SAP.TRBGB.MULTHRFILE.TO.CATAL.IN',null,null,null,'kmccorma', 'HR Route to SI_BS_SAP_TRBGB_MultiHRFiles_To_CATAL');

-- 09/05/2013 AC Entries for IA-156
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE', 'ALE_OUTBOUND', 'SapZiRclna01', 'SI_BS_CUPID_VEH_SAP_TRBGB_WTYSFTYRCL', 'SI.AD.SAP.TRBGB.ALE.OUT',null,null,null,'achaudha', 'Routing Entry to Route Idocs to the SAP TRBGB Outbound Adapter');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE', 'ALE_OUTBOUND', 'SapZiRclna01', 'SI_BS_GRSRT_VEH_SAP_TRBGB_WTYSFTYRCL', 'SI.AD.SAP.TRBGB.ALE.OUT',null,null,null,'achaudha', 'Routing Entry to Route Idocs to the SAP TRBGB Outbound Adapter');

-- 09/05/2013: SP Entries for IA-46. IFU951
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'FGAFS_JAG_KJ12', 'SI_BS_FGFSH_INVOICES_SAP_TRBGB_KJ12JAG', 'SI.BS.FGFSH.FUNDACCJAG_SNGLE.TO.SAP.TRBGB.IN',null,null,null,'spatel5', 'Fund Acceptances KJ12 Single Jaguar Messages to Business Service Flow');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'FGAFS_LR_KJ12', 'SI_BS_FGFSH_INVOICES_SAP_TRBGB_KJ12LR', 'SI.BS.FGFSH.FUNDACCLR_SNGLE.TO.SAP.TRBGB.IN',null,null,null,'spatel5', 'Fund Acceptances KJ12 Single Land Rover Messages to Business Service Flow');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'FGAFS_JAG_KJ12', 'SI_BS_FGFSH_INVOICES_SAP_TRBGB_KJ12JAGSIN', 'SI.AD.SAP.TRBGB.BAPIST.OUT',null,null,null,'spatel5', 'Fund Acceptances KJ12 Jaguar Messages to SAP Outbound Adapter');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'FGAFS_LR_KJ12', 'SI_BS_FGFSH_INVOICES_SAP_TRBGB_KJ12LRSIN', 'SI.AD.SAP.TRBGB.BAPIST.OUT',null,null,null,'spatel5', 'Fund Acceptances KJ12 Land Rover Messages to SAP Outbound Adapter');

-- 10/05/2013 YG IA-104 Routing Enteries
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'SapZbapiApDocuments', 'SI_BS_CITIB_PAYMT_SAP_TRBGB_TRAVLCARDS', 'SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'ygoyal', 'Route Citibank Travel Cards messages to SAP');

-- 20/05/2013 AP IA-296 Routing Enteries
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE', 'ALE_OUTBOUND', 'SapZiWtyrestriction', 'SI_BS_POLK_VEH_SAP_TRBGB_WTYRESTRICTION', 'SI.AD.SAP.TRBGB.ALE.OUT',null,null,null,'apanjiya', 'Routing Entry to Route Idocs to the SAP TRBGB Outbound Adapter');

-- 23/05/2013 YG IA-103 Routing Enteries
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'SapZbapiApDocuments', 'SI_BS_CITIB_PAYMT_SAP_TRBGB_PURCHCARDS', 'SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'ygoyal', 'Route Citibank Purchase Cards messages to SAP');

-- 11/06/2013 HA IA-171 Routing Enteries
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'SapZbapiAccDocumentPost', 'SI_BS_HR_PMTANDDED_SAP_TRBGB_TEMLR', 'SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'havhale', 'Route HR TEM LR to SAP Turbo');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'SapZbapiAccDocumentPost', 'SI_BS_HR_PMTANDDED_SAP_TRBGB_TEMJR', 'SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'havhale', 'Route HR TEM JR to SAP Turbo');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'SapZbapiAccDocumentPost', 'SI_BS_HR_PMTANDDED_SAP_TRBGB_JEMLR', 'SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'havhale', 'Route HR JEM LR to SAP Turbo');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'SapZbapiAccDocumentPost', 'SI_BS_HR_PMTANDDED_SAP_TRBGB_JEMJR', 'SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'havhale', 'Route HR JEM JR to SAP Turbo');

-- 12/06/2013 YG IA-172 Routing Enteries
-- 05/06/2014 RB. Changes for IFU-2029. IA-172 Routing Enteries changed to SI_AD_SAP_TRBGB_BAPI_ST_Outbound - Reverted. Not required
--25/11/2015 NC. commented entries ESB is not using these entries (IFU3539)
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'SapZbapiAccDocumentPost', 'SI_BS_PAYRL_GLENTRY_SAP_TRB_JAGHOURLY', 'SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'ygoyal', 'Route Payroll GL entry to SAP Turbo');
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'SapZbapiAccDocumentPost', 'SI_BS_PAYRL_GLENTRY_SAP_TRB_JAGMONTHLY', 'SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'ygoyal', 'Route Payroll GL entry to SAP Turbo');
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'SapZbapiAccDocumentPost', 'SI_BS_PAYRL_GLENTRY_SAP_TRB_LRHOURLY', 'SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'ygoyal', 'Route Payroll GL entry to SAP Turbo');
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'SapZbapiAccDocumentPost', 'SI_BS_PAYRL_GLENTRY_SAP_TRB_LRMONTHLY', 'SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'ygoyal', 'Route Payroll GL entry to SAP Turbo');
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'SapZbapiAccDocumentPost', 'SI_BS_PAYRL_GLENTRY_SAP_TRB_JLRMONTHLY', 'SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'ygoyal', 'Route Payroll GL entry to SAP Turbo');
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'SapZbapiAccDocumentPost', 'SI_BS_PAYRL_GLENTRY_SAP_TRB_HALHOURLY', 'SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'ygoyal', 'Route Payroll GL entry to SAP Turbo');
-- 19/11/2013 SK Added entry for IA-172
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'SapZbapiAccDocumentPost', 'SI_BS_EMC_GLENTRY_SAP_TRB_NRTHGTARSO', 'SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'skarri', 'Route EMC Northgate Arinso Payroll GL entry to SAP Turbo');
-- 16/11/2015 SN Added entry for IA-172 as part of IFU3539
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'SapZbapiAccDocumentPost2', 'SI_BS_PAYRL_GLENTRY_SAP_TRB_NGABRAZIL', 'SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'snidumuk', 'Route NGA Brazil Payroll GL entry to SAP Turbo');


--12/06/2013 GG IA-09 Entries for CAF Code Trigger
--30/10/2013 HA IA-09 IFU 1298 - BS_OUTPUT_DESTINATION Added
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('CANONICAL','VEH_STAT','SapZvistaD42OutIf/INVDLR','SI_BS_CANON_VEH_STATUS','SI.BS.VEHICLE.EVENTS.WVTA.IN','SI.BS.VEHICLE.EVENTS.WVTA.BATCH',null,null,'ggawali','Entry for CAF code trigger event to WVTA');

--27/06/2013 AC IA-71 Routing Entry for DEUTSCHE Bank
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'VehDraft_Finsta01','SI_BS_ALL_PAYMT_SAP_ESM_BNKSTAKDEU','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'achaudha','Entry for the IA 71 for SAP eSMART');

--09/03/2015 AaP IFU-2803 New payments to Scotia
--12/07/2013 YG IA-70 Routing Entry for Multiple systems.
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_ESMALL_BAPI','BAPI_INBOUND','SapZfiF110XmlToEsbWrapper_CA02','SI_BS_SAP_ESM_PAYMT_COMER_BNKTRNPYMT','SI.BS.SAP.ESM.BANKTRANSPYMTS.TO.COMER.IN','SI.BS.SAP.ESM.BANKTRANSPYMTS.TO.COMER.BATCH',null,null,'ygoyal','Routing Entry to Route Bank Payments to the associated Business Service');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_ESMALL_BAPI','BAPI_INBOUND','SapZfiF110XmlToEsbWrapper_CA02','SI_BS_SAP_ESM_PAYMT_COMORSCOT_BNKTRNPYMT','SI.BS.SAP.ESM.BANKTRANSPYMTS.TO.COMORSCOT.IN','SI.BS.SAP.ESM.BANKTRANSPYMTS.TO.COMER.BATCH',null,null,'apanjiya','Routing Entry to Route Bank Payments to the associated Business Service');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_ESMALL_BAPI','BAPI_INBOUND','SapZfiF110XmlToEsbWrapper_DE03','SI_BS_SAP_ESM_PAYMT_MULTI_BNKTRNPYMT','SI.BS.SAP.ESM.BANKTRANSPYMTS.TO.MULTI.IN',null,null,null,'ygoyal','Routing Entry to Route Bank Payments to the associated Business Service');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_ESMALL_BAPI','BAPI_INBOUND','SapZfiF110XmlToEsbWrapper_IT02','SI_BS_SAP_ESM_PAYMT_MULTI_BNKTRNPYMT','SI.BS.SAP.ESM.BANKTRANSPYMTS.TO.MULTI.IN',null,null,null,'ygoyal','Routing Entry to Route Bank Payments to the associated Business Service');
-- 26/10/2013 HA - IA -122 Rounting for CITI bank updated (IFU 1277)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_SMTCN_BAPI','BAPI_INBOUND','SapZfiF110XmlToEsbWrapper_JLCN','SI_BS_SAP_ESM_PAYMT_MULTI_BNKTRNPYMT','SI.BS.SAP.ESM.BANKTRANSPYMTS.TO.MULTI.IN','SI.BS.SAP.ESM.BANKTRANSPYMTS.TO.MULTI.BATCH',null,null,'havhale','Routing Entry to Route Bank Payments to the associated Business Service');


-- 26/07/2013 RB FRS-260. Added entry for routing messages to Engineering Change Service.
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'ECN_DATA','SI_SV_WERS_ADAPSV_ENGCHNG_IN','SI.SV.WERS.ENGCHNG.IN',null,null,null,'rbabu','Entry for Engineering Change Adapter to rote to Outbound flow');
-- 19/03/2015 KT FRS-260. Updated BS_INPUT_DESTINATION and INTERFACE_TYPE
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_SV_ECS', 'MQ_OUTBOUND', 'ECN_DATA','SI_SV_WERS_ADAPSV_ENGCHNG_OUT','SI.BS.WERS.ENGCHANGE.TO.ALL.IN',null,null,null,'kthanga2','Entry for Engineering Change Adapter to SI_BS_WERS_EngineringChange_To_Multiple_Systems');

-- 18/11/2014 SG Updated for INC000000230781 and INC000000197968
-- 26/07/2013 VA FRS 107. Added Entry for Order Replicate for Canonical Vehicle Adapter
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'VEHICLE', 'CANONICAL','SI_SV_CUSSV_ORDERREPLICATE','SI.SV.ORDER.REPLICATE.CANON.IN',null,null,null,'vannare1','Entry for Order Replicate for Canonical Vehicle Adapter');

-- 26/07/2013 VA FRS 107. Added  Entry for Replicate Order Service 
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL','SI_SV_CUSSV_ORDERREPLICATE','SI.SV.ORDER.REPLICATE.CANON.IN',null,null,null,'vannare1','Entry for Replicate Order Service');


--19/11/2014 AP Entry removed for delfor02. Entry added in SI_SAP_INBOUND_CTRL_HDR_DET
-- 02/08/2013 AP FRS261 Added  Entry for SI_BS_SAP_TRBGB_Vehicle_Parts_To_GXS  
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE', 'ALE_INBOUND', 'SapDelvry07','SI_BS_SAP_TRBGB_VEHICLE_GXS_PARTS','SI.BS.SAP.TRBGB.VEHICLEPARTS.TO.GXS.IN',null,null,null,'apathak2','Route SAP Request to Business Service Flow');


--15/09/2014- Entry removed for delfor02 IFU-2361 New entry added in SI_SAP_INBOUND_CTRL_HDR_DET
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE', 'ALE_INBOUND', 'SapDelfor02','SI_BS_SAP_TRBGB_VEHICLE_GXS_PARTS','SI.BS.SAP.TRBGB.VEHICLEPARTS.TO.GXS.IN',null,null,null,'apathak2','Route SAP Request to Business Service Flow');



-- 18/10/2016 NB Entry added and updated business service name and input destination for FRS-261(IFU4163)

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE', 'ALE_INBOUND', 'SapGsverf03','SI_BS_SAP_TRBGB_VEHICLE_ALL_PARTS','SI.BS.SAP.TRBGB.VEHICLEPARTS.TO.ALL.IN',null,null,null,'apathak2','Route SAP Request to Business Service Flow');


INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE', 'ALE_INBOUND', 'SapPexr2002','SI_BS_SAP_TRBGB_VEHICLE_ALL_PARTS','SI.BS.SAP.TRBGB.VEHICLEPARTS.TO.ALL.IN',null,null,null,'apathak2','Route SAP Request to Business Service Flow');


INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_HTTP_1', 'HTTP_OUTBOUND', 'VEH_PART_DET','SI_BS_SAP_TRBGB_VEHICLE_ALL_PARTS','SI.AD.HTTP.OUT',null,null,null,'apathak2','Route Business Service Flow request to HTTP Outbound flow');

--02/08/2013 AP FRS261 Added  Entry for SI_BS_GXS_Vehicle_Parts_To_SAP_TRBGB  
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE', 'ALE_OUTBOUND', 'VEHICLE_PARTS_DETAIL','SI_BS_GXS_VEHICLE_SAP_TRBGB_PARTS','SI.AD.SAP.TRBGB.ALE.OUT',null,null,null,'apathak2','Route either to  SAP Turbo ALE Outbound Adapter');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_HTTP_1', 'HTTP_INBOUND', 'Statusupdate/EDI/In','SI_BS_GXS_VEHICLE_SAP_TRBGB_PARTS','SI.BS.GXS.VEHICLEPARTS.TO.SAP.TRBGB.IN',null,null,null,'apathak2','HTTP Inbound Routing for GXS to SAP Turbo for Vehicle Parts');

--03/07/2014 AP FRS-261 Entry added for Http reply adapter as per IFU-2119
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_HTTP_1', 'HTTP_REPLY', 'Statusupdate/EDI/In','SI_BS_GXS_VEHICLE_SAP_TRBGB_PARTS','SI.AD.HTTP.DISTRIBUTION.REPLY.IN',null,null,null,'apathak2','HTTP reply entry for GXS to SAP Turbo for Vehicle Parts');


-- 06/08/2013 AC FRS 108. Added Entry for Account Create or Update for Canonical Adapter
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'ACCOUNT', 'CANONICAL','SI_SV_CUSSV_ACCTCRTUPD','SI.SV.ACCOUNT.CREATEUPDATE.IN',null,null,null,'achibbe1','Entry for Create or Update Account for Canonical Account Adapter');

-- 06/08/2013 AC FRS 108. Added Entry for Create or Update Account Service 
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL','SI_SV_CUSSV_ACCTCRTUPD','SI.AD.CANONICAL.ACCOUNT.IN',null,null,null,'achibbe1','Entry for Create or Update Account Service');

--21/04/2017 AT renoved entries as part of IFU4590
-- 06/08/2013 AC FRS 116. Added Entry for Replicate Vehicle for Canonical Adapter
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'VEHICLE', 'CANONICAL','SI_SV_CUSSV_VEHREFDATAREPLICATE','SI.SV.VEHREFDATA.REPLICATE.CANON.IN',null,null,null,'achibbe1','Entry for Create or Update Account for Canonical Account Adapter');

-- 06/08/2013 AC FRS 116. Added Entry for Replicate Vehicle Service 
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL','SI_SV_CUSSV_VEHREFDATAREPLICATE','SI.AD.CANONICAL.VEHICLE.IN',null,null,null,'achibbe1','Entry for Replicate Vehicle Service ');						   

--08/08/2013 Saptarshi Goswami Adding entry for FRS-000111
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_GETACCTDTLS','SI.AD.CANONICAL.ACCOUNT.IN',null,null,null,'sgoswam1', 'Entry for Get Account Details Service');     

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'ACCOUNT', 'CANONICAL', 'SI_SV_CUSSV_GETACCTDTLS','SI.SV.GETACCTDTLS.IN',null,null,null,'sgoswam1', 'Entry for Get Account Details for Canonical Account Adapter');     

-- 08/08/2013 Deepak Ingwale Added Entry for FRS-000009  		
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'FEATURE_OK_TO_USE_LIST','SI_BS_ACE_PRODUCT_ALL_OKTOUSELST','SI.AD.RMDV.OUT',null,null,null,'dingwale','Entry for Publish Feature OK To Use List to RMDV');			

--13/08/2013 Nisha Purohit Adding entry for FRS-109
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_CONTRACTREPLICATE','SI.AD.CANONICAL.CONTRACT.IN',null,null,null,'npurohit', 'Entry for Replicate Contract Service');     

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'CONTRACT', 'CANONICAL', 'SI_SV_CUSSV_CONTRACTREPLICATE','SI.SV.CONTRACT.REPLICATE.CANON.IN',null,null,null,'npurohit', 'Entry for Canonical Contract Adapter');     

-- 21/08/2013 Entries for FRS-110
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_SEARCHACCT','SI.AD.CANONICAL.ACCOUNT.IN',null,null,null,'spatel5', 'Entry for Search Account Service');     
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'ACCOUNT', 'CANONICAL', 'SI_SV_CUSSV_SEARCHACCT','SI.SV.SEARCHACCT.IN',null,null,null,'spatel5', 'Entry for Search Account for Canonical Account Adapter');     

-- 21/08/2013 Pratik Khot Added Entries for FRS-000029, 14/01/2014 PG amended - first insert adjusted for IFU1562 
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_INBOUND', 'SapZp2pRfcVendorSendWrapper', 'SI_BS_SAP_TRBGB_VEHICLE_ENOV_VNDRMASTER','SI.BS.SAP.TRBGB.VENDORMASTER.TO.ENOV.IN',null,null,null,'pgregory', 'Route Vendor BAPI Request to Enovia Business Service Flow');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'VendorMasterUpdatesToEnovia', 'SI_BS_SAP_TRBGB_VEHICLE_ENOV_VNDRMASTER','SI.AD.ENOV.OUT',null,null,null,'pkhot', 'Vendor Master Updates message to Enovia'); 

--28/08/2013 Nisha Purohit Adding entry for FRS-122
-- 01/08/2016 VV Commented the following 2 SQL Statements for IFU-4064
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_GETCMPGNSLIST','SI.AD.CANONICAL.CAMPAIGN.IN',null,null,null,'npurohit', 'Entry for Get List of Campaigns for Dealer Service');     

--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'CAMPAIGN', 'CANONICAL', 'SI_SV_CUSSV_GETCMPGNSLIST','SI.SV.GETCMPGNSLIST.IN',null,null,null,'npurohit', 'Entry for Get List of Campaign Details for Canonical Campaign Adapter');

-- 29/08/2013 Saptarshi Goswami Adding entry for FRS-121
-- 01/08/2016 VV Commented the following 2 SQL Statements for IFU-4064
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_GETCMPGNMBRS','SI.AD.CANONICAL.CAMPAIGN.IN',null,null,null,'sgoswam1', 'Entry for Get Campaign Members Service');     

--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'CAMPAIGN', 'CANONICAL', 'SI_SV_CUSSV_GETCMPGNMBRS','SI.SV.GETCMPGNMBRS.IN',null,null,null,'sgoswam1', 'Entry for Get Campaign Members for Canonical Campaign Adapter');


-- 29/08/2013 GG Added Entry for FRS 352
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('PLO_MQ_OUT_1', 'MQ_OUTBOUND', 'EXT_VEH_ORDER', 'SI_BS_PLO_VEH_CJLR_EVEHORDREQ','SI.AD.PLO.OUT',null,null,null,'ggawali', 'External Vehicle Order requests ');

--  29/08/2013 HA Added Entry for FRS 352(Vehicel Order Status)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('PLO_MQ_OUT_1', 'MQ_OUTBOUND', 'EXT_VEH_STATUS', 'SI_SV_VEHSV_EVEHORDSTA','SI.AD.PLO.OUT',null,null,null,'havhale', 'External Vehicle order status');


-- 11/09/2013 AC Entries for IA-124
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION)VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'VehDraft_Finsta01', 'SI_BS_DEUTB_BNKREPLY_SAP_ESMDE_ACKSTAT', 'SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'achaudha', 'Entry for the IA 124 for SAP eSMART');

-- 25/09/2013 SB Added Entry for FRS-000113
-- 01/08/2016 VV Commented the following 2 SQL statements for IFU-4064
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_GETCASESLIST','SI.AD.CANONICAL.CASES.IN',null,null,null,'sbabu4', 'Entry for Get List of Cases Service');
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'CASES', 'CANONICAL', 'SI_SV_CUSSV_GETCASESLIST','SI.SV.GETCASESLIST.IN',null,null,null,'sbabu4','Entry for Get List of Cases Details for Canonical Cases Adapter');


-- 08/10/2013 GG Added Entry for IA-336
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'IMS_VENDORTOOL', 'SI_BS_WERS_VEHICLE_SAP_TRBGB_VENDORTOOL','IMS.VENDORTOOL.REQ','SI_SERVICE_ROUTING.OUTPUT.VENDORTOOL',null,null,'ggawali', 'IMS WERS data request ');

-- 08/10/2013 AS Entry for FRS-383
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('ESB_BUS_SERV','MQ_OUTBOUND','ECN_DATA','SI_SV_WERS_ECHGVDRT_IN','SI.BS.WERS.VENDORTOOL.TO.SAP.TRBGB.IN',null,null,null,'asannago','WERS Eng Change notification to VT');

-- 09/10/2013 AC Entry for FRS 356
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION)VALUES ('PLO_MQ_OUT_1', 'MQ_OUTBOUND', 'KD_VEH_CREATE', 'SI_BS_PLO_VEHSERV_SAP_TRBGB_KDCREATE','SI.AD.PLO.OUT',null,null,null,'achaudha', 'KD Vehicle Create Acknowledgement to PLO');

-- 09/10/2013 Saptarshi Goswami Adding entry for FRS-128
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'SERORREP', 'CANONICAL', 'SI_SV_CUSSV_CTUPSERREP','SI.SV.CRTUPD.SERORREPEVNT.CANON.IN',null,null,null,'sgoswam1', 'Entry for Create Update ServiceOrRepair for Canonical ServiceOrRepair Adapter');

-- 14/10/2013 Aditi Pathak Entry for FRS 266
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION)VALUES ('ESB_HTTP_1', 'HTTP_INBOUND', 'manufacturing/productioncontrol/kanban', 'SI_BS_LSZEB_VEHICLE_SAP_TRBGB_ENGPARTS','SI.BS.LSZEB.VEHENGPARTS.TO.SAP.TRBGB.IN',null,null,null,'apathak2', 'HTTP Inbound Routing for LSZEB to SAP Turbo for Vehicle Engine Parts');
-- 19/08/2014 SP Commented entry below as the flow will now route to new BAPI ON Outbound Adapter flow
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION)VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'SapZppIRfckanban', 'SI_BS_LSZEB_VEHICLE_SAP_TRBGB_ENGPARTS','SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'apathak2', 'Route Engine parts BAPI request to SAP Turbo BAPI Outbound Adapter');
-- 17/04/2014 Ram Bhamid Entry for IFU1813 - FRS 266
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION)VALUES ('ESB_HTTP_1', 'HTTP_REPLY', 'manufacturing/productioncontrol/kanban', 'SI_BS_LSZEB_VEHICLE_SAP_TRBGB_ENGPARTS','SI.AD.HTTP.DISTRIBUTION.REPLY.IN',null,null,null,'rbhamid', 'HTTP reply entry for LSZEB to SAP Turbo for Vehicle Engine Parts');
--19/08/2014 SP Added Routing entry to route FRS266 messages to new BAPI ON Outbound Adapter flow
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION)VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'SapZppIRfckanban', 'SI_BS_LSZEB_VEHICLE_SAP_TRBGB_ENGPARTS','SI.AD.SAP.TRBGB.BAPI.ON.OUT',null,null,null,'spatel5', 'Route Engine parts BAPI request to SAP Turbo BAPI Outbound ON Adapter');

--17/10/2013 Pratik Khot Added Entries for FRS-000017(Under IFU-1257)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('PLO_MQ_OUT_1', 'MQ_OUTBOUND', 'GEN_SOLVE_REQ', 'SI_BS_PLO_PRO_ACE_GENSOLVE','SI.AD.PLO.OUT',null,null,null,'pkhot', 'Generic Solve Requests');

--21/10/2013 Seenesh Patel added entry for IA-93
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'EMP_DATA_ESB', 'SI_BS_SAP_TRB_HR_WAJ1_EMPDATACHANGES','SI.BS.ESB.EMPDATACHNGE.TO.ALL.IN',null,null,null,'spatel5', 'Employee Data internal routing for WAJ1');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'EMP_DATA_ESB', 'SI_BS_SAP_TRB_HR_CARS_EMPDATACHANGES','SI.BS.ESB.EMPDATACHNGE.TO.ALL.IN',null,null,null,'spatel5', 'Employee Data internal routing for CARS');

--28/10/2013 Pratik Khot Added Entries for FRS-000073
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'EBOM_DATA', 'SI_BS_ENOV_PRODUCT_VCATS_EBOM','SI.AD.VCATS.OUT',null,null,null,'pkhot', 'VCATS Outbound Adapter');

--29/10/2013 SB Added Entries for FRS-000120
--01/08/2016 VV Commented the following 2 SQL Statements for IFU-4064
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_GETLEADDTLS','SI.AD.CANONICAL.LEAD.IN',null,null,null,'sbabu4', 'Entry for Get Lead Details Service');

--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('CANONICAL', 'LEAD', 'CANONICAL', 'SI_SV_CUSSV_GETLEADDTLS','SI.SV.GETLEADDTLS.IN',null,null,null,'sbabu4', 'Entry for Get Lead Details for Canonical Lead Adapter');

-- 07/11/2013 SG Added Entries for FRS-000128
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_CTUPSERREP','SI.AD.CANONICAL.SERORREPEVNT.IN',null,null,null,'sgoswam1', 'Entry for Create Update ServiceOrRepair Service');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_CTUPSERREP_ACCT','SI.AD.CANONICAL.ACCOUNT.IN',null,null,null,'sgoswam1', 'Entry for Create Update ServiceOrRepair Service');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_CTUPSERREP_VREL','SI.AD.CANONICAL.VEHICLE.IN',null,null,null,'sgoswam1', 'Entry for Create Update ServiceOrRepair Service');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('CANONICAL', 'ACCOUNT', 'CANONICAL', 'SI_SV_CUSSV_CTUPSERREP','SI.SV.CRTUPD.SERORREPEVNT.CANON.IN',null,null,null,'sgoswam1', 'Entry for Create Update ServiceOrRepair for Canonical Account Adapter');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('CANONICAL', 'VEHICLE', 'CANONICAL', 'SI_SV_CUSSV_CTUPSERREP','SI.SV.CRTUPD.SERORREPEVNT.CANON.IN',null,null,null,'sgoswam1', 'Entry for Create Update ServiceOrRepair for Canonical Vehicle Adapter');

-- 18/12/2013 SG Following entries not required for FRS-128 as part of IFU1422/IFU1448 
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
--VALUES ('ESB_HTTPS_1', 'HTTPS_INBOUND', 'mss/CRM_S0004-CreateOrUpdateServiceOrRepairEventForVehicleBatch', --'SI_SV_CUSSV_CTUPSERREP','SI.SV.CRTUPD.SERORREPEVNT.IN',null,null,null,'sgoswam1', 'Entry for Create or Update ServiceOrRepair');

--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
--VALUES ('ESB_HTTPS_1', 'HTTPS_REPLY', 'MFTREPLY', 'SI_SV_CUSSV_CTUPSERREP','SI.AD.MFT.HTTPS.REPLY.IN',null,null,null,'sgoswam1', 'Entry for MFT HTTP Reply');

-- 11/11/2013 RB Added Entries for FRS-000112
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_CRTUPDLEAD','SI.AD.CANONICAL.LEAD.IN',null,null,null,'rbabu', 'Entry for Create Update Lead Service ');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_CRTUPDLEAD_ACCT','SI.AD.CANONICAL.ACCOUNT.IN',null,null,null,'rbabu', 'Entry for Create Update Lead Service');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_CRTUPDLEAD_ACTV','SI.AD.CANONICAL.ACTIVITY.IN',null,null,null,'rbabu', 'Entry for Create Update Lead Service');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('CANONICAL', 'ACCOUNT', 'CANONICAL', 'SI_SV_CUSSV_CRTUPDLEAD','SI.SV.CRTUPD.LEADPRSPCT.CANON.IN',null,null,null,'rbabu', 'Entry for Create Update Lead for Canonical Account Adapter');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('CANONICAL', 'LEAD', 'CANONICAL', 'SI_SV_CUSSV_CRTUPDLEAD','SI.SV.CRTUPD.LEADPRSPCT.CANON.IN',null,null,null,'rbabu', 'Entry for Create Update Lead for Canonical Lead Adapter');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('CANONICAL', 'ACTIVITY', 'CANONICAL', 'SI_SV_CUSSV_CRTUPDLEAD','SI.SV.CRTUPD.LEADPRSPCT.CANON.IN',null,null,null,'rbabu', 'Entry for Create Update Lead for Canonical Activity Adapter');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('ESB_HTTPS_1', 'HTTPS_INBOUND', 'mss/CRM_S0002-CreateOrUpdateLeadAndProspectBatch', 'SI_SV_CUSSV_CRTUPDLEAD','SI.SV.CRTUPD.LEADPRSPCT.IN',null,null,null,'rbabu', 'Entry for Create or Update Lead or Prospect');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('ESB_HTTPS_1', 'HTTPS_REPLY', 'MFTREPLY','SI_SV_CUSSV_CRTUPDLEAD','SI.AD.MFT.HTTPS.REPLY.IN',null,null,null,'rbabu', 'Entry for MFT HTTP Reply');

-- 14/11/2013 TK Added Entries for FRS-000119
-- 01/08/2016 VV Commented the following 2 SQL Statements for IFU-4064
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_GTLSTLEADS','SI.AD.CANONICAL.LEAD.IN',null,null,null,'tksheers','Entry for Get List of Leads for Dealer Service');

--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('CANONICAL','LEAD','CANONICAL','SI_SV_CUSSV_GTLSTLEADS','SI.SV.GETLISTOFLEADSFORDEALER.IN',null,null,null,'tksheers','Entry for Get List of Leads for Dealer Service');

---15/11/2013 NCH Added entries for FRS-000027 
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) 
VALUES ('SAP_TRBGB_ALE','ALE_OUTBOUND','WTYSERVPART','SI_BS_ENOV_PRODUCT_SAP_TRBGB_WTYSERVPART','SI.AD.SAP.TRBGB.ALE.OUT',null,'nch','Enovia Warranty Services Parts to SAP');

---15/11/2013 SS Added entries for FRS-000127 
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_CRUPPTCHFS','SI.AD.CANONICAL.VEHICLE.IN',null,null,null,'ssingh25', 'Entry for CrtUpd Part Tech FSE Issue Service');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('CANONICAL', 'VEHICLE', 'CANONICAL', 'SI_SV_CUSSV_CRUPPTCHFS','SI.SV.CRTUPD.PARTTECHFSE.CANON.IN',null,null,null,'ssingh25', 'Entry for CrtUpd Part Tech FSE Issue for Canonical Vehicle Adapter');

--19/12/2013 HM IFU1478 Entries for HTTP adapter are now redundant as SFTP is being used
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
--VALUES ('ESB_HTTPS_1', 'HTTPS_INBOUND', 'mss/CRM_S0006-CreateOrUpdatePartsTechnicalOrFSEIssueForVehicleBatch', 'SI_SV_CUSSV_CRUPPTCHFS','SI.SV.CRTUPD.PARTTECHFSE.IN',null,null,null,'ssingh25', 'Entry for CrtUpd Part Tech FSE Issue Service');
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
--VALUES ('ESB_HTTPS_1', 'HTTPS_REPLY', 'MFTREPLY', 'SI_SV_CUSSV_CRUPPTCHFS','SI.AD.MFT.HTTPS.REPLY.IN',null,null,null,'ssingh25', 'Entry for MFT HTTP Reply');

-- 19/11/2013 HM Addition of entry for FRS-000380
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_HTTP_1', 'HTTP_INBOUND', 'createSIMRAVVehicleAssociation', 'SI_BS_SDD_VEHICLE_BRNSC_SIMRAVDATA','SI.BS.SDD.VEHSIMRAVDAT.TO.BRNSC.IN',null,null,null,'hmistry', 'HTTP Inbound Routing for SDD to Brazil NSC for Vehicle SIMRAV Data');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_HTTP_1', 'HTTP_REPLY', 'createSIMRAVVehicleAssociation', 'SI_BS_SDD_VEHICLE_BRNSC_SIMRAVDATA','SI.AD.HTTP.DISTRIBUTION.REPLY.IN',null,null,null,'nmithari', 'HTTP reply entry for SDD Vehicle SIMRAV Data ');


--- 19/11/2013 SB Addition of entry for FRS-000133

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_REPLICATECASE','SI.AD.CANONICAL.CASES.IN',null,null,null,'sbabu4', 'Entry for Replicate Case to Cases Service');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('CANONICAL', 'CASES', 'CANONICAL', 'SI_SV_CUSSV_REPLICATECASE','SI.SV.REPLICATECASE.IN',null,null,null,'sbabu4', 'Entry for Canonical to Replicate Case business Service Flow');

-- 20/11/2013 SM Added entry for FRS-123
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_BRKDWNEVNT', 'SI.AD.CANONICAL.BREAKDOWNEVENT.IN',null,null,null,'smathur', 'Entry for Create Breakdown Event for Vehicle Service');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'BREAKDOWNEVENT', 'CANONICAL', 'SI_SV_CUSSV_BRKDWNEVNT', 'SI.SV.CRT.BRKDWNEVNT.CANON.IN',null,null,null,'smathur', 'Entry for Breakdown Event for Canonical Breakdown Event Adapter ');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_SVCRM_BRKDWNEVNT', 'SI.AD.CANONICAL.BREAKDOWNEVENT.IN',null,null,null,'smathur', 'Entry for Create Breakdown Event for Vehicle Service ');

-- 21/11/2013 SG Added Entries for FRS-000130
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_REPLICTEDR','SI.AD.CANONICAL.TRADINGPARTNER.IN',null,null,null,'sgoswam1', 'Entry for Replicate Dealer Service');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('CANONICAL', 'TRADINGPARTNER', 'CANONICAL', 'SI_SV_CUSSV_REPLICTEDR','SI.SV.REPLICATEDEALER.IN',null,null,null,'sgoswam1', 'Entry for Replicate Dealer for Canonical Trading Partner Adapter');

-- KM FRS-000130 Tactical
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_REPLICTEDR_TACT','SI.AD.CANONICAL.TRADINGPARTNER.IN',null,null,null,'sgoswam1', 'Entry for Replicate Dealer Service');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('CANONICAL', 'TRADINGPARTNER', 'CANONICAL', 'SI_SV_CUSSV_REPLICTEDR_TACT','SI.SV.REPLICATEDEALER.TACT.IN',null,null,null,'sgoswam1', 'Entry for Replicate Dealer for Canonical Trading Partner Adapter');

--21/04/2017 AT Removed entries as part of IFU4591
-- 21/11/2013 PG Added Entries for FRS-000129
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) 
--VALUES ('ESB_BUS_SERV','MQ_OUTBOUND','CANONICAL','SI_SV_CUSSV_CRTUPDCASE','SI.AD.CANONICAL.CASES.IN',null,'pgupta3','Entry for Create Update Case Service');

--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) 
--VALUES ('CANONICAL','CASES','CANONICAL','SI_SV_CUSSV_CRTUPDCASE','SI.SV.CRTUPD.CASE.CANON.IN',null,'pgupta3','Entry for Create Update Case for Canonical Case Adapter');

-- 11/11/2013 KM Added Entries for FRS-000117
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_CRTUPDFINCNTRPROP','SI.AD.CANONICAL.FINANCE.IN',null,null,null,'kmccorma', 'Entry for Create Update Fin Con or Prop');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_CRTUPDFINCNTRPROP_ACCT','SI.AD.CANONICAL.ACCOUNT.IN',null,null,null,'kmccorma', 'Entry for Create Update Fin Con or Prop');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_CRTUPDFINCNTRPROP_VREL','SI.AD.CANONICAL.VEHICLE.IN',null,null,null,'kmccorma', 'Entry for Create Update Fin Con or Prop');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'ACCOUNT', 'CANONICAL', 'SI_SV_CUSSV_CRTUPDFINCNTRPROP','SI.SV.CRTUPD.FINCNTRPROP.CANON.IN',null,null,null,'kmccorma', 'Entry for Create Update Fin Con or Prop for Canonical Account Adapter');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'FINANCE', 'CANONICAL', 'SI_SV_CUSSV_CRTUPDFINCNTRPROP','SI.SV.CRTUPD.FINCNTRPROP.CANON.IN',null,null,null,'kmccorma', 'Entry for Create Update Fin Con or Prop for Canonical Finance Adapter');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'VEHICLE', 'CANONICAL', 'SI_SV_CUSSV_CRTUPDFINCNTRPROP','SI.SV.CRTUPD.FINCNTRPROP.CANON.IN',null,null,null,'kmccorma', 'Entry for Create Update Fin Con or Prop for Canonical Vehicle Adapter');


-- 25/11/2013 SM Added Entries for FRS-000118
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV','MQ_OUTBOUND','CANONICAL','SI_SV_CUSSV_CRTUPDCPGNEVNTORRSPS','SI.AD.CANONICAL.CAMPAIGN.IN',null,'smuley','Entry Create Update Campaign Event and Response Service');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES ('CANONICAL','CAMPAIGN','CANONICAL','SI_SV_CUSSV_CRTUPDCPGNEVNTORRSPS','SI.SV.CRTUPD.CPGNEVNTORRSPS.IN',null,'smuley','Entry Create Update Campaign Event and Response Service');


-- 09/09/2014 GT Updated entries for FRS-115 as part of R2.0
-- 26/11/2013 PS Added Entries for FRS-000115
-- 13/10/2016 SS Updated entries for FRS-115 as part of IFU4177
-- 04/08/2017 Entry no more required. Interface moved to new build framework
/* INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) 
VALUES ('ESB_BUS_SERV','MQ_OUTBOUND','CANONICAL','SI_SV_CUSSV_REPLEADPSP','SI.SV.REPLEADPSPCT.IN',null,'psrivas1','Entry for Replicate Lead and Prospect Service');
 */
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) 
--VALUES ('CANONICAL','LEAD','CANONICAL','SI_SV_CUSSV_REPLEADPSP','SI.SV.REPLEADPSPCT.IN',null,'psrivas1','Entry for Get Lead Details for Canonical Lead Adapter');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) 
VALUES ('ESB_HTTP_1','HTTP_OUTBOUND','REPLEAD','SI_SV_CUSSV_REPLEADPSP_SHIFTDIGITAL','SI.SV.REPLEADPSPCT.IN',null,'ssingh20','Entry for Replicate Lead and Prospect Service');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) 
VALUES ('ESB_SOAP_1','SOAP_OUTBOUND','REPLEAD','SI_SV_CUSSV_REPLEADPSP_ENQUIRYMAX','SI.SV.REPLEADPSPCT.IN',null,'ssingh20','Entry for Replicate Lead and Prospect Service');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) 
VALUES ('ESB_SOAP_1','SOAP_OUTBOUND','REPLEAD','SI_SV_CUSSV_REPLEADPSP_OCCAM','SI.SV.REPLEADPSPCT.IN',null,'ssingh20','Entry for Replicate Lead and Prospect Service');
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) 
--VALUES ('CANONICAL','LEAD','CANONICAL','SI_SV_CUSSV_REPLEADPSP_SHIFTDIGITAL','SI.SV.REPLEADPSPCT.IN',null,'gthamma','Entry for Get Lead Details for Canonical Lead Adapter');
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) 
--VALUES ('CANONICAL','LEAD','CANONICAL','SI_SV_CUSSV_REPLEADPSP_ENQUIRYMAX','SI.SV.REPLEADPSPCT.IN',null,'gthamma','Entry for Get Lead Details for Canonical Lead Adapter');
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) 
--VALUES ('CANONICAL','LEAD','CANONICAL','SI_SV_CUSSV_REPLEADPSP_OCCAM','SI.SV.REPLEADPSPCT.IN',null,'gthamma','Entry for Get Lead Details for Canonical Lead Adapter');


-- 21/12/2013 GT Removed Entries for FRS-000123 as these are no more required

-- INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) 
-- VALUES ('ESB_HTTPS_1','HTTPS_INBOUND','mss/CRM_S0003-CreateBreakdownEventForVehicle','SI_SV_CUSSV_SVCRM_BRKDWNEVNT','SI.SV.CRT.BRKDWNEVNT.SVCRM.IN',null,'smathur','Entry for Create Breakdown Event for Vehicle Service');

-- INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) 
-- VALUES ('ESB_HTTPS_1','HTTPS_REPLY','MFTREPLY','SI_SV_CUSSV_SVCRM_BRKDWNEVNT','SI.AD.MFT.HTTPS.REPLY.IN',null,'smathur','Entry for MFT HTTP Reply');


-- 01/12/2013 HM Added Entries for FRS-000139 - Service
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_REPVEHSALESTAT_VEH','SI.AD.CANONICAL.VEHICLE.IN',null,null,null,'hmistry', 'Entry for Replicate BBSS Vehicle Sale or Status');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_REPVEHSALESTAT_CTR','SI.AD.CANONICAL.CONTRACT.IN',null,null,null,'hmistry', 'Entry for Replicate BBSS Vehicle Sale or Status');

-- 02/12/2013 HM Added Entries for FRS-000139 - Canonical
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'VEHICLE', 'CANONICAL', 'SI_SV_CUSSV_REPVEHSALESTAT','SI.SV.REPLICVEHSALESTAT.IN',null,null,null,'hmisty', 'Entry for Replicate BBSS Vehicle Sale or Status');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'CONTRACT', 'CANONICAL', 'SI_SV_CUSSV_REPVEHSALESTAT','SI.SV.REPLICVEHSALESTAT.IN',null,null,null,'hmisty', 'Entry for Replicate BBSS Vehicle Sale or Status');


-- 09/12/2013 HS Added Entries for FRS-000083 - Only ONE HTTP entry should be active at a given time, so two are commented out below
-- Interim Solution Level 1 one record to route from HTTP Adapter to CARS. BS Output Destination set to return response to HTTP Reply Adapter

--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) 
--VALUES ('ESB_HTTP_1','HTTP_INBOUND','VistaSolve','SI_SV_PRDSV_CARS_VISTASOLVE','SI.SV.CARS.VISTASOLVE.IN','SI.AD.VISTA.HTTP.REPLY.IN','hsabat','VistaSolve to CARS Interim Solution 1');

---Interim Solution Level 2, one record to route from HTTP Adapter to secondary flow.
---Four records to route response from the secondary flow with BS Output Destination set to return response to HTTP Reply Adapter

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) 
VALUES ('ESB_HTTP_1','HTTP_INBOUND','VistaSolve','SI_SV_PRDSV_VISTASOLVE','SI.SV.ALL.VISTASOLVE.IN','SI.AD.VISTA.HTTP.REPLY.IN','hsabat','VistaSolve to CARS/ACE Interim Solution 2');


---Interim Solution Level 2, one record to route from HTTP Adapter to secondary flow.
---Three records to route response from the secondary flow with BS Output Destination set to return response to HTTP Reply Adapter

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) 
VALUES ('ESB_BUS_SERV','MQ_OUTBOUND','VistaSolve','SI_SV_PRDSV_VISTASOLVE_CARS_NOAGG','SI.SV.CARS.VISTASOLVE.IN','SI.AD.VISTA.HTTP.REPLY.IN','hsabat','VistaSolve to CARS no aggregation Interim Solution 2');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) 
VALUES ('ESB_BUS_SERV','MQ_OUTBOUND','VistaSolve','SI_SV_PRDSV_VISTASOLVE_ACE_NOAGG','SI.SV.ACE.VISTASOLVE.IN','SI.AD.VISTA.HTTP.REPLY.IN','hsabat','VistaSolve to ACE no aggregation Interim Solution 2');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) 
VALUES ('ESB_BUS_SERV','MQ_OUTBOUND','VistaSolve','SI_SV_PRDSV_VISTASOLVE','SI.AD.VISTA.HTTP.REPLY.IN',null,'pgregory','VistaSolve Aggregation Reply to HTTP Reply');

----Future Solution, one record to route from HTTP Adapter to ACE. BS Output Destination set to return response to HTTP Reply Adapter.

--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) 
--VALUES ('ESB_HTTP_1','HTTP_INBOUND','VistaSolve','SI_SV_PRDSV_ACE_VISTASOLVE','SI.SV.ACE.VISTASOLVE.IN','SI.AD.VISTA.HTTP.REPLY.IN','hsabat','VistaSolve to ACE');

-- 12/12/2013 AS IA-000163 entries
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) 
VALUES ('SAP_TRBGB_ALE','ALE_INBOUND','SapZiAwsPartsdata','SI_BS_SAP_TRBGB_VEH_AWS_PARTSDATA','SI.BS.SAP.TRBGB.PARTSDATA.TO.AWS.IN','SI.BS.SAP.TRBGB.PARTSDATA.TO.AWS.BATCH','asannago','Warranty Parts Data to AWS');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) 
VALUES ('SAP_TRBGB_ALE','ALE_INBOUND','SapZiAwsWccdata','SI_BS_SAP_TRBGB_VEH_AWS_PARTSDATA','SI.BS.SAP.TRBGB.PARTSDATA.TO.AWS.IN','SI.BS.SAP.TRBGB.PARTSDATA.TO.AWS.BATCH','asannago','Warranty WCC to AWS');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) 
VALUES ('MFT_FTP_OUT_1','FTP_OUTBOUND','AWS_PARTS_DATA','SI_BS_SAP_TRBGB_VEH_AWS_PARTSDATA','SI.AD.MFT.OUT',NULL,'asannago','Entry for SAP Turbo Wrnty Parts Data to MFT');
-- End of IA-000163
-- 16/12/2013 HA IA 158 Entries
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION)VALUES ('SAP_TRBGB_ALE', 'ALE_OUTBOUND', 'WTYSRO', 'SI_BS_ATD_VEH_ALL_SRODATA','SI.AD.SAP.TRBGB.ALE.OUT',null,null,null,'havhale', 'ATD SRO Data to SAP Turbo');

--13/01/2014 Nisha Purohit Adding entry for FRS-000107(Warranty)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_BS_VISTA_VEH_SAP_TRBGB_GOF','SI.AD.CANONICAL.VEHICLE.IN',null,null,null,'npurohit', 'Vista_GOF_To_SAPTRB To Veh_Canon_Adapter');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE', 'ALE_OUTBOUND', 'ZI_WTYJLR', 'SI_BS_VISTA_VEH_SAP_TRBGB_GOF','SI.AD.SAP.TRBGB.ALEST.OUT',null,null,null,'npurohit', 'Vista GOF to SAP Turbo');     

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'VEHICLE', 'CANONICAL', 'SI_BS_VISTA_VEH_SAP_TRBGB_GOF','SI.BS.VISTA.GOF.TO.SAP.TRBGB.CANON.IN',null,null,null,'npurohit', 'Entry for Vista_To_SAPTRB (FRS-107) flow from Veh_Canon_Adapter');     

--14/01/2014 Hari Krishna Sabat Added entries for FRS-091(ACE_BRS_Deltas)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'Feature Data', 'SI_BS_ACE_VEHICLE_ALL_LEGACYFEED_FEAT','SI.BS.BRS.VEHSPECSFEAT.TO.SAP.ESM.IN',null,'hsabat', 'ACE Features to e-Smart mapping flow');  

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'Derivative Data', 'SI_BS_ACE_VEHICLE_ALL_LEGACYFEED_DERIV','SI.BS.ALL.VEHSPECSDERIV.TO.ALL.IN',null,'hsabat', 'Derivative Data to Vehicle Specs Derivative flow');  

--Transition Solution (ACE and BRS provide) 2 further records added to route Derivative Deltas from SI_BS_Multiple_Systems_VehSpecsDeriv_To_Multiple_Systems Flow to e-Smart, Turbo and PLO mapping flows

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'Derivative Data', 'SI_BS_ALL_VEHICLE_ALL_SPECSDERIV','SI.BS.BRS.VEHSPECSDERIV.TO.SAP.ESM.IN',null,'hsabat','Derivative Data to e-Smart Mapping Flow'); 

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'Derivative Data', 'SI_BS_ALL_VEHICLE_ALL_SPECSDERIV','SI.BS.BRS.PRICINGMATMAS.TO.ALL.IN',null,'hsabat','Derivative Data to Turbo/PLO Mapping Flow ');

--To Be Solution (ACE only as provider) the 3 Derivative records of the Transition solution are replaced by 2 Derivative Records as flow SI_BS_Multiple_Systems_VehSpecsDeriv_To_Multiple_Systems becomes redundant.

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'Derivative Data', 'SI_BS_ACE_VEHICLE_ALL_LEGACYFEED_DERIV','SI.BS.BRS.VEHSPECSDERIV.TO.SAP.ESM.IN',null,'hsabat','Derivative Data to e-Smart Mapping Flow ');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'Derivative Data', 'SI_BS_ACE_VEHICLE_ALL_LEGACYFEED_DERIV','SI.BS.BRS.PRICINGMATMAS.TO.ALL.IN',null,'hsabat','Derivative Data to Turbo/PLO Mapping Flow');

-- 17/01/2014 HA Entries for FRS 353
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION)VALUES ('SAP_TRBGB_ALE', 'ALE_OUTBOUND', 'VEH_SPEC_WERS_CODES', 'SI_BS_GEMSL_VEHSERV_SAP_TRBGB_SPECWERS','SI.AD.SAP.TRBGB.ALE.OUT',null,null,null,'havhale', 'Route Veh Spec WERS Code IDOCS to SAP Turbo');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION)VALUES ('PLO_MQ_OUT_1', 'MQ_OUTBOUND', 'VEH_SPEC_WERS_CODES', 'SI_BS_GEMSL_VEHSERV_SAP_TRBGB_SPECWERS','SI.AD.PLO.OUT',null,null,null,'havhale', 'Route Veh Spec WERS Code Confirmation to PLO');

-- 20/01/2014 AC Entries for FRS 618
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION)VALUES ('SAP_TRBGB_ALE', 'ALE_OUTBOUND', 'ZI_WTYPRICES', 'SI_BS_UNIPT_PRODUCT_SAP_TRBGB_MATPRCGRP','SI.AD.SAP.TRBGB.ALE.OUT',null,null,null,'achaudha', 'Unipart Material Price Grp to SAP Turbo');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION)VALUES ('SAP_TRBGB_ALE', 'ALE_OUTBOUND', 'ZI_WTYPRICES', 'SI_BS_NEOV_PRODUCT_SAP_TRBGB_MATPRCGRP','SI.AD.SAP.TRBGB.ALE.OUT',null,null,null,'achaudha', 'Neovia Material Price Grp to SAP Turbo');

--22/01/2014 Naresh CH Added entries for FRS -022

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES ('ACE_MQ_OUT_1','MQ_OUTBOUND','SSG_REQUEST','SI_BS_PLO_PRODUCT_ACE_SLOTGEN','SI.AD.ACE.OUT',null,'nch','Entry for SSGRequest to be send to ACE');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES ('PLO_MQ_OUT_1','MQ_OUTBOUND','SSG_RESPONSE','SI_BS_PLO_PRODUCT_ACE_SLOTGEN','SI.AD.PLO.OUT',null,'nch','Entry for SSGResponse to be send to PLO');

--24/01/2014 SNEHAL KOLHE Added entries for FRS-123(Warranty)

INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES('SAP_TRBGB_ALE','ALE_OUTBOUND','ZI_CLAIM','SI_BS_CANON_VEH_SAP_TRBGB_BRKDWEVNT','SI.AD.SAP.TRBGB.ALE.OUT','skolhe','Breakdown Event to SAP Turbo');

-- 03/02/2014 Samiksha Singh -added entry for IA-000271 (Warranty)
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES('SAP_TRBGB_ALE','ALE_OUTBOUND','WARRANTY_CLAIMS_IN','SI_SV_INVSV_WRRNTYCLMS','SI.AD.SAP.TRBGB.ALE.OUT','ssingh20','Entry for route Warranty Claims IDOCS to SAP Turbo');

--06/02/2014 Apathak2 Entry added for FRS-378 
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('PLO_MQ_OUT_1', 'MQ_OUTBOUND', 'EXT_VEH_ORD_FORECAST', 'SI_SV_VEHSV_EVEHORDFOR','SI.AD.PLO.OUT',null,null,null,'apathak2', 'External Vehicle Order Forecast routing');

-- 21/02/2014 AC Entries for FRS 130 (updated 08/07/2104 PG from ST queue to MT queue)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION)VALUES ('SAP_TRBGB_ALE', 'ALE_OUTBOUND', 'ZI_WTYCUSTOMER', 'SI_BS_CANON_DEALER_SAP_TRBGB_REPLICTEDR','SI.AD.SAP.TRBGB.ALE.OUT',null,null,null,'achaudha', 'Replicate Dealer to SAP Turbo');

-- 21/02/2014 Amit Karma Added entry for FRS-000081

INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES('ENOV_MQ_OUT_1','MQ_OUTBOUND','UCCSFI_RESPONSE','SI_BS_ENOV_PRODUCT_CMMS3_MANUFACUCC','SI.AD.ENOV.OUT','akarma','Entry for Responses to be send to ENOVIA');

--03/03/2014 Naresh CH Added entries for FRS-090(Expose BRSData (Derivative and Feature Feeds))
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES('ESB_HTTP_1','HTTP_OUTBOUND','VISTA','SI_BS_ALL_VEHICLE_ALL_PUBVEHDESC','SI.AD.HTTP.OUT','nch','Entry for Vehicle Desc feeds from ACE/BRS to VISTA over HTTP');

 --07/03/2014 Naresh CH Added entries for FRS-009(For the part of IFU 1749)
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES('ESB_BUS_SERV','MQ_OUTBOUND','FEATURE_OK_TO_USE_LIST','SI_BS_ACE_PRODUCT_ALL_OKTOUSELST','SI.AD.SAPDS.OUT',null,'nch','Entry for Publish Feature OK To Use List to SAPDS');
 
 --19/03/2014 Skarri added enties for IFU-1765 for IA-000074 as per new services ASPEN anD BYRES
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'AccntRec_Aspen','SI_BS_ASPEN_BILLG_SAP_ESMUS_ACCREIV','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'skarri','Aspen Accounts Receivable to Sap eSmart');
--15/04/2014 AS IFU-1857, Entry commented out for SI_BS_BYCRK_BILLG_SAP_ESMUS_ACCREIV (Byers Creek deactivated)
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'AccntRec_Byers Creek','SI_BS_BYCRK_BILLG_SAP_ESMUS_ACCREIV','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'skarri','Byers Creek Accounts Receivable to Sap eSmart');


--26/03/2014 SK added entires for IA-000027 as per BELGIUM and Netherland:
-- 13/06/2014 RBH updated entires for IA-000027 as per IFU1981
----------
-- INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_MULTI_BATCH','MQ_OUTBOUND','ESMBE','SI_BS_SAP_TRBGB_INVCRDDETS_ESMBE','SI.BS.SAP.TRBGB.INVCRDDETS.TO.ESMBE.IN',null,null,null,'skarri','Entry for SAP to eSmart Belgium Invoice and Credit transform flow');
-- INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESMBE_BAPI', 'BAPI_OUTBOUND', 'ESMBE','SI_BS_SAP_TRBGB_INVCRDDETS_ESMBE','SI.AD.SAP.ESMALL.BAPI.OUT',null,null,null,'skarri','Entry for SAP to Esmart Belgium over SAP');

-- INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_MULTI_BATCH','MQ_OUTBOUND','ESMNL','SI_BS_SAP_TRBGB_INVCRDDETS_ESMNL','SI.BS.SAP.TRBGB.INVCRDDETS.TO.ESMNL.IN',null,null,null,'skarri','Entry for SAP to eSmart NetherLands Invoice and Credit transform flow');
-- INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESMNL_BAPI', 'BAPI_OUTBOUND', 'ESMNL','SI_BS_SAP_TRBGB_INVCRDDETS_ESMNL','SI.AD.SAP.ESMALL.BAPI.OUT',null,null,null,'skarri','Entry for SAP to Esmart NetherLands over SAP');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_MULTI_BATCH','MQ_OUTBOUND','ESMBE','SI_BS_SAP_TRBGB_INVCRDDETS_ESMBE','SI.BS.SAP.TRBGB.INVCRDDETS.TO.ESMALL.IN',null,null,null,'skarri','Entry for SAP to eSmart Belgium Invoice and Credit transform flow');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_MULTI_BATCH','MQ_OUTBOUND','ESMNL','SI_BS_SAP_TRBGB_INVCRDDETS_ESMNL','SI.BS.SAP.TRBGB.INVCRDDETS.TO.ESMALL.IN',null,null,null,'skarri','Entry for SAP to eSmart NetherLands Invoice and Credit transform flow');

-- 13/06/2014 RBH added entires for IA-000027 as per Australia for IFU1981
----------
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_MULTI_BATCH','MQ_OUTBOUND','ESMAU','SI_BS_SAP_TRBGB_INVCRDDETS_ESMAU','SI.BS.SAP.TRBGB.INVCRDDETS.TO.ESMALL.IN',null,null,null,'rbhamid','Entry for SAP to eSmart Australia Invoice and Credit transform flow');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESMALL_BAPI', 'BAPI_OUTBOUND', 'ESMALL','SI_BS_SAP_TRBGB_INVCRDDETS_ESMALL','SI.AD.SAP.ESMALL.BAPI.OUT',null,null,null,'rbhamid','Entry for SAP Turbo to eSmart for Invoice Credit');

-- 24/11/2014 MJ Added entries as per IFU- 2525
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_MULTI_BATCH','MQ_OUTBOUND','ESMIN','SI_BS_SAP_TRBGB_INVCRDDETS_ESMIN','SI.BS.SAP.TRBGB.INVCRDDETS.TO.ESMALL.IN',null,null,null,'mjeevart','Entry for SAP to eSmart India Invoice and Credit transform flow');

--02/06/2016 LH Removed entries for BSID SI_BS_ALL_VEHSERV_SAP_TRBGB_MVRISREG, SI_BS_ALL_VEHSERV_SAP_TRBGB_AFRLREG and added entry for BSID SI_BS_ALL_VEHSERV_ALL_VEHREGIS
--27/03/2014 NM added entries for IA-000207
--------------------------------------------
--INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES('ESB_HTTP_1','HTTP_OUTBOUND','VEH_SERVICE','SI_BS_ALL_VEHSERV_ALL_MVRISREG','SI.AD.HTTP.OUT','nmithari','Registrations Capture Data from MVRIS');
--INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES('ESB_HTTP_1','HTTP_OUTBOUND','VEH_SERVICE','SI_BS_ALL_VEHSERV_ALL_AFRLREG','SI.AD.HTTP.OUT','nmithari','Registrations Capture Data from AFRL');
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES('ESB_HTTP_1','HTTP_OUTBOUND','VEH_SERVICE','SI_BS_ALL_VEHSERV_ALL_VEHREGIS','SI.AD.HTTP.OUT','lhake','Registrations Capture Data from MVRIS and  AFRL');
 
--04/04/2014 SS added entries for IA-000324
--------------------------------------------
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) values('SAP_TRBGB_ALE','ALE_OUTBOUND','ZI_WTYNONJLREXD','SI_BS_ASRNT_VEHICLE_SAP_TRBGB_WTYEXTCTRT','SI.AD.SAP.TRBGB.ALE.OUT',null,'ssingh20','Extended Warranty to SAP Turbo');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) values('CANONICAL','WARRANTY','CANONICAL','SI_BS_ASRNT_VEHICLE_SAP_TRBGB_WTYEXTCTRT','SI.BS.CANON.EXTSUPPCNTRCTS.TO.SAP.TRBGB.IN',null,'ssingh20','Extended Warranty Canonical to SAP Turbo');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) values('ESB_BUS_SERV','MQ_OUTBOUND','CANONICAL','SI_BS_ASRNT_VEHICLE_SAP_TRBGB_WTYEXTCTRT','SI.AD.CANONICAL.WARRANTYCONTRACT.IN',null,'ssingh20','Extended Warranty to Canon Adapter');

--20/08/2014 AaP Removed entry for FRS-621 as it now uses SI_SAP_INBOUND_CTRL_HDR_DET table entry
-- 09/04/2014 AaP Entries for FRS 621
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION)VALUES ('SAP_ESM_ALE', 'ALE_INBOUND', 'SapVehcle01', 'SI_BS_SAP_ESM_VEHICLE_KIRPE_LICORDREL','SI.BS.SAP.ESM.VEHLICORDREL.TO.KIRPE.IN','SI.BS.SAP.ESM.VEHLICORDREL.TO.KIRPE.BATCH','apanjiya', 'Vehicle Licence Order Release to Kirpestein');

-- 09/04/2014 SK Entries for FRS 622
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'SapVehcle01Zvehcle01','SI_BS_KIRPE_VEHICLE_SAP_ESM_VEHLICRESP','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'skarri','Vehicle Licence Plate Response to SAP ESM');

-- 17/04/2014 AC Entries for FRS 626
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'RegResponce_FBIAC', 'SI_BS_FEBAC_VEHICLE_SAP_ESM_REGRESP','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'achaudha', 'Registration Response to SAP ESM');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'RegResponce_RDC', 'SI_BS_RDC_VEHICLE_SAP_ESM_REGRESP','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'achaudha', 'Registration Response to SAP ESM');

-- 03/02/2015 Added entry for IFU 2658- FRS 626
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'RegResponce_ANT', 'SI_BS_ANT_VEHICLE_SAP_ESM_REGRESP','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'mjeevart', 'Registration Response to SAP ESM');

-- 05/05/2014 NM Entries for FRS 372
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_HTTP_1', 'HTTP_INBOUND', 'Vehicle/vehiclestatusupdate', 'SI_SV_VEHSV_VEHDSTST','SI.SV.VEHDISTR.IN',null,null,null,'nmithari', 'HTTP Inbound Routing for D42 to CJLR for Vehicle Distribution Status');

--21/04/2014 PK Added Entries for FRS-000018.
--------------------------------------------
--Transition Solution, Profet routes to the Collection queue so that distribution is not commenced until both ACE and Profet files have been received onto WMB.
--The following two entries will redundant post Transition.
 
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'Profet Data', 'SI_AD_PROFT_FTP_IN','SI.BS.ALL.PROFETFILE.TO.ALL.COLLECTOR.IN',null,null,null,'pkhot', 'Transition,Input from Profet route to collector');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'ACE Data', 'SI_AD_ACE_FTP_IN','SI.BS.ALL.PROFETFILE.TO.ALL.COLLECTOR.IN',null,null,null,'pkhot', 'Transition,Input from ACE route to collector');

--Transition Solution, Collection flow routes to BS Flow 

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'Profet Data', 'SI_BS_ALL_PRODUCT_ALL_PROFTCOLL','SI.BS.ALL.PROFETFILE.TO.ALL.IN',null,null,null,'pkhot', 'Transition,input from collector to merge flow');

--Needed in both Transition and ACE solutions. Routing of the "Ready to send" messages

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'Profet Data', 'SI_BS_ALL_PRODUCT_ALL_PROFTMERGE','SI.BS.ALL.PROFETSEND.TO.ALL.IN',null,null,null,'pkhot', 'Send ACE/Profet files to destinations');

--Needed in both Transition and ACE solutions. Routing of SAP iDOCS to the SAP Adapter, this entry replaces the entry with BSID= �SI_BS_PROFT_VEHICLE_SAP_TRBGB_CLASCONFMT�

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('SAP_TRBGB_ALE', 'ALE_OUTBOUND', 'Profet Data', 'SI_BS_ALL_PRODUCT_SAP_TRBGB_CLASCONFMT','SI.AD.SAP.TRBGB.ALEST.OUT',null,null,null,'pkhot', 'Route Merged Profet files to SAP');

--07/05/2014 GG Addition of entries for IA 94 HR Position Data (internal routing of the message)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'POS_DATA_ESB','SI_BS_SAP_TRB_HR_ALL_POSITION','SI.BS.ESB.POSDATA.TO.ALL.IN',null,null,null,'ggawali','HR Position data internal routing');

--09/01/2015 YT IFU-2614 Updated Entry for IA-220(BSID value changed)
--08/05/2014 NM Insert statement for IA000220 SI_BS_FGFSH_PYMTCONFRM_TO_SAP_ESMNL
--Routing Entry to Route ZFISHKJ09  IDOC to the SAP esmart ALE Outbound router
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'SapZfishkj09','SI_BS_FGFSH_INVOICE_SAP_ESMNL_KJ09_PCONF','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'nmithari','Routing Entry to Route ZFISHKJ09  IDOC to the SAP esmart ALE Outbound router');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'SapZfishkj09','SI_BS_FGFSH_INVOICE_SAP_ESMALL_KJ09_PCONF','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'nmithari','Routing Entry to Route ZFISHKJ09  IDOC to the SAP esmart ALE Outbound router');

--29/05/2014 HA Added for FRS 620
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'VEHWEIGHT','SI_BS_VCATS_VEHICLE_PLO_VEHWEIGHT','SI.AD.PLO.OUT',null,null,null,'havhale','PLO Outbound Adapter');

--30/05/2014 AaP Added for IFU1898
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL','SI_SV_VEHSV_PUBFINSTAT','SI.AD.CANONICAL.VEHICLE.STATUS.IN',null,null,null,'apanjiya','Entry for Publish Finance Status');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'VEH_STAT', 'manufacturing/ExternalVehicleFinanceStatus','SI_BS_CANON_VEH_STATUS','SI.BS.VEHICLE.EVENTS.VISTA.IN',null,null,null,'apanjiya','Entry for Publish Finance Status');

--01/06/2014 SG Added for FRS-136
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL','SI_SV_CUSSV_REPACVHOWN','SI.AD.CANONICAL.ACCOUNT.IN',null,null,null,'sgoswam1','Entry for Replicate Account and Vehicle Ownership Service');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'ACCOUNT', 'CANONICAL','SI_SV_CUSSV_REPACVHOWN','SI.SV.REPACCVEHOWN.IN',null,null,null,'sgoswam1','Entry for Canonical to Replicate Account and Vehicle Ownership business Service Flow');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL','SI_SV_CUSSV_REPVHVHOWN','SI.AD.CANONICAL.VEHICLE.IN',null,null,null,'sgoswam1','Entry for Replicate Vehicle and Vehicle Ownership Service');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'VEHICLE', 'CANONICAL','SI_SV_CUSSV_REPVHVHOWN','SI.SV.REPVEHVEHOWN.IN',null,null,null,'sgoswam1','Entry for Canonical to Replicate Vehicle and Vehicle Ownership business Service Flow');

--11/09/2014 SG Added new entries for FRS-136(R2.0)
--10/10/2014 SB Commented BMA entries for FRS-136 as part of IFU2438(R2.0)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'AVO', 'CANONICAL','SI_SV_CUSSV_REPAVO','SI.SV.REPLICATEAVO.IN',null,null,null,'sgoswam1','Entry for Replicate Account and Vehicle Ownership Service');
--IFU4565:Commented below entries as the OSH is no more required
/* INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_SOAP_1', 'SOAP_OUTBOUND', 'REPAVO','SI_SV_CUSSV_REPAVO_OSH','SI.AD.CANONICAL.ACCOUNT.IN',null,null,null,'sgoswam1','Entry for Replicate Account and Vehicle Ownership Service for OSH');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'ACCOUNT', 'CANONICAL','SI_SV_CUSSV_REPAVO_OSH','SI.SV.REPLICATEAVO.IN',null,null,null,'sgoswam1','Entry for Canonical to Replicate Account and Vehicle Ownership business Service Flow for OSH'); */ 
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_SOAP_1', 'SOAP_OUTBOUND', 'REPAVO','SI_SV_CUSSV_REPAVO_OCCAM','SI.AD.CANONICAL.ACCOUNT.IN',null,null,null,'sgoswam1','Entry for Replicate Account and Vehicle Ownership Service for OCCAM');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'ACCOUNT', 'CANONICAL','SI_SV_CUSSV_REPAVO_OCCAM','SI.SV.REPLICATEAVO.IN',null,null,null,'sgoswam1','Entry for Replicate Account and Vehicle Ownership Service for OCCAM'); 
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_SOAP_1', 'SOAP_OUTBOUND', 'REPAVO','SI_SV_CUSSV_REPAVO_BMA','SI.AD.CANONICAL.ACCOUNT.IN',null,null,null,'sgoswam1','Entry for Replicate Account and Vehicle Ownership Service for BMA');
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'ACCOUNT', 'CANONICAL','SI_SV_CUSSV_REPAVO_BMA','SI.SV.REPLICATEAVO.IN',null,null,null,'sgoswam1','Entry for Replicate Account and Vehicle Ownership Service for BMA');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'VVO', 'CANONICAL','SI_SV_CUSSV_REPVVO','SI.SV.REPLICATEVVO.IN',null,null,null,'sgoswam1','Entry for Replicate Vehicle and Vehicle Ownership Service');
--IFU4565:Commented below entries as the OSH is no more required
/* INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_SOAP_1', 'SOAP_OUTBOUND', 'REPVVO','SI_SV_CUSSV_REPVVO_OSH','SI.AD.CANONICAL.VEHICLE.IN',null,null,null,'sgoswam1','Entry for Replicate Vehicle and Vehicle Ownership Service for OSH');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'VEHICLE', 'CANONICAL','SI_SV_CUSSV_REPVVO_OSH','SI.SV.REPLICATEVVO.IN',null,null,null,'sgoswam1','Entry for Canonical to Replicate Vehicle and Vehicle Ownership business Service Flow for OSH'); */ 
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_SOAP_1', 'SOAP_OUTBOUND', 'REPVVO','SI_SV_CUSSV_REPVVO_OCCAM','SI.AD.CANONICAL.VEHICLE.IN',null,null,null,'sgoswam1','Entry for Replicate Vehicle and Vehicle Ownership Service for OCCAM');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'VEHICLE', 'CANONICAL','SI_SV_CUSSV_REPVVO_OCCAM','SI.SV.REPLICATEVVO.IN',null,null,null,'sgoswam1','Entry for Replicate Vehicle and Vehicle Ownership Service for OCCAM'); 
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_SOAP_1', 'SOAP_OUTBOUND', 'REPVVO','SI_SV_CUSSV_REPVVO_BMA','SI.AD.CANONICAL.VEHICLE.IN',null,null,null,'sgoswam1','Entry for Replicate Vehicle and Vehicle Ownership Service for BMA');
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'VEHICLE', 'CANONICAL','SI_SV_CUSSV_REPVVO_BMA','SI.SV.REPLICATEVVO.IN',null,null,null,'sgoswam1','Entry for Replicate Vehicle and Vehicle Ownership Service for BMA');  

--07/04/2017: IFU4533 :SK - Added entries for newly destination 'SAPVMS' entries for VVO
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_SOAP_1','SOAP_OUTBOUND','REPVVO','SI_SV_CUSSV_REPVVO_SAPVMS','SI.AD.CANONICAL.VEHICLE.IN',null,null,null,'skumari4','Entry for Replicate Vehicle and Vehicle Ownership Service for SAPVMS');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL','VEHICLE','CANONICAL','SI_SV_CUSSV_REPVVO_SAPVMS','SI.SV.REPLICATEVVO.IN',null,null,null,'skumari4','Entry for Canonical to Replicate Vehicle and Vehicle Ownership business Service Flow for SAPVMS');

--11/06/2014 NM Added for IA 09- IFU 1985 Vehicle Events To PXCAR
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'VEH_STAT', 'SapZvistaD42OutIf/INVDLR','SI_BS_CANON_VEH_STATUS','SI.BS.VEHICLE.EVENTS.PXCAR.IN',null,null,null,'nmithari','Entry for Vehicle Status INVDLR event to PRIXVAR');

--20/06/2014 HA added for IA - 05 Vista To SMART
-- 01/07/2014 Addition of entry For IA 05 - SMARt - IFU 2103
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_SMTALL_BAPI', 'BAPI_OUTBOUND', 'SapZvmVistaFromEsb','SI_BS_VISTA_SALESORDER_SAP_SMT_GOFVISTA','SI.AD.SAP.SMTALL.BAPIST.OUT',null,null,null,'havhale','Route to SMART BAPI Outbound adapter');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_SMTALL_BAPI', 'BAPI_OUTBOUND', 'SapZvmVistaFromEsb','SI_BS_VISTA_SALESORDER_SAP_SMT_GOFVISTAFR','SI.AD.SAP.SMTFR.BAPI.OUT',null,null,null,'achaudha','SAP SMART FR BAPI Outbound entry for VISTA GOF');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_SMTALL_BAPI', 'BAPI_OUTBOUND', 'SapZvmVistaFromEsb','SI_BS_VISTA_SALESORDER_SAP_SMT_GOFVISTACN','SI.AD.SAP.SMTCN.BAPI.OUT',null,null,null,'achaudha','SAP SMART CN BAPI Outbound entry for VISTA GOF');



--23/06/2014 HA added for IA - 61 PLO/D42 To SMART
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_SMT_ALE', 'ALE_OUTBOUND', 'SapZvmVistaFromEsb','SI_BS_ALL_MISC_SMA_PLANEVENT','SI.AD.SAP.SMTALL.ALEST.OUT',null,null,null,'havhale','Route to SMART ALE Outbound adapter');
-- 01/07/2014 AC Entries added as per IFU 2103
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_SMT_ALE', 'ALE_OUTBOUND', 'SapZvmVistaFromEsb','SI_BS_ALL_MISC_SMA_PLANEVENTCN','SI.AD.SAP.SMTCN.ALE.OUT',null,null,null,'achaudha','Planning Event to SMART CN');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_SMT_ALE', 'ALE_OUTBOUND', 'SapZvmVistaFromEsb','SI_BS_ALL_MISC_SMA_PLANEVENTFR','SI.AD.SAP.SMTFR.ALE.OUT',null,null,null,'achaudha','Planning Event to SMART FR');


INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_HTTP_1', 'HTTP_INBOUND', 'Vehicle/VehiclePlanning','SI_BS_ALL_MISC_SMA_PLANEVENT','SI.BS.MULTI.PLANINGEVENT.TO.SMTALL.IN',null,null,null,'havhale','Route to BS Flow');

--25/06/2014 HA Addition of entries for IA-67, D42 Vehicle Events to SAP Smart
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_HTTP_1', 'HTTP_INBOUND', 'Vehicle/vehiclestatusupdate','SI_BS_D42_VEH_SAP_SMTALL_VEHEVENTS','SI.AD.CANONICAL.VEHICLE.STATUS.IN',null,null,null,'havhale','HTTP Inbound Routing for D42 to SAP Smart for Vehicle Events');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'VEH_STAT', 'Vehicle/vehiclestatusupdate','SI_BS_D42_VEH_SAP_SMTALL_VEHEVENTS','SI.BS.D42.VEHEVENTS.TO.SAP.SMTALL.IN',null,null,null,'havhale','Canonical Translation for D42 to SAP Smart for Vehicle Events');
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_SMT_ALE', 'ALE_OUTBOUND', 'SapZstatusPlngIdoc','SI_BS_D42_VEH_SAP_SMTALL_VEHEVENTS','SI.AD.SAP.SMTALL.ALEST.OUT',null,null,null,'havhale','SAP ALE Outbound entry for D42 Vehicle Events');

18/07/2014 IFU 2103 entry to be removed
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_HTTP_1', 'HTTP_REPLY', 'Vehicle/vehiclestatusupdate','SI_BS_D42_VEH_SAP_SMTALL_VEHEVENTS','SI.AD.HTTP.DISTRIBUTION.REPLY.IN',null,null,null,'havhale','HTTP reply entry for D42 Vehicle Events');

-- 02/07/2014 AC Addition of entries for IFU 2103
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_SMT_ALE', 'ALE_OUTBOUND', 'SapZstatusPlngIdoc','SI_BS_D42_VEH_SAP_SMTALL_VEHEVENTSCN','SI.AD.SAP.SMTCN.ALE.OUT',null,null,null,'achaudha','SAP ALE CN Outbound entry for D42 Vehicle Events');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_SMT_ALE', 'ALE_OUTBOUND', 'SapZstatusPlngIdoc','SI_BS_D42_VEH_SAP_SMTALL_VEHEVENTSFR','SI.AD.SAP.SMTFR.ALE.OUT',null,null,null,'achaudha','SAP ALE FR Outbound entry for D42 Vehicle Events');

-- 27/06/2014 AC Addition of entry for IA 122- defect 8323
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_ESMALL_BAPI','BAPI_INBOUND','SapZfiF110XmlToEsbWrapper_NL02','SI_BS_SAP_ESM_PAYMT_MULTI_BNKTRNPYMT','SI.BS.SAP.ESM.BANKTRANSPYMTS.TO.MULTI.IN',null,null,null,'achaudha','Routing Entry to Route Bank Payments to the associated Business Service');

--09/07/2014 NM Insert statement for FRS-000640 � WERS Code Description (WERS to ATD,TOPix and SAP TURBO)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE', 'ALE_OUTBOUND', 'ZI_WTYWERSMDATA','SI_BS_WERS_VEHSERV_ALL_CODEDESC','SI.AD.SAP.TRBGB.ALE.OUT',null,null,null,'nmithari','WERS Code Description to SAP Turbo');

--21/04/2017 AT Removed entries as part of IFU4590
--01/06/2014 GT Added for FRS-138
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL','SI_SV_CUSSV_REPVEHDERV','SI.AD.CANONICAL.VEHICLE.IN',null,null,null,'gthamma','Entry for Replicate Vehicle Derivatives');

--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'VEHICLE', 'CANONICAL','SI_SV_CUSSV_REPVEHDERV','SI.SV.REPLICATEVEHDERIV.CANON.IN',null,null,null,'gthamma','Entry for Replicate Vehicle Derivatives');

--15/07/2014 GG Added for FRS-633
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_INBOUND', 'SapZshpdata','SI_BS_SAP_ESMAU_VEHICLE_PXCAR_SHPNOTIFIC','SI.BS.SAP.ESMAU.SHPNOTIFIC.TO.PXCAR.IN',null,null,null,'ggawali','Entry for Vehicle Shipment Notification');


--22/07/2014 AP added for FRS-632
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_HTTP_1', 'HTTP_INBOUND', 'Flags2D42Service/QueryManufactureStatus','SI_SV_VEHSV_FLAGSD42PROC','SI.SV.FLAGSD42PROC.IN',null,null,null,'apathak2','HTTP Inbound Routing for D42 to FLAGS2');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_HTTP_1', 'HTTP_INBOUND', 'Flags2D42Service/SetManufactureStatus','SI_SV_VEHSV_FLAGSD42PROC','SI.SV.FLAGSD42PROC.IN',null,null,null,'apathak2','HTTP Inbound Routing for D42 to FLAGS2');
--18/08/2016 KB updated for FRS-632
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_HTTP_1', 'HTTP_REPLY', 'Flags2D42Service/*','SI_SV_VEHSV_FLAGSD42PROC','SI.AD.FLAGSD42.HTTP.PRCMNFSTS.IN',null,null,null,'kbhosale','HTTP Reply to D42');

--23/07/2014 TK Added for FRS-141
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL','SI_SV_CUSSV_CTUPVEHOWN','SI.AD.CANONICAL.VEHICLE.IN',null,null,null,'tksheers','Entry for Crt Upd Vehicle Ownership');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'VEHICLE', 'CANONICAL','SI_SV_CUSSV_CTUPVEHOWN','SI.SV.CRTUPD.VEHOWNSHP.IN',null,null,null,'tksheers','Entry for Crt Upd Vehicle Ownership for Canonical Vehicle Adapter');

-- 31/07/2014 AK FRS 615

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE', 'ALE_INBOUND', 'ZI_WTYCONTDATA', 'SI_BS_SAP_TRBGB_VEHICLE_ALL_REPWTYCNTR','SI.BS.SAP.TRBGB.REPWTYCNTRCT.TO.ALL.IN',null,null,null,'akarma', 'SAP Warranty Contract to Service Flow');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_BS_SAP_TRBGB_VEHICLE_ALL_REPWTYCNTR','SI.AD.CANONICAL.WARRANTYCONTRACT.IN',null,null,null,'akarma', 'SAP Warranty Contract to Canonical Flow');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'WARRANTY', 'CANONICAL', 'SI_BS_SAP_TRBGB_VEHICLE_ALL_REPWTYCNTR','SI.BS.SAP.TRBGB.REPWTYCNTRCT.CANON.IN',null,null,null,'akarma', 'SAP Warranty Contract Canonical to Service Flow');

-- 11/08/2014 HA FRS - 644
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'FILE_TO_MQ_OUTBOUND', 'VISTA', 'SI_BS_VISTA_VEHICLE_ALL_ORDER_STATUS_BATCH','SI.BS.VISTA.ORDERSTATUS.TO.DURBAN.IN',null,null,null,'havhale', 'VISTA vehicle (order and feature) updates published to consumers');

-- 11/08/2014 SB Added Entry for FRS-000137
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV','MQ_OUTBOUND', 'CANONICAL','SI_SV_CUSSV_CTUPVHCL','SI.AD.CANONICAL.VEHICLE.IN',null,null,null,'sbabu4','FRS-00137- Entry for Crt Upd Vehicle');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL','VEHICLE','CANONICAL', 'SI_SV_CUSSV_CTUPVHCL','SI.SV.CRTUPD.VEHICLE.IN',null,null,null,'sbabu4','FRS-00137 - Entry for Crt Upd Vehicle for Canonical Vehicle Adapter');

-- 13/08/2014 NM Added entry for IA-258(IFU 2178)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESMALL_BAPI','BAPI_INBOUND','SapZrfcHfmEomFiDataWrapper', 'SI_BS_SAP_ESM_INVOICE_HYPER_FIDATA','SI.BS.SAP.ESMALL.FIDATA.TO.HYPER.IN',null,null,null,'nmithari','SAP To Hyperion Financial Data');

-- 13/08/2014 SM Added entry for FRS-628
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE','ALE_INBOUND','SapZiParStatus', 'SI_BS_SAP_TRBGB_VEHICLE_GCM_FREDMAINT','SI.BS.SAP.TRBGB.FREDMAINT.TO.GCM.IN',null,null,null,'smuley','Warranty FRED Update to GCM');

-- 20/08/2014 AP Added entry for FRS-272
--22/08/2014 AP Now sap_inbound_control header will be used.
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE','ALE_INBOUND','SapOrders05Zeiorders05', 'SI_SV_VEHSV_TDPARTS','SI.SV.TRADIVVEHPART.IN',null,null,null,'apathak2','SAP Trading Division ORDERS05 to Service flow');

--21/08/2014 TK Added for FRS-143
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL','SI_SV_CUSSV_SENDWRTCON','SI.AD.CANONICAL.WARRANTYCONTRACT.IN',null,null,null,'tksheers','Entry for Send Warranty Contract Service');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL','SI_SV_CUSSV_SENDWRTCON_ACCT','SI.AD.CANONICAL.ACCOUNT.IN',null,null,null,'tksheers','Entry for Send Warranty Contract
Account Service');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL','SI_SV_CUSSV_SENDWRTCON_VREL','SI.AD.CANONICAL.VEHICLE.IN',null,null,null,'tksheers','Entry for Send Warranty Contract
Vehicle Service');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'ACCOUNT', 'CANONICAL','SI_SV_CUSSV_SENDWRTCON','SI.SV.SEND.WRNTYCONTR.CANON.IN',null,null,null,'tksheers','Entry for Send Warranty Contract
for Canonical Account Adapter');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'WARRANTY', 'CANONICAL','SI_SV_CUSSV_SENDWRTCON','SI.SV.SEND.WRNTYCONTR.CANON.IN',null,null,null,'tksheers','Entry for Send Warranty Contract
for Canonical WarrantyContract Adapter');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'VEHICLE', 'CANONICAL','SI_SV_CUSSV_SENDWRTCON','SI.SV.SEND.WRNTYCONTR.CANON.IN',null,null,null,'tksheers','Entry for Send Warranty Contract for Canonical Vehicle Adapter');

--22/08/2014 AC Added for IA- 63 (IFU 2250)
--15/03/2016 PK Removed for IFU3771
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'Warranty_Claim_FromVKING','SI_BS_VKING_INVOICE_SAP_ESM_WRNTYBILLG','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'achaudha','VIKING Warranty Claim Billing to SAP eSmart');

-- 27/08/2014 HA Added for FRS - 277 (Trading Division) IFU 2220,2227
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE', 'ALE_OUTBOUND', 'executeSapDelvry03','SI_BS_ESB_VEHICLE_SAP_TRB_ASNPROV','SI.AD.SAP.TRBGBTD.ALE.OUT',null,null,null,'havhale','ASN Provision to SAP Turbo Trading Division');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'provideASNEnhancement','SI_SV_VEHSV_ADVSHPNT','SI.BS.ESB.ASNPROVTD.TO.SAP.TRBGB.IN',null,null,null,'havhale','Route ASN To Trading Division');

-- 04/09/2014 NCH Added for FRS - 096 (Enovia TO MPNR)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) 
VALUES ('ENOV_MQ_OUT_1','MQ_OUTBOUND','SER_PART_CHG','SI_BS_MPNR_PRODUCT_ENOV_SERVICEPART','SI.AD.ENOV.OUT',null,'nch','Entry for Servicepart changes');

-- 05/09/2014 NM Added entry for FRS-634(IFU 2278)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE','ALE_INBOUND','SapZshpdata', 'SI_BS_SAP_ESMAU_VEHICLE_PXCAR_VEHICLEUPD','SI.BS.SAP.ESMAU.VEHICLEUPD.TO.PXCAR.IN',null,null,null,'nmithari','Copy to Vehicle Update flow');

-- 09/09/2014 AK Entries for FRS 631

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE','ALE_INBOUND','SapZiWtycjlrprofet', 'SI_BS_SAP_TRBGB_VEHSERV_PLO_WERSCONV','SI.BS.SAP.TRBGB.WERSCODECONV.TO.PLO.IN',null,null,null,'akarma','Route SAP Turbo Brand Codes  to PLO');

INSERT INTO SI_SERVICE_ROUTING  (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE','ALE_OUTBOUND','SAP_ALE','SI_BS_PLO_VEHSERV_SAP_TRBGB_WERSCONV','SI.AD.SAP.TRBGB.ALE.OUT',null,null,null,'akarma','Entry for route WERS Codes Conv to SAP Turbo ');

INSERT INTO SI_SERVICE_ROUTING  (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV','MQ_OUTBOUND','PLO_MQ','SI_BS_PLO_VEHSERV_SAP_TRBGB_WERSCONV','SI.BS.SAP.TRBGB.WERSCODECONV.TO.PLO.IN',null,null,null,'akarma','Entry for route Brand Codes Conv to PLO');

--18/09/2014 AaP Def-9126 Removed space from Service Identifier value
-- 09/09/2014 AC Added entry for IA 122(IFU 2320)
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESMALL_BAPI', 'BAPI_INBOUND', 'SapZfiF110XmlToEsbWrapper _AU02','SI_BS_SAP_ESM_PAYMT_MULTI_BNKTRNPYMT','SI.BS.SAP.ESM.BANKTRANSPYMTS.TO.MULTI.IN',null,null,null,'achaudha','Routing Entry to Route Bank Payments to the associated Business Service');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESMALL_BAPI', 'BAPI_INBOUND', 'SapZfiF110XmlToEsbWrapper_AU02','SI_BS_SAP_ESM_PAYMT_MULTI_BNKTRNPYMT','SI.BS.SAP.ESM.BANKTRANSPYMTS.TO.MULTI.IN',null,null,null,'apanjiya','Routing Entry to Route Bank Payments to the associated Business Service');


-- 11/09/2014 AC Added entry for IA 122(IFU 2340)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_INBOUND', 'SapZvehicleDrafting','SI_BS_SAP_ESM_PAYMT_MULTI_BNKTRNPYMT','SI.BS.SAP.ESM.BANKTRANSPYMTS.TO.MULTI.IN','SI.BS.SAP.ESM.BANKTRANSPYMTS.TO.MULTI.BATCH',null,null,'achaudha','Routing entry to Business Service Flow to process  Bank Transactions Payments');

-- 08/03/2016 LH Added entry for IFU3759 IA-122
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_SMTCN_BAPI', 'BAPI_INBOUND', 'SapZfmTmsF110SapToEsbWrapper_JLCN','SI_BS_SAP_ESM_PAYMT_MULTI_BNKTRNPYMT','SI.BS.SAP.ESM.BANKTRANSPYMTS.TO.MULTI.IN','SI.BS.SAP.ESM.BANKTRANSPYMTS.TO.MULTI.BATCH',null,null,'Achibbe1','Routing Entry to Route Bank Payments to TMS');

-- 29/07/2016 NM Added entry for IFU4012/INC000001564937 IA-122
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESMALL_BAPI', 'BAPI_INBOUND', 'SapZfiF110XmlToEsbWrapper_KR02','SI_BS_SAP_ESM_PAYMT_MULTI_BNKTRNPYMT','SI.BS.SAP.ESM.BANKTRANSPYMTS.TO.MULTI.IN',null,null,null,'nmithari','Routing Entry to Route Bank Payments to the associated Business Service');


-- 24/09/2014 TK Entries for FRS 362
-- 19/07/2016 LH removed routing entries as per desing change for INC000001504510 FRS-362. Mapping with flow that uses queue was removed and subflow was used. Hence no need of following routing entries.
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV','MQ_OUTBOUND','CANONICAL', 'SI_SV_VEHSV_VEHENQUIRY','SI.AD.CANONICAL.VEHICLE.IN',null,null,null,'tksheers','Vehicle Enquiry to Canonical Adapter');

--INSERT INTO SI_SERVICE_ROUTING  (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL','VEHICLE','CANONICAL','SI_SV_VEHSV_VEHENQUIRY','SI.SV.VEHENQUIRY.IN',null,null,null,'tksheers','Response from Vehicle Canonical Adapter');

-- 30/09/2013 AaP IFU-2346 Entries for IA-124(ANZ system added)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION)VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'VehDraft_Finsta01', 'SI_BS_ANZB_BNKREPLY_SAP_ESMAU_ACKSTAT', 'SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'apanjiya', 'Entry for the IA 124 for SAP eSMART for ANZ');

-- 07/09/2016 MJ IFU-4084 Entries for IA-124(Citibank Korea system added)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION)VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'VehDraft_Finsta01', 'SI_BS_CTBKR_BNKREPLY_SAP_ESMKR_ACKSTAT', 'SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'mjeevart', 'Entry for IA 124 for SAP eSMART');

-- 06/10/2014- Entry added for FRS-650
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION)VALUES ('SAP_TRBGB_ALE', 'ALE_OUTBOUND', 'VEHPAR_TRANS_UPD_OUT', 'SI_BS_AOS_VEHICLE_SAP_TRBGB_VEHPATRAUP', 'SI.AD.SAP.TRBGB.ALE.OUT',null,null,null,'apathak2', 'Route Vehicle Parts Transportation data to SAP Turbo ALE Outbound Adapter');

-- 07/10/2014 - Entry added for business service 'SI_BS_SAP_TRBGB_HR_MSXI_SECRTYDATA' for incident INC000000122148
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) values ('ESB_BUS_SERV','MQ_OUTBOUND','SEC_DATA_ESB','SI_BS_SAP_TRBGB_HR_MSXI_SECRTYDATA','SI.BS.SAP.TRBGB.SECRTYDATA.TO.MSXI.BATCH',null,'ppancha3','HR Security data internal routing entry');

-- 09/10/2014 -SS Entry added for FRS-648
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('SAP_TRBGB_ALE','ALE_OUTBOUND','ZI_PARTLOCL','SI_SV_VEHSV_PARTSLOCAL','SI.AD.SAP.TRBGB.ALE.OUT','ssingh20','Parts Localisation Data to SAP Turbo');

-- 20/10/2014 - SK Added entries for FRS 382-Part1(SAP to Canonical)
-- 21/11/2014 - SP Defect 10513 - Entry below, SERVICE_IDENTIFIER changed from ZI_WTYCLM to SapZiWtyclm1
--INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES('SAP_TRBGB_ALE','ALE_INBOUND','ZI_WTYCLM','SI_BS_SAP_TRBGB_VEHICLE_ALL_WTYCLAIM','SI.BS.SAP.TRBGB.REPWTYCLAIM.TO.ALL.IN','skolhe','SAP Warranty Claim to Business Service Flow');
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES('SAP_TRBGB_ALE','ALE_INBOUND','SapZiWtyclm1','SI_BS_SAP_TRBGB_VEHICLE_ALL_WTYCLAIM','SI.BS.SAP.TRBGB.REPWTYCLAIM.TO.ALL.IN','skolhe','SAP Warranty Claim to Business Service Flow');
      
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES('ESB_BUS_SERV','MQ_OUTBOUND','CANONICAL','SI_BS_SAP_TRBGB_VEHICLE_ALL_WTYCLAIM','SI.AD.CANONICAL.WARRANTYCLAIM.IN','skolhe','SAP Warranty Claim to Canonical Flow');                                                                                                                                                                                                                             
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES('CANONICAL','WARRANTY','CANONICAL','SI_BS_SAP_TRBGB_VEHICLE_ALL_WTYCLAIM','SI.BS.SAP.TRBGB.REPWTYCLAIM.CANON.IN','skolhe','SAP Warranty Contract Canonical to Business Service Flow');

INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES('ESB_BUS_SERV','MQ_OUTBOUND','WTY_CLAIM_MFT_TEST_OUT','SI_BS_SAP_TRBGB_VEHICLE_MFT_WTYCLAIM','SI.BS.SAP.TRBGB.REPWTYCLAIM.TO.MFT.IN','skolhe','SAP Warranty Claim Canonical to Business Service Transformation Flow');

-- 27/10/2014 -AaP Entry added for FRS-654
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('SAP_ESM_ALE','ALE_INBOUND','SapZvmCrmDms','SI_BS_SAP_ESMIN_VEHICLE_DMS_VEHVMSUPD','SI.BS.SAP.ESMIN.VEHVMSUPD.TO.DMS.IN','apanjiya','Entry for Vehicle VMS Update');

---13/11/2014 AK Entry added for FRS 364
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('SAP_TRBGB_ALE','ALE_INBOUND','SapZiWtyvehboly','SI_BS_SAP_TRBGB_VEHICLE_ALL_WRTYVEHCFG','SI.BS.SAP.TRBGB.WRTYVEHCFG.TO.ALL.IN','akarma','Warranty Vehicle Configuration to Multi');

---25/11/2014 NCH Entry updated for FRS-000090(SI_FL_Product)
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('ESB_BUS_SERV','MQ_OUTBOUND','ACE_VEHDESC','SI_BS_ACE_PRODUCT_ALL_VEHSPECDES','SI.BS.ACE.VEHDESC.TO.ALL.IN','nch','Entry for ACE Vehicle Descriptions');

---22/11/2014 Entry for FRS-000656
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('SAP_TRBGB_ALE','ALE_OUTBOUND','','SI_BS_WIPS_VEHICLE_TD_SAP_TRBGB_PRTPRICUPD','SI.AD.SAP.TRBGBTD.ALE.OUT','ppancha3','Entry for Vehicle PartsPriceUpdate. Route to SAP Trading Division outbound adapter');

-- 26/11/2014 AK Entries for FRS 382 - 2B
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('ESB_MULTI_BATCH','MQ_OUTBOUND','CJLR','SI_BS_SAP_TRBGB_VEHICLE_CJLR_WTYCLAIM_PD','SI.BS.SAP.TRBGB.REPWTYCLAIM.TO.CJLR.IN','akarma','Entry for SAP to CJLR Warranty Claim transform flow');

Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('ESB_MULTI_BATCH','MQ_OUTBOUND','CJLR','SI_BS_SAP_TRBGB_VEHICLE_CJLR_WTYCLAIM_SBI','SI.BS.SAP.TRBGB.REPWTYCLAIM.TO.CJLR.IN','akarma','Entry for SAP to CJLR Warranty Claim transform flow');
 
-- 27/11/2014 SK Added entries for FRS 382 - 2A SWORD
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('ESB_MULTI_BATCH','MQ_OUTBOUND','SWORD','SI_BS_SAP_TRBGB_VEHICLE_SWORD_WTYCLAIMJA','SI.BS.SAP.TRBGB.REPWTYCLAIM.TO.SWORD.IN','skolhe','Entry for SAP to SWORD Warranty Claim transform flow');

Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('ESB_MULTI_BATCH','MQ_OUTBOUND','SWORD','SI_BS_SAP_TRBGB_VEHICLE_SWORD_WTYCLAIMLR','SI.BS.SAP.TRBGB.REPWTYCLAIM.TO.SWORD.IN','skolhe','Entry for SAP to SWORD Warranty Claim transform flow');

---  27/11/2014 SM Added Entries for FRS 382 - 2C SMART 
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('ESB_MULTI_BATCH','MQ_OUTBOUND','SMART','SI_BS_SAP_TRBGB_VEHICLE_SMART_WTYCLAIM','SI.BS.SAP.TRBGB.REPWTYCLAIM.TO.SMART.IN','smuley','Entry for SAP to SMART China Warranty Claim transform flow');

--- 27/11/2014 TK Entry added for FRS 382 Part 2D2- Defect-10566
--Jaguar Unpaid Claim 
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('ESB_MULTI_BATCH','MQ_OUTBOUND','BWOOD','SI_BS_SAP_TRBGB_VEHICLE_BWOOD_WTYCLAIM_JAUPD','SI.BS.SAP.TRBGB.REPWTYCLAIM.TO.BWOOD.IN','tksheers','Entry for SAP to BWOOD Warranty Claim transform flow');

--Landrover Unpaid Claim
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('ESB_MULTI_BATCH','MQ_OUTBOUND','BWOOD','SI_BS_SAP_TRBGB_VEHICLE_BWOOD_WTYCLAIM_LRUPD','SI.BS.SAP.TRBGB.REPWTYCLAIM.TO.BWOOD.IN','tksheers','Entry for SAP to BWOOD Warranty Claim transform flow');

--Jaguar Held Claim 
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('ESB_MULTI_BATCH','MQ_OUTBOUND','BWOOD','SI_BS_SAP_TRBGB_VEHICLE_BWOOD_WTYCLAIM_JAHLD','SI.BS.SAP.TRBGB.REPWTYCLAIM.TO.BWOOD.IN','tksheers','Entry for SAP to BWOOD Warranty Claim transform flow');

--Landrover Held Claim
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('ESB_MULTI_BATCH','MQ_OUTBOUND','BWOOD','SI_BS_SAP_TRBGB_VEHICLE_BWOOD_WTYCLAIM_LRHLD','SI.BS.SAP.TRBGB.REPWTYCLAIM.TO.BWOOD.IN','tksheers','Entry for SAP to BWOOD Warranty Claim transform flow');

--- 01/12/2014 PG Entry added for FRS 382 Part 2C1- Defect-10566
--Jaguar Claim 
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('ESB_MULTI_BATCH','MQ_OUTBOUND','AUTOA','SI_BS_SAP_TRBGB_VEHICLE_AUTOA_WTYCLAIM_JAPD','SI.BS.SAP.TRBGB.REPWTYCLAIM.TO.AUTOA.IN','pgupta3','Entry for SAP to AUTOA Warranty Claim transform flow');

--Landrover Claim
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('ESB_MULTI_BATCH','MQ_OUTBOUND','AUTOA','SI_BS_SAP_TRBGB_VEHICLE_AUTOA_WTYCLAIM_LRPD','SI.BS.SAP.TRBGB.REPWTYCLAIM.TO.AUTOA.IN','pgupta3','Entry for SAP to AUTOA Warranty Claim transform flow');

--- 01/12/2014 PG Entry added for FRS 382 Part 2B1 and 2D1- Defect-10566
--Paid Claim 
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('ESB_MULTI_BATCH','MQ_OUTBOUND','SYC1','SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM_PD','SI.BS.SAP.TRBGB.REPWTYCLAIM.TO.SYC1.IN','pgupta3','Entry for SAP to SYC1 Warranty Claim transform flow');

--Unpaid Claim
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('ESB_MULTI_BATCH','MQ_OUTBOUND','SYC1','SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM_UPD','SI.BS.SAP.TRBGB.REPWTYCLAIM.TO.SYC1.IN','pgupta3','Entry for SAP to SYC1 Warranty Claim transform flow');

--SS 08/12/2014 Updated for Def 11001 for FRS-00382
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('ESB_MULTI_BATCH','MQ_OUTBOUND','WTY_CLAIM_MFT_TEST_OUT','SI_BS_SAP_TRBGB_VEHICLE_MFT_WTYCLAIM','SI.BS.SAP.TRBGB.REPWTYCLAIM.TO.MFT.IN','ssingh20','SAP Warranty Contract Canonical to Business Service Transformation Flow');

-- 06/01/2015 SM Added Entry for FRS-00118(R1.2)
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('SAP_SVCRM_ALE','ALE_OUTBOUND','executeSapZjlrCmpgnCreateUpdate','SI_BS_CUSSV_CRTUPDCPGNEVNTORRSPS_SIMP','SI.AD.SAP.SVCRM.ALE.OUT','smuley','Entry for output to SAP SVCRM adapter');

-- 07/01/2015 AB Added Entry for FRS-00128(R1.2)
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) Values('SAP_SVCRM_ALE','ALE_OUTBOUND','ZJLR_REPORD','SI_BS_CUSSV_CTUPSERREP_SIMP','SI.AD.SAP.SVCRM.ALE.OUT','abasak','Publish IDOC for ZJLR_REPORD');

-- 09/01/2015 SB Added Entry for FRS-00112(R1.2)
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) Values('SAP_SVCRM_ALE','ALE_OUTBOUND','executeSapZjlrLeadCreateUpdate','SI_BS_CUSSV_CRTUPDLEAD_SIMP','SI.AD.SAP.SVCRM.ALE.OUT','sbabu4','Entry for output to SAP SVCRM adapter');

-- 09/01/2015 AS Added Entry for FRS-00117(R1.2)
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) Values('SAP_SVCRM_ALE','ALE_OUTBOUND','executeSapZjlrCrtUpdFinCont','SI_BS_CUSSV_CRTUPDFINCNTRPROP_SIMP','SI.AD.SAP.SVCRM.ALE.OUT','asharm32','Entry for output to SAP SVCRM adapter');

-- 15/01/2015 TK Added entry for FRS-000139
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('SAP_SVCRM_ALE','ALE_OUTBOUND','executeSapZjlrBbssCreateUpdate','SI_BS_CUSSV_REPVEHSALESTAT_SIMP','SI.AD.SAP.SVCRM.ALE.OUT','tksheers','Entry for output to SAP SVCRM adapter');

-- 23/01/2015 NM Added entry for FRS-000660
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('SAP_ESM_ALE','ALE_INBOUND','SapZimaweb','SI_BS_SAP_ESMIB_VEHICLE_ALL_VEHSTOKREP','SI.BS.SAP.ESMIB.VEHSTOKREP.TO.ALL.IN','nmithari','Entry for FRS 660 - Vehicle Stock Report');

-- 28/01/2015 AC Added entries for IA 27 (IFU 2593)
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('ESB_MULTI_BATCH','MQ_OUTBOUND','ESMES','SI_BS_SAP_TRBGB_INVCRDDETS_ESMES','SI.BS.SAP.TRBGB.INVCRDDETS.TO.ESMALL.IN','achaudha','Entry for SAP to eSmart Spain Invoice and Credit transform flow');
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('ESB_MULTI_BATCH','MQ_OUTBOUND','ESMPT','SI_BS_SAP_TRBGB_INVCRDDETS_ESMPT','SI.BS.SAP.TRBGB.INVCRDDETS.TO.ESMALL.IN','achaudha','Entry for SAP to eSmart Portugal Invoice and Credit transform flow');

-- 25/11/2015 MJ Added entries for IA 27 (IFU 3557)
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('ESB_MULTI_BATCH','MQ_OUTBOUND','ESMSG','SI_BS_SAP_TRBGB_INVCRDDETS_ESMSG','SI.BS.SAP.TRBGB.INVCRDDETS.TO.ESMALL.IN','mjeevart','Entry for SAP to eSmart Singapore Invoice and Credit transform flow');

-- 19/02/2015 SB Added entries for FRS-148 
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('ESB_BUS_SERV','MQ_OUTBOUND','CANONICAL','SI_SV_CUSSV_REPVEHPLAN','SI.AD.CANONICAL.VEHICLE.IN','sbabu4','Entry for Replicate Vehicle Planning Event.');
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('CANONICAL','VEHICLE','CANONICAL','SI_SV_CUSSV_REPVEHPLAN','SI.SV.REPVEHPLAN.CANON.IN','sbabu4','Entry for Replicate Vehicle Planning Event for Canonical Vehicle Adapter');

--25/02/2015 KS Added entries for FRS-000147
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('ESB_BUS_SERV','MQ_OUTBOUND','CANONICAL','SI_SV_CUSSV_REPVEHSTATUS','SI.AD.CANONICAL.VEHICLE.IN','ksarma','Entry for Replicate Vehicle Status Event.');
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('CANONICAL','VEHICLE','CANONICAL','SI_SV_CUSSV_REPVEHSTATUS','SI.SV.REPVEHSTATUS.CANON.IN','ksarma','Entry for Replicate Vehicle Status Event for Canonical Vehicle Adapter');
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('ESB_HTTP_1','HTTP_INBOUND','Vehicle/vehiclestatusupdate','SI_SV_CUSSV_REPVEHSTATUS','SI.SV.REPVEHSTATUS.IN','ksarma','Entry for Replicate Vehicle Status Event for D42 Inbound Adapter');

--10/03/2015 nch added entries for IFU2708 for FRS000091(Under SI_FL_Product)

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV','VEHFEAT_MQ_OUTBOUND','VEHFEAT','SI_BS_ACE_PRODUCT_ALL_LEGACYFEED','SI.BS.BRS.VEHSPECSFEAT.TO.SAP.ESM.IN',null,'nch','Entry for ACE Features to e-Smart');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV','VEHDERIV_MQ_OUTBOUND','VEHDERIV','SI_BS_ACE_PRODUCT_ALL_LEGACYFEED','SI.BS.BRS.VEHSPECSDERIV.TO.SAP.ESM.IN',null,'nch','Entry for ACE Derivative Data to e-Smart');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV','PLOTURBO_MQ_OUTBOUND','PLO_TURBO','SI_BS_ACE_PRODUCT_ALL_LEGACYFEED','SI.BS.BRS.PRICINGMATMAS.TO.ALL.IN',null,'nch','Entry for ACE Derivative Data to Turbo/PLO');

--11/03/2015 abasak added entries for IFU2785 for FRS000137
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) values ('ESB_BUS_SERV','MQ_OUTBOUND','CANONICAL','SI_SV_CUSSV_CTUPVHCL_SIMP','SI.AD.CANONICAL.VEHICLE.IN',null,'abasak','FRS-00137 - Entry for Crt Upd Vehicle Simplified  for Canonical Vehicle Adapter ');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) values ('CANONICAL','VEHICLE','CANONICAL','SI_SV_CUSSV_CTUPVHCL_SIMP','SI.SV.VEHICLE.CRTUPD.CANON.IN',null,'abasak','FRS-00137- Entry for Crt Upd Vehicle Simplified');

--12/03/2015 SA added entries FRS000670
--30/06/2015 SP amended BAPI Inbound SERVICE_IDENTIFIER entry from SapZfiRfcCustomBrokerFile to SapZfiRfcCustomBrokerFileWrapper
--08/10/2015 SN Added entries for IFU3429
-- 09/03/2017 AS SI_BS_MFT_Invoice_Ack_To_SAP_TRBBR no longer exists, as been removed as part of IFU3563 long back!
-- Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('SAP_TRBGB_BAPI','BAPI_OUTBOUND','SapZfiRfcCustomBrokerStatus','SI_BS_MFT_INVOICE_SAP_TRBBR_INVOICEACK','SI.AD.SAP.TRBGB.BAPI.OUT','sanupoj2','Entry for FRS 670 � Invoice Ack Details From MFT');
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('SAP_TRBGB_BAPI','BAPI_INBOUND','SapZfiRfcCustomBrokerFileWrapper','SI_BS_SAP_TRBBR_INVOICE_TITO_INVDETAILS','SI.BS.SAP.TRBBR.INVDETAILS.TO.TITO.IN','sanupoj2','Entry for FRS 670 � Invoice Details to TITO');
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('SAP_TRBGB_BAPI','BAPI_INBOUND','SapZp2pRfcSendPoToCbWrapper','SI_BS_SAP_TRBBR_INVOICE_TITO_PO','SI.BS.SAP.TRBBR.PO.TO.TITO.IN','snidumuk','Entry for FRS 670 � Purchase Order Details to TITO');

--26/03/2015 MJ Added entries for FRS000695
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE', 'ALE_INBOUND', 'SapCondA04Ze1bpcuval','SI_BS_SAP_TRBGB_PRICING_TO_ALL_MSRPDATA','SI.BS.SAP.TRBGB.REPMSRPDATA.TO.ALL.IN',null,null,null,'mjeevart','SAP MSRP data to Main Business Service Flow');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'MSRP_DATA_OUT','SI_BS_SAP_TRBGB_PRICING_TO_VISTA_MSRPDATA','SI.BS.SAP.TRBGB.REPMSRPDATA.TO.VISTA.IN',null,null,null,'mjeevart','SAP MSRP data to VISTA transformation Flow');

--31/03/2015 PK Added additional entry for FRS-000009 IFU-2901
INSERT INTO  SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES('ESB_BUS_SERV','MQ_OUTBOUND','FEATURE_OK_TO_USE_LIST','SI_BS_ACE_PRODUCT_ALL_OKTOUSELST','SI.AD.RADS.OUT',null,'pkhot','Entry for Publish Feature OK To Use List to RADS');

--08/04/2015 PT Added entries for FRS000669
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'SapZbapiJ1bNfCreatefromdata','SI_BS_TITO_HMRC_SAP_TRBBR_IMPORTDECL','SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'athota','Entry for FRS 669 � Import Declaration details From TITO');

--16/04/2015  KT Added entries for FRS-000271
--19/08/2015 KT IFU3263 FRS-000271 - FFCP request for CJLR will be sent to Local queue in ESB Switch queuemanager
INSERT INTO WMBOWNER.SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'ENGCHANGE', 'SI_BS_WERS_VEH_ALL_ENGCHANGE_FFCP', 'CJLR.PBOM.IN',null,null,null,'kthanga2', 'Engineering Change outbound to CJLR');
INSERT INTO WMBOWNER.SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'ENGCHANGE', 'SI_BS_WERS_VEH_ALL_ENGCHANGE_FFEN', 'SI.SV.ENGCHANGEFORSAP.IN',null,null,null,'kthanga2', 'Engineering Change outbound to EMC');
--25/03/2016 IFU3806 FRS-000271 BOM Filtered FFPJ data to Plant Graz
--08/04/2016 IFU3815 FRS-000271 Amend routing entry to route FFPJ to PGZ via MQ Outbound Adapter.
INSERT INTO WMBOWNER.SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'ENGCHANGE', 'SI_BS_WERS_VEH_ALL_ENGCHANGE_FFPJ', 'SI.AD.PGZ.OUT',null,null,null,'kthanga2', 'Engineering Change outbound for PlantGraz');

--16/04/2015 VV Added entries for FRS-000693
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'WERS_Engineering_Change_To_SAPTRB','SI_BS_WERS_VEHICLE_SAP_TRBGB_ENGCHANGE','SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'vvivekan','Engineering Change to SAP TRB');
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_SV_ECS', 'MQ_OUTBOUND', 'ENGCHANGE','SI_SV_WERS_ADAPSV_ENGCHNG_OUT','SI.BS.WERS.ENGCHANGE.TO.SAP.TRBGB.IN',null,null,null,'vvivekan','Engineering Change Adapter to SAP TRB');

--22/02/2016 VV IFU 3681 Added entries for FRS-000693
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'ENGCHANGE','SI_BS_WERS_VEH_ALL_ENGCHANGE','SI.BS.WERS.ENGCHANGE.TO.SAP.TRBGB.IN',null,null,null,'vvivekan','Engineering Change Adapter to SAP TRB');

--17/04/2015 PK Added entries for FRS-000015
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ENOV_MQ_OUT_1', 'MQ_OUTBOUND', 'TOTAL_SOLVE_GPIRS_REQ','SI_BS_GPIRS_PRODUCT_MULT_COMPVEHREQ','SI.AD.ENOV.OUT',null,null,null,'pkhot','Entry for GPIRSSolveRequest to be send to Enovia Adapter.');
--21/10/2015 AM Entry for BODS to be deleted for FRS000015 IFU3443
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAPDS_MQ_OUT_1', 'MQ_OUTBOUND', 'INC_SOLVE_REQ','SI_BS_GPIRS_PRODUCT_MULT_COMPVEHREQ','SI.AD.SAPDS.OUT',null,null,null,'pkhot','Entry for PublishVehicleSolves and PublishComponentSolves request to SAP DS Adapter.');

-- 21/04/2015 NC Added entries for FRS-000681
-- INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_SV_ECS', 'MQ_OUTBOUND', 'ENGCHANGE','SI_SV_WERS_ADAPSV_ENGCHNG_OUT','SI.BS.WERS.ENGCHANGEBR.TO.SAP.TRBGB.IN',null,null,null,'nch','Engineering Change Adapter to Brazil SAP TRB');
-- 14/05/2015 RB Modified entry for FRS-000681 to route messages through FRS-271.
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'ENGCHANGE','SI_BS_WERS_VEH_ALL_ENGCHANGE_FFBZ','SI.BS.WERS.ENGCHANGEBR.TO.SAP.TRBGB.IN',null,null,null,'rbabu3','Engineering Change outbound to SAP Turbo');

--19/09/2017:KV Added below service routing entry for FRS-000681 as part of IFU4902
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'ENGCHANGE','SI_BS_WERS_VEH_ALL_ENGCHANGE_FFSA','SI.BS.WERS.ENGCHANGEBR.TO.SAP.TRBGB.IN',null,null,null,'kkorlam','Engineering Change outbound to SAP Turbo for Slovakia Plant');

--22/04/2015 YR added entries for IFU-2936 ( FRS - 000382)

--Jaguar Paid Claim
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('ESB_MULTI_BATCH','MQ_OUTBOUND','BWOOD','SI_BS_SAP_TRBGB_VEHICLE_BWOOD_WTYCLAIM_JAPD','SI.BS.SAP.TRBGB.REPWTYCLAIM.TO.BWOOD.IN','yraja','Entry for SAP to BWOOD Warranty Claim transform flow');

--Landrover Paid Claim
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('ESB_MULTI_BATCH','MQ_OUTBOUND','BWOOD','SI_BS_SAP_TRBGB_VEHICLE_BWOOD_WTYCLAIM_LRPD','SI.BS.SAP.TRBGB.REPWTYCLAIM.TO.BWOOD.IN','yraja','Entry for SAP to BWOOD Warranty Claim transform flow');

--				21/05/2015 VP updated entries for FRS-667
--				10/05/2017 KB updated BSID and queue name as per design change IFU4582
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER, INTERFACE_TYPE, SERVICE_IDENTIFIER, BUSINESS_SERVICE_ID, BS_INPUT_DESTINATION, BS_OUTPUT_DESTINATION, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID, DESCRIPTION) values( 'SAP_TRBGB_ALE',  'ALE_INBOUND',  'SapZdelvry07',  'SI_BS_SAP_TRB_MISC_SPEDY_SUPDELINFO',  'SI.BS.SAP.TRB.SUPDELINFO.TO.SPEDY.IN' , null, null, null,  'vprasad1' ,  'Entry for FRS 667 � SAP to Speedy Interface' );

--04-May-2015 AaP added entries for FRS-705
--09/07/2015 PM  Updated the service identifier from SapZiQnSim01 to SapZiQnsim01
--10/05/2017 KB  Updated BSID and queue name according to design change IFU4582
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER, INTERFACE_TYPE, SERVICE_IDENTIFIER, BUSINESS_SERVICE_ID, BS_INPUT_DESTINATION, BS_OUTPUT_DESTINATION, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID, DESCRIPTION) values( 'SAP_TRBGB_ALE',  'ALE_INBOUND',  'SapZiMatCmms01',  'SI_BS_SAP_TRB_SUPPLIER_SIM_GR',  'SI.BS.SAP.TRB.GR.TO.SIM.IN' , null, null, null,  'apanjiya' ,  'Entry for FRS 705 � SAP to SIM Integration' );
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER, INTERFACE_TYPE, SERVICE_IDENTIFIER, BUSINESS_SERVICE_ID, BS_INPUT_DESTINATION, BS_OUTPUT_DESTINATION, INSERT_TIMESTAMP, UPDATE_TIMESTAMP, USER_ID, DESCRIPTION) values( 'SAP_TRBGB_ALE',  'ALE_INBOUND',  'SapZiQnsim01',  'SI_BS_SAP_TRB_SUPPLIER_SIM_QN',  'SI.BS.SAP.TRB.QN.TO.SIM.IN' , null, null, null,  'apanjiya' ,  'Entry for FRS 705 � SAP to SIM Integration' );

-- 05/05/2015 YT Added entires for IA-000005
-- 07/05/2015 NM IFU- 3012 Changed BS_INPUT_DESTINATION from SI.AD.HTTP.OUT to SI.AD.HTTP.V2.OUT
INSERT INTO WMBOWNER.SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) values('ESB_HTTP_1','HTTP_OUTBOUND','LNDAR','SI_BS_VISTA_VEHICLE_LNDAR_GOF','SI.AD.HTTP.V2.OUT','yturkane','Entry for VISTA to LANDAR feed over HTTP');


-- 11/05/2015  PM     Added entries for IFU-2873 --				19/05/2015 PM Modified entry for IFU-2873
-- 18/10/2016 NB Entry added and updated business service name and input destination for FRS-261(IFU4163)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER, INTERFACE_TYPE, SERVICE_IDENTIFIER, BUSINESS_SERVICE_ID, BS_INPUT_DESTINATION, BS_OUTPUT_DESTINATION,USER_ID, DESCRIPTION) values( 'SAP_TRBGB_ALE','ALE_INBOUND','SapZtdccredm01','SI_BS_SAP_TRBGB_VEHICLE_ALL_PARTS','SI.BS.SAP.TRBGB.VEHICLEPARTS.TO.ALL.IN',null,'pmondal','Entry for IFU-2873 � Route SAP Request to Business Service Flow');

-- 13/05/2015  SB  Added entries for FRS-000680(Quarantine Status To MES)
-- 09/06/2015  SB  updated entry for IFU3099
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER, INTERFACE_TYPE, SERVICE_IDENTIFIER, BUSINESS_SERVICE_ID, BS_INPUT_DESTINATION, BS_OUTPUT_DESTINATION,USER_ID, DESCRIPTION) values( 'SAP_TRBGB_ALE','ALE_INBOUND','SapZiQmnotif01','SI_BS_SAP_TRBGB_QUALITY_MES_PRTQRNTNSTUS','SI.BS.SAP.TRBGB.PRTQRNTNSTATUS.TO.MES.IN',null,'sbabu4','SAP QM Part Quarantine Status data to Main Business Service Flow');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER, INTERFACE_TYPE, SERVICE_IDENTIFIER, BUSINESS_SERVICE_ID, BS_INPUT_DESTINATION, BS_OUTPUT_DESTINATION,USER_ID, DESCRIPTION) values( 'MES_MQ_OUT','MQ_OUTBOUND','PART_QUARANTINE_STATUS','SI_BS_SAP_TRBGB_QUALITY_MES_PRTQRNTNSTUS','MES.BR.PARTQUARSTAT.OUT',null,'sbabu4','SAP QM Part Quarantine Status data to MES');

-- 14/05/2015 VV Added entries for FRS-000716 to route messages through FRS-000716.
-- 15/07/2015 SB updated BS_INPUT_DESTINATION with MES.BR.UPDMAINTACK.OUT under Maintenance 
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('MES_MQ_OUT','MQ_OUTBOUND','MES_UPD_STATUS','SI_BS_MES_QUALITY_SAP_TRBGB_UPDSTATUS','MES.BR.UPDMAINTACK.OUT',null,null,null,'vvivekan','MES Update  Maintenance Status');

-- 02/06/15 NT Add entries to FRS-000716 Fault Alarm Notification MES to SAP
-- 15/07/2015 SB updated BS_INPUT_DESTINATION with MES.BR.SENDNOTNUM.OUT as per the DEF14606 
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('MES_MQ_OUT','MQ_OUTBOUND','MES_FAULT_ALARM','SI_BS_MES_QUALITY_SAP_TRBGB_FAULTALARM','MES.BR.SENDNOTNUM.OUT',null,null,null,'sbabu4','MES Fault Alarm Notifications');


--	29/04/2015 NM Added entries for IA-323 as per IFU 2857
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_INBOUND', 'SapZfiFmHyperionWrapper','SI_AD_SAP_TRBGB_MQSERV_BAPIIN','SI.BS.SAP.TRB.FINANRPT.TO.HYPRON.IN',null,null,null,'nmithari','Entry for the SAP Financial Report BAPI SapZbapiFiHyperion interface between SAP Turbo and Hyperion');

--  20/05/2015 YR added entries for NCR Response( FRS - 000680)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE','ALE_INBOUND','SapZiQmnotif02','SI_BS_SAP_TRBGB_QUALITY_MES_NCRRESPONSE','SI.BS.SAP.TRBGB.NCRRESPONSE.TO.MES.IN',null,null,null,'yraja','SAP QM NCR Response data to Main Business Service Flow');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('MES_MQ_OUT','MQ_OUTBOUND','NCR_RESPONSE','SI_BS_SAP_TRBGB_QUALITY_MES_NCRRESPONSE','MES.BR.NCRRESPONSE.OUT',null,null,null,'yraja','SAP QM NCR Response data to MES');

--	20/0/2015 NM Added entry for FRS-711
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('PLO_MQ_OUT_1', 'MQ_OUTBOUND', 'PAINT_BODY_ORD_REQ','SI_BS_SAP_TRBGB_VEHICLE_PLO_PABOORDREQ','SI.AD.PLO.OUT',null,null,null,'nmithari','Entry for FRS 711 � TD SAP to PLO Interface');

-- 21/05/2015 RB Added entries for FRS-000690
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE', 'ALE_OUTBOUND', 'DEMAND_FORE','SI_BS_PLO_SUPPLIER_SAP_TRBGB_FORECAST','SI.AD.SAP.TRBGBSTONE.ALE.OUT',null,null,null,'rbabu3','Demand Forecast to SAP Turbo');

-- 25/05/2015 AaP Added entries for FRS-000711
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('SAP_TRBGB_ALE','ALE_OUTBOUND','SapSystat01','SI_BS_PLO_VEHICLE_SAP_TRBGB_PABOORDSTA','SI.AD.SAP.TRBGBTD.ALE.OUT','apanjiya','Route Painted Body Order status message to SAP Turbo TD ALE Outbound Adapter');


--26/05/2015 PM  Entry for FRS-712
--20/09/2016 KB  Updated queues for BSID SI_BS_MATFL_VEHICLE_GXS_PARTREQ, SI_BS_GXS_VEHICLE_MATFL_DELCONF, FRS-712
INSERT INTO WMBOWNER.SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) values( 'ESB_HTTP_1','HTTP_OUTBOUND','PART_REQUEST','SI_BS_MATFL_VEHICLE_GXS_PARTREQ','SI.AD.HTTP.MATERIALGXS.OUT',null,'pmondal','FRS-712:Routing to HTTP Outbound adapter for Mat Flow Parts Request');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) values ( 'ESB_HTTP_1','HTTP_INBOUND','DelConf/In','SI_BS_GXS_VEHICLE_MATFL_DELCONF','SI.BS.GXS.DELCONF.TO.MATFL.IN',null,'pmondal','FRS-712:HTTP Inbound Adapter Routing for GXS FPP Delivery Confirmation');
								
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) values ( 'ESB_HTTP_1','HTTP_REPLY','DelConf/In','SI_BS_GXS_VEHICLE_MATFL_DELCONF','SI.AD.HTTP.MATERIALGXS.REPLY.IN',null,'pmondal','FRS-712:Routing to HTTP reply adapter for GXS Delivery confirmation');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) values ( 'MATFL_MQ_OUT','MQ_OUTBOUND','DELCONF','SI_BS_GXS_VEHICLE_MATFL_DELCONF_TF_SO','MATFL.SOL.TF.DELCONF',null,'pmondal','FRS-712:Routing for FPP Delivery Confirmation  to Material Flow');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) values ('MATFL_MQ_OUT','MQ_OUTBOUND','DELCONF','SI_BS_GXS_VEHICLE_MATFL_DELCONF_MP_SO','MATFL.SOL.MP.DELCONF',null,'pmondal','FRS-712:Routing for Midpoint/Solihull Delivery Confirmation  to Material Flow');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) values ('MATFL_MQ_OUT','MQ_OUTBOUND','DELCONF','SI_BS_GXS_VEHICLE_MATFL_DELCONF_MP_CB','MATFL.CB.MP.DELCONF',null,'pmondal','FRS-712:Routing for Midpoint/Castle Bromwich Delivery Confirmation  to Material Flow');

--27/05/2015 VB  Entry for FRS-000111 as per IFU3019
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL','SI_BS_AFRL_CUSSV_SVCRM_GETACCTDTLS','SI.AD.CANONICAL.ACCOUNT.IN',null,null,null,'vbordia','Entry for AFRL Get Account Details');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('CANONICAL', 'ACCOUNT', 'CANONICAL','SI_BS_AFRL_CUSSV_SVCRM_GETACCTDTLS','SI.BS.GETACCTDTLS.CANON.IN',null,null,null,'vbordia','Entry for AFRL Get Account Details for Canonical Account Adapter');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('AFRL_MQ_OUT_1', 'MQ_OUTBOUND', 'AFRLJAG_ GETACCTDTLS','SI_BS_AFRL_CUSSV_SVCRM_GETACCTDTLS','ESB.GETACCTDTLS.TO.AFRL.OUT',null,null,null,'vbordia','Entry for get account details response to be send to AFRL Jaguar');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_HTTP_1', 'HTTP_INBOUND', 'mss/afrl/FRS_000111_GetAccountDetails','SI_BS_AFRL_CUSSV_SVCRM_GETACCTDTLS','SI.BS.AFRLLR.GETACCTDTLS.TO.SAPCRM.IN',null,null,null,'vbordia','Entry for Get Account Details for AFRL Inbound Adapter');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_HTTP_1', 'HTTP_REPLY', 'mss/afrl/FRS_000111_GetAccountDetails','SI_BS_AFRL_CUSSV_SVCRM_GETACCTDTLS','SI.AD.HTTP.V2.REPLY.IN',null,null,null,'vbordia','Entry for Replicate Vehicle Status Event for D42 Inbound Adapter');

-- 01/06/2015 RB Added entries for FRS-000715
-- TLS Broadcast
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBBR_ALE', 'ALE_OUTBOUND', 'TLS_BROADCAST','SI_BS_MES_VEHICLE_SAP_TRBBR_TLSBROADCT','SI.AD.SAP.TRBBREWM.ALE.OUT',null,null,null,'rbabu3','Routing to SAP Outbound adapter for ZITLSUPDATE');
-- Vehicle Movement Info
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBBR_ALE', 'ALE_OUTBOUND', 'VEH_MOVEMENT','SI_BS_MES_VEHICLE_SAP_TRBBR_VEHMOVEINF','SI.AD.SAP.TRBBREWM.ALE.OUT',null,null,null,'rbabu3','Routing to SAP Outbound adapter for ZIVEHPOSUPDATE');

-- 18/06/2015 KT Added entries for FRS-000679
INSERT INTO WMBOWNER.SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'MES_MasterData_Ack','SI_BS_MES_VEHICLE_ESB_MASTDATACK','SI.BS.ESB.MASTDATAACK.TO.SAP.TRBBR.IN',null,null,null,'kthanga2','Internal routing for Master Data Ack from MES ');

-- 18/06/2015 AS Added entry for FRS-000707
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'MES_OrderBOM_Ack','SI_BS_MES_VEHICLE_ESB_ORDERBOMACK','SI.BS.ESB.ORDERBOMACK.TO.SAP.TRBBR.IN',null,null,null,'asannag1','Internal routing for OrderBOM Ack from MES');

-- 22/06/2015 AaP Added entry for FRS-000272 IFU3123
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE', 'ALE_OUTBOUND', 'VEHICLE_PARTS_OUT','SI_SV_VEHSV_PARTS','SI.AD.SAP.TRBGBTD.ALE.OUT',null,null,null,'apanjiya','Route Vehicle Parts data to SAP Turbo ALE Outbound Adapter');

-- 22/06/2015 SB Added entry for FRS680(Vehicle Genealogy To Multiple Systems)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE', 'ALE_OUTBOUND', 'VEH_GENEALOGY','SI_BS_MES_QUALITY_ALL_VEHGENEALOGY','SI.AD.SAP.TRBGBSTONE.ALE.OUT',null,null,null,'sbabu4','MES Vehicle Genealogy Data to SAP Turbo');

--                25/06/2015 VP IFU3107 changes
--02/05/2017 VK Removed entries after Framework migration of FRS-273.
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,	INTERFACE_TYPE,	SERVICE_IDENTIFIER,	BUSINESS_SERVICE_ID,	BS_INPUT_DESTINATION,	BS_OUTPUT_DESTINATION,	INSERT_TIMESTAMP,	UPDATE_TIMESTAMP,	USER_ID,	Description) VALUES ('SAP_TRBGB_ALE',	'ALE_OUTBOUND',	'PARTS_DEMAND_OUT',	'SI_SV_VEHSV_DEMANDUPD',	'SI.AD.SAP.TRBGBTD.ALE.OUT',	null,	null,	null,	'vprasad1',	'Route Demand Parts data to SAP Turbo ALE Outbound Adapter');

-- 25/06/2015 YR FRS 261 changes for Stone
-- 18/10/2016 NB Entry added and updated business service name and input destination for FRS-261(IFU4163)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBBR_ALE','ALE_INBOUND','SapDelfor02','SI_BS_SAP_TRBGB_VEHICLE_ALL_PARTS','SI.BS.SAP.TRBGB.VEHICLEPARTS.TO.ALL.IN',null,null,null,'yraja','Route SAP APO Request to Business Service Flow');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBBR_ALE','ALE_INBOUND','SapZiscsedm01','SI_BS_SAP_TRBGB_VEHICLE_ALL_PARTS','SI.BS.SAP.TRBGB.VEHICLEPARTS.TO.ALL.IN',null,null,null,'yraja','Route SAP APO Request to Business Service Flow');

--21/07/2015 HB Added New entry for FRS731
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,	INTERFACE_TYPE,	SERVICE_IDENTIFIER,	BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,	BS_OUTPUT_DESTINATION,	INSERT_TIMESTAMP,	UPDATE_TIMESTAMP,	USER_ID,	Description) VALUES ('PLO_MQ_OUT_1',	'MQ_OUTBOUND',	'ORDER_ALLOC',	'SI_BS_VISTA_DEALER_PLO_OPENORDER',	'SI.AD.PLO.OUT',	null,	null,	null,	'hborate',	'MES Fault Alarm Notifications');

--04/11/2015 AaP IFU3504 switch to direct delivery to CJLR Switch QM queue (change in BS_INPUT_DESTINATION Q)
--21/07/2015 NM Added New entry for FRS668
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'SBOM_DATA','SI_BS_LSTOR_VEHICLE_ALL_SBOM','SI.SV.ENGCHANGEFORSAP.IN',null,null,null,'nmithari','This will send the message to the SAP flow');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'SBOM_DATA','SI_BS_LSTOR_VEHICLE_ALL_SBOM','CJLR.SBOM.IN',null,null,null,'apanjiya','This will send the message to the SAP flow');


--31/07/2015 NM Added New entry for IFU 3190 (FRS-718)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_HTTP_1', 'HTTP_OUTBOUND', 'VEH_MAN_STATUS','SI_BS_MES_VEHICLE_SAP_TRBBR_PLNORDCONF','SI.AD.HTTP.V2.OUT',null,null,null,'vvivekan','MES Message to D42 System');

--05/08/2015 NC Added New entry for FRS719
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_HTTP_1', 'HTTP_INBOUND', 'Vehicle/vehiclestatusupdate','SI_BS_D42_VEHICLE_MES_VEHSTATUSUPD','SI.BS.D42.VEHSTATUPD.TO.MES.IN',null,null,null,'nch','HTTPInboundRouting D42 to MES VehicleStatusUpdate');

--14/10/2015 VP FRS-000271 - Modified entry for 'FFE2' -- IFU3472
INSERT INTO WMBOWNER.SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'ENGCHANGE', 'SI_BS_WERS_VEH_ALL_ENGCHANGE_FFE2', 'CJLR.PBOM.IN',null,null,null,'vprasad1', 'Engineering Change outbound to EMC');

--24/09/2015 SB IA-170 - Added new entry as per IFU3382
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('PLO_MQ_OUT_1','MQ_OUTBOUND','VEH_ALERT','SI_BS_SAP_TRBGB_VEH_PLO_BDFUPD','SI.AD.PLO.OUT',null,null,null,'sbabu4','SAP Turbo routing entry to PLO MQ Outbound Adapter for BDF Updates');

--05/11/2015 SN FRS721 -- Added new entries
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('SAP_TRBGB_ALE','ALE_INBOUND','SapZiOtcSerpro01','SI_BS_SAP_TRBBR_VEHICLE_SERPR_VEHREG','SI.BS.SAP.TRBBR.VEHREG.TO.SERPR.IN','snidumuk','SAP TRBBR Veh Reg Idoc to SERPRO');
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('SAP_TRBGB_BAPI','BAPI_OUTBOUND','SapZo2cBrSerproAcknowledge','SI_BS_SERPR_VEHICLE_SAP_TRBBR_VEHREGACK','SI.AD.SAP.TRBGB.BAPI.OUT','snidumuk','SAP TRBBR Veh Reg Ack BAPI');

--12/11/2015 AT - Added new entry for FRS689 
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_NGA_ALE','ALE_OUTBOUND','SapEmpOrgData','SI_BS_CANON_HR_NGA_EMPORGDATA','SI.AD.SAP.NGA.ALE.OUT',null,null,null,'athota','Route Employee Data or Organisation Management Data message to SAP NGA ALE Outbound Adapter');

--20/11/2015 NC Added entries for IA-000172

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_OUTBOUND', 'SapZbapiAccDocumentPost2', 'SI_BS_PAYRL_GLENTRY_SAP_TRB', 'SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'nch', 'Route Payroll GL entry to SAP Turbo');

--23/11/2015 SB Added entry for FRS258(IFU3534)

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBBR_BAPI', 'BAPI_OUTBOUND', 'SapZo2cFmSimravAssignment', 'SI_SV_VEHSV_PRODCTRL', 'SI.AD.SAP.TRBGB.BAPI.OUT',null,null,null,'sbabu4', 'Entry for FRS 258 � Production control TCUProfile details to SAP Turbo');

--08/12/2015 NC Added entries for FRS669(Vehicle import declaration)

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBBR_ALE', 'ALE_OUTBOUND','VEH_IMP_DECL', 'SI_BS_TITO_HMRC_SAP_TRBBR_VEHIMPDECL', 'SI.AD.SAP.TRBGBSTONE.ALE.OUT',null,null,null,'nch', 'Routing to SAP Outbound adapter for ZI_CUSTOM_TITO_IN');

--10/12/2015 SB Added entries for FRS670(Vehicle Information to TITO)

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE', 'ALE_INBOUND','SapZiCustomTito', 'SI_BS_SAP_TRBBR_INVOICE_TITO_VEHINFO', 'SI.BS.SAP.TRBBR.VEHINFO.TO.TITO.IN',null,null,null,'sbabu4', 'Entry for FRS 670 � Vehicle Information to TITO');

--23/12/15 Added entries for FRS-722 After Market Order feed SI_SERVICE_ROUTING
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES 
('SAP_TRBGB_ALE', 'ALE_OUTBOUND', 'SapOrders05ZordNeovia','SI_BS_NEOV_VEHICLE_SAP_TRBBR_AFTMKTORD','SI.AD.SAP.TRBGBSTONE.ALE.OUT',null,null,null,'kkorlam','SAP TRBBR After Mkt Orders Idoc');

--23/12/15 Added entries for FRS-722 After Market Order feed
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES 
('SAP_TRBGB_ALE', 'ALE_INBOUND', 'SapZneoviaConf01','SI_BS_SAP_TRBBR_VEHICLE_NEOV_AMORDRESP','SI.BS.SAP.TRBBR.ORDRESP.TO.NEOV.IN',null,null,null,'kkorlam','SAP TRBBR After Market order response Idoc to Neovia');


-- 22/12/2015 PM Entries for FRS 130 IFU3545
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION)VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'ZI_DEBMAS03_CUST', 'SI_BS_CANON_DEALER_SAP_ESM_REPLICTEDR','SI.AD.SAP.ESMALL.ALE.OUT',null,null,null,'pmondal', 'Replicate Dealer to SAP eSmart');

-- 13/07/2016 HB FRS-000807 - Added entries for OA Code Translation Service
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION)VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'OACODETRANSL', 'SI_SV_MISCSV_OACODETRANSL','SERVICE.DEVELOPMENT.CODETRANSL.REQ','SI.SV.OACODETRANSL.PLO.RES',null,null,'hborate', 'Route Code Translation Request to PLO');

-- 25/01/2016 SN FRS661 - Added entry for FRS661
  --10/02/2017 KV FRS 661(IFU 4365) -Commented below entry as it this is shifted to New build
/*INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_INBOUND','SapZfiRfcF110IndusOutWrapper', 'SI_BS_SAP_TRBGB_PAYMT_SINTEL_ARPAYMT', 'SI.BS.SAP.TRBGB.ARPAYMT.TO.SINTEL.IN',null,null,null,'snidumuk', 'Entry for FRS-661, Accounts Receivable Payment Request');*/

--01/02/2016 LH Added entry for FRS-000802
Insert into SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_TRBGB_ALE','ALE_OUTBOUND','ZI_WTYEFGDES','SI_BS_BRS_VEH_SAP_TRB_VEHSPECSFEAT','SI.AD.SAP.TRBGB.ALE.OUT',null,null,null,'lhake','Vehicle Spec Features Delta to SAP Turbo');


--Added entries for FRS-653 of Message flow SI_SV_IndependentSecurityCheck
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) 
Values('ESB_BUS_SERV','MQ_OUTBOUND','SECURITY_CHECK','SI_SV_SECSV_SECURITYCK','SI.SV.TRUSTCENTRES.IN','kkorlam','Independent Security Check to Canonical');  


--Added entries for FRS-653 of Message SI_SV_TrustCentres
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) Values('ESB_BUS_SERV','MQ_OUTBOUND','TRUST_CENTRES_CLIENT','SI_SV_SECSV_SECURITYCK_RESP','SI.SV.SECURITYCHECKRESPONSE.IN','spatel5','Trust Centre Checks to Independent Security Client');
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) Values('ESB_BUS_SERV','MQ_OUTBOUND','TRUST_CENTRES_NICB','SI_SV_SECSV_SECURITYCK_NICB','SI.SV.SECURITYNOTF.IN','spatel5','Trust Centre Checks to Security Notification');

-- 03/03/2016 VP Added entry for FRS-811
insert into wmbowner.si_service_routing (SYSTEM_IDENTIFIER,	INTERFACE_TYPE,	SERVICE_IDENTIFIER,	BUSINESS_SERVICE_ID,	BS_INPUT_DESTINATION,	BS_OUTPUT_DESTINATION,	USER_ID,	DESCRIPTION) values ('ESB_BUS_SERV',	'MQ_OUTBOUND',	'PART_REQUEST',	'SI_BS_MONEX_MISC_ALL_CURRTRIANG',	'SI.BS.MONEX.CURNCYTRIANG.TO.FAST.IN',	null,	'vprasad1',	'Routing currency triangulation to FAST ');
insert into wmbowner.si_service_routing (SYSTEM_IDENTIFIER,	INTERFACE_TYPE,	SERVICE_IDENTIFIER,	BUSINESS_SERVICE_ID,	BS_INPUT_DESTINATION,	BS_OUTPUT_DESTINATION,	USER_ID,	DESCRIPTION) values ('ESB_BUS_SERV',	'MQ_OUTBOUND',	'PART_REQUEST',	'SI_BS_MONEX_MISC_ALL_CURRTRIANG',	'SI.BS.MONEX.CURNCYTRIANG.TO.LGCY.IN',	null,	'vprasad1',	'Routing currency triangulation to  legacy ');
insert into wmbowner.si_service_routing (SYSTEM_IDENTIFIER,	INTERFACE_TYPE,	SERVICE_IDENTIFIER,	BUSINESS_SERVICE_ID,	BS_INPUT_DESTINATION,	BS_OUTPUT_DESTINATION,	USER_ID,	DESCRIPTION) values ('MONEX_XRATE_FTP',	'FTP_INBOUND',	'CURRENCY_TRIANG',	'SI_AD_MONEX_FTP_IN',	'SI.BS.MONEX.CURNCYTRIANG.TO.ALL.IN',	null,	'vprasad1',	'Monex to ESB Triangulation');


-- 03/03/2016 PM Entries for FRS 638 Development
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION)VALUES ('SAP_TRBGB_ALE', 'ALE_OUTBOUND', 'SapZiWtysrodes', 'SI_BS_TOPIX_VEHICLE_SAP_TRBGB_SROTRANSL','SI.AD.SAP.TRBGB.ALEST.OUT',null,null,null,'pmondal', 'Entry for FRS-638, SRO Local Translations to SAP Turbo');

-- 04/03/2016 NM Entries for FRS 795 Development
-- 16/03/2016 NM One entry deleted and SERVICE_IDENTIFIER changed as per Design update
INSERT INTO SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) Values('SAP_TRBGB_ALE','ALE_OUTBOUND','MATCOSTPRC','SI_BS_ALL_VEHICLE_SAPTRBGB_MATCOSTPRC','SI.AD.SAP.TRBGB.ALEST.OUT','nmithari','Entry for FRS000795 to route IDoc INFREC01 to the outbound SAP adapter flow');


-- 17/03/2016 PM Entry added as per FRS-812 Development
INSERT INTO SI_SERVICE_ROUTING(
SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION
) Values ('SAP_SMTCN_ALE','ALE_OUTBOUND','SapZiInFiTMS','SI_BS_TMS_INVOICE_SAPSMTCN_GLFILE','SI.AD.SAP.SMTCN.ALE.OUT','pmondal','Entry for FRS-812, TMS GL File to SAP SMART China');

--30/03/2016 HB Added New entry for FRS 810
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('ESB_BUS_SERV','MQ_OUTBOUND','COADATA','SI_BS_SAP_TRBGB_PAYMT_ESB_COADATA','SI.BS.ESB.COA.TO.ALL.IN',null,null,null,'hborate','Entry for FRS-810, COA Data to Mainframe');

--13/04/2016 HB Added missing entry for adapter Def-18078
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_TRBGB_ALE','ALE_INBOUND','SapZPsdecommData','SI_BS_SAP_TRBGB_PAYMT_ESB_COADATA','SI.BS.SAP.TRBGB.COA.TO.ESB.IN',null,null,null,'hborate','Entry for FRS-810, Z_PSDECOMM_DATA idoc to Mainframe');

--13/04/2016 KB Added entry for FRS-000690 IFU3829
--16/06/2016 KB Updated for FRS-000690 IFU3986
insert into wmbowner.si_service_routing (SYSTEM_IDENTIFIER,	INTERFACE_TYPE,	SERVICE_IDENTIFIER,	BUSINESS_SERVICE_ID,	BS_INPUT_DESTINATION,	BS_OUTPUT_DESTINATION,	USER_ID,	DESCRIPTION) values ('ESB_BUS_SERV',	'MQ_OUTBOUND',	'DEMAND_FORE',	'SI_BS_PLO_SUPPLIER_ALL_FORECAST_PlantGrazFore',	'SI.BS.PLO.GB.FORECAST.TO.PGZ.GB.ON.OUT',	null,	'kbhosale',	'Demand Forecast to PGZ');

-- 21/04/2016 PK Added entries for FRS-809
Insert into SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_TRBGB_ALE','ALE_OUTBOUND','GRP_USER_DATA','SI_BS_GRP_VEHICLE_SAP_TRBGB_USERDATA','SI.AD.SAP.TRBGB.ALE.CUA.MTV2.OUT',null,null,null,'pkumar43','Routes GRP User data to SAP Turbo');

--29/04/2016 KB Added entry for FRS-000813 
insert into wmbowner.si_service_routing (SYSTEM_IDENTIFIER,	INTERFACE_TYPE,	SERVICE_IDENTIFIER,	BUSINESS_SERVICE_ID,	BS_INPUT_DESTINATION,	USER_ID,	DESCRIPTION) values ('ESB_BUS_SERV',	'MQ_OUTBOUND',	'ALL',	'SI_BS_CANON_PRODUCT_PGZ_MATLMASTER',	'SI.AD.PGZ.OUT',	'kbhosale',	'Material Master routing to PGZ MQ Outbound Adapter');


--03/05/2016 AM Added entry for FRS-000038(IFU 3816)
Insert into SI_SERVICE_ROUTING(SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('ENOV_MQ_OUT_1','MQ_OUTBOUND','UNIPT_ECO','SI_BS_ALL_PROD_UNIPT_ECO','SI.AD.ENOV.OUT',null,null,null,'amahesh2','Entry for ESB Error Report of ECO Notice Numbers');

--09/05/2016 NB Added entry for FRS-000814
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) values ('ESB_BUS_SERV','MQ_OUTBOUND','ALL','SI_BS_CANON_PRODUCT_PGZ_VENDMASTER','SI.AD.PGZ.OUT','nbarma','Vendor Master routing to PGZ MQ Outbound Adapter');

--11/05/2016 KB Added entries for FRS-000817 
insert into wmbowner.si_service_routing (SYSTEM_IDENTIFIER,	INTERFACE_TYPE,	SERVICE_IDENTIFIER,	BUSINESS_SERVICE_ID,	BS_INPUT_DESTINATION,	USER_ID,	DESCRIPTION) values ('ESB_BUS_SERV',	'MQ_OUTBOUND',	'ORDER',	'SI_BS_PLO_VEHICLE_PGZ_ORDER',	'SI.AD.PGZ.OUT',	'kbhosale',	'PLO Orders to Graz');
insert into wmbowner.si_service_routing (SYSTEM_IDENTIFIER,	INTERFACE_TYPE,	SERVICE_IDENTIFIER,	BUSINESS_SERVICE_ID,	BS_INPUT_DESTINATION,	USER_ID,	DESCRIPTION) values ('ESB_BUS_SERV',	'MQ_OUTBOUND',	'ORDERSTATUS',	'SI_BS_PGZ_VEHICLE_PLO_ORDERSTAT',	'SI.AD.PLO.OUT',	'kbhosale',	'PGZ Order Status to PLO');
 
 --16/05/2016 NB Added entry for FRS-000815 
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) values ('ESB_BUS_SERV','MQ_OUTBOUND','CTC_PlantGraz','SI_BS_CANON_PRODUCT_PGZ_CTC','SI.AD.PGZ.OUT','nbarma','FRS-000815 CTC message to Plant Graz MQ Outbound adapter');

--16/05/2016 HB Added New entry for FRS 818
-- 08/09/2016 HB Updated Entry for FRS-818 as per IFU-4055
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('SAP_TRBGB_ALE','ALE_OUTBOUND','SapDelvry03','SI_BS_CMMS3_MISC_SAP_TRBGB_INTSTKMVMT','SI.AD.SAP.TRBGBTD.ALE.OUT',null,null,null,'hborate','Route Advanced Shipment Notice message to SAP Turbo TD ALE Outbound Adapter');

-- 27/06/2016 AT Added for FRS-000107(IFU 3897 OCRM) 
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) values ('ESB_BUS_SERV','MQ_OUTBOUND','CANONICAL','SI_SV_CUSSV_ORDERREPLICATE','SI.SV.ORDERREPL.OCRM.IN','atatar','Entry for Replicate Order Service to OCRM');

-- 28/06/2016 PK Added for FRS-000820
--SI_BS_CMMS3_ASN_PlantSOL_To_ESB
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) values ('ESB_BUS_SERV','MQ_OUTBOUND','ASN_SOL','SI_BS_CMMS3_SUPPLIER_ESB_ASNSOL','SI.BS.ESB.ASNSOL.TO.CIC.IN','pkumar43','FRS-820, Solihull plant ASNs from CMMS3 to ESB');
--SI_BS_CMMS3_ASN_PlantCBBIW_To_ESB
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) values ('ESB_BUS_SERV','MQ_OUTBOUND','ASN_CBBIW','SI_BS_CMMS3_SUPPLIER_ESB_ASNCBBIW','SI.BS.ESB.ASNCBBIW.TO.CIC.IN','pkumar43','FRS-820, Castle Bromwich - BIW plant ASNs from CMMS3 to ESB');
--SI_BS_CMMS3_ASN_PlantCBTF_To_ESB
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) values ('ESB_BUS_SERV','MQ_OUTBOUND','ASN_CBTF','SI_BS_CMMS3_SUPPLIER_ESB_ASNCBTF','SI.BS.ESB.ASNCBTF.TO.CIC.IN','pkumar43','FRS-820, Castle Bromwich - TF plant ASNs from CMMS3 to ESB');
--SI_BS_CMMS3_ASN_PlantHW_To_ESB
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) values ('ESB_BUS_SERV','MQ_OUTBOUND','ASN_HW','SI_BS_CMMS3_SUPPLIER_ESB_ASNHW','SI.BS.ESB.ASNHW.TO.CIC.IN','pkumar43','FRS-820, Halewood plant ASNs from CMMS3 to ESB');

--01/07/2016 KB Added entry for FRS-000819 
insert into wmbowner.si_service_routing (SYSTEM_IDENTIFIER,	INTERFACE_TYPE,	SERVICE_IDENTIFIER,	BUSINESS_SERVICE_ID,	BS_INPUT_DESTINATION,	USER_ID,	DESCRIPTION) values ('ESB_HTTP_1',	'HTTP_INBOUND',	'Dealer/distributionlabel',	'SI_BS_D42_DEALER_PGZ_DISTLABEL',	'SI.BS.D42.DISTLABEL.TO.PGZ.IN',	'kbhosale',	'HTTP Inbound Routing from D42 to PGZ for Distribution Label');
insert into wmbowner.si_service_routing (SYSTEM_IDENTIFIER,	INTERFACE_TYPE,	SERVICE_IDENTIFIER,	BUSINESS_SERVICE_ID,	BS_INPUT_DESTINATION,	USER_ID,	DESCRIPTION) values ('ESB_HTTP_1',	'HTTP_REPLY',	'Dealer/distributionlabel',	'SI_BS_D42_DEALER_PGZ_DISTLABEL',	'SI.AD.HTTP.V2.REPLY.IN',	'kbhosale',	'HTTP Reply Routing from ESB to D42 for Distribution Label');
insert into wmbowner.si_service_routing (SYSTEM_IDENTIFIER,	INTERFACE_TYPE,	SERVICE_IDENTIFIER,	BUSINESS_SERVICE_ID,	BS_INPUT_DESTINATION,	USER_ID,	DESCRIPTION) values ('ESB_BUS_SERV',	'MQ_OUTBOUND',	'ALL',	'SI_BS_D42_DEALER_PGZ_DISTLABEL',	'SI.AD.PGZ.OUT',	'kbhosale',	'Distribution Label routing to PGZ MQ Outbound Adapter');


-- 11/07/2016 NB Added new entries for FRS-000372(IFU3913, IFU3955)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) values ('ESB_BUS_SERV','MQ_OUTBOUND','ALL','SI_SV_VEHSV_VEHDSTST','SI.AD.PGZ.OUT','nbarma','FRS-000372 Distribution Label routing to PGZ MQ Outbound Adapter');


-- 28/07/2016 NB: Added entries for FRS-000371(IFU3928)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) values ('ESB_BUS_SERV','MQ_OUTBOUND','Blank','SI_BS_PGZ_VEHICLE_D42_MANUFACSTATUS','SI.AD.PGZ.OUT','nbarma','D42 Manufacturing status response to PGZ');

 --24/08/2016 KB Added entry for SPC messages FRS-000815 
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) values ('ESB_BUS_SERV','MQ_OUTBOUND','SPC_PlantGraz','SI_BS_CANON_PRODUCT_PGZ_SPC','SI.AD.PGZ.OUT','kbhosale','FRS-000815 SPC message to Plant Graz MQ Outbound adapter');




-- 30/08/2016 AT: Added entries for IA-000099
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE','ALE_OUTBOUND','SapZiHr001401','SI_BS_ALL_HR_TO_SAP_TRGB_AVGSHIFT','SI.AD.SAP.TRBGBHR.ALE.OUT',Null,'atatar','HR Average Shift to SAP Turbo UK');

--02/09/2016 HV added entry for IA-000148
--25/01/2017 HV updated entry for IA-000148
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE','ALE_OUTBOUND','ZI_WTYPRICES','SI_BS_UNIPT_VEHSERV_SAP_TRBGB_PARTSPRICE','SI.AD.SAP.TRBGB.ALE.OUT','hvommi','Unipart Warranty Parts Pricing to SAP Turbo');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE','ALE_OUTBOUND','ZI_WTYPRICES','SI_BS_NEOV_VEHSERV_SAP_TRBGB_PARTSPRICE','SI.AD.SAP.TRBGB.ALE.OUT','hvommi','Neovia Warranty Parts Pricing to SAP Turbo');

-- 16/09/2016 NM: Added entry for FRS-000828
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) values ('SAP_TRBGB_ALE','ALE_OUTBOUND','SapAccDoc04','SI_BS_FAST_INVOICE_SAP_TRBGB_FINANRECON','SI.AD.SAP.TRBGBTD.ALE.OUT','nmithari','Route Finance Reconciliation messages to SAP Turbo TD ALE Outbound Adapter');

--29/09/2016 NB Entry added for FRS-833
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) values ('SAP_TRBGB_ALE','ALE_OUTBOUND','ALL','SI_BS_PGZ_PRODUCT_SAP_TRBGB_VALOBOM','SI.AD.SAP.TRBGB.ALE.OUT','nbarma','Evaluated OBOM Data routing to SAP ALE Outbound Adapter');

--05/09/2016 SK added antries for FRS-000154 for IFU4148

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_CTUPACTVTY', 'SI.AD.CANONICAL.ACTIVITY.IN',null,null,null,'skumari4', 'FRS-00154- Entry for Crt Upd activity');

INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) values ('CANONICAL','ACTIVITY','CANONICAL','SI_SV_CUSSV_CTUPACTVTY','SI.SV.ACTIVITY.CRTUPD.CANON.IN',null,null,null,'skumari4','FRS-00154- Entry for Crt Upd activity Canonical Adaptor');

--07/10/2016 KB Added entry for FRS-000837 
insert into wmbowner.si_service_routing (SYSTEM_IDENTIFIER,	INTERFACE_TYPE,	SERVICE_IDENTIFIER,	BUSINESS_SERVICE_ID,	BS_INPUT_DESTINATION,	USER_ID,	DESCRIPTION) values ('ESB_BUS_SERV',	'MQ_OUTBOUND',	'ALL',	'SI_BS_SAP_INVOICE_PGZ_SBINV',	'SI.AD.PGZ.OUT',	'kbhosale',	'Distribution Label routing to PGZ MQ Outbound Adapter');

--18/10/2016 NB Entry added and updated business service name and input destination for FRS-261(IFU4163)
--12/12/2016 MJ Def20298 Commented FRS261 entry for SapDelvry07 as it is present in SAP Inbound table.
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) values ('ESB_BUS_SERV','MQ_OUTBOUND','VEH_PART_DET','SI_BS_SAP_TRBGB_VEHICLE_ALL_PARTS_PGZ','SI.BS.SAP.TRBGB.SBINV.TO.PGZ.IN','nbarma','Route PlantGraz message to Business Service Flow');
--INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) values ('SAP_TRBGB_ALE','ALE_INBOUND','SapDelvry07','SI_BS_SAP_TRBGB_VEHICLE_ALL_PARTS','SI.BS.SAP.TRBGB.VEHICLEPARTS.TO.ALL.IN','nbarma','Route SAP Request to Business Service Flow');

-- 08/11/2016 AM Added entries for IA258 as part of IFU4140/4141
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) values ('SAP_ESMALL_BAPI','BAPI_INBOUND','SapZrfcHfmEomFiDataEsSmWrapper','SI_BS_ALL_INVOICE_HYPER_FIDATA','SI.BS.ALL.FIDATA.TO.HYPER.IN','amahesh2','SAP eSMART Inbound entry for Hyperion Financial Data');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) values ('SAP_SMTCN_BAPI','BAPI_INBOUND','SapZrfcHfmEomFiDataEsSmWrapper','SI_BS_ALL_INVOICE_HYPER_FIDATA','SI.BS.ALL.FIDATA.TO.HYPER.IN','amahesh2','SAP SMART China Inbound entry for Hyperion Financial Data');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) values ('SAP_SMTFR_BAPI','BAPI_INBOUND','SapZrfcHfmEomFiDataEsSmWrapper','SI_BS_ALL_INVOICE_HYPER_FIDATA','SI.BS.ALL.FIDATA.TO.HYPER.IN','amahesh2','SAP SMART France Inbound entry for Hyperion Financial Data');


-- 18/11/2016 VVS Added new Entries for FRS-000155 as per the IFU4236
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_CRTUPDAPPNT','SI.AD.CANONICAL.APPOINTMENT.IN',null,null,null,'vteki', 'FRS-00155- Entry for Crt Upd Appointment');

-- 18/11/2016 VVS Added new Entries for FRS-000155 as per the IFU4236
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('CANONICAL', 'APPOINTMENT', 'CANONICAL', 'SI_SV_CUSSV_CRTUPDAPPNT','SI.SV.APPOINTMENT.CRTUPD.CANON.IN',null,null,null,'vteki', 'FRS-00155- Entry for Crt Upd Appointment Canonical Adaptor');

-- 24/11/2016 SK Added new Entries for FRS-000156 as per the IFU4244
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_REPLCAMPGN', 'SI.SV.REPLCAMPGN.IN',null,null,null,'skumari4', 'FRS-00156- Entry for Replicate Campaign');

-- 02/12/2016 AT Added new Entries for FRS-000153 as per the IFU4255
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'CANONICAL', 'SI_SV_CUSSV_CMPGNCRTUPD','SI.AD.CANONICAL.CAMPAIGN.IN',null,null,null,'athota', 'FRS-00153-Entry for Create or Update Campaign Service');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) 
VALUES ('CANONICAL', 'CAMPAIGN', 'CANONICAL', 'SI_SV_CUSSV_CMPGNCRTUPD','SI.SV.CAMPAIGN.CREATEUPDATE.IN',null,null,null,'athota', 'FRS-00153-Entry for Create or Update Campaign for Canonical Account Adapter');


--05/12/2016 PM Addition of entries for IA 74. Other all entries are removed as part of IFU4179
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_ESM_ALE', 'ALE_OUTBOUND', 'AccountReceivable','SI_BS_ALL_BILLG_SAP_ESMRT_ACCREIV','SI.AD.SAP.ESMALL.ALE.OUT.V2',null,null,null,'pmondal','All Accounts Receivable and payable to Sap eSmart');

--14/12/2016 MJ Routing entry added under FRS-841
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'ListPrice','SI_BS_AFRL_VEHICLE_ESB_LISTPRICE','SI.BS.ESB.LISTPRICE.TO.AFRL.IN',null,null,null,'mjeevart','FRS-000841, entry for ESB routing');

--15/12/2016 HV added new entry for FRS-271 as part of New interface for GTS(FRS-000823)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION)VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'ENGCHANGE', 'SI_BS_WERS_VEH_ALL_ENGCHANGE','SI.BS.WERS.MATMAS.TO.GTS.IN',null,null,null,'hvommi', 'Material Master to SAP GTS. This entry is used by FRS-000271 to route the message to FRS-000823 implementation.');

--22/12/2016 AM added new entry for IA 27 as part of IFU4330
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION)VALUES ('ESB_MULTI_BATCH', 'MQ_OUTBOUND', 'ESMKR', 'SI_BS_SAP_TRBGB_INVCRDDETS_ESMKR','SI.BS.SAP.TRBGB.INVCRDDETS.TO.ESMALL.IN',null,null,null,'amamodia', 'Entry for SAP Turbo to eSmart South Korea for Invoice Credit');

-- 16/01/2017 CD Added New entry for FRS-000838

Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('PLO_MQ_OUT_1','MQ_OUTBOUND1','ALL','SI_BS_PGZ_MISC_PLO_VEHMNFSTAT','SI.AD.PLO.OUT','cdeshpan','Vehicle Manufacturing Status routing to PLO Adapter Flow');

-- 28/01/2017    NB Added Entry for Encore Program IFU4253(FRS-000620)
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('ESB_BUS_SERV', 'MQ_OUTBOUND', 'VEHWEIGHT_PLO','SI_BS_PGZ_VEHICLE_PLO_VEHWEIGHT','SI.BS.VCATS.VEHWEIGHT.TO.PLO.IN',null,null,null,'nbarma','FRS-620 VCATS to PLO Business Service flow');

-- 30/01/2017 CD Added New entry for FRS-000817(IFU4373)
Insert into SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION)values('ESB_HTTP_1','HTTP_OUTBOUND','VISTA','SI_BS_PLO_VEHICLE_PGZ_ORDER','SI.AD.HTTP.V2.OUT','cdeshpan','PLO Orders under CCA status to VISTA');

-- 18/02/2017 LH Added Initial Entry for FRS-786
INSERT INTO WMBOWNER.SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_SMTCN_ALE','ALE_INBOUND','SapZfundingRequest','SI_BS_SAP_SMTCN_INVOICE_BRC_FUNDINGREQ','SI.BS.SAP.SMTCN.FUNDINGREQ.TO.BRC.IN',null,null,null,'lhake','Entry for FRS 786 � Funding Request');

--01/03/2017 NM Added routing entry for IA-52 IFU-4428
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_ALE','ALE_OUTBOUND','ZI_WTYVEHRESTRICTIONS','SI_BS_BBSS_CUSTOMER_ALL_CUSTDETALS','SI.AD.SAP.TRBGB.ALEST.OUT',null,null,null,'nmithari','Entry for BBSS Customer Detail interface � To SAP Turbo ');

--21/04/2017 AM Added routing entry for PODs Interface IA107
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('SAP_TRBGB_BAPI', 'BAPI_INBOUND', 'SapZp2pRfcVendorSendWrapper','SI_BS_SAP_TRB_VEHICLE_PODS_VNDRMASTER','SI.BS.SAP.TRB.VENDORMASTER.TO.PODS.IN',null,null,null,'amahesh2','IA-000107, VendorMasterUpdates to PODS');
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,BS_OUTPUT_DESTINATION,INSERT_TIMESTAMP,UPDATE_TIMESTAMP,USER_ID,DESCRIPTION) VALUES ('PODS_MQ_OUT_1', 'MQ_OUTBOUND', 'VendorMasterData_PODS','SI_BS_SAP_TRB_VEHICLE_PODS_VNDRMASTER','SI.BS.SAP.PODGB.VENDOR.TO.PODS.OUT',null,null,null,'amahesh2','IA-000107, VendorMasterUpdates to PODS');

--10/11/2017 KB Added routing entry for IA122
INSERT INTO SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER,INTERFACE_TYPE,SERVICE_IDENTIFIER,BUSINESS_SERVICE_ID,BS_INPUT_DESTINATION,USER_ID,DESCRIPTION) values ('SAP_ESMALL_BAPI','BAPI_INBOUND','SapZfiF110XmlToEsbWrapper_JP02','SI_BS_SAP_ESM_PAYMT_MULTI_BNKTRNPYMT','SI.BS.SAP.ESM.BANKTRANSPYMTS.TO.MULTI.IN','kbhosale','Routing Entry to Route Bank Payments related to Mizuho Bank and Factoring');

COMMIT;