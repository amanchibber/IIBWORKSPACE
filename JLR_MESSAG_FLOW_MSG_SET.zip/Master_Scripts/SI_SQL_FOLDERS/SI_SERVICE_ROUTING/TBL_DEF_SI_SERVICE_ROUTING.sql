--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: $Revision: 1.5 $
-- Description 	: Create table script for SI_SERVICE_ROUTING table which will hold details required
--				  by the adapters for routing of services
-- History 		: 25/01/2012 Hina Mistry Initial create statement for table
--				  01/02/2012 Hina Mistry Table name changed as was incorrect
--				  13/04/2012 Hina Mistry Altering size of the business_service_id column
--				  14/08/2012 Hina Mistry Altering user_id column as not nullable
--                05/11/2013 Kenny McCormack Altering SI_SERVICE_ROUTING column to be 100 bytes long
--------------------------------------------------------------------------------------------------------

DROP TABLE SI_SERVICE_ROUTING;

CREATE TABLE SI_SERVICE_ROUTING (SYSTEM_IDENTIFIER VARCHAR2(15) NOT NULL, 
								 INTERFACE_TYPE VARCHAR2(20) NOT NULL, 
								 SERVICE_IDENTIFIER VARCHAR2(50) NOT NULL, 
								 BUSINESS_SERVICE_ID VARCHAR2(50), 
								 BS_INPUT_DESTINATION VARCHAR2(48), 
								 BS_OUTPUT_DESTINATION VARCHAR2(48), 
								 INSERT_TIMESTAMP VARCHAR2(4000), 
								 UPDATE_TIMESTAMP VARCHAR2(4000), 
								 USER_ID VARCHAR2(10), 
								 DESCRIPTION VARCHAR2(4000),
								 CONSTRAINT SI_SERVICE_ROUTING_PK PRIMARY KEY (SERVICE_IDENTIFIER, INTERFACE_TYPE, SYSTEM_IDENTIFIER, BUSINESS_SERVICE_ID, BS_INPUT_DESTINATION));
								 
--13/04/2012 HM Business Service ID column - size alteration
ALTER TABLE SI_SERVICE_ROUTING MODIFY BUSINESS_SERVICE_ID VARCHAR2(45);								 
								 
--14/08/2012 Hina Mistry Altering user_id column as not nullable
ALTER TABLE SI_SERVICE_ROUTING MODIFY USER_ID VARCHAR2(10) NOT NULL;

--05/11/2013 Kenny McCormack Altering SI_SERVICE_ROUTING column to be 100 bytes long
ALTER TABLE SI_SERVICE_ROUTING MODIFY SERVICE_IDENTIFIER VARCHAR2(100);


COMMIT;
