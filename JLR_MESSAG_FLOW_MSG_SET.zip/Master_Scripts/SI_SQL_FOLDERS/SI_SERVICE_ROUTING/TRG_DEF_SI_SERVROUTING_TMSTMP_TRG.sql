--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: $Revision: 1.2 $
-- Description 	: Create trigger script for trigger on table SI_SERVICE_ROUTING which will update the table
--				  with a insert timestamp when a row has been inserted 
-- History 		: 13/04/2012 Hina Mistry Initial create statement for trigger SI_SERVROUTING_TMSTMP_TRG
-- 				  17/01/2013 Hina Mistry Missing ; from Drop statement corrected
--------------------------------------------------------------------------------------------------------

DROP TRIGGER SI_SERVROUTING_TMSTMP_TRG;

--Trigger which will insert or update the timestamp if an insert or update action occurs
CREATE OR REPLACE
TRIGGER SI_SERVROUTING_TMSTMP_TRG
BEFORE INSERT OR UPDATE ON SI_SERVICE_ROUTING
FOR EACH ROW
BEGIN

IF INSERTING THEN
	:new.INSERT_TIMESTAMP := systimestamp;
	:new.UPDATE_TIMESTAMP := NULL;
ELSE
	:new.UPDATE_TIMESTAMP := systimestamp;
  END IF;
END;
/
COMMIT;
