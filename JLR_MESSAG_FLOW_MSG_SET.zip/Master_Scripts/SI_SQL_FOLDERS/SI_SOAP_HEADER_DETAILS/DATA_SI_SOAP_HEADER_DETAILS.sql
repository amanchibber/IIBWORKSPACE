--------------------------------------------------------------------------------------------------------
-- Author         : skarri
-- Version         : $Revision: 1.45 $
-- Description     : Create data script for SI_SOAP_HEADER_DETAILS table which will hold details of runtime overrides used by the SOAP Outbound adapter
-- History         : 26/06/2013 SK Adding entry for FRS-000271
--				   : 10/08/2013 RB Adding entry for FRS-000260
--				   : 12/08/2013 Deepak Ingwale Adding entry for FRS-000009
--                 : 09/10/2013 SK Adding entry for FRS-000273
--                 : 10/10/2013 RB Changes to FRS-260 entry as per QC 107.
--                 : 23/10/2013 PK Added entry for FRS-29 under IFU-1283.
-- 		           : 30/10/2013 SK Edited entry for FRS-000271 after Discussing with BA
--		   		   : 18/11/2013 HA Updated entry as per defect 143 and 151
-- 				   : 21/11/013  HA Updated entries for WSA To after confirmation from Di Gregory on email
-- 				   : 18/02/2014 RB. Updated JV-Bridge URL as per IFU-1718.
-- 				   : 14/08/2014 GS. Added entry for FRS-000628
--				   : 05/09/2014 Naresh CH Added entries for FRS-096(Enovia to MPNR)
--				   : 16/09/2014 SM Updated entry for FRS-000628 for 'FRS-000628_UpdateFRED'
--				   : 26/09/2014 Naresh CH updated entries for FRS-096(Enovia to MPNR)
--				   : 30/09/2014 Pratik Khot Defect 44 fix.Added entries for FRS-081(SI_BS_ENOV_Manufacturing_UCC_To_CMMS3)
--				   : 22/10/2014 AC Added entry for FRS 657
--				   : 02/12/2014 AMW Addeed entry fro FRS-115 (R2.0) endpoint for EnquiryMax (suspect that this may need to be updated)
--				   : 15/12/2014 PK Updated entry under for FRS-29 for DEF 61.
--                 : 16/02/2014 AMW Updated for OCCAM 
--                 : 18/02/2014 AMW Updated for OCCAM as they do not want ws-a info
-- 				   : 29/12/2014 SA added entries for IFU 2620/Defect 3175(FRS 136)
--				   : 16/04/2014 KT	Updated FRS-000271 entry
--				   : 23/04/2015	KT FRS-000271 Changed BSID from SI_SV_VEHSV_ENGGCHGSAP to SI_BS_WERS_VEH_ALL_ENGCHANGE
--                 : 29/07/2015 NM	Updated FRS-000668 entry
--				   : 16/09/2015 AM updated entries for FRS-096(Enovia to MPNR)
--					: 21/10/2015 AM Added Entry for FRS000015 IFU3443
--                    10/11/2015 VP FRS-000273 entries added
--					: 16/12/2015 KT Added entries for FRS-000803
--				   :07/04/2017 IFU4565:Commented below entries as the OSH is no more required
--				   :07/04/2017 VB IFU4565:Commented entries as the OSH is no more required
--                 :02/05/2017 VK Removed entries after Framework migration of FRS-273.
--                 :25/05/2017 SK IFU4533: Added entries for VVO SAPVMS for FRS-136
--				   :25/10/2017 VB DEF14651:Changed value of WSA_HDR_IND from 'N' to 'Y' for bsid 'SI_SV_CUSSV_REPLEADPSP_OCCAM'
--                 :04/12/2017 SK IFU5124: Updated WSA_TO value in soap_header_details for SI_SV_CUSSV_REPAVO_OCCAM and SI_SV_CUSSV_REPVVO_OCCAM for FRS-136
--				   :04/12/2017 VB IFU5123:Updated value of WSA_TO for SI_SV_CUSSV_REPLEADPSP_OCCAM (FRS-115)
--------------------------------------------------------------------------------------------------------

DELETE FROM SI_SOAP_HEADER_DETAILS;
-- SK 26/06/2013 Added to prevent prompt when inserting due to &
--SET DEFINE OFF;


--26/06/2013 SK Adding entry for FRS-000271
--16/04/2014 KT	Updated FRS-000271 entry
INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME,WS_SERVICE,WS_SERVICE_ACTION,JLR_COMMON_HDR_IND,JLR_CH_EPR_TO,JLR_CH_EPR_FROM,JLR_CH_SLA_TIMEOUT,JLR_CH_SLA_PERSISTENT,JLR_CH_SLA_EXPIRE,JLR_CH_SLA_LANG_CODE,JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND,WSA_TO,WSA_FROM,WSA_REPLY_TO,WSA_RELATES_TO,WSSE_HDR_IND,WSSE_USERNAME,WSSE_PASSWORD,WSSE_NONCE,WSSE_CREATED,  DESCRIPTION,USER_ID,INSERT_TIMESTAMP,UPDATE_TIMESTAMP)
VALUES('SI_BS_WERS_VEH_ALL_ENGCHANGE', 'notifyChange','urn:NotifyChange','Y','http://esb.cherryjaguarlandrover.com','http://www.wmb.jlrint.com',Null,Null,Null,Null,Null,'Y','http://www.wmb.jlrext.com/Service/development/SAPEngineeringGWChange',Null,Null,Null,'N',Null,Null,Null,Null,'SOAP Header Details for Engineering Change GW Service','kthanga2','','');

-- 10/08/2013 RB Adding entry for FRS-000260
-- 10/10/2013 RB Changes to FRS-260 entry as per QC 107.
INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		VALUES('SI_SV_WERS_ADAPSV_ENGCHNG_OUT', 'notifyChange', 'urn:NotifyChange', 'Y', 'http://wmb.jlrint.com','http://wers.jlrint.com',Null,Null,Null,Null,Null,'Y','http://www.wmb.jlrint.com/Service/services/EngineeringChange',Null,Null,Null,'N',Null,Null,Null,Null,'SOAP Header Details for Engineering Change ESB Service','rbabu','','');
		
-- 12/08/2013 Deepak Ingwale Adding entry for FRS-000009

INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		VALUES('SI_SV_PRDSV_MASTFEATDC', 'getMFDRequest', 'urn:getMFDRequest', 'Y', 'https://www.wmb.jlrint.com/Service/development/JLRmasterfeaturedictionary','http://www.wmb.jlrint.com',Null,Null,Null,Null,Null,'Y','https://www.wmb.jlrint.com/Service/development/JLRmasterfeaturedictionary','http://www.wmb.jlrint.com',Null,Null,'N',Null,Null,Null,Null,'SOAP Header Details for MFD ESB Service','dingwale','','');
		
INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		VALUES('SI_SV_PRDSV_EVENTCAL', 'GetEventCalendars', 'urn:GetEventCalendars', 'Y', 'https://www.wmb.jlrint.com/Service/development/EventCalendarService','http://www.wmb.jlrint.com',Null,Null,Null,Null,Null,'Y','https://www.wmb.jlrint.com/Service/development/EventCalendarService','http://www.wmb.jlrint.com',Null,Null,'N',Null,Null,Null,Null,'SOAP Header Details for GetEvent Calendars ESB Service','dingwale','','');

--09/10/2013 SK Adding entry for FRS-000273
--18/11/2013 HA Updated entry as per defect 143 and 151
-- 21/11/2013 HA Updated entries for WSA To after confirmation from Di Gregory on email
-- 18/02/2014 RB. Updated JV-Bridge URL as per IFU-1718.
--02/05/2017 VK Removed entries after Framework migration of FRS-273.
-- INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		-- VALUES('SI_SV_VEHSV_DEMANDUPD', 'JVBridge', 'UpdateWeeklyDemand', 'Y', 'http://jvbridge.jlrint.com','http://www.wmb.jlrint.com',Null,Null,Null,Null,Null,'Y','https://webapps.jlrint.com/Service/planning/JVBridge',Null,Null,Null,'N',Null,Null,Null,Null,'SOAP Header Details for JV Bridge UpdateWeeklyDemand  Service','skarri','','');
/* -- INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		VALUES('SI_SV_VEHSV_DEMANDUPD', 'JVBridge', 'UpdateWeeklyDemand', 'Y', 'http://jvbridge.jlrint.com','http://www.wmb.jlrint.com',Null,Null,Null,Null,Null,'Y','https://webapps01.jlrint.com/Service/planning/JVBridge',Null,Null,Null,'N',Null,Null,Null,Null,'SOAP Header Details for JV Bridge UpdateWeeklyDemand  Service','skarri','','');


-- INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		-- VALUES('SI_SV_VEHSV_DEMANDUPD', 'JVBridge', 'GetPlantNextSequence', 'Y', 'http://jvbridge.jlrint.com','http://www.wmb.jlrint.com',Null,Null,Null,Null,Null,'Y','https://webapps.jlrint.com/Service/planning/JVBridge',Null,Null,Null,'N',Null,Null,Null,Null,'SOAP Header Details for JV Bridge GetPlantNextSequence Service','skarri','','');
INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		VALUES('SI_SV_VEHSV_DEMANDUPD', 'JVBridge', 'GetPlantNextSequence', 'Y', 'http://jvbridge.jlrint.com','http://www.wmb.jlrint.com',Null,Null,Null,Null,Null,'Y','https://webapps01.jlrint.com/Service/planning/JVBridge',Null,Null,Null,'N',Null,Null,Null,Null,'SOAP Header Details for JV Bridge GetPlantNextSequence Service','skarri','','');


-- INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		-- VALUES('SI_SV_VEHSV_DEMANDUPD', 'JVBridge', 'GetForecastData', 'Y', 'http://jvbridge.jlrint.com','http://www.wmb.jlrint.com',Null,Null,Null,Null,Null,'Y','https://webapps.jlrint.com/Service/planning/JVBridge',Null,Null,Null,'N',Null,Null,Null,Null,'SOAP Header Details for JV Bridge GetForecastData Service','skarri','','');
INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		VALUES('SI_SV_VEHSV_DEMANDUPD', 'JVBridge', 'GetForecastData', 'Y', 'http://jvbridge.jlrint.com','http://www.wmb.jlrint.com',Null,Null,Null,Null,Null,'Y','https://webapps01.jlrint.com/Service/planning/JVBridge',Null,Null,Null,'N',Null,Null,Null,Null,'SOAP Header Details for JV Bridge GetForecastData Service','skarri','','');


-- INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		-- VALUES('SI_SV_VEHSV_DEMANDUPD', 'JVBridge', 'RecalculateWeeklyDemand', 'Y', 'http://jvbridge.jlrint.com','http://www.wmb.jlrint.com',Null,Null,Null,Null,Null,'Y','https://webapps.jlrint.com/Service/planning/JVBridge',Null,Null,Null,'N',Null,Null,Null,Null,'SOAP Header Details for JV Bridge RecalculateWeeklyDemand Service','skarri','','');
INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		VALUES('SI_SV_VEHSV_DEMANDUPD', 'JVBridge', 'RecalculateWeeklyDemand', 'Y', 'http://jvbridge.jlrint.com','http://www.wmb.jlrint.com',Null,Null,Null,Null,Null,'Y','https://webapps01.jlrint.com/Service/planning/JVBridge',Null,Null,Null,'N',Null,Null,Null,Null,'SOAP Header Details for JV Bridge RecalculateWeeklyDemand Service','skarri','','');

		-- 10/11/2015 VP FRS-000273 entries added
INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		VALUES('SI_SV_VEHSV_DEMANDUPD', 'JVBridge', 'ProcessPartDemand', 'Y', 'http://jvbridge.jlrint.com','http://www.wmb.jlrint.com',Null,Null,Null,Null,Null,'Y','https://webapps01.jlrint.com/Service/planning/JVBridge',Null,Null,Null,'N',Null,Null,Null,Null,'SOAP Header Details for JV Bridge ProcessPartDemand Service','vprasad1','','');


INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		VALUES('SI_SV_VEHSV_DEMANDUPD', 'JVBridge', 'FileCreateRollBack', 'Y', 'http://jvbridge.jlrint.com','http://www.wmb.jlrint.com',Null,Null,Null,Null,Null,'Y','https://webapps01.jlrint.com/Service/planning/JVBridge',Null,Null,Null,'N',Null,Null,Null,Null,'SOAP Header Details for JV Bridge FileCreateRollBack Service','vprasad1','','');

		
INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		VALUES('SI_SV_VEHSV_DEMANDUPD', 'JVBridge', 'YearEndResetCheck', 'Y', 'http://jvbridge.jlrint.com','http://www.wmb.jlrint.com',Null,Null,Null,Null,Null,'Y','https://webapps01.jlrint.com/Service/planning/JVBridge',Null,Null,Null,'N',Null,Null,Null,Null,'SOAP Header Details for JV Bridge YearEndResetCheck Service','vprasad1','','');
 */

		
-- 23/10/2013 PK Added entry for FRS-29 under IFU-1283.
-- 15/12/2014 PK Updated entry under for FRS-29 for DEF 61.
INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		VALUES('SI_BS_SAP_TRBGB_VEHICLE_ENOV_VNDRMASTER', 'publishVendorData', 'urn:publishVendorData', 'Y', Null,'http://www.wmb.jlrint.com',Null,Null,Null,Null,Null,'N',Null,Null,Null,Null,'N',Null,Null,Null,Null,'SOAP Header Details for publishVendorData Service','pkhot','','');


-- 	   : 14/08/2014 GS. Added entry for FRS-000628
INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		VALUES('SI_BS_SAP_TRBGB_VEHICLE_GCM_FREDMAINT', 'frs628FREDMaintenance', 'UpdateFRED', 'Y', 'SI_SOAP_HEADER_DETAILS.SI_BS_SAP_TRBGB_VEHICLE_GCM_FREDMAINT.JLR_CH_EPR_TO','SI_SOAP_HEADER_DETAILS.SI_BS_SAP_TRBGB_VEHICLE_GCM_FREDMAINT.JLR_CH_EPR_FROM',Null,Null,Null,'EN','FRS-000628_UpdateFRED','N',Null,Null,Null,Null,'N',Null,Null,Null,Null,'SOAP Header Details for frs628FREDMaintenance Service','gsmith17','','');

--26/09/2014 Naresh CH Added entries for FRS-096(Enovia to MPNR)
--16/09/2015: Akhilesh Updated entry for FRS 96, Service part
INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		VALUES('SI_BS_MPNR_PRODUCT_ENOV_SERVICEPART','PublishServicePartMappingChanges','urn:PublishServicePartMappingChanges','Y','Enovia','http://www.wmb.jlrint.com',Null,Null,Null,Null,'ServicePartMappingChanges','N',Null,Null,Null,Null,'N',Null,Null,Null,Null,Null,'amahesh2','','');


--30/09/2014 Pratik Khot Defect 44 fix.Added entries for FRS-081(SI_BS_ENOV_Manufacturing_UCC_To_CMMS3)

INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		VALUES('SI_BS_ENOV_PRODUCT_CMMS3_MANUFACUCC','publishManufacturingSFI','urn:publishManufacturingSFI','Y', Null,'http://www.wmb.jlrint.com',Null,Null,Null,Null,Null,'N',Null,Null,Null,Null,'N',Null,Null,Null,Null,Null,'pkhot','','');
		
INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		VALUES('SI_BS_ENOV_PRODUCT_CMMS3_MANUFACUCC','publishManufacturingTimings','urn:publishManufacturingTimings','Y', Null,'http://www.wmb.jlrint.com',Null,Null,Null,Null,Null,'N',Null,Null,Null,Null,'N',Null,Null,Null,Null,Null,'pkhot','','');		
		

INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP) 
		VALUES('SI_BS_ENOV_PRODUCT_CMMS3_MANUFACUCC','publishManufacturingProductionDemand','urn:publishManufacturingProductionDemand','Y', Null,              'http://www.wmb.jlrint.com',Null,Null,Null,Null,Null,'N',Null,Null,Null,Null,'N',Null,Null,Null,Null,Null,'pkhot','','');

-- FRS 657 entry added
INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		VALUES('SI_BS_CJLR_RETPRTCLM','CJLRReturningPartsService','urn:CJLRReturningParts','Y', Null,'http://www.wmb.jlrint.com',Null,Null,Null,Null,Null,'N',Null,Null,Null,Null,'N',Null,Null,Null,Null,Null,'achaudha','','');


INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		VALUES('SI_BS_SWORD_RETPRTSUPD','JLRReturnPartsStatusUpdatesService','urn:returnPartsStatusUpdates','Y', Null,'http://www.wmb.jlrint.com',Null,Null,Null,Null,Null,'N',Null,'http://www.wmb.jlrint.com',Null,Null,'N',Null,Null,Null,Null,Null,'achaudha','','');
		

-- 02/12/2014 AMW 
-- FRS 115
INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		VALUES('SI_SV_CUSSV_REPLEADPSP_ENQUIRYMAX','replicateLeadAndProspect','Replicate','Y', Null,Null,Null,Null,Null,Null,Null,'N',Null,'http://www.wmb.jlrint.com',Null,Null,'N',Null,Null,Null,Null,'SOAP details for Enquiry Max','amoseley','','');
-- 04/12/2014
--IFU5123:Updated value of WSA_TO for SI_SV_CUSSV_REPLEADPSP_OCCAM (FRS-115)
INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		VALUES('SI_SV_CUSSV_REPLEADPSP_OCCAM','replicateLeadAndProspect','Replicate','Y', Null,Null,Null,Null,Null,Null,Null,'Y','https://jlrtest-sap-service.occam-dm.com/JLR.OpenIntegration.SIT/ReplicateLeadAndProspectPortTypeSOAP.svc',Null,Null,Null,'Y',Null,Null,Null,Null,'SOAP details for OCCAM','amoseley','','');		
		
		
-- 29/12/2014 sa added entries for IFU 2620/Defect 3175(FRS 136)
--IFU4565:Commented below entries as the OSH is no more required		
/* INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		VALUES('SI_SV_CUSSV_REPAVO_OSH','replicateAccountAndVehicleOwnership','Replicate','Y', Null,Null,Null,Null,Null,Null,Null,'Y','https://prs74733.portsmouth.jlrint.com:310/osh-svcrm/service/ReplicateAccountAndVehicleOwnership',Null,Null,Null,'N',Null,Null,Null,Null,'Replicate entry SOAP lookups for AVO to OSH','sanupoj2','','');		

INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		VALUES('SI_SV_CUSSV_REPVVO_OSH','replicateVehicleAndVehicleOwnership','Replicate','Y', Null,Null,Null,Null,Null,Null,Null,'Y','https://prs74733.portsmouth.jlrint.com:310/osh-svcrm/service/ReplicateVehicleAndVehicleOwnership',Null,Null,Null,'N',Null,Null,Null,Null,'Replicate entry SOAP lookups for VVO to OSH','sanupoj2','',''); */

--04/12/2017 SK IFU5124: Updated WSA_TO value in soap_header_details for SI_SV_CUSSV_REPAVO_OCCAM and SI_SV_CUSSV_REPVVO_OCCAM for FRS-136		
		
INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		VALUES('SI_SV_CUSSV_REPAVO_OCCAM','replicateAccountAndVehicleOwnership','Replicate','Y', Null,Null,Null,Null,Null,Null,Null,'Y','https://jlrtest-sap-service.occam-dm.com/JLR.OpenIntegration.SIT/ReplicateAccountAndVehicleOwnershipPortTypeSOAP.svc',Null,Null,Null,'N',Null,Null,Null,Null,'Replicate entry SOAP lookups for AVO to OCCAM','skumari4','','');

INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
		VALUES('SI_SV_CUSSV_REPVVO_OCCAM','replicateVehicleAndVehicleOwnership','Replicate','Y', Null,Null,Null,Null,Null,Null,Null,'Y','https://jlrtest-sap-service.occam-dm.com/JLR.OpenIntegration.SIT/ReplicateVehicleAndVehicleOwnershipPortTypeSOAP.svc',Null,Null,Null,'N',Null,Null,Null,Null,'Replicate entry SOAP lookups for VVO to OCCAM','skumari4','','');
		
--25/05/2017 SK IFU4533: Added entries for VVO SAPVMS for FRS-136

INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME, WS_SERVICE, WS_SERVICE_ACTION, JLR_COMMON_HDR_IND, JLR_CH_EPR_TO, JLR_CH_EPR_FROM, JLR_CH_SLA_TIMEOUT, JLR_CH_SLA_PERSISTENT, JLR_CH_SLA_EXPIRE, JLR_CH_SLA_LANG_CODE, JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND, WSA_TO, WSA_FROM, WSA_REPLY_TO, WSA_RELATES_TO, WSSE_HDR_IND, WSSE_USERNAME, WSSE_PASSWORD, WSSE_NONCE, WSSE_CREATED, DESCRIPTION, USER_ID, INSERT_TIMESTAMP, UPDATE_TIMESTAMP)
VALUES('SI_SV_CUSSV_REPVVO_SAPVMS','replicateVehicleAndVehicleOwnership','Replicate','Y', Null,Null,Null,Null,Null,Null,Null,'Y','https://jlrtest-sap-service.sapvms-dm.com/jlr.openintegration/ReplicateVehicleAndVehicleOwnershipPortTypeSOAP.svc',Null,Null,Null,'N',Null,Null,Null,Null,'Replicate entry SOAP lookups for VVO to SAPVMS','skumari4','','');

--29/07/2015 NM	Updated FRS-0002668 entry
INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME,WS_SERVICE,WS_SERVICE_ACTION,JLR_COMMON_HDR_IND,JLR_CH_EPR_TO,JLR_CH_EPR_FROM,JLR_CH_SLA_TIMEOUT,JLR_CH_SLA_PERSISTENT,JLR_CH_SLA_EXPIRE,JLR_CH_SLA_LANG_CODE,JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND,WSA_TO,WSA_FROM,WSA_REPLY_TO,WSA_RELATES_TO,WSSE_HDR_IND,WSSE_USERNAME,WSSE_PASSWORD,WSSE_NONCE,WSSE_CREATED,  DESCRIPTION,USER_ID,INSERT_TIMESTAMP,UPDATE_TIMESTAMP)
VALUES('SI_BS_LSTOR_VEHICLE_ALL_SBOM', 'notifyChange','urn:#GetSBOM_DETAILS','Y','http://esb.cherryjaguarlandrover.com','http://www.wmb.jlrint.com',Null,Null,Null,Null,Null,'Y','http://www.wmb.jlrext.com/Service/development/SAPEngineeringGWChange',Null,Null,Null,'N',Null,Null,Null,Null,'SOAP Header Details for Service Engineering Change GW Service','nmithari','','');
		
--21/10/2015 AM Added Entry for FRS000015 IFU3443
INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME,WS_SERVICE,WS_SERVICE_ACTION,JLR_COMMON_HDR_IND,JLR_CH_EPR_TO,JLR_CH_EPR_FROM,JLR_CH_SLA_TIMEOUT,JLR_CH_SLA_PERSISTENT,JLR_CH_SLA_EXPIRE,JLR_CH_SLA_LANG_CODE,JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND,WSA_TO,WSA_FROM,WSA_REPLY_TO,WSA_RELATES_TO,WSSE_HDR_IND,WSSE_USERNAME,WSSE_PASSWORD,WSSE_NONCE,WSSE_CREATED,  DESCRIPTION,USER_ID,INSERT_TIMESTAMP,UPDATE_TIMESTAMP)
VALUES('SI_BS_GPIRS_PRODUCT_MULT_COMPVEHREQ', 'PublishSolvesRequest','urn:PublishSolvesRequest','Y','Enovia','ESB',Null,Null,Null,Null,Null,'N',Null,Null,Null,Null,'N',Null,Null,Null,Null,'SOAP Header Details for Publish GPIRS Solve Request','amahesh2','','');		

--16/12/2015 KT Added entries for FRS-000803
INSERT INTO SI_SOAP_HEADER_DETAILS(BUSINESS_SERVICE_NAME,WS_SERVICE,WS_SERVICE_ACTION,JLR_COMMON_HDR_IND,JLR_CH_EPR_TO,JLR_CH_EPR_FROM,JLR_CH_SLA_TIMEOUT,JLR_CH_SLA_PERSISTENT,JLR_CH_SLA_EXPIRE,JLR_CH_SLA_LANG_CODE,JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND,WSA_TO,WSA_FROM,WSA_REPLY_TO,WSA_RELATES_TO,WSSE_HDR_IND,WSSE_USERNAME,WSSE_PASSWORD,WSSE_NONCE,WSSE_CREATED,  DESCRIPTION,USER_ID,INSERT_TIMESTAMP,UPDATE_TIMESTAMP)
VALUES('SI_BS_WERS_VEHICLE_JVBRG_ENGCHANGE', 'JVBridge','urn:AddScheduleAgreement','Y','http://jvbridge.jlrint.com','http://www.wmb.jlrint.com',Null,Null,Null,Null,Null,'Y','SI_SOAP_HEADER_DETAILS.WSA_TO.JVBridge',Null,Null,Null,'N',Null,Null,Null,Null,'SOAP Header Details for JVBridge AddScheduleAgreement Service','kthanga2','','');


COMMIT;

