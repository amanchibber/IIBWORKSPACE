--------------------------------------------------------------------------------------------------------
-- Author 		: Srinivasarao karri
-- Version 		: $Revision: 1.1 $
-- Description 	: Create table script for SI_SOAP_HEADER_DETAILS table which will hold details of runtime overrides used by the SOAP Outbound adapter
-- History 		: 26/06/2013 Initial create statement for table
---------------------------------------------------------------------------------------------------------

DROP TABLE WMBOWNER.SI_SOAP_HEADER_DETAILS CASCADE CONSTRAINTS;

CREATE TABLE WMBOWNER.SI_SOAP_HEADER_DETAILS
(
BUSINESS_SERVICE_NAME    VARCHAR2(40) NOT NULL,
WS_SERVICE    VARCHAR2(40) NOT NULL,
WS_SERVICE_ACTION    VARCHAR2(40) NOT NULL,
JLR_COMMON_HDR_IND    VARCHAR2(1),
JLR_CH_EPR_TO    VARCHAR2(150),
JLR_CH_EPR_FROM    VARCHAR2(150),
JLR_CH_SLA_TIMEOUT    VARCHAR2(5),
JLR_CH_SLA_PERSISTENT    VARCHAR2(5),
JLR_CH_SLA_EXPIRE    VARCHAR2(5),
JLR_CH_SLA_LANG_CODE    VARCHAR2(5),
JLR_CH_SLA_CONSUMERREF    VARCHAR2(50),
WSA_HDR_IND    VARCHAR2(1),
WSA_TO    VARCHAR2(150),
WSA_FROM    VARCHAR2(150),
WSA_REPLY_TO    VARCHAR2(150),
WSA_RELATES_TO    VARCHAR2(150),
WSSE_HDR_IND    VARCHAR2(1),
WSSE_USERNAME    VARCHAR2(150),
WSSE_PASSWORD    VARCHAR2(150),
WSSE_NONCE    VARCHAR2(150),
WSSE_CREATED    VARCHAR2(150),
DESCRIPTION    VARCHAR2(100),
USER_ID    VARCHAR2(10) NOT NULL,
INSERT_TIMESTAMP    TIMESTAMP,
UPDATE_TIMESTAMP    TIMESTAMP
)

   
COMMIT;
