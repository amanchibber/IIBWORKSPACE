--------------------------------------------------------------------------------------------------------
-- Author         : skarri
-- Version         : $Revision: 1.1 $
-- Description     : Create data script for SI_SOAP_OUTBOUND_DETAILS table which will hold details of runtime overrides used by the SOAP Outbound adapter
-- History         : 25/06/2013 SK Adding entry for FRS-000271
--------------------------------------------------------------------------------------------------------

DELETE FROM SI_SOAP_OUTBOUND_DETAILS;

-- SK 25/06/2013 Added to prevent prompt when inserting due to &
--SET DEFINE OFF;


INSERT INTO SI_SOAP_OUTBOUND_DETAILS(BUSINESS_SERVICE_NAME,    WS_SERVICE,      WS_SERVICE_ACTION,  JLR_COMMON_HDR_IND,  JLR_CH_EPR_TO,                               JLR_CH_EPR_FROM,       JLR_CH_SLA_TIMEOUT,    JLR_CH_SLA_PERSISTENT,   JLR_CH_SLA_EXPIRE,    JLR_CH_SLA_LANG_CODE,     JLR_CH_SLA_CONSUMERREF, WSA_HDR_IND,                                 WSA_TO,                                 WSA_FROM,   WSA_REPLY_TO,  WSA_RELATES_TO,  WSSE_HDR_IND,   WSSE_USERNAME,  WSSE_PASSWORD,   WSSE_NONCE,  WSSE_CREATED,  DESCRIPTION,                                             USER_ID,     INSERT_TIMESTAMP,UPDATE_TIMESTAMP)

VALUES('SI_SV_VEHSV_ENGGCHANGE', 'notifyChange', 'urn:NotifyChange',              'Y',     'http://esb.cherryjaguarlandrover.com ','http://www.wmb.jlrint.com',        Null,                 Null,                   Null,                 Null,                     Null,                'Y',    'http://www.wmb.jlrext.com/Service/development/SAPEngineeringGWChange',      Null,        Null,            Null,          'N',             Null,           Null,            Null,         Null,     'SOAP Header Details for Engineering Change GW Service','skarri',              '',           '');

COMMIT;

