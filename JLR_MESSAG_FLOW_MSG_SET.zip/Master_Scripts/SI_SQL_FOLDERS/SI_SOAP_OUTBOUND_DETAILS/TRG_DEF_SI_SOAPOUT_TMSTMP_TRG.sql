--------------------------------------------------------------------------------------------------------
-- Author 		: Srinivasarao karri
-- Version 		: $Revision: 1.1 $
-- Description 	: Create trigger script for SI_SOAP_OUTBOUND_DETAILS table
-- History 		: 25/06/2013 Srinivasarao karri Initial create statement for trigger
--------------------------------------------------------------------------------------------------------

DROP TRIGGER TRG_DEF_SI_SOAPOUT_TMSTMP_TRG;

--Trigger which will insert or update the timestamp if an insert or update action occurs

CREATE OR REPLACE
TRIGGER TRG_DEF_SI_SOAPOUT_TMSTMP_TRG
BEFORE INSERT OR UPDATE ON SI_SOAP_OUTBOUND_DETAILS
FOR EACH ROW
BEGIN

IF INSERTING THEN
	:new.INSERT_TIMESTAMP := systimestamp;
	:new.UPDATE_TIMESTAMP := NULL;
ELSE
	:new.UPDATE_TIMESTAMP := systimestamp;
  END IF;
END;
/
COMMIT;
