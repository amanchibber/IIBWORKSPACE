--------------------------------------------------------------------------------------------------------
-- Author 		: Kenny McCormack
-- Version 		:$Revision: 1.4 $
-- Description 	: Create table script for SI_STATIC_VAL table 
-- History 		: 18/05/2012 Kenny McCormack Initial create statement for table
-- 				: 14/08/2012 Hina Mistry Addition of user id, insert/update timestamp columns and Primary Key
-- 				: 27/02/2014 Seenesh Patel Changing the table definition to amend Primary Key
--------------------------------------------------------------------------------------------------------

DROP TABLE SI_STATIC_VAL;

CREATE TABLE SI_STATIC_VAL (STATIC_IN VARCHAR2(20) NOT NULL, 
							STATIC_OUT VARCHAR2(20) NOT NULL,
							STATIC_DESC VARCHAR2(80),
							CONSTRAINT STATIC_VAL_PK PRIMARY KEY (STATIC_IN));

--14/08/2012 Hina Mistry Addition of user id, insert/update timestamp columns
ALTER TABLE SI_STATIC_VAL ADD USER_ID VARCHAR2(10) NOT NULL;
ALTER TABLE SI_STATIC_VAL ADD INSERT_TIMESTAMP TIMESTAMP;
ALTER TABLE SI_STATIC_VAL ADD UPDATE_TIMESTAMP TIMESTAMP;

-- 16/01/2013 Ravindra Babu Changing the table definition to amend Column sizes
ALTER TABLE SI_STATIC_VAL MODIFY STATIC_IN VARCHAR(45);
ALTER TABLE SI_STATIC_VAL MODIFY STATIC_OUT VARCHAR(120);

-- 16/01/2013 Ravindra Babu Changing the table definition to amend Primary Key
ALTER TABLE SI_STATIC_VAL DROP CONSTRAINT STATIC_VAL_PK;
ALTER TABLE SI_STATIC_VAL ADD CONSTRAINT STATIC_VAL_PK PRIMARY KEY (STATIC_IN,STATIC_OUT);

-- 27/02/2014 Seenesh Patel Changing the table definition to amend Primary Key
ALTER TABLE SI_STATIC_VAL DROP CONSTRAINT STATIC_VAL_PK;
ALTER TABLE SI_STATIC_VAL ADD CONSTRAINT STATIC_VAL_PK PRIMARY KEY (STATIC_IN,STATIC_OUT,STATIC_DESC);

COMMIT;
