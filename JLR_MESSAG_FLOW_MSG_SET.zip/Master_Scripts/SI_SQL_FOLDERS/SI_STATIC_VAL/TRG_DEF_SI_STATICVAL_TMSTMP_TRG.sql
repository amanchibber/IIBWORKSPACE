--------------------------------------------------------------------------------------------------------
-- Author 		: Hina Mistry
-- Version 		: $Revision: 1.1 $
-- Description 	: Create trigger script for trigger on table SI_STATIC_VAL which will update the table
--				  with a insert timestamp when a row has been inserted 
-- History 		: 14/08/2012 Hina Mistry Initial create statement for trigger SI_STATICVAL_TMSTMP_TRG
--------------------------------------------------------------------------------------------------------

DROP TRIGGER SI_STATICVAL_TMSTMP_TRG;

--Trigger which will insert or update the timestamp if an insert or update action occurs
CREATE OR REPLACE
TRIGGER SI_STATICVAL_TMSTMP_TRG
BEFORE INSERT OR UPDATE ON SI_STATIC_VAL
FOR EACH ROW
BEGIN

IF INSERTING THEN
	:new.INSERT_TIMESTAMP := systimestamp;
	:new.UPDATE_TIMESTAMP := NULL;
ELSE
	:new.UPDATE_TIMESTAMP := systimestamp;
  END IF;
END;
/
COMMIT;
