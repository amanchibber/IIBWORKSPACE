------------------------------------------------------------------------------------------------------------------------
-- Author 		: Seenesh Patel
-- Version 		: $Revision: 1.1 $
-- Description 	: Create table script for SI_TARGET_SYSTEMS table which will hold vehicle alert data for different target systems
-- History 		: 03/07/2012 SP: Initial create statement for table
-- 				  14/08/2012 Hina Mistry Addition of user id, insert/update timestamp columns
------------------------------------------------------------------------------------------------------------------------

DROP TABLE SI_TARGET_SYSTEMS;
							  
CREATE TABLE SI_TARGET_SYSTEMS 
(
  SAP_VEHICLE_ALERT_UPDATE 	VARCHAR2(11) NOT NULL, 
  TARGET_SYSTEMS 		VARCHAR2(10) NOT NULL, 
  LEGACY_VEHICLE_ALERT_UPDATE 	VARCHAR2(11), 
  ALERT_UPDATE_VERB 		VARCHAR2(10), 
  CONSTRAINT SI_TARGET_SYSTEMS_PK PRIMARY KEY (SAP_VEHICLE_ALERT_UPDATE, TARGET_SYSTEMS) ENABLE);

--14/08/2012 Hina Mistry Addition of user id, insert/update timestamp columns
ALTER TABLE SI_TARGET_SYSTEMS ADD USER_ID VARCHAR2(10) NOT NULL;
ALTER TABLE SI_TARGET_SYSTEMS ADD INSERT_TIMESTAMP TIMESTAMP;
ALTER TABLE SI_TARGET_SYSTEMS ADD UPDATE_TIMESTAMP TIMESTAMP;  
  
COMMIT;
