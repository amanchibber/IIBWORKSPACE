--------------------------------------------------------------------------------------------------------
-- Author 		: Yogesh Raja Sharma
-- Version 		: $Revision: 1.3 $
-- Description 	: Create index script for SI_TRANSACTION_AUDIT table
-- History 		: 19/02/2015 Yogesh Raja Initial creation
--  			: 15/07/2015 Paul Gregory - removed duplicate entry for IDX_SI_TRANSACTION_AUDIT_02
--				: 04/12/2015 Paul Gregory - reference to MSG_RECIEVED_TIMESTAMP was still present. Removed the entry
--------------------------------------------------------------------------------------------------------

create index WMBOWNER.IDX_SI_TRANSACTION_AUDIT_01 on WMBOWNER.SI_TRANSACTION_AUDIT("BUSINESS_SERVICE_ID");
create index WMBOWNER.IDX_SI_TRANSACTION_AUDIT_02 on WMBOWNER.SI_TRANSACTION_AUDIT("BUSINESS_SERVICE_ID","MSG_RECEIVED_TIMESTAMP");
create index WMBOWNER.IDX_SI_TRANSACTION_AUDIT_03 on WMBOWNER.SI_TRANSACTION_AUDIT("BUSINESS_SERVICE_ID","BROKER");