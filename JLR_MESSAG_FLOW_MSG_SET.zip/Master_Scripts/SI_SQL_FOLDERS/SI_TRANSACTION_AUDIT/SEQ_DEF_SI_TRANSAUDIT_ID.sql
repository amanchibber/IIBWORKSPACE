--------------------------------------------------------------------------------------------------------
-- Author 		: Yogesh Raja 
-- Version 		: $Revision: 1.1 $
-- Description 	: Create sequence script for table SI_TRANSACTION_AUDIT table
-- History 		: 19/02/2015 Yogesh Raja Initial create statement for sequence
--------------------------------------------------------------------------------------------------------
DROP SEQUENCE SI_TRANSAUDIT_ID;
		
CREATE SEQUENCE SI_TRANSAUDIT_ID
MINVALUE 1
START WITH 1
INCREMENT BY 1
CACHE 10;

