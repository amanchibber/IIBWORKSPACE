--------------------------------------------------------------------------------------------------------
-- 	Author 			: Yogesh Raja
-- 	Version 		: $Revision: 1.3 $
--	Description 	: Create table definition script for si_transaction_audit table which will hold details of events emitted by message flows
-- 	History 		: 19/02/15 YR Initial creation statement
--				    : 13/03/15 YR Removed Message Type column
--------------------------------------------------------------------------------------------------------

DROP TABLE si_transaction_audit;

CREATE TABLE si_transaction_audit ( 
	ID NUMBER(10) NOT NULL,
	BUSINESS_SERVICE_ID VARCHAR2(45), 
	INTERFACE VARCHAR2(100),
	MSG_RECEIVED_TIMESTAMP TIMESTAMP,
	BROKER VARCHAR2(10),
	EXECUTION_GROUP VARCHAR2(50),
	MESSAGE_FLOW VARCHAR2(100),
	SUBFLOW_NAME VARCHAR2(100),
	MESSAGE CLOB,
	LOCAL_UUID VARCHAR2(50),
	TRANSACTION_UUID VARCHAR2(50),
	CONSTRAINT PK_SI_AUDIT_ID PRIMARY KEY(ID)
);

ALTER TABLE si_transaction_audit RENAME COLUMN MESSAGE TO MESSAGE_PAYLOAD ;


COMMIT;