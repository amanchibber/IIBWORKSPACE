--------------------------------------------------------------------------------------------------------
-- Author 		: VijayAnand
-- Version 		: $Revision: 1.4 $
-- Description 	: Create index script for SI_TRANSACTION_LOGGING table
-- History 		: 05/01/2016 VijayAnand Initial creation
--------------------------------------------------------------------------------------------------------

create index WMBOWNER.IDX_SI_TRANSACTION_LOGGING_01 on WMBOWNER.SI_TRANSACTION_LOGGING("EVENT_TIMESTAMP","INTERFACE","BUSINESS_SERVICE_ID");
create index WMBOWNER.IDX_SI_TRANSACTION_LOGGING_02 on WMBOWNER.SI_TRANSACTION_LOGGING("EVENT_TIMESTAMP","TRANSACTION_UUID");