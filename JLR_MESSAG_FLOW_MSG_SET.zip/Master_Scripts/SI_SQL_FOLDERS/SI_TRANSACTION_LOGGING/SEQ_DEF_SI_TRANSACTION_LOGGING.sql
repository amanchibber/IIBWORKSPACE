--------------------------------------------------------------------------------------------------------
-- 	Author 			: Seenesh Patel
-- 	Version 		: $Revision: 1.2 $
--	Description 	: Create sequence definition script for table SI_TRANSACTION_LOGGING table
-- 	History 		: 27/01/15 SP Initial creation statement
--------------------------------------------------------------------------------------------------------

DROP SEQUENCE SI_TRANS_LOGGING_ID;
		
CREATE SEQUENCE SI_TRANS_LOGGING_ID
MINVALUE 1
START WITH 1
INCREMENT BY 1
CACHE 10;

