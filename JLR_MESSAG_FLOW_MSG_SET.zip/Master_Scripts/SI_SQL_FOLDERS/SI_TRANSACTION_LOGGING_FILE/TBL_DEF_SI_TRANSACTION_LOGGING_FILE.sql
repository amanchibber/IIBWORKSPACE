--------------------------------------------------------------------------------------------------------
-- 	Author 			: Seenesh Patel
-- 	Version 		: $Revision: 1.3 $
--	Description 	: Create table definition script for SI_TRANSACTION_LOGGING_WRITE_FILE table which will determine if we need to write to a log file
-- 	History 		: 04/02/15 SP Initial creation statement
--------------------------------------------------------------------------------------------------------

DROP TABLE SI_TRANSACTION_LOGGING_FILE;

CREATE TABLE SI_TRANSACTION_LOGGING_FILE ( 
	MESSAGE_FLOW VARCHAR2(100), 
	WRITE_TO_FILE VARCHAR2(1),
	INSERT_TIMESTAMP TIMESTAMP NULL,
	UPDATE_TIMESTAMP TIMESTAMP NULL,
	CONSTRAINT PK_SI_TRANS_LOG_FILE PRIMARY KEY (MESSAGE_FLOW, WRITE_TO_FILE)
);

