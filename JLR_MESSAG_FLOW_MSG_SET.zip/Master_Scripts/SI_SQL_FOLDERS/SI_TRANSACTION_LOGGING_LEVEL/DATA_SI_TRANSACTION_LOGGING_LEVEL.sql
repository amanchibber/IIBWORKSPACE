﻿-- Author 		: Aman Chibber
-- Author 		: Aman Chibber
-- Author 		: Aman Chibber
-- Version 		: $Revision: 1.393 $
-- Description 	: Create data script for SI_TRANSACTION_LOGGING_LEVEL.sql table which will hold Transaction logging level information. 
-- History 		: 05/02/2015 Aman Chibber Initial INSERT statements for FRS-000128,FRS-000112,FRS-000117,FRS-000139,FRS-000118
--				: 10/02/2015 Aman Chibber Added logging level entry for SF_ZJLR_INTLOG_RPC_BAPI in FRS-000128,FRS-000112,FRS-000117,FRS-000139,FRS-000118
--				: 11/02/2015 Seenesh Patel Added entries for FRS-000128,FRS-000112,FRS-000117,FRS-000139,FRS-000118 for new column SUBFLOW_DESC
--				: 13/02/2015 Seenesh Patel Added entries for SI_AD_SAP_SVCRM_ALE_MT_Outbound
--				: 24/02/2015 Srinivas Pithani Added entries for FRS-000148
--                              : 25/02/2015 Krishna Added entries for FRS-000147 
--                              : 05/03/2015 NM Added entries for FRS-000651 
--                              : 11/03/2015 AB Added entries for FRS-000137
--				: 12/03/2015 SA Added entries for FRS-000670
--				: 13/03/2015 MJ Added entries for FRS-000366
--				: 31/03/2015 AT Added entries for FRS-000669
--				: 06/04/2015 MJ Added entries for FRS-000695
--				: 16/04/2015 VV Added entries for FRS-000693
--				: 17/04/2015 PK Added entries for FRS-000015
--				: 21/04/2015 NC Added entries for FRS-000681
--				: 21/04/2015 VP Added entries for FRS-000667
--				: 23/04/2015 AaP Entry for FRS-673
--				: 29/04/2015 PM New Infrastructure Development: transaction logging level entries for ESB HTTP INBOUND V2, ESB HTTP REPLY V2 AND ESB HTTP OUTBOUND V2 adapters.
--  			: 01/05/2015 AC Added entries for FRS-000112 & it's dependent canonical adapters.
--				: 04-May-2015 AaP Entry for FRS-705
--				: 05/05/2015 PK Updated the entries for FRS-000015.
--                05/05/2015 YT Added entires for IA-000005
--                08/05/2015 VP Added entires for FRS-651 SAP to KN
-- 				: 08/05/2015 AB Updated entries for DEF-4321 FRS-112
 -- 			: 11/05/2015 YR Added entires for FRS-680
-- 			    : 13/05/2015 SB Added entires for FRS-000680(Quarantine Status To MES)
--				: 14/05/2015 AB Added for SF_Logging3  FRS-000139 
-- 				: 14/05/2015 RB Removed SF_Logging1 configuration
--  			: 20/05/2015 YR added entries for NCR Response( FRS - 000680)
--				: 20/05/2015 VV Added for FRS-000716 (Measurement Doc from MES to SAP)
--				: 21/05/2015 RB Added entries for FRS-000690
--				: 21/05/2015 NM Added entries for FRS-000711
--				: 22/05/2015 AB Updated for SF_Logging3 and SF_Logging1 SubFlow Description  FRS-000139 
--                              : 22/05/2015 MJ Entry for new adapter flow as per FRS 695
-- 				:25/05/2015 AaP Added entries for FRS-000711
-- 				:26/05/2015 PM  Added entries for FRS-000712
-- 				:27/05/2015 SM  Added entries for FRS110:DEF4621(Performance issue)
--				:27/05/2015:VB:Added entries for FRS111:IFU3019
--				:28/05/2015:AB Added entries for FRS-000108
--				:28/05/2015:AB: Added entries for FRS-000111
--				:29/05/2015 VV Added for FRS-000716 (Update Status Notification from MES to SAP)
--				:01/06/2015:RB Added entries for FRS-000715
--				:02/06/2015 VV Added for FRS-000718 (Planned Order Confirmation from MES to SAP)
--				:08/06/2015 AB Added for FRS-000110 SF_SOAP_ErrorHandlingV2
--				:10/06/2015 HB Added entries for IFU3024
--				:18/06/2015 KT Added entries for FRS-000679
--				:18/06/2015 AS Added entry for FRS-000707
-- 				:24/06/2015 SB Added entries for FRS680(Vehicle Genealogy To Multiple Systems)
-- 				:29/06/2015 VB Changed column and value sequence for FRS000110
--              : 29/06/2015 YR Added entries for FRS621(changes for Stone)
-- 				: 29/06/2015 NC Added entries for FRS-000670
--				:30/06/2015	 PP Added entries for FRS-364 (Warranty vehicle configuration) and FRS-382 (Warranty replicate claims) batch services
--				:30/06/2015  PP Added entries for Batch framework message flows
--              :08/07/2015 VP FRS674 initial entry
-- 				:08-07/2015 SM FRS136 initial entry
--              :13/07/2015 YR Added entries for FRS261(changes for Stone)
-- 				:21/07/2015 HB Added New entries for FRS731
-- 				:21/07/2015 NM Added New entries for FRS668
--				:22/07/2015:AB: Added entries for FRS-000115
--			    :23/07/2015 VB: Added entries for FRS-000107
--				:23/07/2015:SA: Added entries for FRS-000109
--				:23/07/2015:SM: Added entries for FRS-000116
--				:28/07/2015:AS: Added missing entry for FRS-000382
-- 				:28/07/2015 VB: Added entry for FRS-000127
-- 				:30/07/2015 VB: Added entry for FRS-000141
--				:31/07/2015 VV: Added for IFU 3190 (FRS-000718 Planned Order Confirmation from MES to D42/SAP)
--				:31/07/2015 SA: Added entry for FRS-000128
--				:04/08/2015 SA: Added entry for FRS-000143
--				:05/08/2015 NC Added New entry for FRS719
--				:06/08/2015 SA Added New entry for FRS129
--				:07/08/2015 SM Added New entry for FRS130
--				:07/08/2015 VB Added New entries for FRS136 AVO
--				:10/08/2015 VB Added New entries for FRS136 VVO and Batch Flow
--				:10/08/2015 SM Added New entries for FRS130(Canonical Flow)
--				:10/08/2015 SM Added New entries for FRS138
--				:11/08/2015 SA Added New entries for FRS137
--				:12/08/2015 SA Added New entries for FRS133
--				:14/08/2015 PG The SubFlow Descs for SI_BS_GXS_VEHICLE_MATFL_DELCONF Out were inverted
--				:19/08/2015 TK DEF5700:Added New entries for Adapter flows used in FRS115 & FRS136
--				:20/08/2015 SM DEF5828 : Corrected scripts for SF_CrtBreakdownEventForVehicle_SVCRM
--              :21/08/2015 KV IFU 3239:Added New entries for FRS 382(SYC1)
-- 				:27/08/2015 TK IFU 3341:Added New entries for FRS 143
--				:03/09/2015 AB Updated entries for FRS130 with SI_SV_CUSSV_REPLICTEDR_SVCRM_CRTUPDDLR and SI_SV_CUSSV_REPLICTEDR_SVCRM_CRTUPDTER
--				:04/09/2015 TK Updated entries for FRS-000128,FRS-000112,FRS-000117,FRS-000118
-- 				:07/09/2015 AB: Updated entry for FRS-000143(DEF6107)
--				: 11/09/2015 HB updated logging level for 'SF_Logging1' to 3 --IFU3354
--              : 15/09/2015 SB Added New entries for FRS-000687
--				: 16/09/2015 PP Restored the lost data entries that are added between 18/06/2015 & 30/06/2015 (more specifically the changes made between CVS versions (inclusive) 1.62 - 1.67)
--				: 21/08/2015 TK DEF6318: Updated BSID for Batch Flow to SI_SV_CUSSV_REPACVHSTD for SF_Logging4 & SF_Logging5
-- 				: 22/09/2015 NC Added entries for FRS-720
-- 				: 24/09/2015 SB Added entries for IA-170 as per IFU3382
-- 				: 25-09-2015 TK MNT:Added entries for FRS123
-- 				: 25-09-2015 VB MNT:Added entries for FRS128(Canonical Flow)
--				: 28-09-2015 NC updated entries for FRS-720
--				: 08-10-2015 SN	Added entries for FRS-670 as per IFU3429
--				: 08/10/2015 AS FRS-000669 Customs Declaration
--				: 19/10/2015 SM FRS-000129 Updated scripts for SF_CreateUpdateCaseFrom_SVCRM
--				: 21/10/2015 AM Entry for BODS to be deleted for FRS000015 IFU3443
-- 				: 27-10-2015 AaP Added entries for FRS-650 under IFU3483
-- 				: 05-11-2015 SN Added entries for FRS-721
--                09/11/2015 VP Added entries for FRS-000273
--              : 16/11/2015 AT Added entries for FRS-000689
--                17/11/2015 VP Added entries for FRS-000277
--                18/11/2015 VP Added entries for FRS-000277
-- 				: 19/11/2015 KT Added entries for IA-000147
--				: 20/11/2015 NC Added entries for IA-000172
--                23/11/2015 VP Added entries for FRS-000272
--				: 25/11/2015 AB added entry for FRS-000107 for IFU3554
--				: 26/11/2015 MJ Added entries for FRS-000616 for IFU3497
--				: 08/12/2015 NC Added New entry for FRS669(Vehicle Import Declaration)
--				: 10/12/2015 SB Added New entry for FRS670 – Vehicle Information to TITO
--				: 11/12/2015 AB Updated LOGGING_LEVEL to 3 for all Guanxi FRS
--				:14/12/2015 HB IFU3419: Added entries for adapters of FRS-000382
--				:15/12/2015 SN Added entries for FRS-000737
--				: 16/12/2015 KT Added entries for FRS-000803
-- 				: 22/12/2015 HB updated SUBFLOW_DESC and LOGGING_LEVEL for FRS-000382 DEF-15043
-- 				: 22/12/2015 HB added entry for FRS-000382 DEF-15043
--				: 23/12/2015 KV added entry for FRS-000722 
--                31/12/2015 VP DEF15043 reduce logging level to 2 
-- 				: 07/01/2016 HB Added enty for FRS-000364 as part of IFU-3622
--				: 11/01/2016 MJ Added Logging level entry SF_Logging4 for FRS-000366 as per IFU 3590
--              : 13/07/2016 HB FRS-000807 - Added entries for OA Code Translation Service
--				: 21/01/2016 VB Added entries for FRS-000109 Contract Canonical flow
--				: 22/01/2016 PM IFU3545 FRS-130
--                25/01/2016 VP added entries for FRS791
--              : 25/01/2016 SN Added entries for RS661
--              : 27/01/2016 AB Updated Logging level for all Guanxi FRS entries IFU3670
--              : 27/01/2016 TK IFU3670: Updated logging level for some logging points to 2 for FRS-000147 & FRS-000148 
--              : 29/01/2016 SN Added entries for logging3 sub flow in FRS661
--              : 29/01/2016 VV Added entries for FRS260 IFU 3681
--              : 01/02/2016 LH Added entries for FRS-000802 
--              : 04/02/2016 AB Updated Logging level for common flows Guanxi FRS entries IFU3694
--              : 05/02/2016 VP modified entries for IFU3662
--				: 11/02/2016 LH changed logging level as part of IFU 3717
-- 				: 15/02/2016 AB: Updated entry for FRS-000128 for INC000001198511
-- 				: 17/02/2016 AB: SUBFLOW_DESC updated for FRS-000128 (SI_SV_CUSSV_CTUPSERREP) for INC000001198511
--				: 17/02/2016 KV: Added Entries for FRS 653(ILD)
--				: 18/02/2016 SM: Updated entry for SF_SOAP_ErrorHandlingV2
-- 				: 19/02/2016 TK: INC000001211696: Updated entry for FRS-000123 related to SF_SOAP_ErrorHandlingV2
-- 				: 22/02/2016 TK: Updated entry for FRS-000128 for MNT
--				: 22/02/2016 VV: IFU 3681 Commented 2 SQL entries for FRS-000693. Added 2 SQL entries for FRS-000693
--				: 25/02/2016 VB Changed LOGGING_LEVEL to 3 for FRS-133
--				: 26/02/2016 VB Reverted back the changes for LOGGING_LEVEL for FRS-133
-- 				: 26/02/2016 PM Updated logging level to 3 (as per mail from Sai Sankar Kunapareddi)
--              : 03/03/2016 VP Added entry for FRS-811
--				: 03/03/2016 PM added entry for FRS-638
--				: 04/03/2016 LH inserted entry for FRS-791 IFU3764
--				: 04/03/2016 NM inserted entry for FRS-795
-- 				: 07/03/2016 TK MNT: Updated entry for SF_Logging2 of FRS141
--              : 07/03/2016 MJ Added entry for IA-271
--              : 08/03/2016 PM Added entries for FRS-638 SAP adapter
--				: 10/03/2016 LH IFU3676 FRS-259 entries
--				: 15/03/2016 LH IFU3605 FRS-258 entries
--          	: 17/03/2016 PM Added as per FRS-812 Development
--				: 21/03/2016 AB: Updated entry for FRS-000143(IFU3767)
--				: 25/03/2016 PP: Added logging level entries for EXCEP_REPLAY_ALL (exception replay web service)
--				: 30/03/2016 MJ: Added entry for IA-49
-- 				: 21/07/2015 HB Added New entries for FRS810
--              : 31/03/2016 PK Added new entries for IFU3797
--				: 06/04/2016 PM Added as per SI_AD_SAP_SMTCN_ALE_MT_OutboundV2 (FRS-812 SAP Adapter)
--				: 08/04/2016 KT IFU3815 MQ Adapter flow for PGZ SI_AD_PGZ_MQSERV_MQOUT
--				: 15/04/2016 SS IFU3819 entries added for SI_AD_SOAP_STD_MT_OutboundV2
--				: 18/04/2016 TK MNT: Updated logging level to 3 for QA testing for FRS 143
-- 				: 18/04/2016 TK Reverted logging level as earlier for FRS 143 
-- 				: 18/04/2016 KB Added new entries for FRS-000690 IFU3829 
--				: 19/04/2016 PM Added new entries for FRS-382 Bollywood.
--				: 21/04/2016 MJ Updated entry for IA-49
--              : 21/04/2016 PK Added new entries for FRS-809
-- 				: 22/04/2016 AB: Updated entry for FRS-000128 for IFU3828 New exception handler changes
-- 				: 22/04/2016 AaP added entry for FRS-000382 AUTOA flow DEF-15043
--				: 25/04/2016 SM  IFU3822(FRS-000109):Updated subflow name to V2 after error handling changes
--				: 25/04/2016 SM  IFU3800(FRS-000108):Updated subflow name to V2 after error handling changes
-- 				: 28/04/2016 NCH added entries for FRS-000816 
-- 				: 29/04/2016 KB Added new entries for FRS-000813 
-- 				: 03/05/2016 PM removed SF_Logging4 for AutoA. As it is no longer required.
-- 				: 04/05/2016 PM removed duplicate entries for AutoA.
-- 				: 05/05/2016 AT Added new entries for FRS-000115 Adapter flow V2
-- 				: 09/05/2016 NB Added new entries for FRS-000814
-- 				: 11/05/2016 KB Added new entries for FRS-000817 
--				: 11/05/2016:NC:DEF#18516 updated loggig level to 3 for SI_AD_PGZ_MQSERV_MQOUT,FRS-000816 ,000813 and 000814
--				: 11/05/2016:NC:DEF#18516 reverted loggig level to 2 for SI_AD_PGZ_MQSERV_MQOUT,FRS-000816 ,000813 and 000814
--				: 12/05/2016 VB IFU3808: Updated entry as per the design changes for FRS-133
--              : 13/05/2015 IFU:3824 added entries for FRS-000112
-- 				: 16/05/2016 NB Added new entries for FRS-000815
--				: 16/05/2016 HB Added New entries for FRS818
--				: 17/05/2016 NC updated BSID for FRS-000813 
--				: 23/05/2016 NCH added entries for FRS-000816 Canonical and adapter(CTC) flow
--				: 26/05/2016 HB Added New entries for IA-61 as part of IFU-3878
--				: 01/06/2016 ANA Added for FRS-000151, flow SI_AD_CANONICAL_PRODREF_MT_OUT
--              :02/06/2016 KV Added Entries for FRS 000130/IFU 3888(OCRM)
--				:02/06/2016 VB:DEF8114 - Added entry for 'SF_AcctCrtUpd_SVCRMV' for FRS-108
--				:02/06/2016 LH: Added entries for IA-207 under IFU3924
--				:07/06/2016	VB:DEF8161/DEF8169 - Added entries for 'SF_Contract_CreateUpdate' and 'SF_VehicleAccountRelationship_CreateUpdate'
--				:07/06/2016 SB Updated logging level to 3 for SI_BS_SAP_TRBBR_INVOICE_TITO_PO
-- 				:08/06/2016 HB Added New entries for IA-108
--				:08/06/2016 VB:DEF8114 - Updated entry for 'SF_AcctCrtUpd_SVCRM' for FRS-108
--				:13/06/2016 LH: IFU3948 --Removed logging level entries for unused topix logging subflows
--				:16/06/2016 VB:IFU3983 - Added missing entries for FRS-000128 
--				:16/06/2016 VP DEF15043 added logging entries for smart flow
--				:16/06/2016 ANA Added for FRS-000151, flow SI_BS_CANON_ProdRef_To_SVCRM
--				:17/06/2016 SM  IFU3990:Added logging level for SF_Logging5
-- 				:27/06/2016 AT Added for FRS-000107(IFU 3897 OCRM) 
--				:28/06/2016 AB: Added entry for FRS-000127 for DEF8397
-- 				:28/06/2016 PK Added for FRS-000820
-- 			    :01/07/2016 KB Added new entries for FRS-000819 
--				:07/07/2016 LH IFU4023 IA-000207 Change in Message flow. Accordingly changing Transaction Logging level script
-- 				:11/07/2016 NB Added new entries for FRS-000372(IFU3913, IFU3955)
-- 				:12/07/2016 AaP DEF15043-SWORD added logging entries for sword flow FRS382
-- 				:12/07/2016 RBH Added new entries for FRS-000151(IFU3942)
--				:19/07/2016 LH Added entries for FRS-362 service flow framework migration BSID is SI_SV_VEHSV_VEHENQUIRY
-- 				:28/07/2016 NB: Added entries for FRS-000371(IFU3928)
--				:05/08/2016 PP: IFU3907 Added log level entries for all IA-27 interfaces
-- 				:09/08/2016 HB Updated Entry for FRS-818 as per IFU-4055
-- 				:16/08/2016 TK Added new entries for IA-000027(IFU3907)
-- 				:16/08/2016 VB:MNT(FRS-112) - Replaced SF_SOAP_ErrorHandling with SF_SOAP_ErrorHandlingV2
-- 				:18/08/2016 KB Added new entries for FRS632 adapters
-- 				:19/08/2016 KB Added new entries for IA44 adapters
-- 				:19/08/2016 SB Added new entries for FRS-266 adapters
--              :20/08/2016 :KV Added the new Entries for FRS-000151(IFU4049)
-- 				:28/08/2016  SM  Added for FRS-000107(IFU 4047 OCRM)
--              :24/08/2016 :KV Added the db entry for RES_LOGINWS logging as part of  FRS-000151(IFU4049)
--              :24/08/2016 :NB Added the new Entries for FRS-000130(IFU4048)  
--              :26/08/2016 :KV Updated the subflow name to SF_SV_GetSession_from_OCRM for FRS 130 and FRS 151 OCRM 
--              :26/08/2016 :SM Updated the subflow name to SF_SV_GetSession_from_OCRM for FRS 107(OCRM)
--				:30/08/2016 :MG Updated for IA-000293 for SI_BS_WAJ1_MFT_HR_SAP_TRBGB_TRADEUNION
--              :01/09/2016 :AT Updated for IA-000099
--				:02/09/2016 :PK IFU4108 : Added entry for JAG and LR and removed the old entry
--				:02/09/2016 HV added entry for IA-000148
--				:06/09/2016 HV modified logging level
--				:08/09/2016 KT Added entry for SF_Logging_Err in FRS271 Main flow
--				:13/09/2016 PP IFU4126 - For IA-27 interface, deleted entries for BUSINESS_SERVICE_ID=SI_BS_SAP_TRBGB_INVCRDDETS_BOBBE, SI_BS_SAP_TRBGB_INVCRDDETS_FVF3, --								SI_BS_SAP_TRBGB_INVCRDDETS_HPFM and SI_BS_SAP_TRBGB_INVCRDDETS_LISA; as these flows are decommissioned.
--				:14/09/2016 SN added entries for IA-97 as part of ESB remediation 
--				:15/09/2016 HV added entries for IA-148 as part of ESB remediation 
--              :16/09/2016 NM: Added entry for FRS-000828
--              :16/09/2016 AT: Added entry for IA000094
--              :16/09/2016 AT: Added entry for IA000094 for adapter flow SI_AD_SAP_TRBGB_ALE_HR_PosSecData_MT_Inbound 
-- 				:19/09/2016 KB Added new entries for FRS-000712 HTTP adapters
-- 				:20/09/2016 KB updated BSID for SI_AD_HTTP_MATERIALGXS_REPLY_V2,  FRS-000712 HTTP adapters
--				:21/09/2016 HV:Added entry for IA-44 as part of ESB remediation
--              :21/09/2016 AT ESB Remediation: Added new Entry for FRS-000632
-- 				:22/09/2016 VB DEF9134:Updated 'SUBFLOW_DESC' for 'SF_Logging2','SF_Logging3' and 'SF_Logging4' for FRS-000151, flow 	SI_BS_CANON_ProdRef_To_SVCRM
--              :27/09/2016 SN Added entries for IA-95 as part of ESB remediation
--				:28/09/2016 HV added entries for FRS-000266 as part of esb remidiation
--				:29/09/2016 NB Added entries for FRS-000388.
--				:30/09/2016 MG added entry for IA-000290 (ESB-Remediation)
--              :05/10/2016: SK(IFU4148) :Added entries for FRS-000154 
-- 				:07/10/2016 KB Added new entries for FRS-000837 
--				:13/10/2016 PP (IFU4180)FRS-000136 2 new logging entries added (one each for BSID's- SI_SV_CUSSV_REPAVO & SI_SV_CUSSV_REPVVO)
--				:13/10/2016:SS: Added entries for SF_Logging8 and SF_Logging9 FRS-000115 for IFU4177
--				:13/10/2016 PP (IFU4195)FRS-000136 logging entries modified for BSID's - SI_SV_CUSSV_REPACVHBAT & SI_SV_CUSSV_REPACVHSTD
--				:17/10/2016 NB Entry added for FRS-261(IFU4163)
--				:22/10/2016 MJ Entry added for FRS-261(IFU4227)
-- 				:10/23/2016 HB Added Entry for FRS-790
-- 				:08/11/2016 SN Added Entry for IA-290 adapter entries
-- 				08/11/2016 AM Added entries for IA258 as part of IFU4140/4141
-- 				08/11/2016 SN Corrected entries of Business service flow of IA-290
--				08/11/2016 PP IFU-3907 IA-27. Amended the business service id for NSCNT interface to be SI_BS_SAP_TRBGB_INVCRDDETS_JAGNSCNT & SI_BS_SAP_TRBGB_INVCRDDETS_LRNSCNT respectively
--				08/11/2016 MJ Entry added for IA-354(IFU4251)
--				09/11/2016 PK Entry added for IA-355(IFU4252)
-- 				12/11/2016 HB Added Entry for IA-52 and SAP adapter IFU-4097
-- 				17/11/2016 HB Added Entry for IA-52 IFU-4097
--              18/11/2016 VVS Added New entries for FRS155 as per the IFU4236(SI_SV_CreateUpdate_Appointment)
--              18/11/2016 VVS Added New entries for FRS155 as per the IFU4236(SI_AD_CANONICAL_APPOINTMENT_MT_OUT)
-- 				23/11/2016 AM Added entry for IA258 as part of IFU4140/4141 for SI_AD_SAP_ESMALL_FIDATA_BAPI_InboundV2 Flow
--              24/11/2016 SK Added New entries for FRS156 as per the IFU4244(SI_SV_ReplicateCampaign)
--              25/11/2016 SK Added New entries for FRS156 as per the IFU4244(SI_AD_CANONICAL_CAMPAIGN_MT_OUT)
--              29/11/2016 LH Added New entries for FRS839
--				02/12/2016 AT Added New entries for FRS153 as per the IFU4255
--				07/12/2016 AT Added New entries for FRS154 IFU4275
--				08/12/2016 SN Added New entry for IA-000095 as per Defect15
--				12/12/2016 MJ Added new entries for FRS841
--				12/12/2016 SN Added new entries for IA-000099
--              12/12/2016 PK Added New entries for IFU4224(IA-000158) changes.
--              13/12/2016: AT(MNT)Updated entries for FRS153/154/155/156(logging level 2 and 3 based on SVCRMrequirement)
--				13/12/2016 SN Added new entries for IA-000293
--				14/12/2016 PM Added entries as per IFU4179
--				20/12/2016 SN Added new entries for IA-000097
--              21/12/2016 SK Updated BUSINESS_SERVICE_ID for 'SF_VehicleAccountRelationship_CreateUpdateV2' for IFU4329(MNT)
--              23/12/2016 NB Added new entries for FRS-000372(IFU4338)
--				27/12/2016 LH Added entries as a part of IFU4327 FRS-366
--				28/12/2016 VB (MNT): Changed logging level as 3 wherever applicable for FRS-133
--				03/01/2017 HB Added Entries for FRS615 IFU4306
--              09/01/2017 SK DEF10616 Updated BSID for SF_VehicleAccountRelationship_CreateUpdateV2 for FRS-143
--				12/01/2017 AaP Entries for FRS130 (GCM)IFU4264
-- 				16/01/2017 CD Added entries for FRS-000838
-- 				18/01/2017 VK Added entries for FRS-000093.
-- 				26/01/2017 NM Added entries for FRS-000096.
--              28/01/2017 NB Added entries for SI_BS_PGZ_Vehicle_Weight_To_PLO Service IFU4253(FRS-000620)
-- 				30/01/2017 CD Added entries for FRS-000815(IFU4373)and Updated  SUBFLOW_DESC to OUT_PGZ in the existing entry
--  			01/02/2017 CD Added changes for IFU4373 Updated SUBFLOW_DESC to OUT_PGZ in the existing entry.
--				07/02/2017 INC000001981360:Corrected SUBFLOW_DESC for SF_Logging.Changed from IN_PLO to IN_D42
--              07/07/2017 NM IFU-4388 Replaced ASTAT to AAARA
--              10/02/2017 VK IA-000093 Added entries for SI_AD_SAP_TRBGB_ALE_HR_EmpDataChgs_MT_Inbound and SI_AD_SAP_TRBGB_ALE_HR_EmpDataChgs01_MT_Inbound adapters 
--              10/02/2017 KV FRS-000661(IFU-4365)  Commented Entries for business Service ID's SI_BS_SAP_TRBGB_PAYMT_SINTEL_ARPAYMT,SI_AD_SAP_TRBGB_BAPIFIMT_IN_V2 as these entries are shifted to New Build
--              18/02/2017 LH Inserted initial Entries for FRS-786
--              24/02/2017 SK Removed entries for SUBFLOW_NAME = 'SF_Logging1' for Simplified batch interfaces(FRS-112,FRS-117,FRS-118,FRS-128) as per IFU4381
--              27/02/2017 VK IA-000093 Made changes in entry for  SI_AD_SAP_TRBGB_ALE_HR_EmpDataChgs_MT_Inbound.
--              01/03/2017 NM IFU-4428 Added new logging entry as per IFU
-- 				09/03/2017 AS Flow SI_BS_MFT_Invoice_Ack_To_SAP_TRBBR removed as part of IFU3563, this entry should have been commented out long back!
-- 			    14/03/2017 MJ IFU-4438 Added entries for FRS-000107
--				28/02/2017 AaP Added New entry for FRS381 under IFU4418
--              16/03/2017 SK Added SI_TRANSACTION_LOGGING_LEVEL for adapter as part of adapter SI_AD_SOAP_STD_MT_Outbound_SYNC(FRS-000115)-IFU4500
-- 				20/03/2017 KB Added new entries for FRS-000620 SI_BS_VCATS_Vehicle_Weight_To_PLO 
--              24/03/2017 SK DEF11764 Added SF_Logging5 entry for BSID 'SI_SV_CUSSV_CTUPACTVTY_ACTV' for FRS-154
--              24/03/2017 VK Reverted entries for IFU-4428
-- 				27/03/2017 KB Added new entries for IA-00067 SI_BS_D42_VEH_SAP_ESMALL_VEHEVENTS 
-- 				27/03/2017 KB Added new entries for IA-00067 SI_BS_D42_VEH_SAP_SMTALL_VEHEVENTS 
--              27/03/2017 VK Restored Entries for IFU-4428.
--              04/04/2017 MJ Added new entries for FRS-107 IFU4515 
--			 	11/04/2017 KB Added new entries for FRS-000258 IFU4561 SI_BS_PGZ_VEHICLE_WLCAR_PRODCTRL 
--			 	11/04/2017 MJ Updated entries for FRS-107 Map Suppliers
--			 	17/04/2017 MJ Added new entries for FRS-000259 IFU4514 PLO Vehicle Maps Property Data
--              21/04/2017 AT Removed entries as part of IFU4590
--				21/04/2017 AT Removed entries As part of FU4590 FRS-138
--              21/04/2017 AT Removed entries As part of IFU4591
-- 				21/04/2017 AM Added new entries for IA107 PODS Interface
--              02/05/2017 VK Removed entries after framework migration of FRS-273.
--              03/05/2017 SK IFU4604:Updated entries(BSID and subflow name) for FRS-000154(Account)
--              08/06/2017 SK INC000002275437:Added entries for SF_Logging1 for FRS-000117(SI_BS_CUSSV_CRTUPDFINCNTRPROP_SIMP)
--			 	09/06/2017 LH Added new entries for IA-000115 IFU4711 
--              20/06/2017 VVS INC000002275437:Added entries for SUBFLOW_NAME  = 'SF_Logging1  for FRS118 
--  			27/06/2017 APT INC000002320935 Added entries for BSID'SI_SV_CUSSV_CRTUPDLEAD_ACTV'and'SI_SV_CUSSV_CRTUPDLEAD_ACCT'for    SF_Logging4 FRS112
--				07/07/2017 PM Updated entries as per IFU4763
--              11/07/2017 APT INC000002361203:Added entries(BSID and subflow name SF_Logging5,SF_Logging6 ) for FRS-000154 
--				07/08/2017 PM Entries added as per FRS-868 Development
--              18/08/2017 NM FRS-000828 IFU4823 Added entry to log Warning
-- 				21/08/2017 AMAHESH2  Entries migrated to SI_Components FRS 720 under IFU 4684
-- 				06/09/2017 VK Made changes for INC000002399137 - SI_BS_VISTA_CUSSV_MAPSUP_GOF_HERE from SUBFLOW_NAME='LogHTTPResFailure' to SUBFLOW_NAME='LogHTTPResFail'
-- 				07/09/2017 VK Made changes for SI_BS_VISTA_CUSSV_MAPSUP_GOF_NNG,SI_BS_VISTA_CUSSV_MAPSUP_GOF_AUTONAVI from SUBFLOW_NAME='LogHTTPResFailure' to SUBFLOW_NAME='LogHTTPResFail'

--              24/01/2018 SK Entry added for FRS-833(VOTS) as per IFU5190
--------------------------------------------------------------------------------------------------------

DELETE FROM WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL ;

--PM 07/08/2017 Entries added as per FRS-868 Development
--Inbound Bapi adapter
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRB_RFC_10_BAPIIN','IN_SAP_BAPI_REQ','IN_SAP_BAPI_REQ',2);


--FRS-000128
--IFU4381:SK -Removing entries for SUBFLOW_NAME = 'SF_Logging1'
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CUSSV_CTUPSERREP_SIMP','SF_Logging','IN',3);
/*Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CUSSV_CTUPSERREP_SIMP','SF_Logging1','ROUTE_NOTFIRST',2);*/
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CUSSV_CTUPSERREP_SIMP','SF_Logging2','OUT_SAPCRM_A',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CUSSV_CTUPSERREP_SIMP','SF_ZJLR_INTLOG_RPC_BAPI_V2.SF_Logging','REQUEST_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CUSSV_CTUPSERREP_SIMP','SF_ZJLR_INTLOG_RPC_BAPI_V2.SF_Logging1','RESPONSE_SAPCRM',3);
                                                                                       
--FRS-000112 
--IFU4381:SK -Removing entries for SUBFLOW_NAME = 'SF_Logging1'                                                                           
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CUSSV_CRTUPDLEAD_SIMP','SF_Logging','IN',3);
/*Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CUSSV_CRTUPDLEAD_SIMP','SF_Logging1','ROUTE_NOTFIRST',2);*/
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CUSSV_CRTUPDLEAD_SIMP','SF_Logging2','OUT_SAPCRM_A',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CUSSV_CRTUPDLEAD_SIMP','SF_ZJLR_INTLOG_RPC_BAPI_V2.SF_Logging','REQUEST_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CUSSV_CRTUPDLEAD_SIMP','SF_ZJLR_INTLOG_RPC_BAPI_V2.SF_Logging1','RESPONSE_SAPCRM',3);
                                                                                       
--FRS-000117 
                                                                         
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CUSSV_CRTUPDFINCNTRPROP_SIMP','SF_Logging','IN',3);

--08/06/2017 SK INC000002275437:Added entries for SF_Logging1 for FRS-000117(SI_BS_CUSSV_CRTUPDFINCNTRPROP_SIMP)
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CUSSV_CRTUPDFINCNTRPROP_SIMP','SF_Logging1','ROUTE_NOTFIRST',3);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CUSSV_CRTUPDFINCNTRPROP_SIMP','SF_Logging2','OUT_SAPCRM_A',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CUSSV_CRTUPDFINCNTRPROP_SIMP','SF_ZJLR_INTLOG_RPC_BAPI_V2.SF_Logging','REQUEST_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CUSSV_CRTUPDFINCNTRPROP_SIMP','SF_ZJLR_INTLOG_RPC_BAPI_V2.SF_Logging1','RESPONSE_SAPCRM',3);

--FRS-000139
--FRS-000139 AB Added for SF_Logging3                                                                           
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CUSSV_REPVEHSALESTAT_SIMP','SF_Logging','IN',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CUSSV_REPVEHSALESTAT_SIMP','SF_Logging1','REQUEST_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CUSSV_REPVEHSALESTAT_SIMP','SF_Logging2','OUT_SAPCRM_A',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CUSSV_REPVEHSALESTAT_SIMP','SF_Logging3','RESPONSE_SAPCRM',3);
--Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CUSSV_REPVEHSALESTAT_SIMP','SF_ZJLR_INTLOG_RPC_BAPI.SF_Logging','REQUEST_SAPCRM',2);
--Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CUSSV_REPVEHSALESTAT_SIMP','SF_ZJLR_INTLOG_RPC_BAPI.SF_Logging1','RESPONSE_SAPCRM',2);
                                                                                       
--FRS-000118  
--IFU4381: SK -Removing entries for SUBFLOW_NAME  = 'SF_Logging1                                                                         
--INC000002275437: VVS -Added entries for SUBFLOW_NAME  = 'SF_Logging1  
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CUSSV_CRTUPDCPGNEVNTORRSPS_SIMP','SF_Logging','IN',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CUSSV_CRTUPDCPGNEVNTORRSPS_SIMP','SF_Logging1','ROUTE_NOTFIRST',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CUSSV_CRTUPDCPGNEVNTORRSPS_SIMP','SF_Logging2','OUT_SAPCRM_A',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CUSSV_CRTUPDCPGNEVNTORRSPS_SIMP','SF_ZJLR_INTLOG_RPC_BAPI_V2.SF_Logging','REQUEST_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CUSSV_CRTUPDCPGNEVNTORRSPS_SIMP','SF_ZJLR_INTLOG_RPC_BAPI_V2.SF_Logging1','RESPONSE_SAPCRM',3);

--SI_AD_SAP_SVCRM_ALE_MT_Outbound
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_SVCRM_ALE_OUTBOUND','SF_Logging','IN',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_SVCRM_ALE_OUTBOUND','SF_Logging1','RESPONSE',2);

--FRS-000148                                                                           
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVEHPLAN','SF_Logging','IN_PLO',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVEHPLAN','SF_Logging1','OUT_CANVEH_A',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVEHPLAN','SF_Logging2','IN_CANVEH_A',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVEHPLAN','SF_Logging3','REQUEST_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVEHPLAN','SF_Logging4','RESPONSE_SAPCRM',3);

--FRS-000147
--INC000001981360:Corrected SUBFLOW_DESC for SF_Logging.Changed from IN_PLO to IN_D42
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVEHSTATUS','SF_Logging','IN_D42',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVEHSTATUS','SF_Logging1','OUT_CANVEH_A',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVEHSTATUS','SF_Logging2','IN_CANVEH_A',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVEHSTATUS','SF_Logging3','REQUEST_SAPCRM',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVEHSTATUS','SF_Logging4','RESPONSE_SAPCRM',3);
--SM:IFU3990:Added logging level for SF_Logging5
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVEHSTATUS','SF_Logging5','ERR_OUT',2);

--FRS-000366
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_TRACKUPD','SF_Logging','IN',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_TRACKUPD','SF_Logging1','OUT_REPLY',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_TRACKUPD','SF_Logging2','REQUEST_D42',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_TRACKUPD','SF_Logging3','RESPONSE_D42',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_TRACKUPD','SF_Logging4','ERR_WCAR',2);
--LH Added entries as a part of IFU4327 FRS-366
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_TRACKUPD','SF_Logging5','MQ_REQUEST_D42',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_TRACKUPD','SF_Logging6','MQ_ERR_WCAR',2);



--                08/05/2015 VP Added entires for FRS-651 SAP to KN
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL(ID, BUSINESS_SERVICE_ID, 	SUBFLOW_NAME, 	SUBFLOW_DESC, 	LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_BS_SAP_TRBGB_HMRC_KN_INVOUTDECL', 	'SF_Logging_In', 	'IN_FROM_SAP_AD', 	2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL(ID, BUSINESS_SERVICE_ID, 	SUBFLOW_NAME, 	SUBFLOW_DESC, 	LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_BS_SAP_TRBGB_HMRC_KN_INVOUTDECL', 	'SF_Logging_Out', 	'OUT_TO_KN', 	2);



--FRS-000137


Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPVHCL_SIMP','SF_Logging','IN_FMS',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPVHCL_SIMP','SF_Logging1','OUT_CANVEH_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPVHCL_SIMP','SF_Logging2','IN_CANVEH_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPVHCL_SIMP','SF_Logging3','REQUEST_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPVHCL_SIMP','SF_Logging4','RESPONSE_SAPCRM',3);

--FRS-000670
-- 09/03/2017 AS Flow SI_BS_MFT_Invoice_Ack_To_SAP_TRBBR removed as part of IFU3563, this entry should have been commented out long back!
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MFT_INVOICE_SAP_TRBBR_INVOICEACK','SF_Logging','IN_MFT',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MFT_INVOICE_SAP_TRBBR_INVOICEACK','SF_Logging1','OUT_SAPTRB_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBBR_INVOICE_TITO_INVDETAILS','SF_Logging','IN_SAPTRB_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBBR_INVOICE_TITO_INVDETAILS','SF_Logging1','OUT_TITO',2);
--IFU3429
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBBR_INVOICE_TITO_PO','SF_Logging','IN_SAPTRB_AD',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBBR_INVOICE_TITO_PO','SF_Logging1','OUT_TITO',3);

--FRS-000669
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_TITO_HMRC_SAP_TRBBR_IMPORTDECL','SF_Logging','IN_MFT',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_TITO_HMRC_SAP_TRBBR_IMPORTDECL','SF_Logging1','OUT_SAPTRB_AD',2);


--FRS-000695
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_PRICING_TO_ALL_MSRPDATA','SF_Logging','IN_SAPTRB_AD',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_PRICING_TO_ALL_MSRPDATA','SF_Logging1','OUT_TARG_FLOW',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_PRICING_TO_VISTA_MSRPDATA','SF_Logging','IN_HEAD_FLOW',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_PRICING_TO_VISTA_MSRPDATA','SF_Logging1','OUT_VISTA_DB',3);

--Entry for new adapter flow as per FRS 695

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_ALEMT_IN_V2','SF_Logging','IN',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_ALEMT_IN_V2','SF_Logging1','OUT',2);


--FRS-000693
--LH changed logging level as part of IFU 3717
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WERS_VEHICLE_SAP_TRBGB_ENGCHANGE','SF_Logging','IN',3);

-- VV IFU 3681 Commented the following SQL Statements 
--Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WERS_VEHICLE_SAP_TRBGB_ENGCHANGE','SF_Logging1','MSGFORMAT_PARTSDATA',3);
--Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WERS_VEHICLE_SAP_TRBGB_ENGCHANGE','SF_Logging2','OUT',3);
--Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WERS_VEHICLE_SAP_TRBGB_ENGCHANGE','SF_Logging3','ERROR',3);

-- VV IFU 3681 Added the following SQL Statements
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WERS_VEHICLE_SAP_TRBGB_ENGCHANGE','SF_Logging1','OUT',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WERS_VEHICLE_SAP_TRBGB_ENGCHANGE','SF_Logging2','ERROR',3);

--FRS-000271
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WERS_VEH_ALL_ENGCHANGE','SF_Logging','IN',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WERS_VEH_ALL_ENGCHANGE','SF_Logging1','OUT',3);
--Keep WARNING_PARTSFILTEREDOUT log level as 3 to log warnings into database.
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WERS_VEH_ALL_ENGCHANGE','SF_Logging2','WARNING_PARTSFILTEREDOUT',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WERS_VEH_ALL_ENGCHANGE','SF_Logging_Err','ERROR',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_ENGGCHGSAP','SF_Logging','REQUEST',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_ENGGCHGSAP','SF_Logging1','RESPONSE',3);

--FRS-000015
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_GPIRS_PRODUCT_MULT_COMPVEHREQ','SF_Logging','IN_GPIRS',2);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_GPIRS_PRODUCT_MULT_COMPVEHREQ','SF_Logging1','OUT_ENOV',2);

--21/10/2015 AM Entry for BODS to be deleted for FRS000015 IFU3443
--Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_GPIRS_PRODUCT_MULT_COMPVEHREQ','SF_Logging2','OUT_BODS',2);

--FRS-000681
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WERS_VEHSERV_SAP_TRBGB_ENGBRAZIL','SF_Logging','IN',2);

-- 18/05/2015 RB Removed SF_Logging1 configuration
-- Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WERS_VEHSERV_SAP_TRBGB_ENGBRAZIL','SF_Logging1','MSGFORMAT_PARTSDATA',2);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WERS_VEHSERV_SAP_TRBGB_ENGBRAZIL','SF_Logging2','BAPI_REQUEST',2);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WERS_VEHSERV_SAP_TRBGB_ENGBRAZIL','SF_Logging3','BAPI_RESPONSE',2);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WERS_VEHSERV_SAP_TRBGB_ENGBRAZIL','SF_Logging4','ERROR',2);

--				: 21/04/2015 VP Added entries for FRS-000667
--				: 11/09/2015 HB updated logging level for 'SF_Logging1' to 3 --IFU3354
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,  'SI_BS_SAP_TRBGB_MISC_SPEDY_SUPDELINFO',  'SF_Logging',  'IN_SAPTRB_AD' , 2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values(SI_TRANS_LOG_LEV_SEQ.NEXTVAL,  'SI_BS_SAP_TRBGB_MISC_SPEDY_SUPDELINFO',  'SF_Logging1',  'OUT_SPEDY' , 3);

--:23/04/2015 AaP Entry for FRS-673
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_TD_VEH_CJLR_PROVASN','SF_Logging','IN_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_TD_VEH_CJLR_PROVASN','SF_Logging1','IN_CJLR',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_TD_VEH_CJLR_PROVASN','SF_Logging2','OUT_CJLR',2);


--Start: 29/04/2015 PM New Infrastructure Development: transaction logging level entries for ESB HTTP INBOUND V2, ESB HTTP REPLY V2 AND ESB HTTP OUTBOUND V2 adapters.
--------Inbound--------
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_V2_INBOUND','SF_Logging','IN',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_V2_INBOUND','SF_Logging1','OUT',2);

------- Reply ---------
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_V2_REPLY','SF_Logging','IN',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_V2_REPLY','SF_Logging1','OUT',2);

-------Outbound -------------
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_V2_OUTBOUND','SF_Logging','IN',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_V2_OUTBOUND','SF_Logging1','OUT',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_V2_OUTBOUND','SF_Logging2','ERROR_HTTP',2);
--End: 29/04/2015 PM New Infrastructure Development: transaction logging level entries for ESB HTTP INBOUND V2, ESB HTTP REPLY V2 AND ESB HTTP OUTBOUND V2 adapters.


--  01/05/2015 AC Added entries for FRS-000112 & it's dependent canonical adapters.
--  08/05/2015 AB Updated entries for DEF-4321
--  13/05/2015 IFU:3824 added entries for FRS-000112
--  27/06/2017 INC000002320935 Added entries for BSID 'SI_SV_CUSSV_CRTUPDLEAD_ACTV'and 'SI_SV_CUSSV_CRTUPDLEAD_ACCT' for subflow SF_Logging4
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDLEAD','SF_Logging','IN_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDLEAD','SF_Logging1','OUT_CANAD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDLEAD','SF_Logging2','IN_CANAD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDLEAD','SF_Logging3','OUT_TOLABEl',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDLEAD_ACCT','SF_Logging3','OUT_TOLABEl',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDLEAD_ACTV','SF_Logging3','OUT_TOLABEl',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDLEAD','SF_Logging4','OUT_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDLEAD_ACCT','SF_Logging4','OUT_SAPCRM',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDLEAD_ACTV','SF_Logging4','OUT_SAPCRM',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDLEAD','SF_Logging5','OUT_STOREQ',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDLEAD_ACCT','SF_AcctCrtUpd_SVCRM.SF_Logging','REQUEST_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDLEAD_ACCT','SF_AcctCrtUpd_SVCRM.SF_Logging1','RESPONSE_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDLEAD','SF_CrtUpdLeadPrspct_SVCRM.SF_Logging','REQUEST_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDLEAD','SF_CrtUpdLeadPrspct_SVCRM.SF_Logging1','RESPONSE_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDLEAD_ACTV','SF_CrtUpdActivity_SVCRM.SF_Logging','REQUEST_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDLEAD_ACTV','SF_CrtUpdActivity_SVCRM.SF_Logging1','RESPONSE_SAPCRM',3);

-- 16/08/2016 VB:MNT(FRS-112) - Replaced SF_SOAP_ErrorHandling with SF_SOAP_ErrorHandlingV2
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDLEAD','SF_SOAP_ErrorHandlingV2.SF_Logging','RESPONSE_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDLEAD_ACCT','SF_AcctCrtUpd_SVCRMV2.SF_Logging','REQ_SAPCRM',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDLEAD_ACCT','SF_AcctCrtUpd_SVCRMV2.SF_Logging1','RES_SAPCRM',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDLEAD','SF_CrtUpdLeadPrspct_SVCRMV2.SF_Logging','REQ_SAPCRM',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDLEAD','SF_CrtUpdLeadPrspct_SVCRMV2.SF_Logging1','RESP_SAPCRM',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDLEAD_ACTV','SF_CrtUpdActivity_SVCRMV2.SF_Logging','REQ_SAPCRM',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDLEAD_ACTV','SF_CrtUpdActivity_SVCRMV2.SF_Logging1','RESP_SAPCRM',2);


-- 18-04-2016 TK MNT: Updated logging level to 3 for QA testing for FRS 143
-- 18-04-2016 TK Reverted logging level as earlier for FRS 143
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_ACCOUNT','SF_Logging','CANACCTAD_IN',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_ACCOUNT','SF_Logging1','CANACCTAD_TRANSF',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_ACCOUNT','SF_Logging2','CANACCTAD_OUT',2);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_LEAD','SF_Logging','CANLEADAD_IN',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_LEAD','SF_Logging1','CANLEADAD_TRANSF',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_LEAD','SF_Logging2','CANLEADAD_OUT',2);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_ACTIVITY','SF_Logging','CANACTAD_IN',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_ACTIVITY','SF_Logging1','CANACTAD_TRANSF',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_ACTIVITY','SF_Logging2','CANACTAD_OUT',2);

--:04-May-2015 AaP Entry for FRS-705
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_SUPPLIER_SIM_SUPIMPMETR','SF_Logging','IN_SAPTRB_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_SUPPLIER_SIM_SUPIMPMETR','SF_Logging1','OUT_DATAMART',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_SUPPLIER_SIM_SUPIMPMETR','SF_Logging2','OUT_SIM',2);

-- 05/05/2015 YT Added entires for IA-000005
 Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_VISTA_VEHICLE_LNDAR_GOF','SF_Logging','IN_VISTA_AD','3');
 Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_VISTA_VEHICLE_LNDAR_GOF','SF_Logging1','OUT_LNDAR_AD','3'); 

 -- 11/05/2015 YR Added entires for FRS-680
 Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_QUALITY_SAP_TRBGB_NCRNOTIFY','SF_Logging','IN','2');
 Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_QUALITY_SAP_TRBGB_NCRNOTIFY','SF_Logging1','BAPI_REQUEST','2');
 Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_QUALITY_SAP_TRBGB_NCRNOTIFY','SF_Logging2','BAPI_RESPONSE','2');
 Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_QUALITY_SAP_TRBGB_NCRNOTIFY','SF_Logging3','ERROR','2');
 
 
  -- 13/05/2015 SB Added entires for FRS-000680(Quarantine Status To MES)
 Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_QUALITY_MES_PRTQRNTNSTUS','SF_Logging','IN','2');
 Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_QUALITY_MES_PRTQRNTNSTUS','SF_Logging1','MES_MESSAGE','2');
 Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_QUALITY_MES_PRTQRNTNSTUS','SF_Logging2','ERROR','2');
 Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_MQSERV_ALEINSTONE','SF_Logging','IN','2');
 
-- 20/05/2015 YR added entries for NCR Response( FRS - 000680)

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_QUALITY_MES_NCRRESPONSE','SF_Logging','IN','2');
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_QUALITY_MES_NCRRESPONSE','SF_Logging1','MES_MESSAGE','2');
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_QUALITY_MES_NCRRESPONSE','SF_Logging2','ERROR','2');

-- : 20/05/2015 VV Added for FRS-000716 (Measurement Doc from MES to SAP)
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_QUALITY_SAP_TRBGB_MEASUREDOC','SF_Logging','IN','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_QUALITY_SAP_TRBGB_MEASUREDOC','SF_Logging1','REQUEST_BAPI','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_QUALITY_SAP_TRBGB_MEASUREDOC','SF_Logging2','RESPONSE_BAPI','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_QUALITY_SAP_TRBGB_MEASUREDOC','SF_Logging3','ERROR','2');

-- 21/05/2015 RB Added entries for FRS-000690
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PLO_SUPPLIER_SAP_TRBGB_FORECAST','SF_Logging','IN',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PLO_SUPPLIER_SAP_TRBGB_FORECAST','SF_Logging1','OUT',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PLO_SUPPLIER_SAP_TRBGB_FORECAST','SF_Logging2','ERROR',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGBSTONE_ALEMT_OUT','SF_Logging','IN_REQUEST',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGBSTONE_ALEMT_OUT','SF_Logging1','RESPONSE',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGBSTONE_ALEMT_OUT','SF_Logging2','ERROR',2);

-- 21/05/2015 NM Added entries for FRS-000711
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_PLO_PABOORDREQ','SF_Logging','IN_SAPTRB_AD',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_PLO_PABOORDREQ','SF_Logging1','OUT_PLO_AD',3);

-- 25/05/2015 AaP Added entries for FRS-000711
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PLO_VEHICLE_SAP_TRBGB_PABOORDSTA','SF_Logging','IN_PLO_AD',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PLO_VEHICLE_SAP_TRBGB_PABOORDSTA','SF_Logging1','OUT_SAPTRB_AD',3);


--26/05/2015 PM  Entry for FRS-712
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL ( ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MATFL_VEHICLE_GXS_PARTREQ','SF_Logging',3,'IN');
													
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL ( ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MATFL_VEHICLE_GXS_PARTREQ','SF_Logging1',3,'OUT_HTTP_A');
													
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL ( ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_GXS_VEHICLE_MATFL_DELCONF','SF_Logging',3,'IN');

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL ( ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_GXS_VEHICLE_MATFL_DELCONF','SF_Logging1',3,'OUT_HTTPREP_A');

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL ( ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_GXS_VEHICLE_MATFL_DELCONF','SF_Logging2',3,'OUT');
-- 27/05/2015:SM:Added entries for FRS110:DEF4621(Performance issue)
-- 29/06/2015 : VB : Changed column and value sequence
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL ( ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SEARCHACCT','SF_Logging','IN',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL ( ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SEARCHACCT','SF_Logging1','IN_CANACT_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL ( ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SEARCHACCT','SF_Logging2','OUT_CANACT_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL ( ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SEARCHACCT','SF_Logging3','OUT',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL ( ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SEARCHACCT','SF_GetSearchResultsFromSVCRM.SF_Logging','REQ_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL ( ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SEARCHACCT','SF_GetSearchResultsFromSVCRM.SF_Logging1','RES_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL ( ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SEARCHACCT','SF_SOAP_ErrorHandlingV2.SF_Logging','SOAP_ERR_RES',2);

--27/05/2015:VB:Added entries for FRS111:IFU3019
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_AFRL_CUSSV_SVCRM_GETACCTDTLS','SF_Logging','IN_AFRL',3);

Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_AFRL_CUSSV_SVCRM_GETACCTDTLS','SF_Logging1','OUT_CANACCT_A',2);

Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_AFRL_CUSSV_SVCRM_GETACCTDTLS','SF_Logging2','IN_CANACCT_A',2);

Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_AFRL_CUSSV_SVCRM_GETACCTDTLS','SF_GetAcctDetailsFromSVCRMV2.SF_Logging','REQUEST_SAPCRM',3);

Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_AFRL_CUSSV_SVCRM_GETACCTDTLS','SF_GetAcctDetailsFromSVCRMV2.SF_Logging1','RESPONSE_SAPCRM',3);

Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_AFRL_CUSSV_SVCRM_GETACCTDTLS','SF_Logging3','OUT_CANACCT_A',2);

Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_AFRL_CUSSV_SVCRM_GETACCTDTLS','SF_Logging4','OUT_AFRLJAG',3);

Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_AFRL_CUSSV_SVCRM_GETACCTDTLS','SF_Logging5','OUT_AFRLLR',3);

Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_AFRL_CUSSV_SVCRM_GETACCTDTLS','SF_Logging6','OUT_ERRAFRLJAG',2);

Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_AFRL_CUSSV_SVCRM_GETACCTDTLS','SF_Logging7','OUT_ERRAFRLLR',2);



--28/05/2015:AB: Added entries for FRS-000108
--SM:IFU3800(FRS-000108):Updated subflow name to V2 after error handling changes
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_ACCTCRTUPD','SF_Logging','IN',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_ACCTCRTUPD','SF_Logging1','IN_CANACT_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_ACCTCRTUPD','SF_Logging2','OUT_CANACT_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_ACCTCRTUPD','SF_Logging3','OUT',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_ACCTCRTUPD','SF_AcctCrtUpd_SVCRMV2.SF_Logging','REQ_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_ACCTCRTUPD','SF_AcctCrtUpd_SVCRMV2.SF_Logging1','RES_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_ACCTCRTUPD','SF_SOAP_ErrorHandlingV2.SF_Logging','ERR_RES',2);
--02/06/2016 VB:DEF8114 - Added entry for 'SF_AcctCrtUpd_SVCRMV'. These entries need to be deleted after implementation of error handling changes in R2.1 also 
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_ACCTCRTUPD','SF_AcctCrtUpd_SVCRM.SF_Logging','REQ_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_ACCTCRTUPD','SF_AcctCrtUpd_SVCRM.SF_Logging1','RES_SAPCRM',3);



--28/05/2015:AB: Added entries for FRS-000111
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_GETACCTDTLS','SF_Logging','IN',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_GETACCTDTLS','SF_Logging1','IN_CANACT_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_GETACCTDTLS','SF_Logging2','OUT_CANACT_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_GETACCTDTLS','SF_Logging3','OUT',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_GETACCTDTLS','SF_GetAcctDetailsFromSVCRM.SF_Logging','REQ_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_GETACCTDTLS','SF_GetAcctDetailsFromSVCRM.SF_Logging1','RES_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_GETACCTDTLS','SF_SOAP_ErrorHandlingV2.SF_Logging','SOAP_ERR_RES',2);


-- : 02/06/2015 NT Added for FRS-000716 (Fault Alarm Notification from MES to SAP)
insert into SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, LOGGING_LEVEL, SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_BS_MES_QUALITY_SAP_TRBGB_FAULTALARM', 'SF_Logging', 2, 'IN');
insert into SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, LOGGING_LEVEL, SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_BS_MES_QUALITY_SAP_TRBGB_FAULTALARM', 'SF_Logging1', 2, 'REQUEST_BAPI');
insert into SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, LOGGING_LEVEL, SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_BS_MES_QUALITY_SAP_TRBGB_FAULTALARM', 'SF_Logging2', 2, 'RESPONSE_BAPI');
insert into SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, LOGGING_LEVEL, SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_BS_MES_QUALITY_SAP_TRBGB_FAULTALARM', 'SF_Logging3', 2, 'OUT');
insert into SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, LOGGING_LEVEL, SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_BS_MES_QUALITY_SAP_TRBGB_FAULTALARM', 'SF_Logging4', 2, 'ERROR');

-- : 29/05/2015 VV Added for FRS-000716 (Update Status Notification from MES to SAP)

INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_QUALITY_SAP_TRBGB_UPDSTATUS','SF_Logging','IN','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_QUALITY_SAP_TRBGB_UPDSTATUS','SF_Logging1','REQUEST_BAPI','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_QUALITY_SAP_TRBGB_UPDSTATUS','SF_Logging2','RESPONSE_BAPI','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_QUALITY_SAP_TRBGB_UPDSTATUS','SF_Logging3','OUT','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_QUALITY_SAP_TRBGB_UPDSTATUS','SF_Logging4','ERROR','2');

-- 01/06/2015 RB Added entries for FRS-000715
-- TLS Broadcast
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_VEHICLE_SAP_TRBBR_TLSBROADCT','SF_Logging','IN_MES',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_VEHICLE_SAP_TRBBR_TLSBROADCT','SF_Logging1','OUT_SAPTRBBR_EWM',2);
-- Vehicle Movement Info
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_VEHICLE_SAP_TRBBR_VEHMOVEINF','SF_Logging','IN_MES',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_VEHICLE_SAP_TRBBR_VEHMOVEINF','SF_Logging1','OUT_SAPTRBBR_EWM',2);
-- SAP Turbo EWM Outbound IDoc Adapter
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBBREWM_ALEMT_OUT','SF_Logging','IN_REQUEST',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBBREWM_ALEMT_OUT','SF_Logging1','RESPONSE',2);

-- : 31/07/2015 VV Added for IFU 3190 (FRS-000718 Planned Order Confirmation from MES to D42/SAP)
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_VEHICLE_SAP_TRBBR_PLNORDCONF','SF_Logging','MES_REQ_IN','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_VEHICLE_SAP_TRBBR_PLNORDCONF','SF_Logging1','SAP_REQ','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_VEHICLE_SAP_TRBBR_PLNORDCONF','SF_Logging2','SAP_REQ_OUT','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_VEHICLE_SAP_TRBBR_PLNORDCONF','SF_Logging_Error','EXCEPTION','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_VEHICLE_SAP_TRBBR_PLNORDCONF','SF_Logging3','SAP_RESP_IN','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_VEHICLE_SAP_TRBBR_PLNORDCONF','SF_Logging4','D42_REQ','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_VEHICLE_SAP_TRBBR_PLNORDCONF','SF_Logging5','D42_REQ_OUT','2');

-- : 10/06/2015 HB Added entries for IFU3024 
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_D42_HMRC_RIC_EXPDECL','LogMesageReciept','IN','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_D42_HMRC_RIC_EXPDECL','LogFTPOutput','FTP_OUT','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_D42_HMRC_RIC_EXPDECL','LogHTTPResponses','MQ_OUT','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_D42_HMRC_RIC_EXPDECL','SF_GetSAPVehicleValues.LogBAPICall','BAPI_CALL','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_D42_HMRC_RIC_EXPDECL','SF_GetSAPVehicleValues.LogBAPIResponse','BAPI_RESP','2');

-- 18/06/2015 KT Added entries for FRS-000679
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBBR_VEHICLE_MES_TRNMASDATA','SF_Logging','IN_SAPPI','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBBR_VEHICLE_MES_TRNMASDATA','SF_Logging3','OUT_MES','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBBR_VEHICLE_MES_TRNMASDATA','SF_Logging1','OUT_SAPAPO','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBBR_VEHICLE_MES_TRNMASDATA','SF_Logging4','IN_ERROR','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_VEHICLE_SAP_TRBBR_MASTDATACK','SF_Logging2','IN_ESB','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_VEHICLE_SAP_TRBBR_MASTDATACK','SF_Logging1','OUT_SAPAPO','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_VEHICLE_SAP_TRBBR_MASTDATACK','SF_Logging5','IN_ESB_ERROR','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_VEHICLE_ESB_MASTDATACK','SF_Logging','IN_MES','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_VEHICLE_ESB_MASTDATACK','SF_Logging1','OUT_ESB','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_VEHICLE_ESB_MASTDATACK','SF_Logging2','IN_MES_ERROR','2');

-- 18/06/2015 AS Added entry for FRS-000707
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBBR_VEHICLE_MES_ORDERBOM','SF_Logging','IN_SAPPI',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBBR_VEHICLE_MES_ORDERBOM','SF_Logging1','OUT_SAPAPO_ACK',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBBR_VEHICLE_MES_ORDERBOM','SF_Logging3','OUT_MES',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBBR_VEHICLE_MES_ORDERBOM','SF_Logging4','IN_ERROR',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_VEHICLE_SAP_TRBBR_ORDERBOM','SF_Logging1','OUT_SAPAPO_ACK',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_VEHICLE_SAP_TRBBR_ORDERBOM','SF_Logging2','IN_ESB',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_VEHICLE_SAP_TRBBR_ORDERBOM','SF_Logging5','IN_ERROR',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_VEHICLE_ESB_ORDERBOMACK','SF_Logging','IN_MES',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_VEHICLE_ESB_ORDERBOMACK','SF_Logging1','OUT_ESB',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_VEHICLE_ESB_ORDERBOMACK','SF_Logging2','IN_ERROR',2);


--              08-07/2015 VP FRS674 initial entry
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	SUBFLOW_DESC,	LOGGING_LEVEL,	INSERT_TIMESTAMP,	UPDATE_TIMESTAMP) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_BS_SAP_TRBGB_CUSTOMER_CJLR_CUSTINVOIC',	'SF_Logging',	'IN_SAPTRB_AD',	'2',	null,	null);
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	SUBFLOW_DESC,	LOGGING_LEVEL,	INSERT_TIMESTAMP,	UPDATE_TIMESTAMP) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_BS_SAP_TRBGB_CUSTOMER_CJLR_CUSTINVOIC',	'SF_Logging1',	'IN_CJLR',	'2',	null,	null);
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	SUBFLOW_DESC,	LOGGING_LEVEL,	INSERT_TIMESTAMP,	UPDATE_TIMESTAMP) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_BS_SAP_TRBGB_CUSTOMER_CJLR_CUSTINVOIC',	'SF_Logging2',	'OUT_CJLR',	'2',	null,	null);

-- 08-07/2015 SM FRS136 initial entry
-- 18-04-2016 TK MNT: Updated logging level to 3 for QA testing for FRS 143
-- 18-04-2016 TK Reverted logging level as earlier for FRS 143
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	SUBFLOW_DESC,	LOGGING_LEVEL,	INSERT_TIMESTAMP,	UPDATE_TIMESTAMP) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_AD_CANON_VEHICLE',	'SF_Logging',	'CANVEHAD_IN',	'2',	null,	null);
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	SUBFLOW_DESC,	LOGGING_LEVEL,	INSERT_TIMESTAMP,	UPDATE_TIMESTAMP) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_AD_CANON_VEHICLE',	'SF_Logging1',	'CANVEHAD_TRANSF',	'2',	null,	null);
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	SUBFLOW_DESC,	LOGGING_LEVEL,	INSERT_TIMESTAMP,	UPDATE_TIMESTAMP) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_AD_CANON_VEHICLE',	'SF_Logging2',	'CANVEHAD_OUT',	'2',	null,	null);

-- 13/07/2015 YR Added entries for FRS261(changes for Stone)
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBBR_ALEAPOMT_IN_V2','SF_Logging','IN','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBBR_ALEAPOMT_IN_V2','SF_Logging1','OUT','2');

-- 21/07/2015 HB Added New entries for FRS731
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	SUBFLOW_DESC,	LOGGING_LEVEL,	INSERT_TIMESTAMP,	UPDATE_TIMESTAMP) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_BS_VISTA_DEALER_PLO_OPENORDER',	'SF_Logging',	'IN',	'2',	null,	null);
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	SUBFLOW_DESC,	LOGGING_LEVEL,	INSERT_TIMESTAMP,	UPDATE_TIMESTAMP) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_BS_VISTA_DEALER_PLO_OPENORDER',	'SF_Logging1',	'OUT',	'2',	null,	null);
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	SUBFLOW_DESC,	LOGGING_LEVEL,	INSERT_TIMESTAMP,	UPDATE_TIMESTAMP) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_BS_VISTA_DEALER_PLO_OPENORDER',	'SF_Logging2',	'ERROR',	'2',	null,	null);

-- 21/07/2015 NM Added New entries for FRS668
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_LSTOR_VEHICLE_ALL_SBOM','SF_Logging', 'IN',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_LSTOR_VEHICLE_ALL_SBOM','SF_Logging1','STORE_OUT',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_LSTOR_VEHICLE_ALL_SBOM','SF_Logging2','PLO_OUT',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_LSTOR_VEHICLE_ALL_SBOM','SF_Logging3','PLO_IN',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_LSTOR_VEHICLE_ALL_SBOM','SF_Logging4','FILTER_IN',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_LSTOR_VEHICLE_ALL_SBOM','SF_Logging5','FILTER_OUT',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_LSTOR_VEHICLE_ALL_SBOM','SF_Logging6','BWOOD_OUT',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_LSTOR_VEHICLE_ALL_SBOM','SF_Logging7','CJLR_OUT',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_LSTOR_VEHICLE_ALL_SBOM','SF_Logging9','WARNING_PARTSFILTEREDOUT',2);


--22/07/2015:AB: Added entries for FRS-000115
--13/10/2016:SS: Added entries for SF_Logging8 and SF_Logging9 FRS-000115 for IFU4177
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLEADPSP','SF_Logging','IN',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLEADPSP','SF_Logging1','BEFORE_CAN_TRANS',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLEADPSP','SF_Logging2','OUT_CANLEAD_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLEADPSP','SF_Logging3','RES_WS',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLEADPSP','SF_Logging4','REQ_ADF_HTTP',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLEADPSP','SF_Logging5','REQ_STD_SOAP',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLEADPSP','SF_Logging6','OUT_SOAP_REPLY',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLEADPSP','SF_Logging7','OUT_SOAP_FAULT',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLEADPSP','SF_SOAP_ErrorHandlingV2.SF_Logging','ERR_RES',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLEADPSP','SF_Logging8','AFTER_CAN_TRANS',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLEADPSP','SF_Logging9','TRANS_RESP_TO_CANON',2);

--23/07/2015:VB: Added entries for FRS-000107
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_ORDERREPLICATE','SF_Logging','ESB_IN',3);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_ORDERREPLICATE','SF_Logging1','IN_AD',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_ORDERREPLICATE','SF_Logging2','OUT_AD',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_ORDERREPLICATE','SF_Logging3','REQ_SAPCRM',3);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_ORDERREPLICATE','SF_Logging4','RES_SAPCRM',3);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_ORDERREPLICATE','SF_Logging5','ERR_OUT',3);

--23/07/2015:SA: Added entries for FRS-000109
--SM:IFU3822(FRS-000109):Updated subflow name to V2 after error handling changes
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CONTRACTREPLICATE','SF_Logging','IN',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CONTRACTREPLICATE','SF_Logging1','IN_CANCNTRCT_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CONTRACTREPLICATE','SF_Logging2','OUT_CANCNTRCT_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CONTRACTREPLICATE','SF_Logging3','TO_VEHREL_CRTUPD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CONTRACTREPLICATE','SF_Logging4','OUT',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CONTRACTREPLICATE','SF_Logging5','ERR_OUT',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CONTRACTREPLICATE','SF_Contract_CreateUpdateV2.SF_Logging','REQ_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CONTRACTREPLICATE','SF_Contract_CreateUpdateV2.SF_Logging1','RES_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CONTRACTREPLICATE','SF_VehicleAccountRelationship_CreateUpdateV2.SF_Logging','REQ_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CONTRACTREPLICATE','SF_VehicleAccountRelationship_CreateUpdateV2.SF_Logging1','RES_SAPCRM',3);

--VB:DEF8161/DEF8169 - Added entries for 'SF_Contract_CreateUpdate' and 'SF_VehicleAccountRelationship_CreateUpdate'
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CONTRACTREPLICATE','SF_Contract_CreateUpdate.SF_Logging','REQ_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CONTRACTREPLICATE','SF_Contract_CreateUpdate.SF_Logging1','RES_SAPCRM',3);

--21/12/2016:SK:IFU4329(MNT)-Updated BUSINESS_SERVICE_ID for 'SF_VehicleAccountRelationship_CreateUpdateV2' as per code.
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CONTRACTREPLICATE_SF_VEHACC','SF_VehicleAccountRelationship_CreateUpdateV2.SF_Logging','REQ_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CONTRACTREPLICATE_SF_VEHACC','SF_VehicleAccountRelationship_CreateUpdateV2.SF_Logging1','RES_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CONTRACTREPLICATE_SF_VEHACC','SF_Logging4','OUT',3);

-- 21/04/2017:AT removed entries as part of IFU4590
--23/07/2015:SM: Added entries for FRS-000116
--Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_VEHREFDATAREPLICATE','SF_Logging','IN',3);
--Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_VEHREFDATAREPLICATE','SF_Logging1','IN_CANVEH_AD',2);
--Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_VEHREFDATAREPLICATE','SF_Logging2','OUT_CANVEH_AD',2);
--Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_VEHREFDATAREPLICATE','SF_Logging3','OUT',2);
--Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_VEHREFDATAREPLICATE','SF_VehicleRefDataTypes_CreateUpdate.SF_Logging','REQ_SAPCRM',3);
--Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_VEHREFDATAREPLICATE','SF_VehicleRefDataTypes_CreateUpdate.SF_Logging1','RES_SAPCRM',3);
--Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_VEHREFDATAREPLICATE','SF_VehicleRefDataCodes_CreateUpdate.SF_Logging','REQ_SAPCRM',3);
--Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_VEHREFDATAREPLICATE','SF_VehicleRefDataCodes_CreateUpdate.SF_Logging1','RES_SAPCRM',3);

-- 28/07/2015, AS, Added missing entry for FRS-000382
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_CJLR_WTYCLAIM','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_CJLR_WTYCLAIM','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_CJLR_WTYCLAIM','SF_Logging','CJLR_SOAP_RESPONSE',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_CJLR_WTYCLAIM','SF_Logging1','CJLR_SOAP_REQUEST',2);

-- 28/07/2015 VB: Added entry for FRS-000127
-- 28/06/2016 AB: Added entry for FRS-000127 for DEF8397
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRUPPTCHFS','SF_Logging','IN',3);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRUPPTCHFS','SF_Logging1','OUT_CANACT_AD',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRUPPTCHFS','SF_Logging2','OUT_CANACT_AD_SVCRM',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRUPPTCHFS','SF_Logging3','SOAP_REPLY',3);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRUPPTCHFS','SF_CrtUpdPartTechFSEIssue_SVCRM.SF_Logging','REQ_SAPCRM',3);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRUPPTCHFS','SF_CrtUpdPartTechFSEIssue_SVCRM.SF_Logging1','RES_SAPCRM',3);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRUPPTCHFS','SF_CrtUpdPartTechFSEIssue_SVCRMV2.SF_Logging','REQ_SAPCRM',3);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRUPPTCHFS','SF_CrtUpdPartTechFSEIssue_SVCRMV2.SF_Logging1','RES_SAPCRM',3);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRUPPTCHFS','SF_SOAP_ErrorHandlingV2.SF_Logging','ERR_RES',2);

-- 29/07/2015 SA: Added entry for FRS-000123
-- 19/02/2016 TK: INC000001211696: Updated entry for FRS-000123 related to SF_SOAP_ErrorHandlingV2
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_BRKDWNEVNT','SF_Logging','SOAP_IN',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_BRKDWNEVNT','SF_Logging1','OUT_CANBRKDWNEV_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_BRKDWNEVNT','SF_Logging2','OUT_SVCRM',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_BRKDWNEVNT','SF_Logging3','SOAP_REPLY',3);

Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_BRKDWNEVNT','SF_SOAP_ErrorHandlingV2.SF_Logging','ERR_RES',2);


Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SVCRM_BRKDWNEVNT','SF_Logging','IN_SVCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SVCRM_BRKDWNEVNT','SF_Logging1','OUT_SVCRM',3);
--SM:DEF5828 : Corrected scripts for SF_CrtBreakdownEventForVehicle_SVCRM
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SVCRM_BRKDWNEVNT','SF_CrtBreakdownEventForVehicle_SVCRM.SF_Logging','REQ_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SVCRM_BRKDWNEVNT','SF_CrtBreakdownEventForVehicle_SVCRM.SF_Logging1','RES_SAPCRM',3);

-- 30/07/2015 VB: Added entry for FRS-000141
-- 07/03/2016 TK MNT: Updated entry for SF_Logging2
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPVEHOWN','SF_Logging','IN',3);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPVEHOWN','SF_Logging1','IN_CANVEH_AD',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPVEHOWN','SF_Logging2','OUT_CANVEH_AD',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPVEHOWN','SF_Logging3','OUT_CANVEH_AD_SVCRM',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPVEHOWN','SF_Logging4','SOAP_REPLY',3);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPVEHOWN','SF_VehicleAccountRelationship_CreateUpdate.SF_Logging','REQ_SAPCRM',3);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPVEHOWN','SF_VehicleAccountRelationship_CreateUpdate.SF_Logging1','RES_SAPCRM',3);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPVEHOWN','SF_SOAP_ErrorHandlingV2.SF_Logging','ERR_RES',2);

-- 31/07/2015 SA: Added entry for FRS-000128
-- 15/02/2016 AB: Updated entry for FRS-000128 for INC000001198511
-- 22/02/2016 TK: Updated entry for FRS-000128 for MNT
-- 22/04/2016 AB: Updated entry for FRS-000128 for IFU3828 New exception handler changes
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPSERREP','SF_Logging','IN_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPSERREP','SF_Logging1','OUT_CANAD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPSERREP','SF_Logging2','IN_CANAD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPSERREP','SF_Logging3','OUT_TOLABEL',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPSERREP','SF_Logging4','OUT_TOSTOREQ',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPSERREP','SF_Logging5','OUT_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPSERREP_ACCT','SF_AcctCrtUpd_SVCRMV2.SF_Logging','REQ_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPSERREP_ACCT','SF_AcctCrtUpd_SVCRMV2.SF_Logging1','RES_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPSERREP','SF_VehicleAccountRelationship_CreateUpdateV2.SF_Logging','REQ_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPSERREP','SF_VehicleAccountRelationship_CreateUpdateV2.SF_Logging1','RES_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPSERREP','SF_CrtUpdSerOrRepEvnt_SVCRMV2.SF_Logging','REQ_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPSERREP','SF_CrtUpdSerOrRepEvnt_SVCRMV2.SF_Logging1','RES_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPSERREP_ACCT','SF_Logging3','OUT_TOLABEL',2);

--VB:IFU3983 - Added missing entries for FRS-000128 
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPSERREP','SF_Logging6','OUT_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPSERREP_ACCT','SF_AcctCrtUpd_SVCRM.SF_Logging','REQ_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPSERREP_ACCT','SF_AcctCrtUpd_SVCRM.SF_Logging1','RES_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPSERREP','SF_VehicleAccountRelationship_CreateUpdate.SF_Logging','REQ_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPSERREP','SF_VehicleAccountRelationship_CreateUpdate.SF_Logging1','RES_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPSERREP','SF_CrtUpdSerOrRepEvnt_SVCRM.SF_Logging','REQ_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPSERREP','SF_CrtUpdSerOrRepEvnt_SVCRM.SF_Logging1','RES_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPSERREP','SF_SOAP_ErrorHandlingV2.SF_Logging','ERROR_SOAP',3);

-- 04/08/2015 SA: Added entry for FRS-000143
-- 07/09/2015 AB: Updated entry for FRS-000143(DEF6107)
-- 21/03/2015 AB: Updated entry for FRS-000143(IFU3767)
-- 18-04-2016 TK MNT: Updated logging level to 3 for QA testing for FRS 143
-- 18-04-2016 TK Reverted logging level as earlier for FRS 143
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SENDWRTCON','SF_Logging','IN',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SENDWRTCON','SF_Logging1','IN_CANWRNTYCNTRCT_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SENDWRTCON','SF_Logging2','OUT_CANWRNTYCNTRCT_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SENDWRTCON','SF_Logging3','TO_LABEL',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SENDWRTCON','SF_Logging4','TO_WRNTYRESPQ',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SENDWRTCON','SF_Logging5','TO_STOREQ',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SENDWRTCON_ACCT','SF_AcctCrtUpd_SVCRMV2.SF_Logging','REQ_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SENDWRTCON_ACCT','SF_AcctCrtUpd_SVCRMV2.SF_Logging1','RES_SAPCRM',3);
--09/01/2017:DEF10616 SK Updated BSID for SF_VehicleAccountRelationship_CreateUpdateV2
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SENDWRTCON_SF_VEHACC','SF_VehicleAccountRelationship_CreateUpdateV2.SF_Logging','REQ_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SENDWRTCON_SF_VEHACC','SF_VehicleAccountRelationship_CreateUpdateV2.SF_Logging1','RES_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SENDWRTCON','SF_CrtUpdAncilProdOrCntrct_SVCRMV2.SF_Logging','REQ_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SENDWRTCON','SF_CrtUpdAncilProdOrCntrct_SVCRMV2.SF_Logging1','RES_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SENDWRTCON_ACCT','SF_CrtUpdAncilProdOrCntrct_SVCRMV2.SF_Logging','REQ_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SENDWRTCON_VREL','SF_CrtUpdAncilProdOrCntrct_SVCRMV2.SF_Logging1','RES_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SENDWRTCON_ACCT','SF_Logging2','OUT_CANWRNTYCNTRCT_AD',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SENDWRTCON_VREL','SF_Logging2','OUT_CANWRNTYCNTRCT_AD',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SENDWRTCON_ACCT','SF_Logging3','TO_LABEL',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SENDWRTCON_VREL','SF_Logging3','TO_LABEL',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SENDWRTCON_ACCT','SF_Logging4','TO_WRNTYRESPQ',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SENDWRTCON_VREL','SF_Logging4','TO_WRNTYRESPQ',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SENDWRTCON_ACCT','SF_Logging5','TO_STOREQ',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SENDWRTCON_VREL','SF_Logging5','TO_STOREQ',3);


--05/08/2015 NC Added New entry for FRS719                                                                           
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_D42_VEHICLE_MES_VEHSTATUSUPD','SF_Logging','IN',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_D42_VEHICLE_MES_VEHSTATUSUPD','SF_Logging1','MES_MESSAGE',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_D42_VEHICLE_MES_VEHSTATUSUPD','SF_Logging2','DISCARDED',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_D42_VEHICLE_MES_VEHSTATUSUPD','SF_Logging3','ERROR',2);

--21/04/2017 AT Removed entries As part of IFU4591
--06/08/2015 SA Added New entries for FRS129
--Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDCASE','SF_Logging','IN',3);
--Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDCASE','SF_Logging1','OUT_AD',2);
--Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDCASE','SF_Logging2','IN_ESB',2);
--Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDCASE','SF_Logging3','OUT_SVCRM_AD',2);
--Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDCASE','SF_Logging4','OUT_ERR',2);
--Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDCASE','SF_CreateUpdateCaseFrom_SVCRM.SF_Logging','REQ_SAPCRM',3);
--Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDCASE','SF_CreateUpdateCaseFrom_SVCRM.SF_Logging1','RES_SAPCRM',3);

--07/08/2015 SM Added New entries for FRS130
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLICTEDR','SF_Logging','IN',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLICTEDR','SF_Logging1','IN_CANTRDPART_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLICTEDR','SF_Logging2','OUT_CANTRDPART_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLICTEDR','SF_Logging3','OUT_FL_SVCRM',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLICTEDR','SF_Logging4','SOAP_REPLY',3);

--AB Updated entries for FRS130 with SI_SV_CUSSV_REPLICTEDR_SVCRM_CRTUPDDLR and SI_SV_CUSSV_REPLICTEDR_SVCRM_CRTUPDTER
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_SVCRM_REPLICTEDR','SF_Logging','IN',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLICTEDR_SVCRM_CRTUPDDLR','SF_Logging1','OUT',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLICTEDR_SVCRM_CRTUPDDLR','SF_Logging2','ERR_OUT',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLICTEDR_SVCRM_CRTUPDTER','SF_Logging1','OUT',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLICTEDR_SVCRM_CRTUPDTER','SF_Logging2','ERR_OUT',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLICTEDR_SVCRM_CRTUPDDLR','SF_CrtUpdDealer_SVCRM.SF_Logging','REQ_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLICTEDR_SVCRM_CRTUPDDLR','SF_CrtUpdDealer_SVCRM.SF_Logging1','RES_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLICTEDR_SVCRM_CRTUPDTER','SF_CrtUpdTerritory_SVCRM.SF_Logging','REQ_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLICTEDR_SVCRM_CRTUPDTER','SF_CrtUpdTerritory_SVCRM.SF_Logging1','RES_SAPCRM',3);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLICTEDR_TACT','SF_Logging','IN',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLICTEDR_TACT','SF_Logging1','IN_CANTDPART_TACT_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLICTEDR_TACT','SF_Logging2','OUT_CANTDPART_TACT_AD',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLICTEDR_TACT','SF_Logging3','OUT',3);

--KV Added Entries for FRS 000130/IFU 3888(OCRM)
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_DEALER_OCRM_REPLICTEDR','SF_Logging','CAN_IN',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_DEALER_OCRM_REPLICTEDR','SF_Logging1','OCRM_REQ',2);
--NB 24/08/2016 IFU4048 FRS-130/IFU4048(OCRM)
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_DEALER_OCRM_REPLICTEDR','SF_SendRequestTo_DBDEALER_OCRM.SF_Logging','REQ_DBDEALER',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_DEALER_OCRM_REPLICTEDR','SF_SendRequestTo_DBDEALER_OCRM.SF_Logging2','RESFAIL_DBDEALER',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_DEALER_OCRM_REPLICTEDR','SF_SendRequestTo_DBDEALER_OCRM.SF_Logging3','RES_DBDELAER',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_DEALER_OCRM_REPLICTEDR','SF_SendRequestTo_DBDEALER_OCRM.SF_SV_GetSession_from_OCRM.SF_Logging1','REQ_LOGININ2',2);


--07/08/2015 VB Added New entries for FRS136 AVO
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPACVHOWN','SF_SOAP_ErrorHandlingV2.SF_Logging','ERR_RES',3);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPACVHOWN','SF_Logging','IN_SAPCRM',3);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPACVHOWN','SF_Logging1','IN_CANACCT_AD',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPACVHOWN','SF_Logging2','OUT_CANACCT _AD',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPACVHOWN','SF_Logging3','REPLY_SAPCRM',3);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPACVHOWN','SF_Logging4','ERR_OUT',3);

Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPAVO','SF_Logging5','TO_REPAVO',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPAVO','SF_Logging6','OUT_LABEL',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPAVO','SF_Logging7','OUT_BATCH',3);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPAVO','SF_Logging8','OUT_WS_ADAP',3);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPAVO','SF_Logging9','OUT_CAN_DISCARD',2);
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPAVO','SF_Logging-Discarded','OUT_BATCH_WS_DATA_DISCARDED',2);

--10/08/2015 VB Added New entries for FRS136 VVO and Batch Flow
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVHVHOWN','SF_SOAP_ErrorHandlingV2.SF_Logging','ERR_RES',3);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVHVHOWN','SF_Logging','IN_SAPCRM',3);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVHVHOWN','SF_Logging1','IN_CANVHCL_AD',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVHVHOWN','SF_Logging2','OUT_CANVHCL_AD',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVHVHOWN','SF_Logging3','REPLY_SAPCRM',3);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVHVHOWN','SF_Logging4','ERR_OUT',3);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVVO','SF_Logging5','TO_REPVVO',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVVO','SF_Logging6','OUT_LABEL',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVVO','SF_Logging7','OUT_BATCH',3);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVVO','SF_Logging8','OUT_WS_ADAP',3);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVVO','SF_Logging9','OUT_CAN_DISCARD',2);
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVVO','SF_Logging-Discarded','OUT_BATCH_WS_DATA_DISCARDED',2);


-- Batch Flow
--21/08/2015 TK DEF6318 Updated BSID for Batch Flow to SI_SV_CUSSV_REPACVHSTD for SF_Logging4 & SF_Logging5
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPACVHBAT','SF_Logging3','OUT_AA',2);
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPACVHBAT','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',2);
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPACVHBAT','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',2);
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPACVHBAT','SF_Logging-Discarded','DUPLICATE_DATA_DISCARDED',2);

INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPACVHSTD','SF_Logging5','OUT_ROI',2);
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPACVHSTD','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',2);
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPACVHSTD','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',2);
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPACVHSTD','SF_Logging-Discarded','DUPLICATE_DATA_DISCARDED',2);


--10/08/2015 SM Added New entries for FRS130(Canonical Flow)
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_TRDEPARTNR','SF_Logging','CANACCTAD_IN',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_TRDEPARTNR','SF_Logging1','CANACCTAD_TRANSF',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_TRDEPARTNR','SF_Logging2','CANACCTAD_OUT',2);

--21/04/2017 AT Removed entries As part of OFU4590
--10/08/2015 SM Added New entries for FRS138
--Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVEHDERV','SF_Logging','IN',3);
--Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVEHDERV','SF_Logging1','IN_CANVEH_AD',2);
--Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVEHDERV','SF_Logging2','OUT_CANVEH_AD',2);
--Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVEHDERV','SF_Logging3','OUT',2);
--Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVEHDERV','SF_CrtUpdVehDeriv_SVCRM.SF_Logging','REQ_SAPCRM',3);
--Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPVEHDERV','SF_CrtUpdVehDeriv_SVCRM.SF_Logging1','RES_SAPCRM',3);

--11/08/2015 SA Added New entries for FRS137
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPVHCL','SF_Logging','IN',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPVHCL','SF_Logging1','IN_CANVEH_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPVHCL','SF_Logging2','OUT_CANVEH_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPVHCL','SF_Logging3','OUT_SVCRM',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPVHCL','SF_Logging4','SOAP_REPLY',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPVHCL','SF_CrtUpdVehicle_SVCRM.SF_Logging','REQ_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPVHCL','SF_CrtUpdVehicle_SVCRM.SF_Logging1','RES_SAPCRM',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPVHCL','SF_SOAP_ErrorHandlingV2.SF_Logging','SOAP_ERR_RES',2);

--12/08/2015 SA Added New entries for FRS133
--25/02/2016 VB Changed LOGGING_LEVEL to 3
--26/02/2016 VB Reverted back the changes for LOGGING_LEVEL
--12/05/2016 VB IFU3808: Updated entry as per the design changes for FRS-133
--28/12/2016 VB (MNT): Changed logging level as 3 wherever applicable for FRS-133
--ReplicateCase
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLICATECASE','SF_Log_Inbound_SOAP_Req','IN',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLICATECASE','SF_Log_Outbound_MQ_Req','IN_CANCASE_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLICATECASE','SF_Log_Inbound_MQ_Resp','OUT_CANCASE_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLICATECASE','SF_Log_Batch_Data_Load','OUT_BATCH',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLICATECASE','SF_Log_Outbound_SOAP_Resp','SOAP_REPLY',3);
--ReplicateCaseBatch
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLICATECASE_ECICDR','Log_ECICDR_Batch','IN_ECICDR_BATCH',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLICATECASE_ECICDR','Log_ECICDR_Record','OUT_ECICDR',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLICATECASE_RAVT','Log_RAVT_Batch','IN_RAVT_BATCH',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLICATECASE_RAVT','Log_RAVT_Record','OUT_RAVT',3);
-- (Canonical Flow)
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_CASES','SF_Logging','CANCASEAD_IN',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_CASES','SF_Logging1','CANCASEAD_TRANSF',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_CASES','SF_Logging2','CANCASEAD_OUT',2);

--19/08/2015 TK DEF5700:Added New entries for Adapter flows used in FRS115 & FRS136
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_POX_OUT','SF_Logging','IN',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_POX_OUT','SF_Logging1','OUT',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_POX_OUT','SF_Logging2','ERR_OUT',2);
--05/05/2016 AT IFU3832:Added New entries for Adapter flows V2 used in FRS115
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_POX_OUT_V2','SF_Logging','IN',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_POX_OUT_V2','SF_Logging1','OUT',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_POX_OUT_V2','SF_Logging2','ERR_OUT',2);

Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SOAP_STD_OUT','SF_Logging','IN',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SOAP_STD_OUT','SF_Logging1','REQ_STD_SOAP',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SOAP_STD_OUT','SF_Logging2','RES_STD_SOAP',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SOAP_STD_OUT','SF_Logging3','ERR_OUT',2);

--27/08/2015 TK IFU 3341:Added New entries for FRS 143
-- 18-04-2016 TK MNT: Updated logging level to 3 for QA testing for FRS 143
-- 18-04-2016 TK Reverted logging level as earlier for FRS 143
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_WARRANTYCONTRACT','SF_Logging','CANWRNTYCNTRCT_IN',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_WARRANTYCONTRACT','SF_Logging1','CANWRNTYCNTRCT_TRANSF',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_WARRANTYCONTRACT','SF_Logging2','CANWRNTYCNTRCT_OUT',2);

--15/09/2015 SB Added New entries for FRS-000687
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_HR_KRONOS_EMPTADATA','SF_Logging','IN_CANONICAL',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_HR_KRONOS_EMPTADATA','SF_Logging1','KRONOS_FILE',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_HR_KRONOS_EMPTADATA','SF_Logging2','ERROR',2);

-- : 24/06/2015 SB Added entries for FRS680(Vehicle Genealogy To Multiple Systems)
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_QUALITY_ALL_VEHGENEALOGY','SF_Logging','IN','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_QUALITY_ALL_VEHGENEALOGY','SF_Logging1','CDM','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_QUALITY_ALL_VEHGENEALOGY','SF_Logging2','SAP_IDOC','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_QUALITY_ALL_VEHGENEALOGY','SF_Logging3','VSA_REQUEST','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_QUALITY_ALL_VEHGENEALOGY','SF_Logging4','VSA_RESPONSE','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_MES_QUALITY_ALL_VEHGENEALOGY','SF_Logging5','ERROR','2');

-- : 29/06/2015 YR Added entries for FRS621(changes for Stone)
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBBR_ALEAPOMT_IN_V2','SF_Logging','IN','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBBR_ALEAPOMT_IN_V2','SF_Logging1','OUT','2');

-- : 29/06/2015 NC Added entries for FRS-000670
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_BAPIMT_IN_V2','SF_Logging','IN','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_BAPIMT_IN_V2','SF_Logging1','OUT','2');

-- :30/06/2015	 PP Added entries for FRS-364 (Warranty vehicle configuration) and FRS-382 (Warranty replicate claims) batch services
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_BWOOD_WRTYVEHCFG','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_BWOOD_WRTYVEHCFG','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_BWOOD_WRTYVEHCFG','SF_Logging','TRANSFORMED_BATCH_RECORD',3,CURRENT_TIMESTAMP,null);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_AWS_WRTYVEHCFG','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_AWS_WRTYVEHCFG','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_AWS_WRTYVEHCFG','SF_Logging','TRANSFORMED_BATCH_RECORD',3,CURRENT_TIMESTAMP,null);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_CTHMS_WTYVHCFGJG','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_CTHMS_WTYVHCFGJG','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_CTHMS_WTYVHCFGJG','SF_Logging','TRANSFORMED_BATCH_RECORD',3,CURRENT_TIMESTAMP,null);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_CTHMS_WTYVHCFGLR','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_CTHMS_WTYVHCFGLR','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_CTHMS_WTYVHCFGLR','SF_Logging','TRANSFORMED_BATCH_RECORD',3,CURRENT_TIMESTAMP,null);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_TOPIX_WTYVHCFGJG','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_TOPIX_WTYVHCFGJG','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_TOPIX_WTYVHCFGJG','SF_Logging','TRANSFORMED_BATCH_RECORD',3,CURRENT_TIMESTAMP,null);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_TOPIX_WTYVHCFGLR','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_TOPIX_WTYVHCFGLR','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_TOPIX_WTYVHCFGLR','SF_Logging','TRANSFORMED_BATCH_RECORD',3,CURRENT_TIMESTAMP,null);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_BWOOD_WTYCLAIM','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_BWOOD_WTYCLAIM','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_BWOOD_WTYCLAIM','SF_Logging','TRANSFORMED_BATCH_RECORD',3,CURRENT_TIMESTAMP,null);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_BWOOD_WTYCLAIM','SF_Logging1','END_DETAIL_TRAILER_RECS',3,CURRENT_TIMESTAMP,null);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_BWOOD_WTYCLAIM','SF_Logging2','OUT_HEADER_REC',3,CURRENT_TIMESTAMP,null);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_BWOOD_WTYCLAIM','SF_Logging3','OUT_DATA_FTP_TRIGGER',3,CURRENT_TIMESTAMP,null);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_CJLR_WTYCLAIM','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_CJLR_WTYCLAIM','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_CJLR_WTYCLAIM','SF_Logging','TRANSFORMED_BATCH_RECORD',3,CURRENT_TIMESTAMP,null);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_MFT_WTYCLAIM','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_MFT_WTYCLAIM','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_MFT_WTYCLAIM','SF_Logging','TRANSFORMED_BATCH_RECORD',3,CURRENT_TIMESTAMP,null);


-- VP DEF15043 added logging entries for smart flow
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_SMART_WTYCLAIM','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_SMART_WTYCLAIM','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_SMART_WTYCLAIM','SF_Logging','OUT_DETAIL_RECS',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_SMART_WTYCLAIM','SF_Logging1','END_DETAIL_RECS',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_SMART_WTYCLAIM','SF_Logging2','OUT_HEADER_REC',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_SMART_WTYCLAIM','SF_Logging3','OUT_DATA_FTP_TRIGGER',3,CURRENT_TIMESTAMP,null);


Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_SWORD_WTYCLAIM','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_SWORD_WTYCLAIM','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_SWORD_WTYCLAIM','SF_Logging','TRANSFORMED_BATCH_RECORD',3,CURRENT_TIMESTAMP,null);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_ALL_WTYCLAIM','SF_Logging','CANON_IN',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_ALL_WTYCLAIM','SF_Logging1','TO_BATCH',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_ALL_WTYCLAIM','SF_Logging2','CLAIM_IN',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_ALL_WTYCLAIM','SF_Logging3','TO_REALTIME_DEST',3,CURRENT_TIMESTAMP,null);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_ALL_WRTYVEHCFG','SF_Logging','TRANSFORMED_BATCH_RECORD',3,CURRENT_TIMESTAMP,null);
-- : 07/01/2016 HB Added enty for FRS-000364 as part of IFU-3622
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_ALL_WRTYVEHCFG','SF_Logging1','SingleBatchMessage',2,CURRENT_TIMESTAMP,null);

--	:30/06/2015  PP Added entries for Batch framework message flows
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BATCH_JOB_DISPATCHER','SF_Logging','BATCH_INVOKED',3,CURRENT_TIMESTAMP,null);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BATCH_ADMIN_INTERFACE','SF_Logging','IN',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BATCH_ADMIN_INTERFACE','SF_Logging1','OUT',3,CURRENT_TIMESTAMP,null);

-- : 22/09/2015 NC Added entries for FRS-720
-- : 28/09/2015 NC updated entries for FRS-720
-- : 26/02/2016 PM Updated logging level to 3 (as per mail from Sai Sankar Kunapareddi)
-- : 21/08/2017 AMAHESH2  Entries migrated to SI_Components FRS 720 under IFU 4684
--Employee
--INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_HREMP','SF_Logging','IN_SAP','3');
--INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_HREMP','SF_Logging1','OUT_CMM','3');
--INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_HREMP','SF_Logging2','ERROR','3');
--Organization
--INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_HRORG','SF_Logging','IN_SAP','2');
--INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_HRORG','SF_Logging1','OUT_CMM','2');
--INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_HRORG','SF_Logging2','ERROR','2');

-- : 24/09/2015 SB Added entries for IA-170 as per IFU3382
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEH_ALL_ALERTUPD','SF_Logging','IN_IDOC','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEH_PLO_ALERTUPD','SF_Logging1','PLO_ALERT','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEH_D42_ALERTUPD','SF_Logging2','D42_ALERT','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEH_PLO_BDFUPD','SF_Logging3','PLO_BDF','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEH_ALL_ALERTUPD','SF_Logging4','ERROR','2');

-- TK 25-09-2015 MNT:Added entries for FRS123
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_BRKDWNEVNT','SF_Logging','CANBRKDWNEVNTAD_IN',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_BRKDWNEVNT','SF_Logging1','CANBRKDWNEVNTAD_TRANSF',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_BRKDWNEVNT','SF_Logging2','CANBRKDWNEVNTAD_OUT',2);

-- VB 25-09-2015 MNT:Added entries for FRS128(Canonical Flow)
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_SERORREP','SF_Logging','CANSERORREP_IN',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_SERORREP','SF_Logging1','CANSERORREP_TRANSF',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_SERORREP','SF_Logging2','CANSERORREP_OUT',2);

-- 08/10/2015, AS, FRS-000669
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_TITO_HMRC_SAP_TRBBR_CUSTDECL','SF_Logging','IN_TITO',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_TITO_HMRC_SAP_TRBBR_CUSTDECL','SF_Logging1','OUT_BAPI_REQ',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_TITO_HMRC_SAP_TRBBR_CUSTDECL','SF_Logging2','IN_BAPI_RESP',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_TITO_HMRC_SAP_TRBBR_CUSTDECL','SF_Logging3','ERROR',2);

-- 16/10/2015 AS Entry for new adapter flow as per FRS 720, SI_AD_SAP_TRBGB_ALE_HR_MT_Inbound
-- 21/08/2017 AMAHESH2  Entries migrated to SI_Components FRS 720 under IFU 4684
--Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_MQSERV_ALEINHR','SF_Logging','IN',2);

-- AaP 27-10-2015 Added entries for FRS-650 under IFU3483 (AOS-SAP flow)
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_AOS_VEHICLE_SAP_TRBGB_VEHPATRAUP','SF_Logging','IN_AOS',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_AOS_VEHICLE_SAP_TRBGB_VEHPATRAUP','SF_Logging1','IN_SAPTRB_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_AOS_VEHICLE_SAP_TRBGB_VEHPATRAUP','SF_Logging2','ERR_AOS',2);
--(SAP-AOS flow)
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_AOS_VEHPATRAUP','SF_Logging','IN_SAPTR_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_AOS_VEHPATRAUP','SF_Logging1','IN_AOS',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_AOS_VEHPATRAUP','SF_Logging2','ERR_OUT',2);

--05-11-2015 SN Added entries for FRS-721
--adapter flow
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_ALEOTCMT_IN_V2','SF_Logging','IN_SAP',2);
--Veh Reg flow
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBBR_VEHICLE_SERPR_VEHREG','SF_Logging','IN_SAPTRB',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBBR_VEHICLE_SERPR_VEHREG','SF_Logging1','OUT_MFT',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBBR_VEHICLE_SERPR_VEHREG','SF_Logging2','OUT_ERROR',2);
--Veh Reg Ack flow
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SERPR_VEHICLE_SAP_TRBBR_VEHREGACK','SF_Logging','IN_SERPRO',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SERPR_VEHICLE_SAP_TRBBR_VEHREGACK','SF_Logging1','OUT_SAPTRB',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SERPR_VEHICLE_SAP_TRBBR_VEHREGACK','SF_Logging2','OUT_ERROR',2);

-- 09/11/2015 VP Added entries for FRS-000273
-- 02/05/2017 VK Removed entries after framework migration of FRS-273.
/* INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_DEMANDUPD',	'SF_Logging',	'3',	'IN_SOAP');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_DEMANDUPD',	'SF_Logging1',	'3',	'SOAP_REPLY');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_DEMANDUPD',	'SF_Logging2',	'3',	'REQUEST_JVBRG');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_DEMANDUPD',	'SF_Logging3',	'3',	'RESPONSE_JVBRG');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_DEMANDUPD',	'SF_Logging4',	'3',	'OUT_CMMS3');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_DEMANDUPD',	'SF_Logging5',	'3',	'OUT_SAP_A');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_DEMANDUPD',	'SF_Logging6',	'3',	'ERROR_SOAPREPLY');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_DEMANDUPD',	'SF_Logging7',	'3',	'IN_MQ');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_DEMANDUPD',	'SF_Logging8',	'3',	'MQ_REPLY');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_DEMANDUPD',	'SF_Logging9',	'3',	'ERROR_MQREPLY');

INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_TDDEMANDUPD',	'SF_Logging',	'3',	'IN');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_TDDEMANDUPD',	'SF_Logging1',	'3',	'REQUEST');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_TDDEMANDUPD',	'SF_Logging2',	'3',	'RESPONSE');
 */
-- 16/11/2015 AT Added entries for FRS-000689
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_NGA_STONE_ALE_MT_OUT','SF_Logging','IN_SAPNGA_MQ',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_NGA_STONE_ALE_MT_OUT','SF_Logging1','ERR_SAPNGA_MQ',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_NGA_STONE_ALE_MT_OUT','SF_Logging3','OUT_SAPNGA_AD',2);


-- 17/11/2015 VP Added entries for FRS-000277
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_BS_ESB_VEHICLE_SAP_TRB_ASNPROV',	'SF_Logging',	'3',	'IN');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_BS_ESB_VEHICLE_SAP_TRB_ASNPROV',	'SF_Logging1',	'3',	'OUT_SAP_A');

-- 18/11/2015 VP Added entries for FRS-000277
--              : 05/02/2016 VP modified entries for IFU3662
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_ADVSHPNT',	'SF_Logging',	'3',	'IN_SOAP');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_ADVSHPNT',	'SF_Logging1',	'3',	'SOAP_REPLY');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_ADVSHPNT',	'SF_Logging2',	'3',	'IN_CMMS_FILE');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_ADVSHPNT',	'SF_Logging3',	'3',	'IN_MQ');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_ADVSHPNT',	'SF_Logging4',	'3',	'REQUEST_JVBRG');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_ADVSHPNT',	'SF_Logging5',	'3',	'REQUEST_CJLR');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_ADVSHPNT',	'SF_Logging6',	'3',	'OUT_SAP_A');
-- INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_ADVSHPNT',	'SF_Logging7',	'3',	'RESPONSE_EVNTSCH');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_ADVSHPNT',	'SF_Logging8',	'3',	'RESPONSE_JVBRG');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_ADVSHPNT',	'SF_Logging9',	'3',	'RESPONSE_CJLR');

-- 19/11/2015 KT Added entries for IA-000147
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SWORD_INVOICE_SAP_TRBGB_WTYDLRPART','SF_Logging_Req_In','REQ_FROM_SWORD','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SWORD_INVOICE_SAP_TRBGB_WTYDLRPART','SF_Logging_Req_Out','REQ_TO_SAP','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SWORD_INVOICE_SAP_TRBGB_WTYDLRPART','SF_Logging_Resp_In','RESP_FROM_SAP','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SWORD_INVOICE_SAP_TRBGB_WTYDLRPART','SF_Logging_Resp_Out','RESP_TO_SWORD','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SWORD_INVOICE_SAP_TRBGB_WTYDLRPART','SF_Logging_Error','ERROR','2');

--20/11/2015 NC Added entries for IA-000172
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PAYRL_GLENTRY_SAP_TRB','SF_Logging','IN','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PAYRL_GLENTRY_SAP_TRB','SF_Logging1','OUT','2');


-- 23/11/2015 VP Added entries for FRS-000272
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_TDPARTS',	'SF_Logging',	'3',	'IN');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_TDPARTS',	'SF_Logging1',	'3',	'REQUEST');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_TDPARTS',	'SF_Logging2',	'3',	'RESPONSE');

INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_PARTS',	'SF_Logging',	'3',	'IN_SOAP');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_PARTS',	'SF_Logging1',	'3',	'OUT_SAP_A');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_PARTS',	'SF_Logging2',	'3',	'REQUEST_JVBRG');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_PARTS',	'SF_Logging3',	'3',	'OUT_CMMS3');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_PARTS',	'SF_Logging4',	'3',	'SOAP_REPLY');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_PARTS',	'SF_Logging5',	'3',	'IN_MQ');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_PARTS',	'SF_Logging6',	'3',	'ERROR_MQREPLY');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_PARTS',	'SF_Logging7',	'3',	'MQ_REPLY');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_PARTS',	'SF_Logging8',	'3',	'RESPONSE_JVBRG');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_SV_VEHSV_PARTS',	'SF_Logging9',	'3',	'ERROR_SOAPREPLY');

-- 26/11/2015 MJ Added entries for FRS-000616
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_VEHCAMPENQ','SF_Logging_Error','SOAP_ERROR','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_VEHCAMPENQ','SF_Logging1','SOAP_REQ_IN','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_VEHCAMPENQ','SF_Logging2','BAPI_REQ_OUT','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_VEHCAMPENQ','SF_Logging3','BAPI_RESP_IN','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_VEHCAMPENQ','SF_Logging4','SOAP_RESP_OUT','2');

-- 25/11/2015 AB added entry for FRS-000107 for IFU3554

INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_BS_VISTA_CUSSV_VITAL_ORDERREPL',	'SF_Logging',	'3',	'IN_VISTA');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,	BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,	'SI_BS_VISTA_CUSSV_VITAL_ORDERREPL',	'SF_Logging1',	'3',	'OUT_VITAL');

--08/12/2015 NC Added New entry for FRS669(Vehicle Import Declaration)

INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_TITO_HMRC_SAP_TRBBR_VEHIMPDECL','SF_Logging','IN_TITO',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_TITO_HMRC_SAP_TRBBR_VEHIMPDECL','SF_Logging1','OUT_IDOC',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_TITO_HMRC_SAP_TRBBR_VEHIMPDECL','SF_Logging2','ERROR',2);


--10/12/2015 SB Added New entry for FRS670 – Vehicle Information to TITO

INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBBR_INVOICE_TITO_VEHINFO','SF_Logging','IN_SAPTRB_AD',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBBR_INVOICE_TITO_VEHINFO','SF_Logging1','OUT_TITO',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBBR_INVOICE_TITO_VEHINFO','SF_Logging2','ERROR',2);

--14/12/2015 HB IFU3419: Added entries for adapters of FRS-000382
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_WARRANTYCLAIM','SF_Logging-Input','IN_IDOC_STORE',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_WARRANTYCLAIM','SF_Logging-Output','OUT_CANON_STORE',2);


--15/12/2015 SN Added entries for FRS-000737
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_NEOV_INVOICE_SAP_TRBBR_COMMERCINV','SF_Logging','IN_MFT',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_NEOV_INVOICE_SAP_TRBBR_COMMERCINV','SF_Logging1','IN_SAPTRB',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_NEOV_INVOICE_SAP_TRBBR_COMMERCINV','SF_Logging2','OUT_SAPTRB',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_NEOV_INVOICE_SAP_TRBBR_COMMERCINV','SF_Logging3','ERR_SAPTRB',2);

-- 16/12/2015 KT Added entries for FRS-000803
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WERS_VEHICLE_JVBRG_ENGCHANGE','SF_Logging','REQ_IN','3');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WERS_VEHICLE_JVBRG_ENGCHANGE','SF_Logging1','SOAPREQ_TO_JVBRG','3');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WERS_VEHICLE_JVBRG_ENGCHANGE','SF_Logging2','SOAPRESP_FROM_JVBRG','3');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WERS_VEHICLE_JVBRG_ENGCHANGE','SF_Logging3','WARNINGS','3');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WERS_VEHICLE_JVBRG_ENGCHANGE','SF_Logging4','ERROR','3');

---23/12/15 Added entries for FRS-722 After Market Order feed. For flow SI_BS_TRBBR_AfterMktOrdResp_To_NEOV SI_TRANSACTION_LOGGING_LEVEL
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBBR_VEHICLE_NEOV_AMORDRESP','SF_Logging','IN_SAPTRB',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBBR_VEHICLE_NEOV_AMORDRESP','SF_Logging1','OUT_MFT',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBBR_VEHICLE_NEOV_AMORDRESP','SF_Logging2','OUT_ERROR',2);


--Added entries for FRS-722 After Market Order feed. For flow SI_BS_NEOV_AfterMarketOrder_To_SAP_TRBBR SI_TRANSACTION_LOGGING_LEVEL
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_NEOV_VEHICLE_SAP_TRBBR_AFTMKTORD','SF_Logging','IN_NEOVIA',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_NEOV_VEHICLE_SAP_TRBBR_AFTMKTORD','SF_Logging1','OUT_SAPTRB',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_NEOV_VEHICLE_SAP_TRBBR_AFTMKTORD','SF_Logging2','OUT_ERROR',2);
---------------------
--21/08/2015 KV IFU 3239:Added New entries for FRS 382(SYC1)
-- 22/12/2015 HB updated SUBFLOW_DESC and LOGGING_LEVEL for FRS-000382 DEF-15043
--Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','SF_Logging','OUT_SYC1',3);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',3,CURRENT_TIMESTAMP,null);
-- VP 31/12/2015 DEF15043 reduce logging level to 2 
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','SF_Logging','OUT_DETAIL_TRAILER_RECS',2,CURRENT_TIMESTAMP,null);

-- 22/12/2015 HB added entry for FRS-000382 DEF-15043
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','SF_Logging1','END_DETAIL_TRAILER_RECS',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','SF_Logging2','OUT_HEADER_REC',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','SF_Logging3','OUT_DATA_FTP_TRIGGER',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_SYC1_WTYCLAIM','SF_Logging4','OUT_JCL_FTP_MSG',2);

-- 13/07/2016 HB FRS-000807 - Added entries for OA Code Translation Service
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_MISCSV_OACODETRANSL','SF_Logging','IN_REQUEST',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_MISCSV_OACODETRANSL','SF_Logging1','OUT_PLOREQ',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_MISCSV_OACODETRANSL','SF_Logging2','IN_PLORES',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_MISCSV_OACODETRANSL','SF_Logging3','REPLY_SOURCE',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_MISCSV_OACODETRANSL','SF_Logging4','ERROR_SOAP',2);

--SM:IFU3619:Added entries for 136 ROI flow
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'ROI_BATCH_SCHEDULER','SF_Logging','ROI_BATCH_OUT',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'ROI_BATCH_SCHEDULER','SF_Logging1','ROI_BATCH_ERR',3);

--21/01/2016 VB: Added entries for FRS-000109 Contract Canonical flow
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_CONTRACT','SF_Logging','CANACCTAD_IN',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_CONTRACT','SF_Logging1','CANACCTAD_TRANSF',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_CONTRACT','SF_Logging2','CANACCTAD_OUT',2);

--PM 22/01/2016  IFU3545 FRS-130  
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_DEALER_SAP_ESM_REPLICTEDR','SF_Logging','IN',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_DEALER_SAP_ESM_REPLICTEDR','SF_Logging1','OUT',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_DEALER_SAP_ESM_REPLICTEDR','SF_Logging2','Error',3);


--VP 25/01/2016 added entries for FRS791
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_BS_CANON_HR_KRONOSUK_EMPTADATA',	'SF_Logging',	'2',	'IN_CANONICAL');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_BS_CANON_HR_KRONOSUK_EMPTADATA',	'SF_Logging1',	'2',	'OUT_BATCH');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_BS_CANON_HR_KRONOSUK_EMPTADATA',	'SF_Logging2',	'2',	'KRONOS_FILE');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_BS_CANON_HR_KRONOSUK_EMPTADATA',	'SF_Batch_Data_Retriever.SF_Logging - Start of Batch',	'2',	'BATCH_START');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_BS_CANON_HR_KRONOSUK_EMPTADATA',	'SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch',	'2',	'BATCH_END');

--LH Added entry for IFU3764
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_BS_CANON_HR_KRONOSUK_EMPTADATA',	'SF_Logging3',	'2',	'MSG_TERMINATION');


-- SN 25/01/2016 Added entries for RS661 
----logging level for FRS661 should be set to 2 only as we don’t have to log input or output messages
   --KV Commented the below entries as below entries has been shifted to New build
/*INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_BAPIFIMT_IN_V2','SF_Logging','IN_SAP',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_PAYMT_SINTEL_ARPAYMT','SF_Logging','IN_SAP',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_PAYMT_SINTEL_ARPAYMT','SF_Logging1','OUT_MFT',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_PAYMT_SINTEL_ARPAYMT','SF_Logging2','OUT_ERROR',2);*/

INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SINTEL_PAYMT_SAP_TRBGB_ARCONFIRM','SF_Logging','IN_MFT',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SINTEL_PAYMT_SAP_TRBGB_ARCONFIRM','SF_Logging1','OUT_SAP',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SINTEL_PAYMT_SAP_TRBGB_ARCONFIRM','SF_Logging2','OUT_ERROR',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SINTEL_PAYMT_SAP_TRBGB_ARCONFIRM','SF_Logging3','SAP_RESP',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SINTEL_PAYMT_SAP_TRBGB_CREDITLMT','SF_Logging','IN_MFT',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SINTEL_PAYMT_SAP_TRBGB_CREDITLMT','SF_Logging1','OUT_SAP',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SINTEL_PAYMT_SAP_TRBGB_CREDITLMT','SF_Logging2','OUT_ERROR',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SINTEL_PAYMT_SAP_TRBGB_CREDITLMT','SF_Logging3','SAP_RESP',2);

-- 29/01/2016 VV Added entries for FRS-260 IFU3681
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_WERS_ADAPSV_ENGCHNG_IN','SF_Logging','IN',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_WERS_ADAPSV_ENGCHNG_IN','SF_Logging1','Warning',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_WERS_ADAPSV_ENGCHNG_IN','SF_Logging2','ToPLO',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_WERS_ADAPSV_ENGCHNG_IN','SF_Logging3','ToStoreQ',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_WERS_ADAPSV_ENGCHNG_IN','SF_Logging4','Error',3);

-- 01/02/2016 VV Added entries for FRS-260 IFU3681
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_WERS_ADAPSV_ENGCHNG_OUT','SF_Logging','IN',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_WERS_ADAPSV_ENGCHNG_OUT','SF_Logging1','ToPLO',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_WERS_ADAPSV_ENGCHNG_OUT','SF_Logging2','ToStoreQ',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_WERS_ADAPSV_ENGCHNG_OUT','SF_Logging3','OUT',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_WERS_ADAPSV_ENGCHNG_OUT','SF_Logging4','Error',3);

-- 01/02/2016 LH Added entries for FRS-000802 
Insert into SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BRS_VEH_SAP_TRB_VEHSPECSFEAT','SF_Logging','XML_IN',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BRS_VEH_SAP_TRB_VEHSPECSFEAT','SF_Logging1','IDOC_OUT',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BRS_VEH_SAP_TRB_VEHSPECSFEAT','SF_Logging2','XML_IN_ERROR',2);


--Added entries for FRS-653 SI_SV_IndependentSecurityCheck feed. For flow SI_SV_IndependentSecurityCheck
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_SECURITYCK','SF_Logging','IN_REQUEST',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_SECURITYCK','SF_Logging1','MSGFORMAT_CANON',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_SECURITYCK','SF_Logging2','OUT_TRUSTCENTRES',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_SECURITYCK','SF_Logging3','ERROR_SOAP',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_SECURITYCK','SF_Logging4','IN_RESPONSE',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_SECURITYCK','SF_Logging5','REPLY_SOURCE',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_SECURITYCK','SF_Logging6','ERROR_MQ',2);



---Added entries for FRS-653 of Message flow SI_SV_TrustCentres
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_TRUSTCENTRES','SF_Logging','IN',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_TRUSTCENTRES','SF_Logging1','ROUTE_LABEL',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_TRUSTCENTRES','SF_Logging2','OUT',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_TRUSTCENTRES','SF_Logging3','ERROR',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_TRUSTCENTRES','SF_Logging4','OUT_ERROR',2);
--IFU3948 LH Topix Sub is no more used
/*
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_TRUSTCENTRES','SF_Logging5','IN_TOPIX_SUB',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_TRUSTCENTRES','SF_Logging6','REQUEST_TOPIX_SUB',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_TRUSTCENTRES','SF_Logging7','RESPONSE_TOPIX_SUB',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_TRUSTCENTRES','SF_Logging8','RESPONSE_TOPIX_SUB_ERROR',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_TRUSTCENTRES','SF_Logging9','RESPONSE_CANON_IN',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_TRUSTCENTRES','SF_Logging10','IN_TOPIX_SEC',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_TRUSTCENTRES','SF_Logging11','REQUEST_TOPIX_SEC',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_TRUSTCENTRES','SF_Logging12','RESPONSE_TOPIX_SEC',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_TRUSTCENTRES','SF_Logging13','RESPONSE_TOPIX_SEC_ERROR',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_TRUSTCENTRES','SF_Logging14','RESPONSE_CANON_IN',2);
 */
 INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_TRUSTCENTRES','SF_Logging15','IN_ALOA',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_TRUSTCENTRES','SF_Logging16','REQUEST_ALOA',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_TRUSTCENTRES','SF_Logging17','RESPONSE_ALOA',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_TRUSTCENTRES','SF_Logging18','RESPONSE_ALOA_ERROR',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_TRUSTCENTRES','SF_Logging19','RESPONSE_CANON_IN',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_TRUSTCENTRES','SF_Logging20','RESPONSE_CANON_OUT',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_TRUSTCENTRES','SF_Logging21','IN_NICB',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_TRUSTCENTRES','SF_Logging22','OUT_NICB',2);



--Added entries for FRS-653 of Message flow SI_SV_SecurityNotification

INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_SECURITYNF','SF_Logging','IN',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_SECURITYNF','SF_Logging1','NICB_REQUEST',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_SECURITYNF','SF_Logging2','NICB_RESPONSE',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_SECURITYNF','SF_Logging3','NICB_ERROR_RESPONSE',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_SECURITYNF','SF_Logging4','RESPONSE_CANON_IN',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_SECSV_SECURITYNF','SF_Logging5','ERROR',2);


--03/03/2016 VP Added entry for FRS-811
insert into wmbowner.si_transaction_logging_level (ID, BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) values(SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_BS_MONEX_MISC_ALL_CURRTRIANG',	'SF_Logging',	'2',	'IN');
insert into wmbowner.si_transaction_logging_level (ID, BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) values(SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_BS_MONEX_MISC_ALL_CURRTRIANG',	'SF_Logging1',	'2',	'OUT');
insert into wmbowner.si_transaction_logging_level (ID, BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) values(SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_BS_MONEX_MISC_FAST_CURRTRIANG',	'SF_Logging',	'2',	'IN');
insert into wmbowner.si_transaction_logging_level (ID, BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) values(SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_BS_MONEX_MISC_LGCY_CURRTRIANG',	'SF_Logging',	'2',	'IN');
insert into wmbowner.si_transaction_logging_level (ID, BUSINESS_SERVICE_ID,	SUBFLOW_NAME,	LOGGING_LEVEL,	SUBFLOW_DESC) values(SI_TRANS_LOG_LEV_SEQ.NEXTVAL, 'SI_BS_MONEX_MISC_LGCY_CURRTRIANG',	'SF_Logging1',	'2',	'OUT');

--03/03/2016 PM added entry for FRS-638
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_TOPIX_VEHICLE_SAP_TRBGB_SROTRANSL','SF_Logging','IN_MFT',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_TOPIX_VEHICLE_SAP_TRBGB_SROTRANSL','SF_Logging1','OUT_SAP',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_TOPIX_VEHICLE_SAP_TRBGB_SROTRANSL','SF_Logging2','OUT_ERROR',2);

--04/03/2016 NM added entry for FRS-795
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_VEHICLE_SAPTRBGB_MATCOSTPRC','Input_NEOV','IN_NEOV',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_VEHICLE_SAPTRBGB_MATCOSTPRC','Input_IPOS','IN_IPOS',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_VEHICLE_SAPTRBGB_MATCOSTPRC','Output_IDoc_INFREC01','OUT_INFREC01_AD',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_VEHICLE_SAPTRBGB_MATCOSTPRC','Output_IDoc_COND_A01','OUT_CONDA01_AD',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_VEHICLE_SAPTRBGB_MATCOSTPRC','Error_NEOV','ERROR_NEOV_FILE',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_VEHICLE_SAPTRBGB_MATCOSTPRC','Error_IPOS','ERROR_IPOS_FILE',2);

--07/03/2016 MJ Added entry for IA-271
--07/07/2017 PM Updated entries as per IFU4763

INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_INVSV_WRRNTYCLMS','SF_Logging','IN_SOAP',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_INVSV_WRRNTYCLMS','SF_Logging1','IN_ADP',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_INVSV_WRRNTYCLMS','SF_Logging2','MSGFORMAT_IDOC',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_INVSV_WRRNTYCLMS','SF_Logging3','RESPONSE_SOAP',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_INVSV_WRRNTYCLMS','SF_Logging4','ERROR_FOUND',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_INVSV_WRRNTYCLMS','SF_Logging5','ERROR_ADP_FILE',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_INVSV_WRRNTYCLMS','SF_Logging6','ERROR_SOAP',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_INVSV_WRRNTYCLMS','SF_Logging7','PARSING_ERROR',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_INVSV_WRRNTYCLMS','SF_Logging8','IN_DDW',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_INVSV_WRRNTYCLMS','SF_Logging9','ERROR_DDW_FILE',3);



--30/03/2016 MJ Added entry for IA-49
--21/04/2016 MJ Updated entry for IA-49

INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BBSS_VEHSERV_ALL_VEHDATA','SF_Log_Input','MFT_IN',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BBSS_VEHSERV_ALL_VEHDATA','SF_Log_SAPESM_Output','SAP_ESM_OUT',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BBSS_VEHSERV_ALL_VEHDATA','SF_Log_AAARA_Output','AAARA_OUT',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BBSS_VEHSERV_ALL_VEHDATA','SF_Log_Batch_Data_Load','BATCH_DATA_LOAD',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BBSS_VEHSERV_ALL_VEHDATA','SF_Log_MultSystems_Error','BS_MULT_SYSTEMS_ERR',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BBSS_VEHSERV_ALL_VEHDATA','SF_Log_ORBITS_Output','ORBITS_OUT',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BBSS_VEHSERV_ALL_VEHDATA','SF_Log_ESPS_Output','ESPS_OUT',2);

--08/03/2016 PM Added entries for FRS-638 SAP adapter
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_ALEST_OUT','SF_Logging','IN',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_ALEST_OUT','SF_Logging1','SAP_OUT',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_ALEST_OUT','SF_Logging2','ERROR_FOUND',3);

-- LH added entries for FRS259 for IFU3676
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_VEHPROPDTA','SF_Logging','IN_PLO',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_VEHPROPDTA','SF_Logging1','IN_WCAR',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_VEHPROPDTA','SF_Logging2','OUT_WCAR',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_VEHPROPDTA','SF_Logging3','ERR_PLO',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_VEHPROPSUB','SF_Logging1','IN_WCAR',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_VEHPROPSUB','SF_Logging2','OUT_WCAR',2);

-- 15/03/2016 LH IFU3605 FRS-258 entries
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_PRODCTRL','SF_Logging','ERR_MQ_VCATS',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_PRODCTRL','SF_Logging1','REQ_MQ_VCATS',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_PRODCTRL','SF_Logging2','RES_MQ_VCATS',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_PRODCTRL','SF_Logging3','REQ_SOAP_VCATS',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_PRODCTRL','SF_Logging4','IN_WCAR',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_PRODCTRL','SF_Logging5','IN_MFT',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_PRODCTRL','SF_Logging6','RES_WCAR',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_PRODCTRL','SF_Logging7','IN_SAPTRB_BR',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_PRODCTRL','SF_Logging8','ROUTE_SAPTRB',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_PRODCTRL','SF_Logging9','IN_SAPTRB',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_PRODCTRL','SF_Logging10','OUT_SAPTRB',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_PRODCTRL','SF_Logging11','IN_SAPTRB_VGA',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_PRODCTRL','SF_Logging12','OUT_SAPTRB_VGA',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_PRODCTRL','SF_Logging13','RES_SOAP_VCATS',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_PRODCTRL','SF_Logging14','ERR_SOAP_VCATS',3);


--17/03/2015 PM Added as per FRS-812 Development
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_TMS_INVOICE_SAPSMTCN_GLFILE','SF_Logging','IN_MFT',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_TMS_INVOICE_SAPSMTCN_GLFILE','SF_Logging1','OUT_SAP',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_TMS_INVOICE_SAPSMTCN_GLFILE','SF_Logging2','OUT_ERROR',2);

--				: 25/03/2016 PP: Added logging level entries for EXCEP_REPLAY_ALL (exception replay web service)
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_EXCEPTION_REPLAY_MGMT','SF_Logging','IN_WEB_REQ',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_EXCEPTION_REPLAY_MGMT','SF_Logging1','OUT_REPLAY_TRIG',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_EXCEPTION_REPLAY_MGMT','SF_Logging2','OUT_WEB_RESP',2);


-- 21/07/2015 HB Added New entries for FRS810
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_PAYMT_ESB_COADATA','SF_Logging','IN_SAP',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_PAYMT_ESB_COADATA','SF_Logging1','OUT_ESB',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_PAYMT_ESB_COADATA','SF_Logging2','OUT_ERROR',2);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_PAYMT_MFRAME_COADATA','SF_Logging','IN_ESB',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_PAYMT_MFRAME_COADATA','SF_Logging1','OUT_MAINFRAME',2);

-- 31/03/2016 PK Added new entries for IFU3797
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_TD_VEH_CJLR_PROVASN','SF_Logging3','ERR_CJLR',2);


--06/04/2016 PM Added as per SI_AD_SAP_SMTCN_ALE_MT_OutboundV2 (FRS-812 SAP Adapter)
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_SMTCN_ALE_OUTBOUND_V2','SF_Logging','IN_SAPSMTCN_MQ',2);

INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_SMTCN_ALE_OUTBOUND_V2','SF_Logging1','OUT_SAPSMTCN_AD',2);

INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_SMTCN_ALE_OUTBOUND_V2','SF_Logging2','ERR_SAPSMTCN_MQ',2);

--IFU3815 MQ Adapter flow for PGZ SI_AD_PGZ_MQSERV_MQOUT
--11/05/2016:NC:DEF#18516 reverted loggig level to 2 for IN
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_PGZ_MQSERV_MQOUT','SF_Logging_In','IN',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_PGZ_MQSERV_MQOUT','SF_Logging_Err','Error',3);

--15/04/2016 SS:IFU3819 entries added for SI_AD_SOAP_STD_MT_OutboundV2
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SOAP_STD_OUT_V2','SF_Logging','IN',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SOAP_STD_OUT_V2','SF_Logging1','REQ_STD_SOAP',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SOAP_STD_OUT_V2','SF_Logging2','RES_STD_SOAP',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SOAP_STD_OUT_V2','SF_Logging3','ERR_STD_SOAP',2);

-- 	18/04/2016 KB Added new entries for FRS-000690 IFU3829 
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PLO_SUPPLIER_ALL_FORECAST','SF_Logging','OUT',2);

-- 21/04/2016 PK Added new entries for FRS-809(SI_BS_GRP_VEHICLE_SAP_TRBGB_USERDATA)
Insert into SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_GRP_VEHICLE_SAP_TRBGB_USERDATA','SF_Logging','IN_GRP',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_GRP_VEHICLE_SAP_TRBGB_USERDATA','SF_Logging1','OUT_SAP_AD',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_GRP_VEHICLE_SAP_TRBGB_USERDATA','SF_Logging2','ERROR_MANDFIELDMISSING',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_GRP_VEHICLE_SAP_TRBGB_USERDATA','SF_Logging3','ERROR_SOURCEFILE',2);

--21/04/2016 PK Added new entries for FRS-809 (SI_AD_SAP_TRBGB_ALE_CUA_OUT_V2)
Insert into SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_ALE_CUA_OUT_V2','SF_Logging','IN_SAPCUA_MQ',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_ALE_CUA_OUT_V2','SF_Logging1','OUT_SAPCUA_AD',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_ALE_CUA_OUT_V2','SF_Logging2','ERR_SAPCUA_MQ',2);

-- 22/04/2016 AaP added entry for FRS-000382 AUTOA flow DEF-15043
-- 03/05/2016 PM removed SF_Logging4 for AutoA. As it is no longer required.
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_AUTOA_WTYCLAIM','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_AUTOA_WTYCLAIM','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_AUTOA_WTYCLAIM','SF_Logging','OUT_DETAIL_TRAILER_RECS',3,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_AUTOA_WTYCLAIM','SF_Logging1','END_DETAIL_TRAILER_RECS',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_AUTOA_WTYCLAIM','SF_Logging2','OUT_HEADER_REC',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_AUTOA_WTYCLAIM','SF_Logging3','OUT_DATA_FTP_TRIGGER',3);


-- 28/04/2016 NCH added entries for FRS-000816 Canonical(Material Master) flow
--11/05/2016:NC:DEF#18516 updated loggig level to 3 for FRS-000816 ,000813 and 000814
--11/05/2016:NC:DEF#18516 reverted loggig level to 2 for FRS-000816 ,000813 and 000814
Insert into SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_MATMAS','SF_Logging','IN_SAP',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_MATMAS','SF_Logging1','OUT_CMM',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_MATMAS','SF_Logging2','ERROR',2);

-- 28/04/2016 NCH added entries for FRS-000816 SAP Adpater(Material Master) flow
Insert into SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_ALEMMMT_IN_V2','SF_Logging','IN_SAP',2);

-- 	29/04/2016 KB Added new entries for FRS-000813
--17/05/2016 NC updated BSID for FRS-000813 
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_PRODUCT_PGZ_MATLMASTER','SF_Logging','IN_CANONICAL',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_PRODUCT_PGZ_MATLMASTER','SF_Logging1','OUT_PGZ',3);

--04/05/2016 NCH added entries for FRS-000816 Canonical(Vendor Master) flow
Insert into SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_VENMAS','SF_Logging','IN_SAP',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_VENMAS','SF_Logging1','OUT_CMM',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_VENMAS','SF_Logging2','ERROR',2);

--04/05/2016 NCH added entries for FRS-000816 Canonical(Vendor Master) flow
Insert into SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_ALEVMMT_IN_V2','SF_Logging','IN_SAP',2);

--09/05/2016 NB added entries for FRS-000814 Canonical(Vendor Master) flow
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_PRODUCT_PGZ_VENDMASTER','SF_Logging','IN_CANONICAL',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_PRODUCT_PGZ_VENDMASTER','SF_Logging1','OUT_PGZ',2);

-- 	11/05/2016 KB Added new entries for FRS-000817 
--  01/02/2017 CD Added changes for IFU4373 Updated SUBFLOW_DESC to OUT_PGZ in the existing entry
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PLO_VEHICLE_PGZ_ORDER','SF_Logging','IN',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PLO_VEHICLE_PGZ_ORDER','SF_Logging1','OUT_PGZ',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PLO_VEHICLE_PGZ_ORDER','SF_Logging2','ERROR',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_VEHICLE_PLO_ORDERSTAT','SF_Logging','IN',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_VEHICLE_PLO_ORDERSTAT','SF_Logging1','OUT',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_VEHICLE_PLO_ORDERSTAT','SF_Logging2','ERROR',2);

-- 	16/05/2016 NB Added new entries for FRS-000815
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_PRODUCT_PGZ_CTC','SF_Logging','IN_CTC_CMM',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_PRODUCT_PGZ_CTC','SF_Logging1','OUT_CTC_PGZ',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_PRODUCT_PGZ_CTC','SF_Logging2','ERROR',2);

-- 16/05/2016 HB Added New entries for FRS818
-- 09/08/2016 HB Updated Entry for FRS-818 as per IFU-4055
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_MISC_SAP_TRBGB_INTSTKMVMT','SF_Logging_In','IN_FTP',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_MISC_SAP_TRBGB_INTSTKMVMT','SF_Logging_Out','OUT_SAPTRB',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_MISC_SAP_TRBGB_INTSTKMVMT','SF_Logging_Err','ERROR',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_MISC_SAP_TRBGB_INTSTKMVMT','SF_Logging_Warning','Warning',3);


--23/05/2016 NCH added entries for FRS-000816 adapter(CTC) flow
Insert into SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_ALECTCMT_IN_V2','SF_Logging','IN_SAP',2);

--23/05/2016 NCH added entries for FRS-000816 Canonical(CTC) flow
Insert into SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_CTC','SF_Logging','IN_SAP',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_CTC','SF_Logging1','OUT_CMM',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL(ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_CTC','SF_Logging2','ERROR',2);

-- 26/05/2016 HB Added New entries for IA-61 as part of IFU-3878
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_MISCSERV_ALL_PLANEVENT','SF_Logging','IN_MQ',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_MISCSERV_ALL_PLANEVENT','SF_Logging1','IN_SAPESM',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_MISCSERV_ALL_PLANEVENT','SF_Logging2','IN_D3',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_MISCSERV_ALL_PLANEVENT','SF_Logging3','IN_VISTA',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_MISCSERV_ALL_PLANEVENT','SF_Logging4','IN_HTTPReply',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_MISCSERV_ALL_PLANEVENT','SF_Logging5','ERR_MQ',2);

-- 01/06/2016 ANA Added for FRS-000151, flow SI_AD_CANONICAL_PRODREF_MT_OUT
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_PRODREF','SF_Logging','IN_BRS',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_PRODREF','SF_Logging1','OUT_CMM',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_PRODREF','SF_Logging2','ERROR',2);

-- LH added entries for IA-000207 for IFU3924
-- LH IFU4023 IA-000207 Change in Message flow. Accordingly changing Transaction Logging level script
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_VEHSERV_ALL_VEHREGIS','SF_Logging_In','IN_VEHREGIS',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_VEHSERV_ALL_VEHREGIS','SF_Logging_ToSAP','OUT_ToSAP',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_VEHSERV_ALL_VEHREGIS','SF_Logging_FromSAP','Error_FromSAP',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_VEHSERV_ALL_VEHREGIS','SF_Logging_ToVista','OUT_ToVISTA',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_VEHSERV_ALL_VEHREGIS', 'SF_Logging_ToCTHMS_JR','OUT_ToCTHMS_JR',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_VEHSERV_ALL_VEHREGIS', 'SF_Logging_ToCTHMS_LR','OUT_ToCTHMS_LR',2);
--INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_VEHSERV_ALL_VEHREGIS', 'SF_Logging_To_CAMD_JR','OUT_ToCAMD_JR',2);
--INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_VEHSERV_ALL_VEHREGIS','SF_Logging_To_CAMD_LR','OUT_ToCAMD_LR',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_VEHSERV_ALL_VEHREGIS', 'SF_Logging_To_CAMD_JR_LR','OUT_ToCAMD',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_VEHSERV_ALL_VEHREGIS','SF_Logging_Error','Error',2);

-- 08/06/2016 HB Added New entries for IA-108
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ERES_INVOICE_SAP_TRBGB_SELFBILLNG','SF_Logging','IN_MFT',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ERES_INVOICE_SAP_TRBGB_SELFBILLNG','SF_Logging2','OUT_SAP',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ERES_INVOICE_SAP_TRBGB_SELFBILLNG','SF_Logging3','OUT_ERROR',2);

-- 16/06/2016 ANA Added for FRS-000151, flow SI_BS_CANON_ProdRef_To_SVCRM
-- 22/09/2016 VB DEF9134:Updated 'SUBFLOW_DESC' for 'SF_Logging2','SF_Logging3' and 'SF_Logging4' for FRS-000151, flow SI_BS_CANON_ProdRef_To_SVCRM
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_PRODUCT_SVCRM_PRODREF','SF_Logging','IN_CMM',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_PRODUCT_SVCRM_PRODREF','SF_Logging1','IN_CMM_HEADER',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_PRODUCT_SVCRM_PRODREF','SF_Logging2','OUT_FEATURE_SVCRM_REQ',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_PRODUCT_SVCRM_PRODREF','SF_Logging3','OUT_DERV_SVCRM_REQ',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_PRODUCT_SVCRM_PRODREF','SF_Logging4','IN_SVCRM_RESP_ERROR',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_PRODUCT_SVCRM_PRODREF','SF_Logging5','IN_SVCRM_RESP',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_PRODUCT_SVCRM_PRODREF','SF_Logging6','ERROR',2);

-- 27/06/2016 AT Added for FRS-000107(IFU 3897 OCRM) 
-- 28/08/2016 SM Added for FRS-000107(IFU 4047 OCRM) 
--SM Updated the subflow name to SF_SV_GetSession_from_OCRM for FRS 107(OCRM)
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_OCRM_ORDERREPL','SF_Logging','VEHCAN_IN',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_OCRM_ORDERREPL','SF_Logging1','OCRM_REQ',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_OCRM_ORDERREPL','SF_SendRequestTo_VISTA_OCRM.SF_Logging','REQ_VISTAOCRMOCRM',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_OCRM_ORDERREPL','SF_SendRequestTo_VISTA_OCRM.SF_Logging1','RES_VISTAOCRM',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_OCRM_ORDERREPL','SF_SendRequestTo_VISTA_OCRM.SF_Logging2','RESFAIL_VISTAOCRMOCRM',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_OCRM_ORDERREPL','SF_SendRequestTo_VISTA_OCRM.SF_SV_GetSession_from_OCRM.SF_Logging1','RES_LOGINWS',2);
-- 28/06/2016 PK Added for FRS-000820
--CMMS3 TO ESB
--SI_BS_CMMS3_ASN_PlantSOL_To_ESB
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_SUPPLIER_ESB_ASNSOL','SF_Logging','IN_BATCH_TRIGGER',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_SUPPLIER_ESB_ASNSOL','SF_Logging1','OUT_ASN_CANONICAL',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_SUPPLIER_ESB_ASNSOL','SF_Logging2','OUT_CIC_AUDIT_TABLE_SUCCESS',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_SUPPLIER_ESB_ASNSOL','SF_Logging3','OUT_CIC_AUDIT_TABLE_ERROR',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_SUPPLIER_ESB_ASNSOL','SF_Logging4','ERROR',2);

--SI_BS_CMMS3_ASN_PlantCBBIW_To_ESB
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_SUPPLIER_ESB_ASNCBBIW','SF_Logging','IN_BATCH_TRIGGER',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_SUPPLIER_ESB_ASNCBBIW','SF_Logging1','OUT_ASN_CANONICAL',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_SUPPLIER_ESB_ASNCBBIW','SF_Logging2','OUT_CIC_AUDIT_TABLE_SUCCESS',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_SUPPLIER_ESB_ASNCBBIW','SF_Logging3','OUT_CIC_AUDIT_TABLE_ERROR',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_SUPPLIER_ESB_ASNCBBIW','SF_Logging4','ERROR',2);

--SI_BS_CMMS3_ASN_PlantCBTF_To_ESB
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_SUPPLIER_ESB_ASNCBTF','SF_Logging','IN_BATCH_TRIGGER',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_SUPPLIER_ESB_ASNCBTF','SF_Logging1','OUT_ASN_CANONICAL',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_SUPPLIER_ESB_ASNCBTF','SF_Logging2','OUT_CIC_AUDIT_TABLE_SUCCESS',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_SUPPLIER_ESB_ASNCBTF','SF_Logging3','OUT_CIC_AUDIT_TABLE_ERROR',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_SUPPLIER_ESB_ASNCBTF','SF_Logging4','ERROR',2);

--SI_BS_CMMS3_ASN_PlantHW_To_ESB
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_SUPPLIER_ESB_ASNHW','SF_Logging','IN_BATCH_TRIGGER',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_SUPPLIER_ESB_ASNHW','SF_Logging1','OUT_ASN_CANONICAL',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_SUPPLIER_ESB_ASNHW','SF_Logging2','OUT_CIC_AUDIT_TABLE_SUCCESS',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_SUPPLIER_ESB_ASNHW','SF_Logging3','OUT_CIC_AUDIT_TABLE_ERROR',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_SUPPLIER_ESB_ASNHW','SF_Logging4','ERROR',2);

--ESB TO CIC
--SI_BS_ESB_ASN_PlantSOL_To_CIC
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_SUPPLIER_CIC_ASNSOL','SF_Logging','IN_ASN_CANONICAL',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_SUPPLIER_CIC_ASNSOL','SF_Logging1','OUT_CIC_INSERT_ASN',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_SUPPLIER_CIC_ASNSOL','SF_Logging2','OUT_CIC_AUDIT_TABLE_ERROR',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_SUPPLIER_CIC_ASNSOL','SF_Logging3','ERROR',2);

--SI_BS_ESB_ASN_PlantCBBIW_To_CIC
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_SUPPLIER_CIC_ASNCBBIW','SF_Logging','IN_ASN_CANONICAL',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_SUPPLIER_CIC_ASNCBBIW','SF_Logging1','OUT_CIC_INSERT_ASN',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_SUPPLIER_CIC_ASNCBBIW','SF_Logging2','OUT_CIC_AUDIT_TABLE_ERROR',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_SUPPLIER_CIC_ASNCBBIW','SF_Logging3','ERROR',2);

--SI_BS_ESB_ASN_PlantCBTF_To_CIC
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_SUPPLIER_CIC_ASNCBTF','SF_Logging','IN_ASN_CANONICAL',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_SUPPLIER_CIC_ASNCBTF','SF_Logging1','OUT_CIC_INSERT_ASN',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_SUPPLIER_CIC_ASNCBTF','SF_Logging2','OUT_CIC_AUDIT_TABLE_ERROR',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_SUPPLIER_CIC_ASNCBTF','SF_Logging3','ERROR',2);

--SI_BS_ESB_ASN_PlantHW_To_CIC
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_SUPPLIER_CIC_ASNHW','SF_Logging','IN_ASN_CANONICAL',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_SUPPLIER_CIC_ASNHW','SF_Logging1','OUT_CIC_INSERT_ASN',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_SUPPLIER_CIC_ASNHW','SF_Logging2','OUT_CIC_AUDIT_TABLE_ERROR',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_SUPPLIER_CIC_ASNHW','SF_Logging3','ERROR',2);

-- 	01/07/2016 KB Added new entries for FRS-000819 
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_D42_DEALER_PGZ_DISTLABEL','SF_Logging','IN_HTTP_REQ',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_D42_DEALER_PGZ_DISTLABEL','SF_Logging1','OUT_PGZ',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_D42_DEALER_PGZ_DISTLABEL','SF_Logging2','OUT_HTTP_RESP',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_D42_DEALER_PGZ_DISTLABEL','SF_Logging3','OUT_HTTP_ERR',2);

-- 11/07/2016 NB Added new entries for FRS-000372(IFU3913, IFU3955)
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_VEHDSTST','SF_Logging','IN',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_VEHDSTST','SF_Logging1','SOAP_REQ',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_VEHDSTST','SF_Logging2','SOAP_RESP',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_VEHDSTST','SF_Logging3','OUT_PGZ',2);
-- 	23/12/2016 NB Added new entries for FRS-000372(IFU4338)
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_VEHDSTST','SF_Logging4','OUT_ESB',2);

-- 12/07/2016 AaP DEF15043-SWORD added logging entries for sword flow FRS382
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_SWORD_WTYCLAIM','SF_Logging','OUT_PERSIST_RECS',2,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_SWORD_WTYCLAIM','SF_Logging1','OUT_RECORDS',2,CURRENT_TIMESTAMP,null);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL,INSERT_TIMESTAMP,UPDATE_TIMESTAMP) values (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_SWORD_WTYCLAIM','SF_Logging2','OUT_DATA_FTP_TRIGGER',2,CURRENT_TIMESTAMP,null);

-- 12/07/2016 RBH Added new entries for FRS-000151(IFU3942)
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_PRODUCT_OCRM_PRODREF','SF_Logging','IN_CMM',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_PRODUCT_OCRM_PRODREF','SF_Logging1','REQUEST_OCRM',2);

--Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_PRODUCT_OCRM_PRODREF','SF_Logging2','OUT_OCRM_REQ_FAILURE',2);
--Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_PRODUCT_OCRM_PRODREF','SF_Logging3','OUT_OCRM_RESP',2);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_PRODUCT_OCRM_PRODREF','SF_Logging4','OUT_ERROR',2);
--20/08/2016 :KV Added the below Entries for FRS-000151(IFU4049)
  --22/08/2016 :KV Added the db entry for RES_LOGINWS logging for FRS-000151(IFU4049)
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_PRODUCT_OCRM_PRODREF','SF_SendRequestTo_BRS_OCRM.SF_Logging','REQ_BRSOCRM',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_PRODUCT_OCRM_PRODREF','SF_SendRequestTo_BRS_OCRM.SF_Logging1','RESFAIL_BRSOCRM',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_PRODUCT_OCRM_PRODREF','SF_SendRequestTo_BRS_OCRM.SF_Logging2','RES_BRSOCRM',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_PRODUCT_OCRM_PRODREF','SF_SendRequestTo_BRS_OCRM.SF_SV_GetSession_from_OCRM.SF_Logging1','RES_LOGINWS',2);

--				:19/07/2016 LH Added entries for FRS-362 service flow framework migration BSID is SI_SV_VEHSV_VEHENQUIRY

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_VEHENQUIRY','SF_Logging','IN_GCM',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_VEHENQUIRY','SF_Logging1','REQUEST_SAP',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_VEHENQUIRY','SF_Logging2','RESPONSE_SAP',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_VEHENQUIRY','SF_Logging3','MSGFORMAT_BAPI',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_VEHENQUIRY','SF_Logging4','MSGFORMAT_CANONICAL',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_VEHENQUIRY','SF_Logging5','OUT_GCM',2);

-- 28/07/2016 NB: Added entries for FRS-000371(IFU3928)
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_VEHICLE_D42_MANUFACSTATUS','SF_Logging','REQ_FROM_PGZ',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_VEHICLE_D42_MANUFACSTATUS','SF_Logging1','REQ_TO_D42',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_VEHICLE_D42_MANUFACSTATUS','SF_Logging2','RESP_FROM_D42',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_VEHICLE_D42_MANUFACSTATUS','SF_Logging3','RESP_TO_PGZ',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_VEHICLE_D42_MANUFACSTATUS','SF_Logging4','D42_CALL_FAILED',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_VEHICLE_D42_MANUFACSTATUS','SF_Logging5','ERROR',2);

-- Prasad P: IFU 3907 New log level entries for all IA-27 interfaces [START]

-- Log level entries for business service name - SI_BS_SAP_TRBGB_INVCRDDETS_IIS
DELETE FROM WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL WHERE BUSINESS_SERVICE_ID = 'SI_BS_SAP_TRBGB_INVCRDDETS_IIS';
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_IIS','SF_Logging_ToIIS','TRANSFORMED_MSG',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_IIS','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_IIS','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',2);


-- Log level entries for business service name - SI_BS_SAP_ALL_INVCRDDETS
DELETE FROM WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL WHERE BUSINESS_SERVICE_ID = 'SI_BS_SAP_ALL_INVCRDDETS';
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_ALL_INVCRDDETS','SF_Logging-RealtimeUpd','REALTIME_MSG',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_ALL_INVCRDDETS','SF_Logging-BatchDataStore','BATCH_DATA_STORE',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_ALL_INVCRDDETS','SF_Logging-PLORequest','PLO_REQUEST',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_ALL_INVCRDDETS','SF_Logging-PLOResponse','PLO_RESPONSE',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_ALL_INVCRDDETS','SF_Logging-Input','INPUT',2);

-- Log level entries for business service name - SI_BS_SAP_TRBGB_INVCRDDETS_NSCNT
DELETE FROM WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL WHERE BUSINESS_SERVICE_ID = 'SI_BS_SAP_TRBGB_INVCRDDETS_NSCNT';
--IFU4108 : Added entry for JAG and LR and removed the old entry
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_JAGNSCNT','SF_Logging_ToJAGNSCNT','OUT_JAG_NSCNT',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_LRNSCNT','SF_Logging_ToLRNSCNT','OUT_LR_NSCNT',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_JAGNSCNT','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_JAGNSCNT','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_LRNSCNT','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_LRNSCNT','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',2);

-- Log level entries for business service name - SI_BS_SAP_TRBGB_INVCRDDETS_NSCRU
DELETE FROM WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL WHERE BUSINESS_SERVICE_ID = 'SI_BS_SAP_TRBGB_INVCRDDETS_NSCRU';
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_NSCRU','SF_Logging_ToNSCRU','TRANSFORMED_MSG',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_NSCRU','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_NSCRU','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',2);

-- Log level entries for business service name - SI_BS_SAP_TRBGB_INVCRDDETS_PICC
DELETE FROM WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL WHERE BUSINESS_SERVICE_ID = 'SI_BS_SAP_TRBGB_INVCRDDETS_PICC';
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_PICC','SF_Logging_ToPICC','TRANSFORMED_MSG',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_PICC','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_PICC','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',2);

-- Log level entries for business service name - SI_BS_SAP_TRBGB_INVCRDDETS_SFS
DELETE FROM WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL WHERE BUSINESS_SERVICE_ID = 'SI_BS_SAP_TRBGB_INVCRDDETS_SFS';
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_SFS','SF_Logging_ToSFS','TRANSFORMED_MSG',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_SFS','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_SFS','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',2);


-- Log level entries for business service name - SI_BS_SAP_TRBGB_INVCRDDETS_AiOCN
DELETE FROM WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL WHERE BUSINESS_SERVICE_ID = 'SI_BS_SAP_TRBGB_INVCRDDETS_AiOCN';
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_AiOCN','SF_Logging_ToAiOCN','TRANSFORMED_MSG',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_AiOCN','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_AiOCN','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',2);

-- Log level entries for business service name - SI_BS_SAP_TRBGB_INVCRDDETS_AiOFR
DELETE FROM WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL WHERE BUSINESS_SERVICE_ID = 'SI_BS_SAP_TRBGB_INVCRDDETS_AiOFR';
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_AiOFR','SF_Logging_ToAiOFR','TRANSFORMED_MSG',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_AiOFR','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_AiOFR','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',2);

-- Log level entries for business service name - SI_BS_SAP_TRBGB_INVCRDDETS_D42
DELETE FROM WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL WHERE BUSINESS_SERVICE_ID = 'SI_BS_SAP_TRBGB_INVCRDDETS_D42';
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_D42','SF_Logging_Output','OUTPUT',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_D42','SF_Logging-Input','INPUT',2);

-- Log level entries for business service name - SI_BS_SAP_TRBGB_INVCRDDETS_LRFiSHKJ10
DELETE FROM WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL WHERE BUSINESS_SERVICE_ID = 'SI_BS_SAP_TRBGB_INVCRDDETS_LRFiSHKJ10';
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_LRFiSHKJ10','SF_Logging_ToFish','TRANSFORMED_MSG',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_LRFiSHKJ10','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_LRFiSHKJ10','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',2);

-- Log level entries for business service name - SI_BS_SAP_TRBGB_INVCRDDETS_JAVIS
DELETE FROM WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL WHERE BUSINESS_SERVICE_ID = 'SI_BS_SAP_TRBGB_INVCRDDETS_JAVIS';
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_JAVIS','SF_Logging_ToJAVIS','TRANSFORMED_MSG',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_JAVIS','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_JAVIS','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',2);

-- Log level entries for business service name - SI_BS_SAP_TRBGB_INVCRDDETS_VISTA
DELETE FROM WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL WHERE BUSINESS_SERVICE_ID = 'SI_BS_SAP_TRBGB_INVCRDDETS_VISTA';
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_VISTA','SF_Logging-Output','OUTPUT',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_VISTA','SF_Logging-Input','INPUT',2);

-- Log level entries for business service name - SI_BS_SAP_TRBGB_INVCRDDETS_ZA
DELETE FROM WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL WHERE BUSINESS_SERVICE_ID = 'SI_BS_SAP_TRBGB_INVCRDDETS_ZA';
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_ZA','SF_Logging_ToZA','TRANSFORMED_MSG',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_ZA','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_ZA','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',2);

-- Log level entries for business service name - SI_BS_SAP_TRBGB_INVCRDDETS_ESMALL
DELETE FROM WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL WHERE BUSINESS_SERVICE_ID = 'SI_BS_SAP_TRBGB_INVCRDDETS_ESMALL';
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_ESMALL','SF_Logging-Output','OUTPUT',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_INVCRDDETS_ESMALL','SF_Logging-Input','INPUT',2);

-- IFU-3907 IA-27 Log level entries [END]

-- 16/08/2016 TK Added new entries for IA-000027(IFU3907)
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_ESMALL_BAPMT_OUT','SF_Logging','IN_SAPESMALL_MQ',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_ESMALL_BAPMT_OUT','SF_Logging1','OUT_SAPESMALL_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_ESMALL_BAPMT_OUT','SF_Logging2','ERR_SAPESMALL_MQ',2);

-- 18/08/2016 KB Added new entries for FRS632 adapters
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_FLAGSD42_PRCMNFSTS_IN','SF_AD_HTTP_V2_Inbound.SF_Logging-Input','IN',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_FLAGSD42_PRCMNFSTS_IN','SF_AD_HTTP_V2_Inbound.SF_Logging-Output','OUT',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_FLAGSD42_PRCMNFSTS_IN','SF_AD_HTTP_V2_Inbound.SF_Logging-HTTPReply','HTTPReply',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_FLAGSD42_PRCMNFSTS_REPLY','SF_AD_HTTP_V2_Reply.SF_Logging-In','IN',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_FLAGSD42_PRCMNFSTS_REPLY','SF_AD_HTTP_V2_Reply.SF_Logging-Out','OUT',2);

-- 19/08/2016 KB Added new entries for IA44 adapters
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_D42_VEHSTSUPD_IN','SF_AD_HTTP_V2_Inbound.SF_Logging-Input','IN',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_D42_VEHSTSUPD_IN','SF_AD_HTTP_V2_Inbound.SF_Logging-Output','OUT',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_D42_VEHSTSUPD_IN','SF_AD_HTTP_V2_Inbound.SF_Logging-HTTPReply','HTTPReply',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_D42_VEHSTSUPD_REPLY','SF_AD_HTTP_V2_Reply.SF_Logging-In','IN',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_D42_VEHSTSUPD_REPLY','SF_AD_HTTP_V2_Reply.SF_Logging-Out','OUT',2);


-- 19/08/2016 SB Added new entries for FRS-266 adapters
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_LSZEB_VEHENGPARTS_IN','SF_AD_HTTP_V2_Inbound.SF_Logging-HTTPReply','Reply_HTTP',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_LSZEB_VEHENGPARTS_IN','SF_AD_HTTP_V2_Inbound.SF_Logging-Input','IN_HTTP',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_LSZEB_VEHENGPARTS_IN','SF_AD_HTTP_V2_Inbound.SF_Logging-Output','OUT_HTTP',2);


--IA-000293 Log level entries [START]
-- Log level entries for business service name - SI_BS_WAJ1_MFT_HR_SAP_TRBGB_TRADEUNION
--13/12/2016 SN added/updated logging level entry for Ia-000293 as part of defect 15
DELETE FROM WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL WHERE BUSINESS_SERVICE_ID = 'SI_BS_WAJ1_MFT_HR_SAP_TRBGB_TRADEUNION';
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WAJ1_MFT_HR_SAP_TRBGB_TRADEUNION','LogExecutionStart','FILE_RECEIVED',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WAJ1_MFT_HR_SAP_TRBGB_TRADEUNION','LogInputFile','INPUT_FILE',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WAJ1_MFT_HR_SAP_TRBGB_TRADEUNION','LogBusinessData','INPUT_BUSINESS_DATA',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WAJ1_MFT_HR_SAP_TRBGB_TRADEUNION','LogLoadError','ERROR',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WAJ1_MFT_HR_SAP_TRBGB_TRADEUNION','LogOutput','OUTPUT_IDOC',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WAJ1_MFT_HR_SAP_TRBGB_TRADEUNION','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WAJ1_MFT_HR_SAP_TRBGB_TRADEUNION','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',2);

-- IA-000293 Log level entries [END]

-- 30/08/2016 AT Added new entries for IA-000099
--12/12/2016 SN updated/inserted an entry as per defect15
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_HR_TO_SAP_TRGB_AVGSHIFT','LogInputAndBusinessData',2,'BUSINESS_DATA');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_HR_TO_SAP_TRGB_AVGSHIFT','LogInputFile',2,'INPUT_FILE');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_HR_TO_SAP_TRGB_AVGSHIFT','LogOutput',2,'OUTPUT_IDOC');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_HR_TO_SAP_TRGB_AVGSHIFT','SF_Batch_Data_Retriever.SF_Logging - Start of Batch',2,'BATCH_START');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_HR_TO_SAP_TRGB_AVGSHIFT','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch',2,'BATCH_END');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_HR_TO_SAP_TRGB_AVGSHIFT','LogExecutionStart',2,'BEGIN_EXECUTION');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_HR_TO_SAP_TRGB_AVGSHIFT','LogBatchLoadError',2,'ERROR_LOADING_BATCH');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_HR_TO_SAP_TRGB_AVGSHIFT','LogBatchFail',2,'BATCH_PROCESSING_FAILED');


--02/09/2016 HV added entry for IA-000148
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_NEOV_VEHSERV_SAP_TRBGB_PARTSPRICE','SF_Logging-BatchDataStore','OUT_BATCH',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_UNIPT_VEHSERV_SAP_TRBGB_PARTSPRICE','SF_Logging-InUnipart','IN_UNIPT',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_NEOV_VEHSERV_SAP_TRBGB_PARTSPRICE','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_NEOV_VEHSERV_SAP_TRBGB_PARTSPRICE','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_UNIPT_VEHSERV_SAP_TRBGB_PARTSPRICE','SF_Logging-ToSAP','OUT_SAP',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_NEOV_VEHSERV_SAP_TRBGB_PARTSPRICE','SF_Logging-ToSAP','OUT_SAP',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_UNIPT_VEHSERV_SAP_TRBGB_PARTSPRICE','SF_Logging_Error','ERR_UNIPT',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_NEOV_VEHSERV_SAP_TRBGB_PARTSPRICE','SF_Logging_Error','ERR_NEOV',2);

--14/09/2016 SN added entries for IA-97 as part of ESB remediation
--20/12/2016 SN Added new entries for IA-000097
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_HR_CVMS_EMPLOYEE_TRBGB_VEHICLES','SF_Logging-BatchDataStore','OUT_BATCH',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_HR_CVMS_EMPLOYEE_TRBGB_VEHICLES','SF_Logging-SAPOutbound','OUT_SAP',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_HR_CVMS_EMPLOYEE_TRBGB_VEHICLES','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_HR_CVMS_EMPLOYEE_TRBGB_VEHICLES','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_HR_CVMS_EMPLOYEE_TRBGB_VEHICLES','SF_Logging_Error','ERROR',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_HR_CVMS_EMPLOYEE_TRBGB_VEHICLES','SF_Logging-WholeFile','IN_WHOLE_FILE',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGBHR_ALEMT_OUT','SF_Logging','IN_SAPHR_MQ',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGBHR_ALEMT_OUT','SF_Logging1','OUT_SAPHR_AD',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGBHR_ALEMT_OUT','SF_Logging2','ERR_SAPHR_MQ',2);

--15/09/2016 HV added entries for IA-148 as part of ESB remediation 
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_ALEMT_OUT','SF_Logging','IN_SAP_MQ',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_ALEMT_OUT','SF_Logging2','ERR_SAP_MQ',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_ALEMT_OUT','SF_Logging1','OUT_ SAP_AD',2);

-- 16/09/2016 NM: Added entry for FRS-000828
-- NM 18/08/2017 IFU4823 Added entry to log Warning
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_FAST_INVOICE_SAP_TRBGB_FINANRECON','SF_Logging','IN_MQ',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_FAST_INVOICE_SAP_TRBGB_FINANRECON','SF_Logging1','OUT_FAST_APP',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_FAST_INVOICE_SAP_TRBGB_FINANRECON','SF_Logging2','IN_SAPTRB',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_FAST_INVOICE_SAP_TRBGB_FINANRECON','SF_Logging3','ERR_MQ',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_FAST_INVOICE_SAP_TRBGB_FINANRECON','SF_Logging4','WARNING',2);

-- 16/09/2016 AT: Added entry for IA000094
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_POSITION','LogInput','2','INPUT_IDOC');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_POSITION','LogBusinessData','2','INPUT_BUSINESS_DATA');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_POSITION','LogIDOCTrailer','2','INPUT_IDOC_TRAILER');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_POSITION','LogBatchLoadError','2','ERROR_LOADING_BATCH');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_POSITION','LogWAJBatch','2','WAJ_RECORD'); 
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_POSITION','LogWAJCompletion','2','WAJ_FILE_COMPLETE');

INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_POSITION','LogWAJBatchFail','2','ERROR_BATCH_PROCESSING');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_POSITION','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','2','BATCH_START');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_POSITION','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','2','BATCH_END');

-- 16/09/2016 AT: Added entry for IA000094 for adapter flow SI_AD_SAP_TRBGB_ALE_HR_PosSecData_MT_Inbound 
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_MQSERV_ALEINHRPOSDATA','LogIDOCPacket','2','IN_SAP');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_MQSERV_ALEINHRPOSDATA','LogIndividualIDOC','2','IN_IDOC');

-- 	19/09/2016 KB Added new entries for FRS-000712 HTTP adapters
-- 	20/09/2016 KB updated BSID for SI_AD_HTTP_MATERIALGXS_REPLY_V2,  FRS-000712 HTTP adapters
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_MATERIALGXS_INBOUND_V2','SF_Logging','IN',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_MATERIALGXS_INBOUND_V2','SF_Logging1','OUT',2);

INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_MATERIALGXS_OUTBOUND_V2','SF_Logging','IN',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_MATERIALGXS_OUTBOUND_V2','SF_Logging1','OUT',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_MATERIALGXS_OUTBOUND_V2','SF_Logging2','ERROR_HTTP',2);

INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_MATERIALGXS_REPLY_V2','SF_Logging','IN',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_HTTP_MATERIALGXS_REPLY_V2','SF_Logging1','OUT',2);

--21/09/2016 HV:Added entry for IA-44 as part of ESB remediation

Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_D42_VEH_SAP_TRBGB_VEHSTATUSUPD','LogInput','INPUT',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_D42_VEH_SAP_TRBGB_VEHSTATUSUPD','LogOutput','RESPONSE',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_D42_VEH_SAP_TRBGB_VEHSTATUSUPD','LogBAPIRequest','BAPI_REQUEST',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_D42_VEH_SAP_TRBGB_VEHSTATUSUPD','LogBAPIResponse','BAPI_RESPONSE',2);
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_D42_VEH_SAP_TRBGB_VEHSTATUSUPD','LogError','ERROR',2);

--21/09/2016 AT ESB Remediation: Added new SI_TRANSACTION_LOGGING_LEVEL Entry for FRS-000632
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_FLAGSD42PROC','SF_Logging-D42Input','2','IN_D42');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_FLAGSD42PROC','SF_Logging-FLAGS2Request','2','FLAGS2_REQ');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_FLAGSD42PROC','SF_Logging-FLAGS2Response','2','FLAGS2_RES');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_FLAGSD42PROC','SF_Logging-D42Output','2','D42_OUT');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_VEHSV_FLAGSD42PROC','SF_Logging-Error','2','ERROR'); 

--27/09/2016 SN Added entries for IA-95 as part of ESB remediation
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_MQSERV_ALEINHRCOSTCENTRE','SF_Logging-Input','IN_SAP',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_MQSERV_ALEINHRCOSTCENTRE','SF_Logging-IndividualIDOC','OUT_IDOC',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_COSTCENTRE','SF_Logging-Input','INPUT_IDOC',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_COSTCENTRE','SF_Logging-BusinessData','INPUT_BUSINESS_DATA',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_COSTCENTRE','SF_Logging-TrailerRec','INPUT_IDOC_TRAILER',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_COSTCENTRE','SF_Logging-BatchDataLoadErr','ERROR_LOADING_BATCH',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_COSTCENTRE','SF_Logging-ToWAJ1','WAJ_RECORD',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_COSTCENTRE','SF_Logging-EndOfFile','END_OF_FILE',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_COSTCENTRE','SF_Logging-BatchFail','ERROR_BATCH_PROCESSING',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_COSTCENTRE','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_COSTCENTRE','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',2);
--DEF15
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_COSTCENTRE','LogWAJ1File','WHOLE_WAJ1_FILE',2);


--28/09/2016 HV added entries for FRS-000266 as part of esb remidiation
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_LSZEB_VEHICLE_SAP_TRBGB_ENGPARTS','LogInput','INPUT',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_LSZEB_VEHICLE_SAP_TRBGB_ENGPARTS','LogBAPI','BAPI_REQUEST',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_LSZEB_VEHICLE_SAP_TRBGB_ENGPARTS','LogError','ERROR',2);

 --29/09/2016 NB Entry added for FRS-833
 --24/01/2018 SK Entry added for FRS-833(VOTS) as per IFU5190
--INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_PRODUCT_SAP_TRBGB_VALOBOM','SF_Logging','IN_XML',2);
--INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_PRODUCT_SAP_TRBGB_VALOBOM','SF_Logging1','OUT_SAP_IDOC',2);

INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_PRODUCT_SAP_TRBGB_VALOBOM','LogInput','IN_XML',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_PRODUCT_SAP_TRBGB_VALOBOM','LogToSAP','OUT_SAP_IDOC',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_PRODUCT_SAP_TRBGB_VALOBOM','LogToMFT','OUT_MFT',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_PRODUCT_SAP_TRBGB_VALOBOM','LogError','ERROR',2); 
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_PRODUCT_SAP_TRBGB_VALOBOM','LogErrorToMFT','ERROR_TO_MFT',2);

--30/09/2016 MG added entry for IA-000290 (ESB-Remediation)
--08/11/2016 SN Corrected entries of Business service flow of IA-290
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL)
values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_CUREMPDATA','LogInput','INPUT_IDOC',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL)
values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_CUREMPDATA','LogBusinessData','INPUT_BUSINESS_DATA',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL)
values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_CUREMPDATA','LogIDOCTrailer','INPUT_IDOC_TRAILER',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL)
values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_CUREMPDATA','LogBatchLoadError','ERROR_LOADING_BATCH',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL)
values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_MSXI_CUREMPDATA','LogMSXiBatch','MSXi_BATCH_RECORD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL)
values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_MSXI_CUREMPDATA','LogMSXiCompletion','MSXi_FILE_COMPLETE',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL)
values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_MEDGT_CUREMPDATA','LogMEDGATEBatch','MEDGATE_BATCH_RECORD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL)
values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_MEDGT_CUREMPDATA','LogMEDGATECompletion','MEDGATE_FILE_COMPLETE',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL)
values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_MSXI_CUREMPDATA','LogMSXiBatchFail','ERROR_MSXi_BATCH_PROCESSING',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL)
values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_MEDGT_CUREMPDATA','LogMEDGATEBatchFail','ERROR_MEDGATE_BATCH_PROCESSING',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL)
values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_MSXI_CUREMPDATA','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','MSXI_BATCH_START',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL)
values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_MSXI_CUREMPDATA','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','MSXI_BATCH_END',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL)
values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_MEDGT_CUREMPDATA','SF_Batch_Data_Retriever1.SF_Logging - Start of Batch','MEDGT_BATCH_START',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL)
values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_MEDGT_CUREMPDATA','SF_Batch_Data_Retriever1.SF_Batch_Complete.SF_Logging - End of batch','MEDGT_BATCH_END',2);

--05/10/2016: SK(IFU4148) :Added entries for FRS-000154 
--13/12/2016: AT(MNT)     :Updated  entries for FRS-000154 (Changes of logging level 2 and 3 based on SVCRM requirement)
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPACTVTY','SF_Logging','IN_CONSUMER',3);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPACTVTY','SF_Logging1','OUT_ACTIVITY_AD',2);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPACTVTY','SF_Logging2','IN_ACTIVITY_AD',2);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPACTVTY','SF_AcctCrtUpd_SVCRMV2.SF_Logging','REQ_CRT_UPD_ACCOUNT',3);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPACTVTY','SF_AcctCrtUpd_SVCRMV2.SF_Logging1','RES_CRT_UPD_ACCOUNT',3);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPACTVTY','SF_Logging3','REQ_CRT_UPD_ACTIVITY',3);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPACTVTY','SF_Logging4','RES_CRT_UPD_AVTIVITY',3);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPACTVTY','SF_Logging5','OUT_CONSUMER',3);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPACTVTY','SF_Logging6','ERR_RES_CRT_UPD_ACCOUNT',3);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPACTVTY','SF_Logging7','ERR_OUT',2);

--24/03/2017 SK DEF11764 Added SF_Logging5 entry for BSID 'SI_SV_CUSSV_CTUPACTVTY_ACTV'
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPACTVTY_ACTV','SF_Logging5','OUT_CONSUMER',3);

-- 	07/10/2016 KB Added new entries for FRS-000837 
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_INVOICE_PGZ_SBINV','SF_Logging','IN_REQ',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_INVOICE_PGZ_SBINV','SF_Logging1','OUT_PGZ',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_INVOICE_PGZ_SBINV','SF_Logging2','Error',2);

--17/10/2016 NB Entry added for FRS-261(IFU4163)
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_ALL_PARTS','SF_Logging_In','IN_FROM_SAP',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_ALL_PARTS','SF_Logging_Out_ToGXS','OUT_TO_GXS',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_ALL_PARTS','SF_Logging_Out_ToPGZ','OUT_TO_PGZ',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_ALL_PARTS','SF_Logging_Err','ERROR',2);

--22/10/2016 MJ Entry added for FRS-261(IFU4227)
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_GXS_VEHICLE_SAP_TRBGB_PARTS','SF_Logging_In','IN_FROM_GXS',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_GXS_VEHICLE_SAP_TRBGB_PARTS','SF_Logging_Out','OUT_TO_SAP',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_GXS_VEHICLE_SAP_TRBGB_PARTS','SF_Logging_Reply','REPLY_TO_GXS',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_GXS_VEHICLE_SAP_TRBGB_PARTS','SF_Logging_Err','ERROR',2);

-- 10/23/2016 HB Added Entry for FRS-790
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_ESM_VEHICLE_LMS_VEHUPDATES','SF_Logging_IN','IN_IDOC',2);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_ESM_VEHICLE_LMS_VEHUPDATES','SF_Logging_REQ','HTTP_REQ',2);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_ESM_VEHICLE_LMS_VEHUPDATES','SF_Logging_RESP','HTTP_RESP',2);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_ESM_VEHICLE_LMS_VEHUPDATES','SF_Logging_ERROR','ERROR',2);

--08/11/2016 SN Added Entry for IA-290 adapter entries
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_MQSERV_ALEINHRCURREMP','LogIDOCPacket','IN_IDOC_PACKET',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_MQSERV_ALEINHRCURREMP','LogIndividualIDOC','OUT_IDOC_SINGLE',2);


--08/11/2016 AM Added entries for IA258 as part of IFU4140/4141
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_INVOICE_HYPER_FIDATA','In_Data','In_Data',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_INVOICE_HYPER_FIDATA','Out_Data','Out_Data',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_INVOICE_HYPER_FIDATA','ERROR','ERROR',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_SMTCN_FIDATA_BAPI_IN_V2','SF_Logging','SF_Logging',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_SMTFR_FIDATA_BAPI_IN_V2','SF_Logging','SF_Logging',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (WMBOWNER.SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_ESMALL_FIDATA_BAPI_IN_V2','SF_Logging','SF_Logging',2);

--08/11/2016 MJ Entry added for IA-354(IFU4251)
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_HMRC_ALL_GDSRECEIPT','SF_Logging_In','IN_FROM_CMMS',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_HMRC_ALL_GDSRECEIPT','SF_Logging_Out_Ricardo','OUT_TO_RICARDO',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_HMRC_ALL_GDSRECEIPT','SF_Logging_Out_MFT','OUT_TO_MFT',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CMMS3_HMRC_ALL_GDSRECEIPT','SF_Logging_Err','ERROR',2);

--09/11/2016 PK Entry added for IA-000355(IFU4252)
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WIPS_HMRC_ALL_PRODPRICNG','SF_Logging- WIPS Input','INPUT_WIPS',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WIPS_HMRC_ALL_PRODPRICNG','SF_Logging-To Ricardo','OUTPUT_RICARDO',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WIPS_HMRC_ALL_PRODPRICNG','SF_Logging-ToMFT','OUTPUT_MFT_CUSSTOMS',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_WIPS_HMRC_ALL_PRODPRICNG','SF_Logging-Error','Error',2);

-- 14/11/2016 HB Added Entry for SAP Adapter IFU-4097
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_ESMALL_ALEST_OUT','SF_Logging_In_ToSAP','IN_FROM_SAP',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_ESMALL_ALEST_OUT','SF_Logging_SAPResp','OUT_TO_ESB',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_ESMALL_ALEST_OUT','SF_Logging_Err','ERROR',2);
-- 17/11/2016 HB Added Entry for IA-52 IFU-4097
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BBSS_CUSTOMER_ALL_CUSTDETALS','SF_Logging_In','FILE_IN_FROM_BBSS',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BBSS_CUSTOMER_ALL_CUSTDETALS','SF_Logging_DlyIn','DailyFileFromBBSS',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BBSS_CUSTOMER_ALL_CUSTDETALS','SF_Logging_MlyIn','MonthlyFileFromBBSS',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BBSS_CUSTOMER_ALL_CUSTDETALS','SF_Logging_ToSAP','To_SAP',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BBSS_CUSTOMER_ALL_CUSTDETALS','SF_Logging_ToWAJ1','To_WAJ1',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BBSS_CUSTOMER_ALL_CUSTDETALS','SF_Logging_ToDDWQ','To_ESBQUEUE ForDDW',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BBSS_CUSTOMER_ALL_CUSTDETALS','SF_Logging_ToMFTQ','To_ESBQUEUE ForMFT',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BBSS_CUSTOMER_ALL_CUSTDETALS','SF_Logging_ToDDW','To_DDW',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BBSS_CUSTOMER_ALL_CUSTDETALS','SF_Logging_ToMFTUrbSc','To_MFT_UrbanScience',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BBSS_CUSTOMER_ALL_CUSTDETALS','SF_Logging_ToMFTFlcrm','To_MFT_Fulcrum',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BBSS_CUSTOMER_ALL_CUSTDETALS','SF_Logging_ToMFTPolk','To_MFT_Polk',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BBSS_CUSTOMER_ALL_CUSTDETALS','SF_Logging_Err','Error',2);

--18/11/2016 VVS Added New entries for FRS155 as per the IFU4236(SI_SV_CreateUpdate_Appointment)
--13/12/2016: AT(MNT) :Updated  entries for FRS-000155 (Changes of logging level 2 and 3 based on SVCRM requirement)
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDAPPNT','SF_Logging','IN_CONSUMER',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDAPPNT','SF_Logging1','OUT_APPOINTMENT_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDAPPNT','SF_Logging2','IN_APPOINTMENT_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDAPPNT_SF_ACCT','SF_AcctCrtUpd_SVCRMV2.SF_Logging','REQ_CRT_UPD_ACCOUNT',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDAPPNT_SF_ACCT','SF_AcctCrtUpd_SVCRMV2.SF_Logging1','RES_CRT_UPD_ACCOUNT',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDAPPNT_SF_APPT','SF_AppointmentCrtUpd_SVCRM.SF_Logging','REQ_CRT_UPD_APPOINTMENT',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDAPPNT_SF_APPT','SF_AppointmentCrtUpd_SVCRM.SF_Logging1','RES_CRT_UPD_APPOINTMENT',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDAPPNT_SF_VEHACC','SF_VehicleAccountRelationship_CreateUpdate.SF_Logging','REQ_CRT_UPD_ACCVEHREL',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDAPPNT_SF_VEHACC','SF_VehicleAccountRelationship_CreateUpdate.SF_Logging1','RES_CRT_UPD_ACCVEHREL',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDAPPNT','SF_Logging3','ERR_RES',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDAPPNT','SF_Logging4','ERROR_REPLY',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CRTUPDAPPNT','SF_Logging5','SUCCESS_REPLY',3);

--18/11/2016 VVS Added New entries for FRS155 as per the IFU4236(SI_AD_CANONICAL_APPOINTMENT_MT_OUT)
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_APPOINTMENT','SF_Logging','CANACTAD_IN',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_APPOINTMENT','SF_Logging1','CANACTAD_TRANSF',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_APPOINTMENT','SF_Logging2','CANACTAD_OUT',2);

--24/11/2016 SK Added New entries for FRS156 as per the IFU4244(SI_SV_ReplicateCampaign)
--13/12/2016: AT(MNT) Updated  entries for FRS-000156 (Changes of logging level 2 and 3 based on SVCRM requirement)
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLCAMPGN','SF_Logging','IN_CONSUMER',3);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLCAMPGN','SF_Logging1','TO_CAN_TRANSF',2);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLCAMPGN','SF_Logging2','OUT_CAN_TRANS',2);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLCAMPGN_GRMS','SF_STD_SOAP_WS_CALL.SF_Logging','REQ_STD_SOAP',3);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLCAMPGN_GRMS','SF_STD_SOAP_WS_CALL.SF_Logging1','RES_STD_SOAP',3);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLCAMPGN_GRMS','SF_Logging3','SUCCESS_REPLY ',3);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLCAMPGN_GRMS','SF_Logging4','ERROR_REPLY ',3);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_REPLCAMPGN','SF_Logging4','ERROR_REPLY',3);

----25/11/2016 SK Added New entries for FRS156 as per the IFU4244(SI_AD_CANONICAL_CAMPAIGN_MT_OUT)
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_CAMPAIGN','SF_Logging','CANCAMPGN_IN',2); 

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_CAMPAIGN','SF_Logging1','CANCAMPGN_TRANSF',2);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_CANON_CAMPAIGN','SF_Logging2','CANCAMPGN_OUT',2);

----29/11/2016 LH Added New entries for FRS839

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_VENDORMASTER_DATASTORE','SF_Logging-In','IN',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_VENDORMASTER_DATASTORE','SF_Logging-Out','OUT',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BATCH_VENDORMASTER_TO_MFT','SF_Logging - Start of Batch','BATCH_START',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BATCH_VENDORMASTER_TO_MFT','SF_Batch_Complete.SF_Logging - End of batch - Start of Batch','BATCH_END',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BATCH_VENDORMASTER_TO_MFT','SF_Logging-Out','TRANSFORMED_MSG',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BATCH_VENDORMASTER_TO_MFT','SF_Logging-Discarded','DISCARDED_MSG',2);

----02/12/2016 AT Added New entries for FRS153
--13/12/2016: AT(MNT) Updated  entries for FRS-000153 (Changes of logging level 2 and 3 based on SVCRM requirement)
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CMPGNCRTUPD','SF_Logging','IN',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CMPGNCRTUPD','SF_Logging1','IN_CANACT_AD',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CMPGNCRTUPD','SF_Logging2','IN_SF_SVCRM_REQ',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CMPGNCRTUPD','SF_Logging3','OUT_CAN_RESP',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CMPGNCRTUPD','SF_Logging4','OUT',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CMPGNCRTUPD','SF_CampaignCrtUpd_SVCRMV2.SF_Logging','REQ_SAPCRM',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CMPGNCRTUPD','SF_CampaignCrtUpd_SVCRMV2.SF_Logging1','RESP_SAPCRM',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CMPGNCRTUPD','SF_CampaignCrtUpd_SVCRMV2.SF_Logging2','OUT_SF_SVCRM_RESP',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CMPGNCRTUPD','SF_CampaignCrtUpd_SVCRMV2.SF_Logging3','OUT_TRANS_ERROR',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CMPGNCRTUPD','SF_CampaignCrtUpd_SVCRMV2.SF_Logging4','OUT_FAIL',3);

----07/12/2016 AT Added New entries for FRS154 IFU4275
--13/12/2016: AT(MNT) Updated  entries for FRS-000154 (Changes of logging level 2 and 3 based on SVCRM requirement)
--03/05/2017:IFU4604 SK Updated entries(BSID and subflow name) for FRS-000154 Account
--11/07/2017:INC000002361203 APT Added entries(BSID and subflow name SF_Logging5,SF_Logging6 ) for FRS-000154  
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPACTVTY_ACCTCONT','SF_Crt_Upd_Acc_and_Contacts_SVCRM.SF_Logging','REQ_CRT_UPD_ACCOUNT',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPACTVTY_ACCTCONT','SF_Crt_Upd_Acc_and_Contacts_SVCRM.SF_Logging1','RES_CRT_UPD_ACCOUNT',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPACTVTY_ACCTCONT','SF_Logging5','OUT_CONSUMER',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPACTVTY_ACCTCONT','SF_Logging6','ERR_RES_CRT_UPD_ACCOUNT',2);


Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPACTVTY_ACTV','SF_Logging3','REQ_CRT_UPD_ACTIVITY',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_CUSSV_CTUPACTVTY_ACTV','SF_Logging4','RES_CRT_UPD_AVTIVITY',3);

----12/12/2016 MJ Added new entries for FRS841
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_AFRL_VEHICLE_ESB_LISTPRICE','SF_Logging','HTTP_GetListPrice_REQ',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_AFRL_VEHICLE_ESB_LISTPRICE','SF_Logging1','HTTP_SetListPrice_REQ',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_AFRL_VEHICLE_ESB_LISTPRICE','SF_Logging2','HTTP_SetListPrice_RESP',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_AFRL_VEHICLE_ESB_LISTPRICE','SF_Logging3','ERROR',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_AFRL_VEHICLE_ESB_LISTPRICE','SF_Logging4','OUT_MQ_ESB',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_AFRL_VEHICLE_ESB_LISTPRICE','SF_Logging5','HTTP_GetListPrice_RESP',2);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_VEHICLE_AFRL_LISTPRICE','SF_Logging','IN_MQ_ESB',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_VEHICLE_AFRL_LISTPRICE','SF_Logging1','HTTP_SetListPrice_REQ',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_VEHICLE_AFRL_LISTPRICE','SF_Logging2','BAPI_REQ',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_VEHICLE_AFRL_LISTPRICE','SF_Logging3','HTTP_SetListPrice_RESP',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_VEHICLE_AFRL_LISTPRICE','SF_Logging4','ERROR',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_VEHICLE_AFRL_LISTPRICE','SF_Logging5','HTTP_SetListPrice_REQ',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ESB_VEHICLE_AFRL_LISTPRICE','SF_Logging6','BAPI_RESP',2);

--12/12/2016 PK Added New entries for IFU4224(IA-000158) changes.
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ATD_VEH_ALL_SRODATA','SF_Logging','IN_ATD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ATD_VEH_ALL_SRODATA','SF_Logging1','OUT_SAPTRB',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ATD_VEH_ALL_SRODATA','SF_Logging2','OUT_TOPIX_JAG',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ATD_VEH_ALL_SRODATA','SF_Logging3','OUT_TOPIX_LR',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ATD_VEH_ALL_SRODATA','SF_Logging4','OUT_BOLLY',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ATD_VEH_ALL_SRODATA','SF_Logging5','OUT_WTRAN',2);

--14/12/2016 PM Added entries as per IFU4179
--Entries for business flow.
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_BILLG_SAP_ESMRT_ACCREIV','SF_Logging_FileIn','FILE_IN',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_BILLG_SAP_ESMRT_ACCREIV','SF_Logging_OutToSAP','OUT_TO_SAP',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_ALL_BILLG_SAP_ESMRT_ACCREIV','SF_Logging_Err','ERROR',2);

--Entries for adapter flow.
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_ESMALL_ALEMT_OUT_V2','SF_Logging_Req_In','REQ_IN_FROM_ESB_TO_SAP',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_ESMALL_ALEMT_OUT_V2','SF_Logging_Resp_In','RESP_FROM_SAP',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_ESMALL_ALEMT_OUT_V2','SF_Logging_Err','ERROR',2);


-- 12/12/2016 HB FRS-615
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_ALL_REPWTYCNTR','SF_Logging_ InSapAdapter','IN_SAP_AD',2);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_ALL_REPWTYCNTR','SF_Logging_InCanonAdapter','IN_CANONICAL_AD',2);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_ALL_REPWTYCNTR','SF_Logging_OutEsbBatch','OUT_ESBBATCH',2);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_ALL_REPWTYCNTR','SF_Logging_ErrorMq','ERROR_MQ',2);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_ALL_REPWTYCNTR','SF_Logging_InEsbBatch','IN_ESBBATCH',2);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_ALL_REPWTYCNTR','SF_Logging_OutFacWtySubs','OUT_FACWTYSUBS',2);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_ALL_REPWTYCNTR','SF_Logging_OutAws','OUT_AWS',2);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_ALL_REPWTYCNTR','SF_Logging_OutNaWtySubs','OUT_NAWTYSUBS',2);

Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_VEHICLE_ALL_REPWTYCNTR','SF_Logging_ErrorBatch','ERROR_BATCH',2);

--AaP Entries for FRS130 (GCM)IFU4264
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_DEALER_GCM_REPLICTEDR','SF_Logging','IN_CANON',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_DEALER_GCM_REPLICTEDR','SF_Logging1','OUT_BATCH',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_DEALER_GCM_REPLICTEDR','SF_Logging2','OUT_GCM',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_DEALER_GCM_REPLICTEDR','SF_Logging3','ERROR',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_DEALER_GCM_REPLICTEDR','SF_Logging4','ERROR',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_DEALER_GCM_REPLICTEDR','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_CANON_DEALER_GCM_REPLICTEDR','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',2);

-- 16/01/2017 CD Added entries for FRS-000838
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_MISC_PLO_VEHMNFSTAT','SF_Logging',2,'IN');
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_MISC_PLO_VEHMNFSTAT','SF_Logging1',2,'ERROR');

-- 18/01/2017 VK Added entries for FRS-000093
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_EMPDATACHANGES','LogMessageReceipt',2,'INPUT_IDOC');
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_EMPDATACHANGES','LogBusinessData',2,'INPUT_BUSINESS_DATA');
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_EMPDATACHANGES','LogIDOCTrailer',2,'INPUT_IDOC_TRAILER');
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_ALL_EMPDATACHANGES','LogBatchDataLoadFailure',2,'ERROR_LOADING_BATCH');
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_CARS_EMPDATACHANGES','LogCARSBatchRecord',2,'CARS_BATCH_RECORD');
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_CARS_EMPDATACHANGES','LogCARSFileCompletion',2,'CARS_FILE_COMPLETE');
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_CARS_EMPDATACHANGES','LogCARSBatchFail',2,'ERROR_CARS_BATCH_PROCESSING');
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_CARS_EMPDATACHANGES','SF_Batch_Data_Retriever.SF_Logging - Start of Batch',2,'CARS_BATCH_START');
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_CARS_EMPDATACHANGES','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch',2,'CARS_BATCH_END');
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_WAJ1_EMPDATACHANGES','LogWAJBatchRecord',2,'WAJ1_BATCH_RECORD');
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_WAJ1_EMPDATACHANGES','LogWAJFileCompletion',2,'WAJ1_FILE_COMPLETE');
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_WAJ1_EMPDATACHANGES','LogWAJBatchFail',2,'ERROR_WAJ1_BATCH_PROCESSING');
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_WAJ1_EMPDATACHANGES','SF_Batch_Data_Retriever1.SF_Logging - Start of Batch',2,'WAJ1_BATCH_START');
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_HR_WAJ1_EMPDATACHANGES','SF_Batch_Data_Retriever1.SF_Batch_Complete.SF_Logging - End of batch',2,'WAJ1_BATCH_END');

-- 26/01/2017 NM Added entries for IA-000096
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_HR_MSXI_SECRTYDATA','SF_Logging-Input','INPUT_IDOC',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_HR_MSXI_SECRTYDATA','SF_Logging-BusinessData','INPUT_BUSINESS_DATA',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_HR_MSXI_SECRTYDATA','SF_Logging-TrailerRec','INPUT_IDOC_TRAILER',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_HR_MSXI_SECRTYDATA','SF_Logging-BatchDataLoadErr','ERROR_LOADING_BATCH',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_HR_MSXI_SECRTYDATA','SF_Logging-ToMFT','MFT_TO_MSXI_FILE',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_HR_MSXI_SECRTYDATA','SF_Logging-BatchFail','ERROR_BATCH_PROCESSING',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_HR_MSXI_SECRTYDATA','SF_Batch_Data_Retriever.SF_Logging - Start of Batch','BATCH_START',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_HR_MSXI_SECRTYDATA','SF_Batch_Data_Retriever.SF_Batch_Complete.SF_Logging - End of batch','BATCH_END',2);

-- 28/01/2017 NB Added entries for SI_BS_PGZ_Vehicle_Weight_To_PLO Service IFU4253(FRS-000620)
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values(SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_VEHICLE_PLO_VEHWEIGHT','SF_Logging','IN_MQ_PGZVCATS',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values(SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_VEHICLE_PLO_VEHWEIGHT','SF_Logging1','IN_StoreQ',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values(SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_VEHICLE_PLO_VEHWEIGHT','SF_Logging2','IN_PLO_LookUP',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values(SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_VEHICLE_PLO_VEHWEIGHT','SF_Logging3','ERR_MQ_PGZVCATS',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values(SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_VEHICLE_PLO_VEHWEIGHT','SF_Logging4','OUT_MQ_PLO_Lookup',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values(SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_VEHICLE_PLO_VEHWEIGHT','SF_Logging5','IN_MQ_PLO',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values(SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_VEHICLE_PLO_VEHWEIGHT','SF_Logging6','ERR_MQ_PLO_Lookup',2);

-- 30/01/2017 CD Added entries for FRS-000815(IFU4373)
Insert into SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,LOGGING_LEVEL,SUBFLOW_DESC) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PLO_VEHICLE_PGZ_ORDER','SF_Logging3',2,'OUT_VISTA');

-- 10/02/2017 VK IA-000093 Added entries for SI_AD_SAP_TRBGB_ALE_HR_EmpDataChgs_MT_Inbound and SI_AD_SAP_TRBGB_ALE_HR_EmpDataChgs01_MT_Inbound adapters.
-- 27/02/2017 VK IA-000093 Made changes in entry for  SI_AD_SAP_TRBGB_ALE_HR_EmpDataChgs_MT_Inbound.
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values(SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_MQSERV_ALEINHREMPDATA','SF_AD_SAP_ALE_Inbound.LogIDOCPacket','IN_IDOC_PACKET',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values(SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_MQSERV_ALEINHREMPDATA','SF_AD_SAP_ALE_Inbound.LogIndividualIDOC','OUT_IDOC_SINGLE',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values(SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_MQSERV_ALEINHREMPDATA01','SF_AD_SAP_ALE_Inbound.LogIDOCPacket','IN_IDOC_PACKET',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values(SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SAP_TRBGB_MQSERV_ALEINHREMPDATA01','SF_AD_SAP_ALE_Inbound.LogIndividualIDOC','OUT_IDOC_SINGLE',2);


-- 18/2/2017 LH Inserted initial Entries for FRS-786
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL(ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL ) VALUES(SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_SMTCN_INVOICE_BRC_FUNDINGREQ', 'SF_Logging', 'IN_SAPSMTCN_AD', '2');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL(ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES(SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_SMTCN_INVOICE_BRC_FUNDINGREQ', 'SF_Logging1', 'OUT_BRC', '2');
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL(ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES(SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_SMTCN_INVOICE_BRC_FUNDINGREQ', 'SF_Logging2', 'ERR_MQ', '2');


-- 14/03/2017 MJ IFU-4438 Added entries for FRS-000107
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_VISTA_CUSSV_XROAD_ORDERREPL','LogInput','IN_FROM_VISTA','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_VISTA_CUSSV_XROAD_ORDERREPL','LogOutput','OUT_TO_XROAD','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_VISTA_CUSSV_XROAD_ORDERREPL','LogSuccess','XROAD_HTTP_SUCCEEDED','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_VISTA_CUSSV_XROAD_ORDERREPL','LogHTTPFailure','XROAD_HTTP_FAILED','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_VISTA_CUSSV_XROAD_ORDERREPL','LogHTTPError','XROAD_RETURNED_ERROR','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_VISTA_CUSSV_XROAD_ORDERREPL','LogError','TRANSACTION_FAILED','2');
INSERT INTO SI_TRANSACTION_LOGGING_LEVEL (ID, BUSINESS_SERVICE_ID, SUBFLOW_NAME, SUBFLOW_DESC, LOGGING_LEVEL) VALUES (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_VISTA_CUSSV_XROAD_ORDERREPL','LogIgnore','PROCESSING_CRITERIA_NOT_MET','2');

--28/02/2017 AaP Added New entry for FRS381 under IFU4418
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_INVSV_CLMSEXPORT','MSGFORMAT_SOAP_REQ','MSGFORMAT_SOAP_REQ',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_INVSV_CLMSEXPORT','REQUEST_SAP','REQUEST_SAP',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_INVSV_CLMSEXPORT','RESPONSE_SAP','RESPONSE_SAP',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_INVSV_CLMSEXPORT','MSGFORMAT_SOAP_RESP','MSGFORMAT_SOAP_RESP',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_SV_INVSV_CLMSEXPORT','ERROR_SOAP','ERROR_SOAP',2);

-- 16/03/2017 SK Added SI_TRANSACTION_LOGGING_LEVEL for adapter as part of adapter SI_AD_SOAP_STD_MT_Outbound_SYNC FRS-000115-IFU4500
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SOAP_STD_OUT_SYNC','SF_Logging','IN',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SOAP_STD_OUT_SYNC','SF_Logging1','REQ_STD_SOAP',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SOAP_STD_OUT_SYNC','SF_Logging2','RES_STD_SOAP',3);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_AD_SOAP_STD_OUT_SYNC','SF_Logging3','ERR_STD_SOAP',3);

-- 	20/03/2017 KB Added new entries for FRS-000620 SI_BS_VCATS_Vehicle_Weight_To_PLO 
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_VCATS_VEHICLE_PLO_VEHWEIGHT','SF_Logging','IN_VCATS',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_VCATS_VEHICLE_PLO_VEHWEIGHT','SF_Logging1','OUT_PLO',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_VCATS_VEHICLE_PLO_VEHWEIGHT','SF_Logging2','Error',2);

-- 	27/03/2017 KB Added new entries for IA-00067 SI_BS_D42_VEH_SAP_ESMALL_VEHEVENTS 
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_D42_VEH_SAP_ESMALL_VEHEVENTS','SF_Logging','IN',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_D42_VEH_SAP_ESMALL_VEHEVENTS','SF_Logging1','OUT',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_D42_VEH_SAP_ESMALL_VEHEVENTS','SF_Logging2','ERROR',2);

-- 	27/03/2017 KB Added new entries for IA-00067 SI_BS_D42_VEH_SAP_SMTALL_VEHEVENTS 
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_D42_VEH_SAP_SMTALL_VEHEVENTS','SF_Logging','IN',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_D42_VEH_SAP_SMTALL_VEHEVENTS','SF_Logging1','OUT',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_D42_VEH_SAP_SMTALL_VEHEVENTS','SF_Logging2','ERROR',2);

-- 27/03/2017 VK Restored Entries for IFU-4428
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_BBSS_CUSTOMER_ALL_CUSTDETALS','SF_Logging_ToSAPTurbo','To_SAP_Turbo',2);


-- 	04/04/2017 MJ Added new entries for FRS-107 IFU4515 
-- 	11/04/2017 MJ Updated entries for FRS-107 Map Suppliers
-- 	06/09/2017 VK Made changes for SI_BS_VISTA_CUSSV_MAPSUP_GOF_HERE from SUBFLOW_NAME='LogHTTPResFailure' to SUBFLOW_NAME='LogHTTPResFail'
-- 	07/09/2017 VK Made changes for SI_BS_VISTA_CUSSV_MAPSUP_GOF_NNG,SI_BS_VISTA_CUSSV_MAPSUP_GOF_AUTONAVI from SUBFLOW_NAME='LogHTTPResFailure' to SUBFLOW_NAME='LogHTTPResFail'
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_VISTA_CUSSV_MAPSUP_GOF','LogInputGOF','IN_FROM_VISTA',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_VISTA_CUSSV_MAPSUP_GOF','LogFlowError','TRANSACTION_FAILED',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_VISTA_CUSSV_MAPSUP_GOF_HERE','LogOutput','OUT_TO_MAPSU',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_VISTA_CUSSV_MAPSUP_GOF_HERE','LogHTTPResSuccess','HTTP_RES_SUCCEES',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_VISTA_CUSSV_MAPSUP_GOF_HERE','LogHTTPResFail','HTTP_RES_FAILED',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_VISTA_CUSSV_MAPSUP_GOF_HERE','LogHTTPResError','HTTP_RES_ERROR',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_VISTA_CUSSV_MAPSUP_GOF_NNG','LogOutput','OUT_TO_MAPSU',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_VISTA_CUSSV_MAPSUP_GOF_NNG','LogHTTPResSuccess','HTTP_RES_SUCCEES',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_VISTA_CUSSV_MAPSUP_GOF_NNG','LogHTTPResFail','HTTP_RES_FAILED',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_VISTA_CUSSV_MAPSUP_GOF_NNG','LogHTTPResError','HTTP_RES_ERROR',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_VISTA_CUSSV_MAPSUP_GOF_AUTONAVI','LogOutput','OUT_TO_MAPSU',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_VISTA_CUSSV_MAPSUP_GOF_AUTONAVI','LogHTTPResSuccess','HTTP_RES_SUCCEES',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_VISTA_CUSSV_MAPSUP_GOF_AUTONAVI','LogHTTPResFail','HTTP_RES_FAILED',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_VISTA_CUSSV_MAPSUP_GOF_AUTONAVI','LogHTTPResError','HTTP_RES_ERROR',2);


-- 	11/04/2017 KB Added new entries for FRS-000258 IFU4561 SI_BS_PGZ_VEHICLE_WLCAR_PRODCTRL 
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_VEHICLE_WLCAR_PRODCTRL','SF_Logging','REQ_PGZVCATS',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_VEHICLE_WLCAR_PRODCTRL','SF_Logging1','IN_PRODCTRL',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_VEHICLE_WLCAR_PRODCTRL','SF_Logging2','OUT_PRODCTRL',3);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PGZ_VEHICLE_WLCAR_PRODCTRL','SF_Logging3','ERR_PGZVCATS',3);


-- 	17/04/2017 MJ Added new entries for FRS-000259 IFU4514 PLO Vehicle Maps Property Data
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PLO_VEHICLE_ALL_VEHMAPPROP','SF_Logging','IN_PLO_AD',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PLO_VEHICLE_ALL_VEHMAPPROP','SF_Logging1','REQUEST_MAPSupplier',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PLO_VEHICLE_ALL_VEHMAPPROP','SF_Logging2','RESPONSE_MAPSupplier',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PLO_VEHICLE_ALL_VEHMAPPROP','SF_Logging3','ERROR_MAPSupplier',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_PLO_VEHICLE_ALL_VEHMAPPROP','SF_Logging4','ERROR_PLO',2);

-- 	21/04/2017 AM Added new entries for IA107 PODS Interface
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_VEHICLE_PODS_VNDRMASTER','SF_Logging','IN_SAP_AD',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_VEHICLE_PODS_VNDRMASTER','SF_Logging1','OUT_PODS',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_VEHICLE_PODS_VNDRMASTER','SF_Logging2','ERROR',2);
Insert into WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRB_VEHICLE_PODS_VNDRMASTER','SF_Logging3','IGNORE',2);

-- NM 16/01/2018 Commented entries for old flow as no longer required
-- 	09/06/2017 LH Added new entries for IA-000115 IFU4711 
/* INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_PAYMT_EIPAY_BACSFILE','SF_Logging','OUT',2);
INSERT INTO WMBOWNER.SI_TRANSACTION_LOGGING_LEVEL (ID,BUSINESS_SERVICE_ID,SUBFLOW_NAME,SUBFLOW_DESC,LOGGING_LEVEL) values (SI_TRANS_LOG_LEV_SEQ.NEXTVAL,'SI_BS_SAP_TRBGB_PAYMT_EIPAY_BACSFILE','SF_Logging1','ERROR',2); */


COMMIT ;