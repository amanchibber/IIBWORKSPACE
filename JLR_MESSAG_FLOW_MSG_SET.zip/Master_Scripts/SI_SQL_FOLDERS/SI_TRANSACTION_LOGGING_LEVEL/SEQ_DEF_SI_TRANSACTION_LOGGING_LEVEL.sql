--------------------------------------------------------------------------------------------------------
-- 	Author 			: Seenesh Patel
-- 	Version 		: $Revision: 1.2 $
--	Description 	: Create sequence definition script for SI_TRANSACTION_LOGGING_LEVEL table
-- 	History 		: 04/02/15 SP Initial creation statement
--------------------------------------------------------------------------------------------------------

DROP SEQUENCE SI_TRANS_LOG_LEV_SEQ;
		
CREATE SEQUENCE SI_TRANS_LOG_LEV_SEQ
MINVALUE 1
START WITH 1
INCREMENT BY 1
CACHE 10;							 

COMMIT;

