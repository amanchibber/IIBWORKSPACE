--------------------------------------------------------------------------------------------------------
-- 	Author 			: Seenesh Patel
-- 	Version 		: $Revision: 1.3 $
--	Description 	: Create table definition script for SI_TRANSACTION_LOGGING_LEVEL table which will hold details of logging levels for monitoring events
-- 	History 		: 04/02/15 SP Initial creation statement
--					: 10/02/15 SP Addition of SUBFLOW_DESC
--------------------------------------------------------------------------------------------------------

DROP TABLE SI_TRANSACTION_LOGGING_LEVEL;

CREATE TABLE SI_TRANSACTION_LOGGING_LEVEL ( 
	ID NUMBER(10) NOT NULL,
	BUSINESS_SERVICE_ID VARCHAR2(45), 
	SUBFLOW_NAME VARCHAR2(150),
	SUBFLOW_DESC VARCHAR2(150),
	LOGGING_LEVEL NUMBER(1),
	INSERT_TIMESTAMP TIMESTAMP NULL,
	UPDATE_TIMESTAMP TIMESTAMP NULL,
	CONSTRAINT PK_SI_TRANS_LOG_LEVEL_ID PRIMARY KEY (BUSINESS_SERVICE_ID, SUBFLOW_NAME)
);

