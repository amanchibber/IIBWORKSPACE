--------------------------------------------------------------------------------------------------------
-- Author 		: Paul Gregory
-- Version 		: 
-- Description 	: Create data script for SI_WARNING_CODE table which will hold all SI USer WARNING codes 
-- History 		: 02/01/2015 Paul Gregory Skeleton insert statement for table
--------------------------------------------------------------------------------------------------------
DELETE FROM WMBOWNER.SI_WARNING_CODE ;

Insert into WMBOWNER.SI_WARNING_CODE (WARNING_CODE,BUSINESS_SERVICE_ID,WARNING_SHORT_DESRIPTION,USER_ID,WARNING_DESCRIPTION) values ('W000000001','xxx','xxx','xxx','xxx');



COMMIT ;