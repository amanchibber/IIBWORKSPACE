--------------------------------------------------------------------------------------------------------
-- Author 		: Paul Gregory
-- Version 		: $Revision: 1.2 $
-- Description 	: Create table script for SI_WARNING_CODE table
-- History 		: 12/12/2014 Initial create statement for table
--				  09/02/2015 renamed WARNING_SHORT_DESRIPTION to WARNING_SHORT_DESCRIPTION
-------------------------------------------------------------------------------------------------------

DROP TABLE SI_WARNING_CODE;

CREATE TABLE SI_WARNING_CODE 
(WARNING_CODE  VARCHAR2(10) NOT NULL,
BUSINESS_SERVICE_ID	VARCHAR2(50) NOT NULL,
WARNING_SHORT_DESCRIPTION	VARCHAR2(100) NOT NULL,
USER_ID	VARCHAR2(10) , 
WARNING_DESCRIPTION	VARCHAR2(4000) ,
INSERT_TIMESTAMP	TIMESTAMP,
UPDATE_TIMESTAMP	TIMESTAMP,
CONSTRAINT "SI_WARNING_PK" PRIMARY KEY ("WARNING_CODE")) ;
