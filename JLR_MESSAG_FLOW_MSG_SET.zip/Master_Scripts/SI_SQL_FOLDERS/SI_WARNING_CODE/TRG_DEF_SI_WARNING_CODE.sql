--------------------------------------------------------------------------------------------------------
-- Author 		: Paul Gregory
-- Version 		: $Revision: 1.2 $
-- Description 	: Create trigger script for SI_WARNING_CODE table  
-- History 		: 23/12/2014 Paul Gregory Initial create statement for trigger
--------------------------------------------------------------------------------------------------------

DROP TRIGGER SI_WARNG_CD_TMSTMP_TRG;

--Trigger which will insert or update the timestamp if an insert or update action occurs
CREATE OR REPLACE
TRIGGER SI_WARNG_CD_TMSTMP_TRG
BEFORE INSERT OR UPDATE ON SI_WARNING_CODE
FOR EACH ROW
BEGIN

IF INSERTING THEN
	:new.INSERT_TIMESTAMP := systimestamp;
	:new.UPDATE_TIMESTAMP := NULL;
ELSE
	:new.UPDATE_TIMESTAMP := systimestamp;
  END IF;
END;
/
COMMIT;
