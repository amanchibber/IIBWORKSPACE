Originally IPLM used a single policy set: 
27/11/2014: We found that this was returning timestamp in the SOAPReply so split into two IPLMPolicySets. The Provider set having Timestamp removed.
IPLMPolicySet
So IPLMPolicySet is redundant