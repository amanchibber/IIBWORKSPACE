########################################################################################################
## Version 		: (Auto generated from build process)
## Description 	: Script to create FtpServer configurable services for object: CS_OBJECT_NAME
## History 		: DATE_TIME FTPServer Template
########################################################################################################

#Broker name - do not change the below property value
BROKER_NAME=componentName

#Property values should be set as <Object_Name>.<Configurable_Service_Property_Name>
#Object_Name is the name of the component or object to create the configurable service for
#Configurable_Service_Property_Name is the property name for the configurable service
#For example MONEX_FTP.client

#FtpServer properties 
ACCOUNT_INFO=CS_OBJECT_NAME.accountInfo
SCAN_DELAY=CS_OBJECT_NAME.scanDelay
PROTOCOL=CS_OBJECT_NAME.protocol
TRANSFER_MODE=CS_OBJECT_NAME.transferMode
CONNECTION_TYPE=CS_OBJECT_NAME.connectionType
REMOTE_DIRECTORY="CS_OBJECT_NAME.remoteDirectory"
SECURITY_IDENTITY=CS_OBJECT_NAME.securityIdentity
FTP_SERVER_NAME=CS_OBJECT_NAME.serverName
TIMEOUT_SECONDS=CS_OBJECT_NAME.timeoutSec
SECID_USERNAME=CS_OBJECT_NAME.userName
SECID_PASSWORD=CS_OBJECT_NAME.password


# Sanity checking the input values
if [ "$SECID_PASSWORD" = "TBC" ]; then  
    echo "Please enter password for user $SECID_USERNAME for security identity $SECURITY_IDENTITY"
    read SECID_PASSWORD
fi

for i in $ACCOUNT_INFO $SCAN_DELAY $PROTOCOL $TRANSFER_MODE $CONNECTION_TYPE $REMOTE_DIRECTORY $SECURITY_IDENTITY $FTP_SERVER_NAME $TIMEOUT_SECONDS $SECID_USERNAME $SECID_PASSWORD 
do
  if [ "$i" = "TBC" ]; then  
    echo "WARNING: TBC found in variables! Please check script - exiting now."
    exit -1;
  fi 
done


# Delete object for CS_OBJECT_NAME
mqsisetdbparms $BROKER_NAME -n ftp::$SECURITY_IDENTITY -d

# Create object for CS_OBJECT_NAME
mqsisetdbparms $BROKER_NAME -n ftp::$SECURITY_IDENTITY -u $SECID_USERNAME -p $SECID_PASSWORD


#FtpServer configurable service definition which can be used for FileInput, FileOutput and FileRead nodes
mqsideleteconfigurableservice $BROKER_NAME -c FtpServer -o CS_OBJECT_NAME

mqsicreateconfigurableservice $BROKER_NAME -c FtpServer -o CS_OBJECT_NAME -n accountInfo,scanDelay,protocol,transferMode,connectionType,remoteDirectory,securityIdentity,serverName,timeoutSec -v $ACCOUNT_INFO,$SCAN_DELAY,$PROTOCOL,$TRANSFER_MODE,$CONNECTION_TYPE,"$REMOTE_DIRECTORY",$SECURITY_IDENTITY,$FTP_SERVER_NAME,$TIMEOUT_SECONDS

# Create the local directory
function checkDir {
        # Check if directory doesn't exist
        if [ ! -d $1 ]
        then
                echo "Creating directory $1"
                mkdir -p $1
        else
                echo "$1 already exists..."
        fi
}

checkDir 'CS_OBJECT_NAME.localDirectory'


