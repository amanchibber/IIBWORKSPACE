########################################################################################################
## Version 		: (Auto generated from build process)
## Description 	: Script to set the HTTP details for Execution Group: CS_OBJECT_NAME
########################################################################################################

BROKER_NAME=componentName
EG_NAME=CS_OBJECT_NAME
HTTPPORT=CS_OBJECT_NAME.httpPortNumber

# Sanity checking the input values
for i in $BROKER_NAME $EG_NAME $HTTPPORT
do
  if [ "$i" = "TBC" ]; then  
    echo "WARNING: TBC found in variables! Please check script - exiting now."
    exit -1;
  fi 
done

# Check if the Port Number was overridden
if [[ "$HTTPPORT" == *httpPortNumber ]]; then 
   echo "WARNING: Error found in variables! Please check script - exiting now."
   exit -1;
fi 

##############
## HTTP Config
##############
mqsichangeproperties $BROKER_NAME -e $EG_NAME -o ExecutionGroup -n httpNodesUseEmbeddedListener -v true
mqsichangeproperties $BROKER_NAME -e $EG_NAME -o HTTPConnector -n explicitlySetPortNumber -v $HTTPPORT
