########################################################################################################
## Version 		: (Auto generated from build process)
## Description 	: Script to set the HTTP and HTTPS details for Execution Group: CS_OBJECT_NAME
########################################################################################################

BROKER_NAME=componentName
EG_NAME=CS_OBJECT_NAME
HTTPSPORT=CS_OBJECT_NAME.httpsPortNumber

# Sanity checking the input values
for i in $BROKER_NAME $EG_NAME $HTTPSPORT
do
  if [ "$i" = "TBC" ]; then  
    echo "WARNING: TBC found in variables! Please check script - exiting now."
    exit -1;
  fi 
done

# Check if the Port Number was overridden
if [[ "$HTTPSPORT" == *httpsPortNumber ]]; then 
   echo "WARNING: Error found in variables! Please check script - exiting now."
   exit -1;
fi 

###############
## HTTPS Config
###############
mqsichangeproperties $BROKER_NAME -e $EG_NAME -o ExecutionGroup -n httpNodesUseEmbeddedListener -v true
mqsichangeproperties $BROKER_NAME -e $EG_NAME -o HTTPSConnector -n clientAuth -v CS_OBJECT_NAME.clientAuth
mqsichangeproperties $BROKER_NAME -e $EG_NAME -o HTTPSConnector -n sslProtocol -v SSL
mqsichangeproperties $BROKER_NAME -e $EG_NAME -o HTTPSConnector -n explicitlySetPortNumber -v $HTTPSPORT
