########################################################################################################
## Version 	: (Auto generated from build process)
## Description 	: CS_OBJECT_NAME Monitoring Profile created from template
## History 		: DATE_TIME - created as part of build process
########################################################################################################

#Broker name
BROKER_NAME=componentName

#Monitoring profile properties
EG_NAME=CS_OBJECT_NAME.EGName
FLOW_NAME=CS_OBJECT_NAME.FlowName
PROFILE_NAME=CS_OBJECT_NAME.ProfileName
PROFILE_PATH=CS_OBJECT_NAME.ProfilePath
PROFILE_FILE=CS_OBJECT_NAME.ProfileFileName


# Sanity checking the input values
for i in $EG_NAME $FLOW_NAME $PROFILE_NAME $PROFILE_PATH $PROFILE_FILE
do
  if [ "$i" = "TBC" ]; then  
    echo "WARNING: TBC found in variables! Please check script - exiting now."
    exit -1;
  fi 
done


# Delete configurable service if one already exists
mqsideleteconfigurableservice $BROKER_NAME -c MonitoringProfiles -o $PROFILE_NAME

# Set up the new configurable service to message broker flow
mqsicreateconfigurableservice $BROKER_NAME -c MonitoringProfiles -o $PROFILE_NAME

# Associate your monitoring profile with the configurable service
mqsichangeproperties $BROKER_NAME -c MonitoringProfiles -o $PROFILE_NAME -n profileProperties -p "$PROFILE_PATH"/$PROFILE_FILE


# Apply a monitoring profile configurable service to a message flow.
mqsichangeflowmonitoring $BROKER_NAME -e $EG_NAME -f $FLOW_NAME -m $PROFILE_NAME

# Activate Monitoring Profile for the flow
mqsichangeflowmonitoring $BROKER_NAME -e $EG_NAME -f $FLOW_NAME -c active
