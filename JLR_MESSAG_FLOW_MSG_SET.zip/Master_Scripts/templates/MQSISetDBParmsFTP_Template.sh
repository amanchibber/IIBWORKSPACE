########################################################################################################
## Version 		: (Auto generated from build process)
## Description 	: Script to for the mqsisetdbparms command for object: CS_OBJECT_NAME
## History 		: DATE_TIME mqsisetdbparms Template
########################################################################################################

#Broker name - do not change the below property value
BROKER_NAME=componentName

#Property values should be set as <Object_Name>.<Configurable_Service_Property_Name>
#Object_Name is the name of the component or object to create the configurable service for
#Configurable_Service_Property_Name is the property name for the configurable service
#For example MONEX_FTP.client

#Properties 
PROTOCOL=CS_OBJECT_NAME.protocol
SECURITY_IDENTITY=CS_OBJECT_NAME.securityIdentity
SECID_USERNAME=CS_OBJECT_NAME.userName
SECID_PASSWORD=CS_OBJECT_NAME.password


# Sanity checking the input values
if [ "$SECID_PASSWORD" = "TBC" ]; then  
    echo "Please enter password for user $SECID_USERNAME for security identity $SECURITY_IDENTITY"
    read SECID_PASSWORD
fi

for i in $ACCOUNT_INFO $SCAN_DELAY $PROTOCOL $TRANSFER_MODE $CONNECTION_TYPE $REMOTE_DIRECTORY $SECURITY_IDENTITY $FTP_SERVER_NAME $TIMEOUT_SECONDS $SECID_USERNAME $SECID_PASSWORD 
do
  if [ "$i" = "TBC" ]; then  
    echo "WARNING: TBC found in variables! Please check script - exiting now."
    exit -1;
  fi 
done


# Delete object for CS_OBJECT_NAME
mqsisetdbparms $BROKER_NAME -n ftp::$SECURITY_IDENTITY -d

# Create object for CS_OBJECT_NAME
mqsisetdbparms $BROKER_NAME -n ftp::$SECURITY_IDENTITY -u $SECID_USERNAME -p $SECID_PASSWORD
