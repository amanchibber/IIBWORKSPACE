########################################################################################################
## Version 		: (Auto generated from build process)
## Description 	: Script to for the mqsisetdbparms command for object: CS_OBJECT_NAME
## History 		: DATE_TIME mqsisetdbparms Template
########################################################################################################

#Broker name - do not change the below property value
BROKER_NAME=componentName
ADPT_NAME=CS_OBJECT_NAME

#Property values should be set as <Object_Name>.<Configurable_Service_Property_Name>
#Object_Name is the name of the component or object to create the configurable service for
#Configurable_Service_Property_Name is the property name for the configurable service
#For example MONEX_FTP.client

#Properties 
SAP_USERNAME=SAP_DEFAULT_OBJECT.userName
SAP_PASSWORD=SAP_DEFAULT_OBJECT.password


# Sanity checking the input values
if [ "$SAP_PASSWORD" = "TBC" ]; then  
    echo "Please enter password for SAP user $SAP_USERNAME"
    read SAP_PASSWORD
fi

for i in $ADPT_NAME $SECID_USERNAME $SECID_PASSWORD 
do
  if [ "$i" = "TBC" ]; then  
    echo "WARNING: TBC found in variables! Please check script - exiting now."
    exit -1;
  fi 
done


# Delete adapter object for CS_OBJECT_NAME
mqsisetdbparms $BROKER_NAME -n eis::$ADPT_NAME -d

# Create adapter object for CS_OBJECT_NAME
mqsisetdbparms $BROKER_NAME -n eis::$ADPT_NAME -u $SAP_USERNAME -p $SAP_PASSWORD
