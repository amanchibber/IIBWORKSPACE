########################################################################################################
## Version 	: (Auto generated from build process)
## Description 	: SAP CS_OBJECT_NAME adapter created from template
## History 		: DATE_TIME - created as part of build process
########################################################################################################

#Broker name
BROKER_NAME=componentName
ADPT_NAME=CS_OBJECT_NAME

#SAP Properties
APPLICATION_SERVER_HOST=SAP_DEFAULT_OBJECT.applicationServerHost
CLIENT=SAP_DEFAULT_OBJECT.client
LOAD_BALANCING=SAP_DEFAULT_OBJECT.loadBalancing
LOGON_GROUP=SAP_DEFAULT_OBJECT.logonGroup
MESSAGE_SERVER_HOST=SAP_DEFAULT_OBJECT.messageServerHost
SAP_SYSTEM_ID=SAP_DEFAULT_OBJECT.SAPSystemID
SYSTEM_NUMBER=SAP_DEFAULT_OBJECT.systemNumber
SHARED_TID_STORE_CLIENT_DEFINITION_FILE=SAP_DEFAULT_OBJECT.sharedTidStoreClientDefinitionFile
SHARED_TID_STORE_QMGR=SAP_DEFAULT_OBJECT.sharedTidStoreQmgr
SAP_USERNAME=SAP_DEFAULT_OBJECT.userName
SAP_PASSWORD=SAP_DEFAULT_OBJECT.password


# Default Values
CONNECTION_IDLE_TIMEOUT=15
RFC_TRACE_ENABLED=false
RFC_TRACE_LEVEL=4
RFC_TRACE_PATH=/home/mqm


# Sanity checking the input values
if [ "$SAP_PASSWORD" = "TBC" ]; then  
    echo "Please enter password for SAP user $SAP_USERNAME"
    read SAP_PASSWORD
fi

for i in $APPLICATION_SERVER_HOST $CLIENT $LOAD_BALANCING $LOGON_GROUP $MESSAGE_SERVER_HOST $SAP_SYSTEM_ID $SYSTEM_NUMBER $SHARED_TID_STORE_CLIENT_DEFINITION_FILE $SHARED_TID_STORE_QMGR $SAP_USERNAME $SAP_PASSWORD
do
  if [ "$i" = "TBC" ]; then  
    echo "WARNING: TBC found in variables! Please check script - exiting now."
    exit -1;
  fi 
done


# Delete adapter object for CS_OBJECT_NAME
mqsisetdbparms $BROKER_NAME -n eis::$ADPT_NAME -d

# Create adapter object for CS_OBJECT_NAME
mqsisetdbparms $BROKER_NAME -n eis::$ADPT_NAME -u $SAP_USERNAME -p $SAP_PASSWORD

# Delete configurable service for CS_OBJECT_NAME
mqsideleteconfigurableservice $BROKER_NAME -c SAPConnection -o $ADPT_NAME

# Create configurable service for CS_OBJECT_NAME
mqsicreateconfigurableservice $BROKER_NAME -c SAPConnection -o $ADPT_NAME -n applicationServerHost,client,connectionIdleTimeout,loadBalancing,logonGroup,messageServerHost,RFCTraceOn,RFCTraceLevel,RFCTracePath,SAPSystemID,systemNumber,sharedTidStoreClientDefinitionFile,sharedTidStoreQmgr -v $APPLICATION_SERVER_HOST,$CLIENT,$CONNECTION_IDLE_TIMEOUT,$LOAD_BALANCING,$LOGON_GROUP,$MESSAGE_SERVER_HOST,$RFC_TRACE_ENABLED,$RFC_TRACE_LEVEL,$RFC_TRACE_PATH,$SAP_SYSTEM_ID,$SYSTEM_NUMBER,$SHARED_TID_STORE_CLIENT_DEFINITION_FILE,$SHARED_TID_STORE_QMGR
