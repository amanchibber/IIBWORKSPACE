########################################################################################################
## Version 		: (Auto generated from build process)
## Description 	: Script to create SMTP configurable services for object: CS_OBJECT_NAME
## History 		: DATE_TIME SMTP Template
########################################################################################################

#Broker name - do not change the below property value
BROKER_NAME=componentName

#Property values should be set as <Object_Name>.<Configurable_Service_Property_Name>
#Object_Name is the name of the component or object to create the configurable service for
#Configurable_Service_Property_Name is the property name for the configurable service
#For example: MONEX_SMTP.accountInfo

#SMTP properties 
SERVER_NAME=CS_OBJECT_NAME.serverName
SECURITY_IDENTITY=CS_OBJECT_NAME.securityIdentity
SECID_USERNAME=CS_OBJECT_NAME.userName
SECID_PASSWORD=CS_OBJECT_NAME.password


# Sanity checking the input values
if [ "$SECID_PASSWORD" = "TBC" ]; then  
    echo "Please enter password for user $SECID_USERNAME for security identity $SECURITY_IDENTITY"
    read SECID_PASSWORD
fi

for i in $SERVER_NAME $SECURITY_IDENTITY $SECID_USERNAME $SECID_PASSWORD
do
  if [ "$i" = "TBC" ]; then  
    echo "WARNING: TBC found in variables! Please check - exiting now."
    exit -1;
  fi 
done



#Delete Security identity which is used to access the SMTP server
mqsisetdbparms $BROKER_NAME -n smtp::$SECURITY_IDENTITY -d

#Security identity which is used to access the SMTP server
mqsisetdbparms $BROKER_NAME -n smtp::$SECURITY_IDENTITY -u $SECID_USERNAME -p $SECID_PASSWORD


#SMTP configurable service definition which can be used for EmailOutput node
mqsideleteconfigurableservice $BROKER_NAME -c SMTP -o CS_OBJECT_NAME

mqsicreateconfigurableservice $BROKER_NAME -c SMTP -o CS_OBJECT_NAME -n serverName,securityIdentity -v $SERVER_NAME,$SECURITY_IDENTITY
