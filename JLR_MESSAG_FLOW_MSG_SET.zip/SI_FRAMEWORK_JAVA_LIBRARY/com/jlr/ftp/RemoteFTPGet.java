package com.jlr.ftp;

/****
 * Description: This flow reads a files from remote directory using FTP or using site commands  
 * based on if site command is passed and copies them to local directory location provided. 
 * * MUST declare org.apache.commons.net as external library dependency
 */

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;

public class RemoteFTPGet extends MbJavaComputeNode {
	
	// read the user-defined properties into static class variables
	private static String FTP_HOST = "";
	private static String FTP_USER_NAME = "";
	private static String FTP_PWORD = "";
	private static String WORKING_DIR = "";
	private static String LOCAL_DIR_LOC = "";	
	private static String SEND_CMD = "";	
	private static String SEND_SITE_CMD = "";
	private static Boolean DELETE_SOURCE_FILE;
	private static String FTP_EXCEPTION_CODE = "";
	
	//@TODO look to implement some level of debug capability.
	//	private static String DEBUG_LOG_LOC = "DebugLogLocation";

	// Initialise class objects
	InputStream is = null;
	OutputStream os = null;
	FTPClient client = null;

	public void onInitialize() throws MbException {
		// The user defined external attributes.
		FTP_HOST = (String) getUserDefinedAttribute("FTPHost");
		FTP_USER_NAME = (String) getUserDefinedAttribute("FTPUserName");
		FTP_PWORD = (String) getUserDefinedAttribute("FTPPword");
		WORKING_DIR = (String) getUserDefinedAttribute("WorkingDirectory");
		LOCAL_DIR_LOC = (String) getUserDefinedAttribute("LocalDirectoryLocation");
		SEND_CMD = (String) getUserDefinedAttribute("SendCommand");	
		SEND_SITE_CMD = (String) getUserDefinedAttribute("SendSiteCommand");
		DELETE_SOURCE_FILE = (Boolean) getUserDefinedAttribute("DeleteSourceFile");
		FTP_EXCEPTION_CODE = (String) getUserDefinedAttribute("FTPExceptionCode");
	}	
	
	public void evaluate(MbMessageAssembly inAssembly) throws MbException 
	{
		/**
		 * At this point we have the list of filenames (with substitutions complete) to retrieve from the z/os ftp
		 * 
		 */
				
		MbOutputTerminal out = getOutputTerminal("out");	
		MbOutputTerminal alt = getOutputTerminal("alternate");
		MbOutputTerminal failure = getOutputTerminal("failure");		
		
		MbMessage outMessage = new MbMessage();  // create new, empty message for output
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly,outMessage); // create the output message assembly (msg + envs + exception)
		try 
		{	
			client = new FTPClient();  // create new FTP object		
			client.connect(FTP_HOST); // using promoted properties connect to z/os	
			boolean login = client.login(FTP_USER_NAME, FTP_PWORD); // login to z/os ftp and capture result			
			client.setFileType(FTP.ASCII_FILE_TYPE);  // set the file xfer type to be ASCII
			
				if (login)  // successfully logged in
				{	String strFILENAME = "";
					MbElement inLocalEnv = inAssembly.getLocalEnvironment().getRootElement(); 
					MbElement FILENAME = inLocalEnv.getFirstElementByPath("Destination/File/Name"); 	
					
					if ((WORKING_DIR != null) && (WORKING_DIR != "")){ 
						client.changeWorkingDirectory(WORKING_DIR);  // If working directory supplied, cd to it 		
					}else{
						MbElement workingDirElm = inLocalEnv.getFirstElementByPath("Destination/File/Remote/WorkingDirectory"); 
						
						if (workingDirElm != null) {
							String workingDir = workingDirElm.getValueAsString();
							client.changeWorkingDirectory(workingDir);
						}
					}
					
					//@TODO add a condition here such as exception on ftp get?
					while ((FILENAME != null) && (FILENAME.getValue().toString() != ""))  // Iterate round all the File Names in the LocalEnvironment
					{	strFILENAME = FILENAME.getValue().toString(); // Set the name of this remote file based on the value passed in to this node via the LocalEnvironment 
						// Create a new FileOutputStream to write the remote file to a local directory.    
						// Create local file with same name as remote				
						os = new FileOutputStream(LOCAL_DIR_LOC + strFILENAME);		// creates an empty local file into which to copy the remote file				
						
						if ((SEND_CMD != null) && (SEND_CMD != "")){
							client.sendCommand(SEND_CMD);} // 	1) Program call such as find the instance of z/os FTP using address space control (ASC) mode

						if ((SEND_SITE_CMD != null) && (SEND_SITE_CMD != "")){
							client.sendSiteCommand(SEND_SITE_CMD);}  //2) 	e.g. Preserve trailing blanks.
						
						boolean myBool = client.retrieveFile(strFILENAME, os);  // "ftp get" the file, and write it to the FileOutputStream (created above)
						// @TODO - we want the process to stop here.  We have a list of files, to get but we can't get one of them.
						if (myBool == false) // If the "ftp get" completed as false, something went wrong, so build a warning.
						{	
							//Delete file from local directory in case remote file transfer fails
							File localFile = new File(LOCAL_DIR_LOC, strFILENAME);
							os.flush();  // close and flush any files
							os.close();
							localFile.delete();
							
							String e = "ERROR: Could not retrieve file: " + strFILENAME + " from HOST: " + FTP_HOST + " User: " + FTP_USER_NAME;
							MbElement globalEnv = inAssembly.getGlobalEnvironment().getRootElement();
							MbElement parent = globalEnv;
							MbElement globalEnvWarnings = parent.getFirstElementByPath("/XMLNSC");
							if(globalEnvWarnings == null) globalEnvWarnings = parent.createElementAsLastChild(MbElement.TYPE_NAME, "XMLNSC", null);
							parent = globalEnvWarnings;
							globalEnvWarnings = parent.getFirstElementByPath("Warnings");
							if(globalEnvWarnings == null) globalEnvWarnings = parent.createElementAsLastChild(MbElement.TYPE_NAME, "Warnings", null);
							MbElement globalEnvSource = globalEnvWarnings.createElementAsLastChild(MbElement.TYPE_NAME, "Source", null);	
							globalEnvSource.createElementAsLastChild(MbXMLNSC.ATTRIBUTE, "FileName", strFILENAME);  // save filename and warning message to Environment
							globalEnvSource.createElementAsLastChild(MbElement.TYPE_NAME, "WarningMsg", e);
						}
						else
						{
							os.flush();  // close and flush any files
							os.close();
						}
						if (DELETE_SOURCE_FILE)
						{	client.deleteFile(strFILENAME);	 // Delete the file on the remote system	
	
						}
						FILENAME = FILENAME.getNextSibling(); // Get the next Name in the LocalEnvironment
									
				} // end while
				client.logout();
			}
			else // login failed @TODO Test
			{	String e = "ERROR: Could not log in to server! " + "HOST: " + FTP_HOST + " User: " + FTP_USER_NAME;
				MbException(e);
			}				
			client.disconnect();  // Disconnect from the FTPClient	
			out.propagate(outAssembly);  // Propagate message to the 'out' terminal
		} // end of try
		
		catch (NullPointerException np) {MbException(np);}
		catch (IOException io) {MbException(io);}
		
		finally  // Final catch block to close all connections before exit. Although there is no guarantee of when this will run
		{	if (client.isConnected())		// ftp client		
				try {client.disconnect();} 
					catch (IOException e) {e.printStackTrace();}		
			if (os != null) 				//outputStream - connection to the local filesystem
				try {os.flush(); os.close();} 
					catch (IOException e){e.printStackTrace();}
		}
	}

	private Exception MbException(String e) throws MbUserException {
		// wrap Exception 'e' in MbUserException 'mbe' (BIPERROR)
		String className = "FTPClient";
		String methodName = "Connect";
		final MbUserException mbe = new MbUserException(className, methodName,
				"Exception Message", FTP_EXCEPTION_CODE, e, null);
		throw mbe;
	}

	private void MbException(IOException io) throws MbUserException {
		// wrap Exception 'eIO' in MbUserException 'mbeio' (BIPERROR)
		String className = "FTPClient";
		String methodName = "IO Exception";
		// find class/method name, from exception stack
		if (io.getStackTrace().length > 0) {
			className = io.getStackTrace()[0].getClassName();
			methodName = io.getStackTrace()[0].getMethodName();
		}
		// extract detail message and backtrace from exception, for inserts
		final StringWriter text = new StringWriter();
		final PrintWriter pw = new PrintWriter(text);
		io.printStackTrace(pw);
		pw.close();
		// populate message inserts, specific to User Exception XXXX
		final Object[] inserts = new String[] { text.toString(), this.getName() };
		final MbUserException mbeio = new MbUserException(className,
				methodName, "Exception Message", FTP_EXCEPTION_CODE, io.getMessage(),
				inserts);
		mbeio.initCause(io);
		throw mbeio;
	}

	private void MbException(NullPointerException np) throws MbUserException {
		// wrap Exception 'eIO' in MbUserException 'mbeio' (BIPERROR)
		String className = "FTPClient";
		String methodName = "NullPointer Exception";
		// find class/method name, from exception stack
		if (np.getStackTrace().length > 0) {
			className = np.getStackTrace()[0].getClassName();
			methodName = np.getStackTrace()[0].getMethodName();
		}
		// extract detail message and backtrace from exception, for inserts
		final StringWriter text = new StringWriter();
		final PrintWriter pw = new PrintWriter(text);
		np.printStackTrace(pw);
		pw.close();
		// populate message inserts, specific to User Exception XXXX
		final Object[] inserts = new String[] { text.toString(), this.getName() };
		final MbUserException mbenp = new MbUserException(className,
				methodName, "Exception Message", FTP_EXCEPTION_CODE, np.getMessage(),
				inserts);
		mbenp.initCause(np);
		throw mbenp;
	}

}
