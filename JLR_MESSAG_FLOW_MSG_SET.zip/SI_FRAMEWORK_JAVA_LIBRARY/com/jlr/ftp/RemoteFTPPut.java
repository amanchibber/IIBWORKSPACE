//Author: Karthick Thangavel
//Updated: Lakhan Hake
//Changed CCSID from 500 to 1208, Handled return code 250 for changeWorkingDirectory. Corrected if condition for creating new directory
//19/09/2017 - DEF22203/DEF22221 - Promoted CCSID and Encoding properties.
/****
 * Description: This flow creates an FTP session on trigger by input of any message parser
 * into the JCN.  The JCN dynamically takes the file name from the localEnvironment under the 
 * following location -
 * 
 * LocalEnvironment
 * 		|_ Destination
 * 				|_ File
 * 					|_ Remote
 * 						|_ ServerDirectory
 * 						|_ SiteCommand
 * 
 * The node takes the input body of any parser type and this is the stream used as the file 
 * in the put.  
 * 
 * * MUST declare org.apache.commons.net as external library dependency
 */

package com.jlr.ftp;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.SocketException;
import java.util.List;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXPath;

public class RemoteFTPPut extends MbJavaComputeNode {
	// Debug options
	private boolean debug = false;

	// access the user-defined properties here
	private static String FTP_HOST = "FTPHost";
	private static String FTP_USER_NAME = "FTPUserName";
	private static String FTP_PWORD = "FTPPword";
	private static String REMOTE_DIR = "RemoteDirectory";
	private static String DEBUG_LOG_LOC = "DebugLogLocation";
	private static String SITE_COMMAND = "SiteCommand";
	private static String FTP_EXCEPTION_CODE = "FTPExceptionCode";
	// Initialising Integer values
	private static Integer CCSID = 1208;
	private static Integer Encoding = 273;
	
	private static boolean OVERWRITE_FILE;
	private static boolean CREATE_REMOTE_DIRECTORY_IFNOTEXIST;
	private static boolean TRANSFER_MODE_ASCII;
			
	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		
		// Initialise variables
		ByteArrayInputStream bs = null;
		OutputStream os = null;
		FTPClient client = null;
		int returncode;
		String leRemoteDir, leSiteCommand = null;
		
		MbOutputTerminal out = getOutputTerminal("out");
		// MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();

		// create new message
		MbMessage outMessage = new MbMessage();
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly,
				outMessage);
		
		try {
			// copy message headers
			copyMessageHeaders(inMessage, outMessage);
			
			// Get the MessageSet, MessageType and MessageFormat
			// from the Properties
			MbElement mSetElm = inAssembly.getMessage().getRootElement()
					.getFirstChild().getFirstElementByPath("MessageSet");
			MbElement mTypElm = inAssembly.getMessage().getRootElement()
					.getFirstChild().getFirstElementByPath("MessageType");
			MbElement mFmtElm = inAssembly.getMessage().getRootElement()
					.getFirstChild().getFirstElementByPath("MessageFormat");

			String mSet = mSetElm.getValueAsString();
			String mTyp = mTypElm.getValueAsString();
			String mFmt = mFmtElm.getValueAsString();
			
			//Promoted property
			Integer encod = Encoding;
			Integer ccsid = CCSID;
			
			

			/********************************************************/
			// Output if in debug mode			
			if (debug) {
				System.out.println("FTP Host Name is: " + FTP_HOST);
				System.out.println("FTP User Name is: " + FTP_USER_NAME);
				System.out.println("FTP Password is: " + FTP_PWORD);
				System.out.println("FTP Working Directory is: " + REMOTE_DIR);
				System.out.println("FTP Put will overwrite: " + OVERWRITE_FILE);
			}
			/********************************************************/
			
			//Reference to Local Environment
			MbElement inLocalEnv = inAssembly.getLocalEnvironment().getRootElement();
			
			//Get Remote file directory path from Local Environment if available
			//NOTE: Remote Directory should be available in LocalEnvironment.Destination.File.Remote.ServerDirectory
			List<MbElement> el = (List<MbElement>) inLocalEnv.evaluateXPath("/File/Remote/ServerDirectory");
			String remoteDiretoryPath = null;
			for (MbElement element : el ) {
				if (remoteDiretoryPath == null) {
					remoteDiretoryPath = element.getValueAsString();
					REMOTE_DIR = remoteDiretoryPath;
				}
			}
			//Get Remote Site Command from Local Environment if available
			//NOTE: Site Command should be available in LocalEnvironment.Destination.File.Remote.SiteCommand
			el = (List<MbElement>) inLocalEnv.evaluateXPath("/File/Remote/SiteCommand");
			String checkSiteCommand = null;
			for (MbElement element : el ) {
				if (checkSiteCommand == null) {
					checkSiteCommand = element.getValueAsString();
					SITE_COMMAND = checkSiteCommand;
				}
			}
			
			// create new FTP session
			client = new FTPClient();

			// connect using externalised values promoted to property
			client.connect(FTP_HOST);
			boolean login = client.login(FTP_USER_NAME, FTP_PWORD);
			
			if (login) {

				// successfully logged in
				/********************************************************/
				if (debug) {
					System.out.println("Login success...");
				}
				/********************************************************/
				
				// Check if REMOTE_DIR is populated
				// change to that directory if it exist 
				//LH corrected condition in IF
				//if (REMOTE_DIR != null && REMOTE_DIR == "tmp") {
				if (REMOTE_DIR != null && REMOTE_DIR != "tmp") {
					client.changeWorkingDirectory(REMOTE_DIR);
					//Check remote ftp directory exist
					returncode = client.getReplyCode();
					//If remote directory doesn't exist, then create remote directory and change working directory.
					if(returncode == 550 && CREATE_REMOTE_DIRECTORY_IFNOTEXIST == true) {
						boolean success = client.makeDirectory(REMOTE_DIR);
						if (success) {
							client.changeWorkingDirectory(REMOTE_DIR);
						}else {
							// Remote directory doesn't exist or couldn't create.
							String e = "ERROR: Remote folder doesn't exist on " + "HOST: " + FTP_HOST + " User: " + FTP_USER_NAME + "and " + FTP_USER_NAME + 
									"user doesn't have access to create new remote directory. Remote Directory is " + REMOTE_DIR;
							MbException(e);
						}
					}
					else if(returncode == 250) {
						//LH added this else if condition to avoid error on successful change in directory
						//nothing to do here
					}
					else {
						// Remote directory doesn't exist.
						String e = "ERROR: Remote folder doesn't exist on " + "HOST: " + FTP_HOST + " User: " + FTP_USER_NAME + "and " + FTP_USER_NAME;
						MbException(e);
					}
				}
				
				 el = (List<MbElement>) inLocalEnv.evaluateXPath("/File/Name");
				 
				// Iterate round the elements in the LocalEnvironment
				for (MbElement element : el) {
					
					String fileName = element.getValueAsString();
					
					if (fileName.equals(null) || fileName.equals("")) {
						// Remote File name not specified.
						String e = "ERROR: Remote file name not specified " + "HOST: " + FTP_HOST + " User: " + FTP_USER_NAME + "and " + FTP_USER_NAME;
						MbException(e);
					}
					
					MbElement inputBody = inAssembly.getMessage()
							.getRootElement().getLastChild();
					
					// Convert Message to Bitstream
					byte[] msgAsBytes = inputBody.toBitstream(mTyp, mSet, mFmt,
							encod, ccsid, 0);
					
					// Converting to string and back doesn't work for EBCDIC lowercase
					//String msgAsText = new String(msgAsBytes);
					
					//ByteArrayInputStream bs = new ByteArrayInputStream(
						//	msgAsText.getBytes());
					
					bs = new ByteArrayInputStream(msgAsBytes) ;
					
					// Check if the file should be overwritten
					if (OVERWRITE_FILE) {
						
						// Delete the file if it currently exists
						client.deleteFile(fileName);
					
					}			
						
					// Set the SiteCommand 
					if (SITE_COMMAND != null) {
						client.sendSiteCommand(SITE_COMMAND);
					}
					
					//Check if transfer mode is ASCII
					if (TRANSFER_MODE_ASCII) {
						client.setFileType(FTP.ASCII_FILE_TYPE);
					}else {
						// default transfer mode is set to binary format
						client.setFileType(FTP.BINARY_FILE_TYPE);
					}
					
						
					// Put File
					boolean filePutResponse = client.appendFile(fileName, bs);
					
					if(!filePutResponse)
					{
						int failureReplyCd = client.getReplyCode();
						String[] failureReplyDesc = client.getReplyStrings();
						
						String e = "ERROR: Filename transfer failed! " + "Filename: " + fileName + "Reply Code: " + failureReplyCd + "Reply Description: " + failureReplyDesc;
						
						MbException(e);
					}
				// close InputStream which is not closed by call
				bs.close();
					
				}
				
			} else if (login == false) {

				// login failed
				String e = "ERROR: Could not log in to server! " + "HOST: " + FTP_HOST + " User: " + FTP_USER_NAME;
				
				MbException(e);
			}
			
			// Propagate message to the 'out' terminal
			out.propagate(outAssembly);

		} catch (SocketException io) {
			/********************************************************/
			if (debug) {
				FileOutputStream fos;
				try {
					fos = new FileOutputStream(new File(DEBUG_LOG_LOC
							+ "SocketException"));
					PrintStream ps = new PrintStream(fos);
					io.printStackTrace(ps);
					// return;
				} catch (FileNotFoundException e) {
					// Do nothing
					e.printStackTrace();
				}
			}
			/********************************************************/
			// throw message broker user exception
			MbException(io);
		} catch (IOException io) {
			/********************************************************/
			if (debug) {
				FileOutputStream fos;
				try {
					fos = new FileOutputStream(new File(DEBUG_LOG_LOC
							+ "IOException"));
					PrintStream ps = new PrintStream(fos);
					io.printStackTrace(ps);
					// return;
				} catch (FileNotFoundException e) {
					// Do nothing
					e.printStackTrace();
				}
			}
			/********************************************************/
			// throw message broker user exception
			MbException(io);
		} finally {

			if (client.isConnected())
				try {
					client.disconnect();
				} catch (IOException e) {
					// Do Nothing
					e.printStackTrace();
				}
			if (bs != null)
				try {
					bs.close();
				} catch (IOException e) {
					// Do Nothing
					e.printStackTrace();
				}
			if (os != null)
				try {
					os.flush();
					os.close();
				} catch (IOException e) {
					// Do Nothing
					e.printStackTrace();
				}

			/********************************************************/

			// clear the outMessage even if there's an exception
			outMessage.clearMessage();
		}

	}

	public void copyMessageHeaders(MbMessage inMessage, MbMessage outMessage)
			throws MbException {
		MbElement outRoot = outMessage.getRootElement();

		// iterate though the headers starting with the first child of the root
		// element
		MbElement header = inMessage.getRootElement().getFirstChild();
		while (header != null && header.getNextSibling() != null) // stop before
		// the last
		// child
		// (body)
		{
			// copy the header and add it to the out message
			outRoot.addAsLastChild(header.copy());
			// move along to next header
			header = header.getNextSibling();
		}
	}

	private void MbException(IOException io) throws MbUserException {

		// wrap Exception 'eIO' in MbUserException 'mbeio' (BIPERROR)
		String className = "Unknown";
		String methodName = "Unknown";

		// find class/method name, from exception stack
		if (io.getStackTrace().length > 0) {
			className = io.getStackTrace()[0].getClassName();
			methodName = io.getStackTrace()[0].getMethodName();
		}

		// extract detail message and backtrace from exception, for inserts
		final StringWriter text = new StringWriter();
		final PrintWriter pw = new PrintWriter(text);
		io.printStackTrace(pw);
		pw.close();

		// populate message inserts, specific to User Exception XXXX
		final Object[] inserts = new String[] { text.toString(), this.getName() };

		final MbUserException mbeio = new MbUserException(className,
				methodName, "BIPmsgs", "ERROR_CODE_TBC", io.getMessage(),
				inserts);

		// optionally, set e as the cause of mbue
		mbeio.initCause(io);

		throw mbeio;

	}

	private Exception MbException(String e) throws MbUserException {

		// wrap Exception 'e' in MbUserException 'mbe' (BIPERROR)
		String className = "FTPClient";
		String methodName = FTP_EXCEPTION_CODE;

		final MbUserException mbe = new MbUserException(className, methodName,
				"BIPmsgs", "ERROR_CODE_TBC", e, null);

		throw mbe;
	}

	public void onInitialize() throws MbException {
		// The user defined external attributes.
		FTP_HOST = (String) getUserDefinedAttribute("FTPHost");
		FTP_USER_NAME = (String) getUserDefinedAttribute("FTPUserName");
		FTP_PWORD = (String) getUserDefinedAttribute("FTPPword");
		REMOTE_DIR = (String) getUserDefinedAttribute("RemoteDirectory");
		DEBUG_LOG_LOC = (String) getUserDefinedAttribute("DebugLogLocation");
		SITE_COMMAND = (String) getUserDefinedAttribute("SiteCommand");
		FTP_EXCEPTION_CODE = (String) getUserDefinedAttribute("FTPExceptionCode");
		CCSID = (Integer) getUserDefinedAttribute("CCSID");
		Encoding = (Integer) getUserDefinedAttribute("Encoding");
		OVERWRITE_FILE = (Boolean) getUserDefinedAttribute("OverwriteRemoteFile");
		CREATE_REMOTE_DIRECTORY_IFNOTEXIST = (Boolean) getUserDefinedAttribute("CreateRemoteDirectoryIfNotExist");
		TRANSFER_MODE_ASCII = (Boolean) getUserDefinedAttribute("TransferModeASCII");
	}

}
