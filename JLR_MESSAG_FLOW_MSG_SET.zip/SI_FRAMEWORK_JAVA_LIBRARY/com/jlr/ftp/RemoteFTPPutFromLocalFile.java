//Author: Ryan Glackin (rglackli)
//Updated: Amith Sannagowdar (asannago)
/****
 * Description: This flow creates an FTP session on trigger by any input from a preceding node to it 'Input'
 * terminal. The JCN dynamically takes the file name and local directory location from the localEnvironment under the 
 * following location -
 * 
 * LocalEnvironment
 * 		|_ Destination
 * 				|_ File
 * 					|_ Name
 * 					|_ Directory
 * 
 * The node takes the file based on the details present in the above structured LocalEnvironment and this is the stream used as the file 
 * in the put.  The radio buttons offer either append or overwrite and as this is z/os specific, a UDP is provided for 
 * JLR site commands .
 * 
 * * MUST declare org.apache.commons.net as external library dependency
 */

package com.jlr.ftp;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.SocketException;
import java.util.List;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;

public class RemoteFTPPutFromLocalFile extends MbJavaComputeNode {

	// Debug options
	private boolean debug = false;

	// access the user-defined properties here
	private static String FTP_HOST = "FTPHost";
	private static String FTP_USER_NAME = "FTPUserName";
	private static String FTP_PWORD = "FTPPword";
	private static String WORKING_DIR; // = "WorkingDirectory";
	private static String DEBUG_LOG_LOC = "DebugLogLocation";
	private static String SITE_COMMAND; // = "SiteCommand";
	private static String FTP_EXCEPTION_CODE = "FTPExceptionCode";
	private static boolean OVERWRITE_FILE;
	private static boolean TRANSFER_MODE_ASCII;

	// file read block size
	protected static final int BLKSIZ = 16384;
	
	// Initialise variables
	InputStream is = null;
	ByteArrayInputStream bs = null;
	OutputStream os = null;
	FTPClient client = null;
	boolean filePutResponse = false;
	String fileName = null, sourceFileDirectory = null, remoteFileDirectory = null, siteCommand=null;
	
	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		
		// Initialise variables
		//int returncode;
		
		MbOutputTerminal out = getOutputTerminal("out");
		// MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();

		// create new message
		MbMessage outMessage = new MbMessage();
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly,
				outMessage);

		
		try {
			// copy message headers
			copyMessageHeaders(inMessage, outMessage);					

			/********************************************************/
			// Output if in debug mode
			if (debug) {
				System.out.println("FTP Host Name is: " + FTP_HOST);
				System.out.println("FTP User Name is: " + FTP_USER_NAME);
				System.out.println("FTP Password is: " + FTP_PWORD);
				System.out.println("FTP Working Directory is: " + WORKING_DIR);
				System.out.println("FTP Put will overwrite: " + OVERWRITE_FILE);
			}
			/********************************************************/
			
			//SB added start1
			
			//Reference to Local Environment
			MbElement inLocalEnv = inAssembly.getLocalEnvironment().getRootElement();
			
			//Get Remote file directory path from Local Environment if available
			//NOTE: Remote Directory should be available in LocalEnvironment.Destination.File.Remote.ServerDirectory
			MbElement serverfileDirElm = inLocalEnv.getFirstElementByPath("Destination/File/Remote/ServerDirectory");

			// If remote server directory is not provided in local environment then use the UDP value
			if (serverfileDirElm != null){
				WORKING_DIR = serverfileDirElm.getValueAsString();
			}
			
			//Get Remote Site Command from Local Environment if available
			//NOTE: Site Command should be available in LocalEnvironment.Destination.File.Remote.SiteCommand
			MbElement remoteSiteCommandElm = inLocalEnv.getFirstElementByPath("Destination/File/Remote/SiteCommand");

			// If remote SITE command is not provided in local environment then use the UDP value
			if (remoteSiteCommandElm != null){
				SITE_COMMAND = serverfileDirElm.getValueAsString();
			}
						
			//SB added end1
			
			// create new FTP session
			client = new FTPClient();

			// connect using externalised values promoted to property
			client.connect(FTP_HOST);
			boolean login = client.login(FTP_USER_NAME, FTP_PWORD);

			// Check if WORKING_DIR is populated and
			// change to that directory if it is
			if (WORKING_DIR != null && WORKING_DIR != "tmp") {
				client.changeWorkingDirectory(WORKING_DIR);
			}
			
			if (login) {

				// successfully logged in
				/********************************************************/
				if (debug) {
					System.out.println("Login success...");
				}
				/********************************************************/
				
				//Check if transfer mode is ASCII
				if (TRANSFER_MODE_ASCII) {
					client.setFileType(FTP.ASCII_FILE_TYPE);
				}else {
					// default transfer mode is set to binary format
					client.setFileType(FTP.BINARY_FILE_TYPE);
				}	
				
				//MbElement inLocalEnv = inAssembly.getLocalEnvironment().getRootElement();

				// get local directory name element from LocalEnvironment.Destination.File.Directory. This is the source file name
				MbElement sourcefileDirElm = inLocalEnv.getFirstElementByPath("Destination/File/Directory");

				if (sourcefileDirElm != null)
					sourceFileDirectory = sourcefileDirElm.getValueAsString();
				else
					MbException("ERROR: Source directory not set in the LocalEnvironment tree at location Destination/File/Directory, so it is not possible to read the file that is to be FTPed from the local file system");

				MbElement fileNameElm = inLocalEnv.getFirstElementByPath("Destination/File/Name");

				// get file name element from LocalEnvironment.Destination.File.Name. This is the source file name
				if (fileNameElm != null)
					fileName = fileNameElm.getValueAsString();
				else
					MbException("ERROR: Source file name is not set in the LocalEnvironment tree at location Destination/File/Name, so it is not possible to read the file that is to be FTPed from the local file system");
				
				// Check if the file should be overwritten
				if (OVERWRITE_FILE) {
					// Delete the file if it currently exists
					client.deleteFile(fileName);
				}
				
				// Set the SiteCommand 
				if (SITE_COMMAND != null && SITE_COMMAND != "tmp") {
				//client.sendSiteCommand("LRECL=1420 RECFM=FB");
					client.sendSiteCommand(SITE_COMMAND);
				}
				
				// In the current case, the source file name is same as target file name (although one can easily externalise the target file name)
				filePutResponse = sendFromFileSystem(sourceFileDirectory, fileName, fileName, client, is, os); // NOTE:
				// The code above has already done "client.changeWorkingDirectory()" using "TargetFileDirectory", hence it is not passed in this call
				// else read the message from the input stream
				
				if (!filePutResponse) {
					int failureReplyCd = client.getReplyCode();
					String[] failureReplyDesc = client.getReplyStrings();
					String failureReplyDescConcat = "";

					// concatenate error description array
					StringBuilder errStringBuilder = new StringBuilder();
					for (String aDescr : failureReplyDesc) {
						errStringBuilder.append(aDescr + " ");
					}
					failureReplyDescConcat = errStringBuilder.toString();

					String e = "ERROR: Filename transfer failed! " + "Filename: " + fileName + "Reply Code: " + failureReplyCd + "Reply Description: " + failureReplyDescConcat;

					MbException(e);
				}
				
				// close InputStream which is not closed by call
				if (bs != null)
					bs.close();

				client.logout();
				client.disconnect();

			} else if (login == false) {

				// login failed
				String e = "ERROR: Could not log in to server! " + "HOST: " + FTP_HOST + " User: " + FTP_USER_NAME;
				
				MbException(e);
			}
			
			// Propagate message to the 'out' terminal
			out.propagate(outAssembly);

		} catch (SocketException io) {
			/********************************************************/
			if (debug) {
				FileOutputStream fos;
				try {
					fos = new FileOutputStream(new File(DEBUG_LOG_LOC
							+ "SocketException"));
					PrintStream ps = new PrintStream(fos);
					io.printStackTrace(ps);
					// return;
				} catch (FileNotFoundException e) {
					// Do nothing
					e.printStackTrace();
				}
			}
			/********************************************************/
			// throw message broker user exception
			MbException(io);
		} catch (IOException io) {
			/********************************************************/
			if (debug) {
				FileOutputStream fos;
				try {
					fos = new FileOutputStream(new File(DEBUG_LOG_LOC
							+ "IOException"));
					PrintStream ps = new PrintStream(fos);
					io.printStackTrace(ps);
					// return;
				} catch (FileNotFoundException e) {
					// Do nothing
					e.printStackTrace();
				}
			}
			/********************************************************/
			// throw message broker user exception
			MbException(io);
		} finally {

			if (client.isConnected())
				try {
					client.disconnect();
				} catch (IOException e) {
					// Do Nothing
					e.printStackTrace();
				}
			if (bs != null)
				try {
					bs.close();
				} catch (IOException e) {
					// Do Nothing
					e.printStackTrace();
				}
			if (os != null)
				try {
					os.flush();
					os.close();
				} catch (IOException e) {
					// Do Nothing
					e.printStackTrace();
				}

			/********************************************************/

			// clear the outMessage even if there's an exception
			outMessage.clearMessage();
		}

	}

	public void copyMessageHeaders(MbMessage inMessage, MbMessage outMessage)
			throws MbException {
		MbElement outRoot = outMessage.getRootElement();

		// iterate though the headers starting with the first child of the root
		// element
		MbElement header = inMessage.getRootElement().getFirstChild();
		while (header != null && header.getNextSibling() != null) // stop before
		// the last
		// child
		// (body)
		{
			// copy the header and add it to the out message
			outRoot.addAsLastChild(header.copy());
			// move along to next header
			header = header.getNextSibling();
		}
	}

	private void MbException(IOException io) throws MbUserException {

		// wrap Exception 'eIO' in MbUserException 'mbeio' (BIPERROR)
		String className = "Unknown";
		String methodName = "Unknown";

		// find class/method name, from exception stack
		if (io.getStackTrace().length > 0) {
			className = io.getStackTrace()[0].getClassName();
			methodName = io.getStackTrace()[0].getMethodName();
		}

		// extract detail message and backtrace from exception, for inserts
		final StringWriter text = new StringWriter();
		final PrintWriter pw = new PrintWriter(text);
		io.printStackTrace(pw);
		pw.close();

		// populate message inserts, specific to User Exception XXXX
		final Object[] inserts = new String[] { text.toString(), this.getName() };

		final MbUserException mbeio = new MbUserException(className,
				methodName, "BIPmsgs", "ERROR_CODE_TBC", io.getMessage(),
				inserts);

		// optionally, set e as the cause of mbue
		mbeio.initCause(io);

		throw mbeio;

	}

	private Exception MbException(String e) throws MbUserException {

		// wrap Exception 'e' in MbUserException 'mbe' (BIPERROR)
		String className = "FTPClient";
		//String methodName = "SI_0086";
		String methodName = FTP_EXCEPTION_CODE;
		
		final MbUserException mbe = new MbUserException(className, methodName,
				"BIPmsgs", "ERROR_CODE_TBC", e, null);

		throw mbe;
	}

	public boolean sendFromFileSystem(String sourceFileDirectory, String localFileName, String targetFileName, FTPClient client, InputStream is, OutputStream os) throws IOException, MbUserException {
		{
			String inFilePath = sourceFileDirectory + File.separator + localFileName;

			// If the data connection cannot be opened (e.g., the file does not
			// exist), null is returned (in which case you may check the reply
			// code to determine the exact reason for failure).
			if (OVERWRITE_FILE) {
				os = client.storeFileStream(targetFileName);
			} else {
				os = client.appendFileStream(targetFileName);
			}
			int replyCode = client.getReplyCode();
			if (os == null) {
				MbException(String.format("file transfer to remote location failed. FTPClient reply code %d , reply string %s ", replyCode, client.getReplyString()));
			}

			is = new FileInputStream(inFilePath);
			BufferedReader reader = new BufferedReader(new FileReader(new File(inFilePath)));
			byte[] byteBlock = new byte[BLKSIZ];
			int blockLength;

			while ((blockLength = is.read(byteBlock)) > 0) {
				os.write(byteBlock, 0, blockLength);
			}

			// os.finish();
			os.flush();
			// is.reset();

			// close streams
			reader.close();
			is.close();
			os.close();

			// complete pending actions
			boolean filePutResponse = client.completePendingCommand();
			return filePutResponse;

		}
	}
	
	public void onInitialize() throws MbException {
		// The user defined external attributes.
		FTP_HOST = (String) getUserDefinedAttribute("FTPHost");
		FTP_USER_NAME = (String) getUserDefinedAttribute("FTPUserName");
		FTP_PWORD = (String) getUserDefinedAttribute("FTPPword");
		WORKING_DIR = (String) getUserDefinedAttribute("RemoteDirectory");
		DEBUG_LOG_LOC = (String) getUserDefinedAttribute("DebugLogLocation");
		SITE_COMMAND = (String) getUserDefinedAttribute("SiteCommand");
		FTP_EXCEPTION_CODE = (String) getUserDefinedAttribute("FTPExceptionCode");
		OVERWRITE_FILE = (Boolean) getUserDefinedAttribute("OverwriteRemoteFile");
		TRANSFER_MODE_ASCII = (Boolean) getUserDefinedAttribute("TransferModeASCII");
	}

}