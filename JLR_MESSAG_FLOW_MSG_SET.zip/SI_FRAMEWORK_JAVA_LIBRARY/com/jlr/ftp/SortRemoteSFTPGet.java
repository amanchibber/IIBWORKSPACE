//Author: Amith Sannagowdar
/****
 * Description: This JCN performs following actions:-
 * 1) Reads files (using SFTP) from remote directory (WORKING_DIR) and copies them to local directory (LOCAL_DIR_LOC). FILE_NAME_PATTERN specifies
 * 		the pattern of filenames to be fetched.
 * 2) An environment tree is created with list of sorted filenames. This list will be used by business service flow to fetch the files sorted by their filenames!
 * 		Environment.Variables.SortedFiles.Filename[]			-- Contains filenames
 * 		Environment.Variables.SortedFiles.FileReadTimeStamp		-- Contains timestamp of when the files were read
 * 	  As of now sorting is done using natural sort!
 * 
 * Prerequisites:-
 * - Availability of tree Environment.Variables in the input message
 * - Directory path must have directory separator at the end. Eg:- "/Test1/Test2/" and NOT "/Test1/Test2"
 */

package com.jlr.ftp;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Vector;
import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.jcraft.jsch.ChannelSftp.LsEntry;

public class SortRemoteSFTPGet extends MbJavaComputeNode {
	
	// read the user-defined properties into static class variables
	private static String FTP_HOST = "";
	private static String FTP_USER_NAME = "";
	private static String FTP_PWORD = "";
	private static String WORKING_DIR = "";
	private static String LOCAL_DIR_LOC = "";
	private static String FILE_NAME_PATTERN = "";
	private static Boolean DELETE_SOURCE_FILE;
	private static String FTP_EXCEPTION_CODE = "";
	private static String DEBUG_LOG_LOC = "";
	// Debug options
	private boolean debug = false;
	
	public void onInitialize() throws MbException {
		// The user defined external attributes.
		FTP_HOST = (String) getUserDefinedAttribute("FTPHost");
		FTP_USER_NAME = (String) getUserDefinedAttribute("FTPUserName");
		FTP_PWORD = (String) getUserDefinedAttribute("FTPPword");
		WORKING_DIR = (String) getUserDefinedAttribute("WorkingDirectory");
		LOCAL_DIR_LOC = (String) getUserDefinedAttribute("LocalDirectoryLocation");
		FILE_NAME_PATTERN = (String) getUserDefinedAttribute("FileNamePattern");
		DELETE_SOURCE_FILE = (Boolean) getUserDefinedAttribute("DeleteSourceFile");
		FTP_EXCEPTION_CODE = (String) getUserDefinedAttribute("FTPExceptionCode");
		DEBUG_LOG_LOC = (String) getUserDefinedAttribute("DebugLogLocation");
	}	
	
	public void evaluate(MbMessageAssembly inAssembly) throws MbException 
	{
		
		MbOutputTerminal out = getOutputTerminal("out");
		//Gets to Environment.Variables. This assumes Environment.Variables path already exists!
		MbElement envVar = inAssembly.getGlobalEnvironment().getRootElement().getFirstElementByPath("Variables");
		
		JSch jsch = new JSch();
        Session session = null;
        Channel channel=null;
        ChannelSftp sftpChannel=null;
                
		try 
		{	
			/********************************************************/
			if (debug) {
				System.out.println("FTP Host Name is: " + FTP_HOST);
				System.out.println("FTP User Name is: " + FTP_USER_NAME);
				System.out.println("FTP Password is: " + FTP_PWORD);
				System.out.println("FTP Working Directory is: " + WORKING_DIR);
				System.out.println("FTP Local Directory is: " + LOCAL_DIR_LOC);
			}
			/********************************************************/
			
			//Establish session 
			session = jsch.getSession(FTP_USER_NAME,FTP_HOST, 22);
	        session.setConfig("StrictHostKeyChecking", "no");
	        session.setPassword(FTP_PWORD);
	        //Establish Connection to session
	        session.connect();
	        channel = session.openChannel("sftp");
	        channel.connect();
	        sftpChannel = (ChannelSftp) channel;	        

			if(channel.isConnected())
            {
				if (debug) 
					{
						System.out.println("Channel is Connected");					
					}

				//Array list to store the filenames
				ArrayList<String> list = new ArrayList<String>();
				//Go to working directory
				sftpChannel.cd(WORKING_DIR);
				//Fetch files by file name pattern
				Vector ls = sftpChannel.ls(FILE_NAME_PATTERN);
				Vector<LsEntry> entries = ls;

				//Loop through list of files
				for (LsEntry entry : entries) {
					list.add(entry.getFilename()); //Add filename to ArrayList
					sftpChannel.get(WORKING_DIR+entry.getFilename(),LOCAL_DIR_LOC+entry.getFilename()); //copy file from remote to local directory
					
					if (DELETE_SOURCE_FILE)
					{
						sftpChannel.rm(WORKING_DIR+entry.getFilename()); //Delete file at remote
					}
				}
				
				//Creates field Environment.Variables.FileReadTimeStamp
				envVar.createElementAsFirstChild(MbElement.TYPE_NAME_VALUE, "FileReadTimeStamp", new Timestamp(System.currentTimeMillis()).toString());
				//Creates field Environment.Variables.SortedFiles
				MbElement envVarSortedVIN = envVar.createElementAsFirstChild(MbElement.TYPE_NAME, "SortedFiles", "");
				
				Collections.sort(list);					//Sorts the ArrayList
				
				Iterator<String> itr = list.iterator();
				//Loop through the sorted list and assign it to the env tree
				while(itr.hasNext())
		        { //Add filename to Environment.Variables.SortedFiles.Filename[]
		          envVarSortedVIN.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "Filename", (String)itr.next());
		        }

            }
			
			else if (channel.isConnected() == false) {
				// login failed
				String e = "ERROR: Could not log in to server! " + "HOST: " + FTP_HOST + " User: " + FTP_USER_NAME;

				MbException(e);
			}
			/********************************************************/
	        // Exit the sftp Channel
	        sftpChannel.exit();
	        // Disconnect from the Session
	        session.disconnect();
			// Propagate message to the 'out' terminal
			out.propagate(inAssembly);
	
		}
		
		catch (JSchException e) {
			// login failed
			String ex = "ERROR: Could not log in to server! " + "HOST: " + FTP_HOST + " User: " + FTP_USER_NAME + e.getLocalizedMessage();
	
			MbException(ex);
			
	    } 
		
		catch (NullPointerException np) {
	
			/********************************************************/
			if (debug) {
				FileOutputStream fos;
				try {
					fos = new FileOutputStream(new File(DEBUG_LOG_LOC
							+ "NullPointerException"));
					PrintStream ps = new PrintStream(fos);
					np.printStackTrace(ps);
					// return;
				} catch (FileNotFoundException e) {
					// Do nothing
					e.printStackTrace();
				}
				
			}
			/********************************************************/
			MbException(np); // Call mbUserException with stackTrace

		} 
		
		catch (SftpException e) {
			e.printStackTrace();
			
			String getCause = "";
			if (e.getCause() != null) { getCause =  e.getCause().toString();}
			
			String ex = "ERROR: SFTP Failure! " + "HOST: " + FTP_HOST + " User: " + FTP_USER_NAME + e.getLocalizedMessage() + getCause;
			MbException(ex);			
		}

		// Final catch block to close all connections before exit
		finally {
			
			if (session.isConnected())
				try {
					session.disconnect();
					if (channel.isConnected())
						try {
							channel.disconnect();
						} catch (Exception e) {
							
							e.printStackTrace(); // Do Nothing
						}
					if (sftpChannel.isConnected())
						try {
							sftpChannel.exit();
						} catch (Exception e) {
							e.printStackTrace(); // Do Nothing
						}
				} catch (Exception e) {
					e.printStackTrace(); // Do Nothing
				}
		}

	}
	
	private Exception MbException(String e) throws MbUserException {

		// wrap Exception 'e' in MbUserException 'mbe' (BIPERROR)
		String className = "FTPClient";
		String methodName = "Connect";

		final MbUserException mbe = new MbUserException(className, methodName,
				"Exception Message", FTP_EXCEPTION_CODE, e, null);

		// optionally, set e as the cause of mbue
		// mbe.initCause(e);

		throw mbe;
	}
	
	private void MbException(NullPointerException np) throws MbUserException {

		// wrap Exception 'eIO' in MbUserException 'mbeio' (BIPERROR)
		String className = "FTPClient";
		String methodName = "NullPointer Exception";

		// find class/method name, from exception stack
		if (np.getStackTrace().length > 0) {
			className = np.getStackTrace()[0].getClassName();
			methodName = np.getStackTrace()[0].getMethodName();
		}

		// extract detail message and backtrace from exception, for inserts
		final StringWriter text = new StringWriter();
		final PrintWriter pw = new PrintWriter(text);
		np.printStackTrace(pw);
		pw.close();

		// populate message inserts, specific to User Exception XXXX
		final Object[] inserts = new String[] { text.toString(), this.getName() };

		final MbUserException mbenp = new MbUserException(className,
				methodName, "Exception Message", FTP_EXCEPTION_CODE, np.getMessage(),
				inserts);

		// optionally, set e as the cause of mbue
		mbenp.initCause(np);

		throw mbenp;

	}
}

