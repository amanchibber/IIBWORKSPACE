package com.jlr.misc;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;

public class FileOperations {

	/**
	 * This method deletes all the files in the given folder name that matches the name pattern.
	 * The method does not recursively delete files in the sub-directories. If a file is locked and
	 * cannot be deleted, then that file name is mentioned in the returned deleteSummary. Files which
	 * are successfully deleted are also returned in the "deleteSummary" string return variable.
	 * 
	 * @author Prasad Panchagnula
	 * 
	 * 
	 * @param directory (folder name)
	 * @param fileNameRegExp (File name using regular expression syntax)
	 * @return deleteSummary (contains 2 separate lists one for successfully deleted file list and another for files that are unable to get delete)
	 */
	
	public static String DeleteMatchedFiles(String directory, String fileNameRegExp) {
		StringBuilder deleteFailed = new StringBuilder();
		StringBuilder deleteSuccess = new StringBuilder();
		String deleteSummary = "";
		
		try
		{
			if ((directory != null) && (fileNameRegExp != null))
			{
				File folder = new File(directory);
		
				File[] files = folder.listFiles();
		
				for (File file : files) {
		
					if (file.getName().matches(fileNameRegExp)) {
		
						if (!file.delete()) {
							if (!(deleteFailed.length() > 1))
								deleteFailed = new StringBuilder(
										"ERROR:Unable to delete the following files in directory - ["
												+ directory + "]. List of files are: ");
							deleteFailed.append("\n    " + file.getName());
						} else {
							if (!(deleteSuccess.length() > 1))
								deleteSuccess = new StringBuilder(
										"SUCCESS: Successfully deleted the following files in directory - ["
												+ directory + "]. List of files are: ");
		
							deleteSuccess.append("\n    " + file.getName());
						}
					}
				}
				deleteSummary = deleteFailed.toString() + "\n"
						+ deleteSuccess.toString();
		
				if (deleteSummary.length() < 3)
					deleteSummary = "ERROR: No matching file names found in directory - ["
							+ directory + "] and fileName pattern - [" + fileNameRegExp
							+ "]";
			}
			else
				deleteSummary = "ERROR: Nothing to delete as either directory or fileNameRegExp is null";
		}
		catch (Exception e)
		{
			// Return stack trace
			StringWriter sw = new StringWriter();
			e.printStackTrace(new PrintWriter(sw));
			return "ERROR:" + sw.toString();
		}
		return deleteSummary;
	}

}
