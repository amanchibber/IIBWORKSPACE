/* Author: Tejashree Ksheersagar
 * Ver	Date		CDSID		Description	
 * V1.0 21/09/2017 	tksheers 	Initial version. File can be updated to place different functions and procedures
 * V1.1 02/11/2017  abadal      Function to convert string to URLEncoder convertStringToURLEncode
 * */

package com.jlr.misc;
import java.io.UnsupportedEncodingException;

import java.net.URLEncoder;



public class GenericLibrary{

	/****
	 * Description: This function performs following actions:-
	 * 1) Reads character string
	 * 2) Store the string in integer variable which in turns converts string in decimal ASCII format
	 * 3) Returns decimal ASCII format value
	 * 
	 * Input Parameters:-
	 * 	character string of length 1
	 */
	public static Long convertToASCII(String inChar) {

		  long lnAscii =  inChar.charAt(0);
		 
		  return lnAscii;
	}
	
	/****
	 * Description: This function performs following actions:-
	 * @param1 is a String , this contains the string which needs to be URL Encoded
	 * @param2 is a String , this contains the Encoding value for example "UTF-8" 
	 * @return is a String , URLEncoded string is return from this function 
	 * @throws This can throw UnsupportedEncodingException via AssertionError  as user may pass encoding in @param2 which might not be supported by JRE
	 * 
	 * 
	 */
	public static String convertStringToURLEncode(String inChar, String inEncoding)  {

		  	String strURLEncode="";
		  	
			try {
				if (inChar.length()>0){
					strURLEncode = URLEncoder.encode(inChar, inEncoding);
				}
				else {
					strURLEncode=inChar;
				}
				strURLEncode = URLEncoder.encode(inChar, inEncoding);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new  AssertionError("Encoding="+inEncoding.toString()+" not supported,  StackTrace  =" +e.toString());
				
			}
			
		  

		  return strURLEncode ;
	}

	
}