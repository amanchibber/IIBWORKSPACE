/* Author: Amith Sannagowdar
 * Ver	Date		CDSID		Description	
 * V1.0 21/07/2017 	asannag2 	Initial version during design phase
 * 
 * */

/****
 * Description: This JCN performs following actions:-
 * 1) Reads the XML message from InputRoot.BLOB.BLOB.
 * 2) Applies XML Signature to the input XML message by reading security config from input Enviornment tree.
 * 3) Signed XML message will be sent as BLOB under OutputRoot.BLOB.BLOB
 * 
 * Input Parameters:-
 * 
 * Prerequisites:-
 * - Availability of XML message in InputRoot.BLOB.BLOB
 * - Availability of Security config in Environment/Variables/Security/Config/Data[1]
 */

package com.jlr.security;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.w3c.dom.Document;
import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbBLOB;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbRecoverableException;
//-- The Java XML Digital Signature API 
import javax.xml.crypto.dsig.*;
import javax.xml.crypto.dsig.keyinfo.*;
import javax.xml.crypto.dsig.spec.*;
import javax.xml.crypto.dsig.dom.*;
//--
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class ApplyXMLSignature extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly assembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		// MbOutputTerminal alt = getOutputTerminal("alternate");
		// MbOutputTerminal fail = getOutputTerminal("failure");

		MbMessage message = assembly.getMessage();
		MbElement inRoot = message.getRootElement(); //InputRoot

		String secEnforcementId = "";
		String currentSecActivity = "";
		
		try{
			//Get Security Config from Environment
			MbElement envRef	= assembly.getGlobalEnvironment().getRootElement(); //Environment
			MbElement secConfig	=	envRef.getFirstElementByPath("/Variables/Security/Config/Data");
			
			secEnforcementId 			= secConfig.getFirstElementByPath("ENFORCEMENT_ID").getValueAsString();
			currentSecActivity 			= secConfig.getFirstElementByPath("ACTIVITY").getValueAsString();
			String keyStoreFile			= secConfig.getFirstElementByPath("STORE_LOCATION").getValueAsString();
			String keyStorePassword		= secConfig.getFirstElementByPath("STORE_PASS").getValueAsString();
			String keyAlias				= secConfig.getFirstElementByPath("KEY_ALIAS").getValueAsString();
			String keyPassword			= secConfig.getFirstElementByPath("KEY_PASS").getValueAsString();
			
			byte[] blobIVI = (byte[]) inRoot.getLastChild().getLastChild().getValue();
			InputStream myInputStream = new ByteArrayInputStream(blobIVI); 
			
			// Create a DOM XMLSignatureFactory that will be used to generate the enveloped signature.
			XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM");
			
			// Create a Reference to the enveloped document
			Reference ref = fac.newReference
			("", fac.newDigestMethod(DigestMethod.SHA1, null),
			  Collections.singletonList
			    (fac.newTransform(Transform.ENVELOPED,
			      (TransformParameterSpec) null)), null, null);
			
			// Create the SignedInfo
			SignedInfo si = fac.newSignedInfo
			(fac.newCanonicalizationMethod
			  (CanonicalizationMethod.EXCLUSIVE,
			    (C14NMethodParameterSpec) null),
			  fac.newSignatureMethod(SignatureMethod.RSA_SHA1, null),
			  Collections.singletonList(ref));
			
			// Load the KeyStore and get the signing key and certificate.
			KeyStore ks = KeyStore.getInstance("JKS");
			ks.load(new FileInputStream(keyStoreFile), keyStorePassword.toCharArray());
			KeyStore.PrivateKeyEntry keyEntry =
			    (KeyStore.PrivateKeyEntry) ks.getEntry
			        (keyAlias, new KeyStore.PasswordProtection(keyPassword.toCharArray()));
			// if keyEntry is null then throw exception here
			if (keyEntry == null){
				throw new Exception("Key couldn't be retrieved for label = " +  keyAlias + "; from keystore = " + keyStoreFile + "; for ENFORCEMENT_ID = " + secEnforcementId + ".");
			}
			
		    X509Certificate cert = (X509Certificate) keyEntry.getCertificate();
		    
		    // Create the KeyInfo containing the X509Data
		    KeyInfoFactory kif = fac.getKeyInfoFactory();
		    List x509Content = new ArrayList();
		    x509Content.add(cert);
		    X509Data xd = kif.newX509Data(x509Content);
		    KeyInfo ki = kif.newKeyInfo(Collections.singletonList(xd));
			
		    // Instantiate the document to be signed
		    DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		    Document doc = db.parse(myInputStream);
		    DOMSignContext dsc = new DOMSignContext (keyEntry.getPrivateKey(), doc.getDocumentElement());
		    // Create the XMLSignature 
		    XMLSignature signature = fac.newXMLSignature(si, ki);
		    //sign the enveloped signature
		    signature.sign(dsc);
		    
		    // Convert a W3C DOM into OutputStream 
		    ByteArrayOutputStream baos = new ByteArrayOutputStream();
		    TransformerFactory tf = TransformerFactory.newInstance();
		    Transformer trans = tf.newTransformer();
		    trans.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
		    trans.transform(new DOMSource(doc), new StreamResult(baos)); 
		     
		    // create new message OutputRoot.BLOB.BLOB
			MbMessage outMessage = new MbMessage(); 
			MbElement outputRoot = outMessage.getRootElement(); 
			MbElement outputBody = outputRoot.createElementAsLastChild(MbBLOB.PARSER_NAME);
			outputBody.createElementAsFirstChild(MbElement.TYPE_NAME_VALUE, "BLOB", baos.toByteArray());
			
			// Create output  message
			MbMessageAssembly outAssembly = new MbMessageAssembly(assembly, outMessage); 
			
			out.propagate(outAssembly);

		}catch(Exception e){
			// Catch any Exception and throw MbRecoverableException
			throw new MbRecoverableException("Class: ApplyXMLSignature", 
											 "Method: evaluate", 
											 message.getRootElement().getName(),
											 "",
											 "Exception while processing Enforcement Id: " + secEnforcementId + " for the activity: " + currentSecActivity + ". Exception message is: " + e.toString(),
											 null);
		}


	}

}
